# R1zz Client — Minecraft Java 1.21

Fabric client-side project starter with a purple/black ClickGUI, a module registry, persistent local configuration, and functional FPS/coordinates HUD toggles.

## Controls
- Right Shift: open/close ClickGUI.
- Click a category to switch panels.
- Click a module to toggle it.
- Drag the top bar to move the GUI.

## Build
Requires JDK 21 and Gradle. This archive does not include the Gradle wrapper JAR.
Run `gradle build` from the project directory (or generate a wrapper using `gradle wrapper` first).
Output: `build/libs/`.

Install the resulting JAR and Fabric API in the Minecraft Java 1.21 Fabric `mods` folder.

This project includes legitimate client-side UI/HUD and practice foundations. It does not include automated combat cheats or anti-cheat bypass/evasion features.

## Logo
The supplied image is bundled as `assets/r1zzclient/textures/gui/r1zz_logo.png` and displayed in the ClickGUI header.

## Current functionality and limits
- FPS and coordinates HUD modules draw their values when enabled.
- Module enable states and key-code values are persisted to `config/r1zz-client.properties`.
- Other registered modules are scaffolding for future implementation; they are not yet full gameplay features.
- This project does not implement anti-cheat bypass or evasion.

## HUD modules implemented
- `R1zzFPS`: live FPS counter.
- `R1zzCoordinates`: live XYZ coordinates.
- `R1zzKeystrokes`: live WASD and jump display.
- `R1zzCrosshair`: purple custom crosshair overlay.
- `R1zzTargetHUD`: information and health bar for the entity under the crosshair.

These are client-side visual features. Automated combat and anti-cheat evasion are not included.

## Build automatically with GitHub Actions
1. Create a new GitHub repository.
2. Upload/extract all source-project files into the repository root (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and run **Build R1zz Client** (or push to `main`/`master`).
4. When the workflow finishes, open its run and download the `r1zz-client-1.21-jar` artifact. The artifact contains the built JAR(s).

GitHub Actions compiles the source; this ZIP itself is not a Minecraft mod JAR.
