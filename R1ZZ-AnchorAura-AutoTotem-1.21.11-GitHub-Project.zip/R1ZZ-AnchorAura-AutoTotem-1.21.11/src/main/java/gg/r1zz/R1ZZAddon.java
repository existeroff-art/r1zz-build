package gg.r1zz;

import gg.r1zz.modules.R1ZZCombatToggle;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;

public final class R1ZZAddon extends MeteorAddon {
    @Override
    public void onInitialize() {
        Modules.get().add(new R1ZZCombatToggle());
    }

    @Override
    public String getPackage() {
        return "gg.r1zz";
    }
}
