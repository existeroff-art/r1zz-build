package gg.r1zz.modules;

import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.AnchorAura;
import meteordevelopment.meteorclient.systems.modules.combat.AutoTotem;

/**
 * Convenience toggle for Meteor's own Anchor Aura and Auto Totem modules.
 * The actual combat logic remains in Meteor Client, avoiding duplicated or
 * version-fragile implementations in this small addon.
 */
public final class R1ZZCombatToggle extends Module {
    private boolean enabledAnchorAura;
    private boolean enabledAutoTotem;

    public R1ZZCombatToggle() {
        super(Categories.Combat, "r1zz-combat", "Toggles Meteor Anchor Aura and Auto Totem together.");
    }

    @Override
    public void onActivate() {
        AnchorAura anchorAura = Modules.get().get(AnchorAura.class);
        AutoTotem autoTotem = Modules.get().get(AutoTotem.class);

        enabledAnchorAura = anchorAura != null && !anchorAura.isActive();
        enabledAutoTotem = autoTotem != null && !autoTotem.isActive();

        if (anchorAura != null) anchorAura.enable();
        if (autoTotem != null) autoTotem.enable();
    }

    @Override
    public void onDeactivate() {
        AnchorAura anchorAura = Modules.get().get(AnchorAura.class);
        AutoTotem autoTotem = Modules.get().get(AutoTotem.class);

        // Only disable modules that this toggle enabled. If they were already
        // enabled before R1ZZ Combat was pressed, leave them enabled.
        if (enabledAnchorAura && anchorAura != null) anchorAura.disable();
        if (enabledAutoTotem && autoTotem != null) autoTotem.disable();

        enabledAnchorAura = false;
        enabledAutoTotem = false;
    }
}
