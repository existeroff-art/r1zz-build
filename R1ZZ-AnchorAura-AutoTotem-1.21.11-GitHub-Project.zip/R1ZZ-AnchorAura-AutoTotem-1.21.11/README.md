# R1ZZ Anchor Aura + Auto Totem (Minecraft 1.21.11)

This is a **Meteor Client addon** for Fabric 1.21.11. It adds one module named **R1ZZ Combat**. Turning it on enables Meteor's built-in **Anchor Aura** and **Auto Totem** together; turning it off disables only the modules that R1ZZ Combat enabled.

> **BananaSMP warning:** BananaSMP's published network rules prohibit hacked clients and mods that give unfair advantages. Do not use this addon on BananaSMP. This project is intended only for single-player or servers whose staff explicitly permit these features. It contains no anti-cheat bypass and cannot make use undetectable or ban-safe.

The actual Anchor Aura and Auto Totem combat code is provided by Meteor Client, which must be installed separately. This project intentionally does not copy or fork Meteor's internal combat implementation.

## What you get

- `R1ZZ Combat`: one toggle/keybind to enable Anchor Aura and Auto Totem together.
- Meteor's built-in `Anchor Aura`: target range, placement/charge/break delay, damage thresholds and anti-suicide settings.
- Meteor's built-in `Auto Totem`: `Strict` or `Smart` mode and tick delay settings. `Strict` keeps a totem in the offhand whenever one is available; a delay of `0` is the fastest setting.
- Meteor's built-in Friends list: Anchor Aura's target selection respects Meteor's friend filtering. Add friends through Meteor's Friends UI or its `.friend` command.

## Requirements

- Minecraft Java Edition 1.21.11
- Fabric Loader 0.18.2 or newer
- Java 21
- Meteor Client build for Minecraft 1.21.11

BlackOut is not required for these two modules. Meteor already supplies Anchor Aura and Auto Totem.

## Build with GitHub Actions from a phone

1. Download this ZIP and extract it on your phone.
2. In your browser, sign in at <https://github.com>.
3. Open <https://github.com/new>.
4. Set repository name to `R1ZZ-AnchorAura-AutoTotem` and create the repository.
5. In the new repository, select **Add file → Upload files**.
6. Select and upload the contents of the extracted project folder. The upload must include `build.gradle`, `gradle.properties`, `settings.gradle`, `src/`, and `.github/workflows/build.yml`.
7. If your file picker hides dot-folders, enable **Show hidden files** so `.github` is included. Alternatively, create `.github/workflows/build.yml` directly in GitHub using the workflow content from this ZIP.
8. Tap **Commit changes**.
9. Open the repository's **Actions** tab.
10. Select **Build R1ZZ Anchor Aura + Auto Totem**.
11. Tap **Run workflow**, then confirm with **Run workflow**.
12. Open the finished run. Under **Artifacts**, download `R1ZZ-AnchorAura-AutoTotem-1.21.11`.
13. Extract the downloaded artifact ZIP. The compiled `.jar` is inside `build/libs/`.
14. Put that JAR in the same `mods` folder as Meteor Client and launch Fabric 1.21.11.

The workflow also runs automatically whenever you push a commit to the `main` branch.

## In-game setup

1. Open Meteor GUI with Right Shift.
2. Under Combat, find `R1ZZ Combat`. Set its keybind in the module's keybind control.
3. You can also configure Meteor's own `Anchor Aura` and `Auto Totem` modules separately.
4. For Auto Totem, choose `Strict` if you want the totem kept in the offhand continuously; set `delay` to `0` for the fastest swap cadence.
5. For Anchor Aura, tune `target-range`, `place-range`, `min-damage`, `max-self-damage`, `anti-suicide`, and the place/charge/break delays.
6. Add allies to Meteor's Friends list. Anchor Aura's target selection uses Meteor's friend-aware target filter, so friends should not be selected as attack targets.

## Important limits

A successful GitHub build only means the source compiled. This JAR has not been verified in a live 1.21.11 game session. It does not guarantee that any server will allow the modules or that the account cannot be banned. Server rules and anti-cheat systems control that; use settings permitted by the server.
