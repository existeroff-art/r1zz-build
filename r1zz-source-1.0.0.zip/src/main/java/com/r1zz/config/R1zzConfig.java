package com.r1zz.config;

import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Properties;
import java.util.Set;

public final class R1zzConfig {
    private static final Properties VALUES = new Properties();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("r1zz.properties");
    private static boolean dirty;
    private R1zzConfig() {}

    public static synchronized void load() {
        try { Files.createDirectories(FILE.getParent()); if (Files.exists(FILE)) try (InputStream in = Files.newInputStream(FILE)) { VALUES.load(in); } writeJvmArgsIfMissing(); }
        catch (IOException e) { System.err.println("[R1zz] Config load failed: " + e.getMessage()); }
    }
    public static synchronized void reload() { VALUES.clear(); dirty = false; load(); }
    private static void writeJvmArgsIfMissing() throws IOException {
        Path p = FILE.getParent().resolve("r1zz_jvm_args.txt"); if (Files.exists(p)) return;
        String content = """
                -Xms4G -Xmx4G
                -XX:+UseG1GC
                -XX:+ParallelRefProcEnabled
                -XX:MaxGCPauseMillis=15
                -XX:+UnlockExperimentalVMOptions
                -XX:+DisableExplicitGC
                -XX:+AlwaysPreTouch
                -XX:G1NewSizePercent=40
                -XX:G1MaxNewSizePercent=60
                -XX:G1HeapRegionSize=8M
                -XX:G1ReservePercent=10
                -XX:G1HeapWastePercent=5
                -XX:G1MixedGCCountTarget=8
                -XX:InitiatingHeapOccupancyPercent=20
                -XX:G1MixedGCLiveThresholdPercent=80
                -XX:G1RSetUpdatingPauseTimePercent=5
                -XX:SurvivorRatio=32
                -XX:MaxTenuringThreshold=1
                -XX:+UseStringDeduplication
                -XX:+PerfDisableSharedMem
                -XX:+UseNUMA
                -XX:+UseFastUnorderedTimeStamps
                -Dsun.rmi.dgc.server.gcInterval=2147483646
                -Dsun.rmi.dgc.client.gcInterval=2147483646
                """;
        Files.writeString(p, content, StandardCharsets.UTF_8);
    }
    public static synchronized String get(String key, String fallback) { return VALUES.getProperty(key, fallback); }
    public static synchronized boolean getBoolean(String key, boolean fallback) { return Boolean.parseBoolean(VALUES.getProperty(key, Boolean.toString(fallback))); }
    public static synchronized double getDouble(String key, double fallback) { try { return Double.parseDouble(VALUES.getProperty(key, Double.toString(fallback))); } catch (RuntimeException ignored) { return fallback; } }
    public static synchronized int getInt(String key, int fallback) { try { return Integer.parseInt(VALUES.getProperty(key, Integer.toString(fallback))); } catch (RuntimeException ignored) { return fallback; } }
    public static synchronized void put(String key, Object value) { VALUES.setProperty(key, String.valueOf(value)); dirty = true; }
    public static synchronized Set<String> friends() {
        Set<String> set = new LinkedHashSet<>();
        for (String name : VALUES.getProperty("friends", "").split(",")) if (!name.isBlank()) set.add(name.trim());
        return set;
    }
    public static synchronized void addFriend(String name) { if (name == null || name.isBlank()) return; Set<String> f = friends(); f.add(name.trim()); VALUES.setProperty("friends", String.join(",", f)); dirty = true; save(); }
    public static synchronized void removeFriend(String name) { Set<String> f = friends(); f.removeIf(n -> n.equalsIgnoreCase(name)); VALUES.setProperty("friends", String.join(",", f)); dirty = true; save(); }
    public static synchronized boolean isFriend(String name) { return friends().stream().anyMatch(n -> n.equalsIgnoreCase(name)); }
    public static synchronized void save() {
        try { Files.createDirectories(FILE.getParent()); try (OutputStream out = Files.newOutputStream(FILE)) { VALUES.store(out, "R1zz client configuration"); } dirty = false; }
        catch (IOException e) { System.err.println("[R1zz] Config save failed: " + e.getMessage()); }
    }
    public static synchronized void saveIfDirty() { if (dirty) save(); }
}
