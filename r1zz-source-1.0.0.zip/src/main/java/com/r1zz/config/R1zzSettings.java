package com.r1zz.config;

import java.util.*;

/** Central persisted settings registry used by the R1zz ClickGUI and module runtime.
 * It intentionally lives outside Module so the Module base class remains unchanged. */
public final class R1zzSettings {
    public enum Type { SLIDER, DROPDOWN, TOGGLE, COLOR, TEXT, LIST }
    public static final class Setting {
        public final String moduleId, key, label; public final Type type; public final double min, max; public final String[] options;
        private Object value;
        Setting(String moduleId,String key,String label,Type type,Object def,double min,double max,String[] options){this.moduleId=moduleId;this.key=key;this.label=label;this.type=type;this.value=def;this.min=min;this.max=max;this.options=options;}
        public Object value(){return value;}
        public String fullKey(){return moduleId+'.'+key;}
        void load(){
            String k=fullKey();
            switch(type){
                case TOGGLE -> value=R1zzConfig.getBoolean(k,(Boolean)value);
                case SLIDER -> value=R1zzConfig.getDouble(k,((Number)value).doubleValue());
                case COLOR -> value=R1zzConfig.getInt(k,((Number)value).intValue());
                default -> value=R1zzConfig.get(k,String.valueOf(value));
            }
        }
        public void set(Object v){
            if(type==Type.TOGGLE)value=Boolean.parseBoolean(String.valueOf(v));
            else if(type==Type.SLIDER){double d;try{d=Double.parseDouble(String.valueOf(v));}catch(Exception e){return;}value=Math.max(min,Math.min(max,d));}
            else if(type==Type.COLOR){try{value=Integer.parseInt(String.valueOf(v));}catch(Exception e){return;}}
            else if(type==Type.DROPDOWN){String s=String.valueOf(v);for(String o:options)if(o.equals(s)){value=s;break;}}
            else value=String.valueOf(v);
            R1zzConfig.put(fullKey(),value);
        }
        public double number(){return ((Number)value).doubleValue();}
        public boolean bool(){return Boolean.TRUE.equals(value);}
        public String text(){return String.valueOf(value);}
    }
    private static final Map<String,List<Setting>> MAP=new LinkedHashMap<>();
    private R1zzSettings(){}
    public static synchronized void initialize(){ if(!MAP.isEmpty()) return;
        group("r1zz_assist");
        add("r1zz_assist","target_players","Players",Type.TOGGLE,true,0,1,new String[0]);
        add("r1zz_assist","target_mobs","Mobs",Type.TOGGLE,true,0,1,new String[0]);
        add("r1zz_assist","target_animals","Animals",Type.TOGGLE,true,0,1,new String[0]);
        add("r1zz_assist","target_crystal","Crystal",Type.TOGGLE,false,0,1,new String[0]);
        add("r1zz_assist","hit_mode","Hit mode",Type.DROPDOWN,"Prioritize crits",0,1,new String[]{"Prioritize crits","Prioritize damage","Normal"});
        add("r1zz_assist","reach","Reach",Type.DROPDOWN,"Default",0,1,new String[]{"Default","3.0","3.5","4.0"});
        add("r1zz_assist","miss_chance","Miss chance",Type.SLIDER,0.0,0,50,new String[0]);
        add("r1zz_assist","when_use_hand","When use hand",Type.TOGGLE,false,0,1,new String[0]);
        add("r1zz_assist","simulate_clicks","Simulate clicks",Type.TOGGLE,false,0,1,new String[0]);
        add("r1zz_assist","only_weapon","Only weapon",Type.TOGGLE,true,0,1,new String[0]);
        add("r1zz_assist","mode","Mode",Type.DROPDOWN,"Server cooldown",0,1,new String[]{"Server cooldown","Vanilla cooldown","Custom"});
        add("r1zz_assist","cooldown","Cooldown",Type.SLIDER,80.1,0,100,new String[0]);
        add("r1zz_assist","delay","Attack delay (ms)",Type.SLIDER,80,0,500,new String[0]);
        group("kill_aura");
        add("kill_aura","range","Range",Type.SLIDER,3.0,2.5,6,new String[0]);
        add("kill_aura","cps","CPS",Type.SLIDER,8,1,20,new String[0]);
        add("kill_aura","rotation","Rotation",Type.DROPDOWN,"Smooth",0,1,new String[]{"None","Smooth","Snap","Lock"});
        add("kill_aura","target","Target",Type.DROPDOWN,"Players",0,1,new String[]{"Players","Entities","Both"});
        add("kill_aura","swing_only","Swing Only",Type.TOGGLE,false,0,1,new String[0]);
        add("kill_aura","auto_block","Auto Block",Type.TOGGLE,false,0,1,new String[0]);
        group("trigger_bot");
        add("trigger_bot","hit_mode","Hit mode",Type.DROPDOWN,"Prioritize crits",0,1,new String[]{"Prioritize crits","Prioritize damage","Normal"});
        add("trigger_bot","reach","Reach",Type.DROPDOWN,"Default",0,1,new String[]{"Default","3.0","3.5","4.0"});
        add("trigger_bot","miss_chance","Miss chance",Type.SLIDER,0,0,50,new String[0]);
        add("trigger_bot","delay","Delay (ms)",Type.SLIDER,80,0,500,new String[0]);
        add("trigger_bot","when_use_hand","When use hand",Type.TOGGLE,false,0,1,new String[0]);
        add("trigger_bot","simulate_clicks","Simulate clicks",Type.TOGGLE,false,0,1,new String[0]);
        add("trigger_bot","only_weapon","Only weapon",Type.TOGGLE,true,0,1,new String[0]);
        add("trigger_bot","auto_block","Auto Block",Type.TOGGLE,false,0,1,new String[0]);
        group("reach");
        add("reach","reach","Reach",Type.SLIDER,3.5,3,6,new String[0]);
        add("reach","chance","Chance",Type.SLIDER,100,0,100,new String[0]);
        group("auto_clicker");
        add("auto_clicker","cps","CPS",Type.SLIDER,8,1,20,new String[0]);
        add("auto_clicker","hold","Hold",Type.TOGGLE,false,0,1,new String[0]);
        add("auto_clicker","only_on_target","Only on target",Type.TOGGLE,true,0,1,new String[0]);
        group("criticals");
        add("criticals","mode","Mode",Type.DROPDOWN,"Jump",0,1,new String[]{"Jump","Packet","Both"});
        add("criticals","chance","Chance",Type.SLIDER,100,0,100,new String[0]);
        group("wtap");
        add("wtap","chance","Chance",Type.SLIDER,100,0,100,new String[0]);
        add("wtap","delay","Delay (ms)",Type.SLIDER,50,0,200,new String[0]);
        group("stap");
        add("stap","chance","Chance",Type.SLIDER,100,0,100,new String[0]);
        add("stap","delay","Delay (ms)",Type.SLIDER,50,0,200,new String[0]);
        group("auto_block");
        add("auto_block","delay","Delay (ms)",Type.SLIDER,50,0,200,new String[0]);
        add("auto_block","only_on_weapon","Only on weapon",Type.TOGGLE,true,0,1,new String[0]);
        group("auto_weapon");
        add("auto_weapon","mode","Mode",Type.DROPDOWN,"Best",0,1,new String[]{"Best","Prefer Sword","Prefer Axe"});
        add("auto_weapon","revert_delay","Revert delay (ms)",Type.SLIDER,200,0,500,new String[0]);
        group("auto_tool");
        add("auto_tool","mode","Mode",Type.DROPDOWN,"Best",0,1,new String[]{"Best","Prefer Speed","Prefer Durability"});
        add("auto_tool","delay","Delay (ticks)",Type.SLIDER,2,1,5,new String[0]);
        group("auto_pot");
        add("auto_pot","hp_threshold","HP threshold",Type.SLIDER,10,1,20,new String[0]);
        add("auto_pot","potion_type","Potion type",Type.DROPDOWN,"Healing",0,1,new String[]{"Healing","Regeneration","Both"});
        add("auto_pot","delay","Delay (ms)",Type.SLIDER,200,0,500,new String[0]);
        add("auto_pot","only_in_combat","Only in combat",Type.TOGGLE,true,0,1,new String[0]);
        group("shield_breaker");
        add("shield_breaker","cooldown","Cooldown (ms)",Type.SLIDER,150,0,500,new String[0]);
        add("shield_breaker","swap","Swap",Type.TOGGLE,true,0,1,new String[0]);
        group("backtrack");
        add("backtrack","delay","Delay (ms)",Type.SLIDER,200,0,500,new String[0]);
        group("no_hit_delay");
        group("sprint");
        add("sprint","mode","Mode",Type.DROPDOWN,"Legit",0,1,new String[]{"Legit","Omni","AutoJump"});
        add("sprint","food_check","Food check",Type.TOGGLE,true,0,1,new String[0]);
        group("step");
        add("step","height","Height",Type.SLIDER,1.0,0.5,2.5,new String[0]);
        add("step","only_on_ground","Only on ground",Type.TOGGLE,true,0,1,new String[0]);
        group("no_fall");
        add("no_fall","mode","Mode",Type.DROPDOWN,"Packet",0,1,new String[]{"Packet","Ground","NoFall+"});
        add("no_fall","only_when_falling","Only when falling",Type.TOGGLE,true,0,1,new String[0]);
        group("velocity");
        add("velocity","horizontal","Horizontal",Type.SLIDER,0,0,100,new String[0]);
        add("velocity","vertical","Vertical",Type.SLIDER,0,0,100,new String[0]);
        add("velocity","explosion","Explosion",Type.TOGGLE,true,0,1,new String[0]);
        add("velocity","push","Push",Type.TOGGLE,true,0,1,new String[0]);
        group("speed");
        add("speed","mode","Mode",Type.DROPDOWN,"Vanilla",0,1,new String[]{"Vanilla","Strafe","YPort","Ground"});
        add("speed","multiplier","Multiplier",Type.SLIDER,1.15,1,1.5,new String[0]);
        group("fly");
        add("fly","speed","Speed",Type.SLIDER,1,0.5,5,new String[0]);
        add("fly","mode","Mode",Type.DROPDOWN,"Vanilla",0,1,new String[]{"Vanilla","Packet","Creative"});
        add("fly","anti_kick","Anti-kick",Type.TOGGLE,true,0,1,new String[0]);
        group("spider");
        add("spider","mode","Mode",Type.DROPDOWN,"Vanilla",0,1,new String[]{"Vanilla","Slow"});
        add("spider","only_on_wall","Only on wall",Type.TOGGLE,true,0,1,new String[0]);
        group("jesus");
        add("jesus","mode","Mode",Type.DROPDOWN,"Solid",0,1,new String[]{"Solid","Dolphin"});
        add("jesus","speed","Speed",Type.SLIDER,1,0.5,2,new String[0]);
        group("no_slow");
        add("no_slow","mode","Mode",Type.DROPDOWN,"Vanilla",0,1,new String[]{"Vanilla","NCP","Grim"});
        add("no_slow","food","Food",Type.TOGGLE,true,0,1,new String[0]);
        add("no_slow","sword","Sword",Type.TOGGLE,true,0,1,new String[0]);
        add("no_slow","bow","Bow",Type.TOGGLE,true,0,1,new String[0]);
        add("no_slow","potion","Potion",Type.TOGGLE,true,0,1,new String[0]);
        group("long_jump");
        add("long_jump","multiplier","Multiplier",Type.SLIDER,2,1,5,new String[0]);
        add("long_jump","auto_jump","AutoJump",Type.TOGGLE,true,0,1,new String[0]);
        group("scaffold");
        add("scaffold","delay","Delay (ticks)",Type.SLIDER,3,1,5,new String[0]);
        add("scaffold","rotation","Rotation",Type.DROPDOWN,"Smooth",0,1,new String[]{"Smooth","Snap","Static"});
        add("scaffold","sprint","Sprint",Type.TOGGLE,true,0,1,new String[0]);
        add("scaffold","safe_walk","Safe walk",Type.TOGGLE,true,0,1,new String[0]);
        group("anti_void");
        add("anti_void","mode","Mode",Type.DROPDOWN,"Teleport",0,1,new String[]{"Teleport","Jump","Both"});
        add("anti_void","delay","Delay (ms)",Type.SLIDER,500,0,2000,new String[0]);
        group("elytra_fly");
        add("elytra_fly","speed","Speed",Type.SLIDER,1.5,0.5,3,new String[0]);
        add("elytra_fly","mode","Mode",Type.DROPDOWN,"Vanilla",0,1,new String[]{"Vanilla","Packet","Boost"});
        group("packet_fly");
        add("packet_fly","speed","Speed",Type.SLIDER,1,0.5,2,new String[0]);
        add("packet_fly","mode","Mode",Type.DROPDOWN,"Slow",0,1,new String[]{"Slow","Fast","Anti-kick"});
        group("phase");
        add("phase","mode","Mode",Type.DROPDOWN,"Vanilla",0,1,new String[]{"Vanilla","NCP","Grim"});
        add("phase","speed","Speed",Type.SLIDER,1,0.5,2,new String[0]);
        group("no_clip");
        add("no_clip","speed","Speed",Type.SLIDER,1,0.5,2,new String[0]);
        group("esp");
        add("esp","targets","Targets",Type.DROPDOWN,"Players",0,1,new String[]{"Players","Mobs","Both"});
        add("esp","box","Box",Type.TOGGLE,true,0,1,new String[0]);
        add("esp","outline","Outline",Type.TOGGLE,true,0,1,new String[0]);
        add("esp","fill","Fill",Type.TOGGLE,false,0,1,new String[0]);
        add("esp","health","Health bar",Type.TOGGLE,true,0,1,new String[0]);
        add("esp","color","Color",Type.COLOR,16733525,0,1,new String[0]);
        add("esp","range","Range",Type.SLIDER,64,16,256,new String[0]);
        group("tracers");
        add("tracers","mode","Mode",Type.DROPDOWN,"Line",0,1,new String[]{"Line","Curve"});
        add("tracers","thickness","Thickness",Type.SLIDER,1,1,3,new String[0]);
        add("tracers","color","Color",Type.COLOR,16777215,0,1,new String[0]);
        add("tracers","range","Range",Type.SLIDER,64,16,256,new String[0]);
        group("nametags");
        add("nametags","scale","Scale",Type.SLIDER,1,0.5,2,new String[0]);
        add("nametags","background","Background",Type.TOGGLE,true,0,1,new String[0]);
        add("nametags","health","Health",Type.TOGGLE,true,0,1,new String[0]);
        add("nametags","distance","Distance",Type.TOGGLE,true,0,1,new String[0]);
        group("fullbright");
        add("fullbright","mode","Mode",Type.DROPDOWN,"Gamma",0,1,new String[]{"Gamma","Night Vision","Both"});
        add("fullbright","brightness","Brightness",Type.SLIDER,10,0.1,10,new String[0]);
        group("no_hurt_cam");
        group("freecam");
        add("freecam","speed","Speed",Type.SLIDER,1.5,0.5,5,new String[0]);
        group("zoom");
        add("zoom","factor","Factor",Type.SLIDER,4,2,10,new String[0]);
        add("zoom","smooth","Smooth",Type.TOGGLE,true,0,1,new String[0]);
        group("chams");
        add("chams","mode","Mode",Type.DROPDOWN,"Flat",0,1,new String[]{"Flat","Texture"});
        add("chams","color","Color",Type.COLOR,16711680,0,1,new String[0]);
        add("chams","range","Range",Type.SLIDER,64,16,256,new String[0]);
        group("storage_e_s_p");
        add("storage_e_s_p","chest","Chest",Type.TOGGLE,true,0,1,new String[0]);
        add("storage_e_s_p","barrel","Barrel",Type.TOGGLE,true,0,1,new String[0]);
        add("storage_e_s_p","shulker","Shulker",Type.TOGGLE,true,0,1,new String[0]);
        add("storage_e_s_p","ender","Ender",Type.TOGGLE,true,0,1,new String[0]);
        add("storage_e_s_p","hopper","Hopper",Type.TOGGLE,true,0,1,new String[0]);
        add("storage_e_s_p","color","Color",Type.COLOR,16776960,0,1,new String[0]);
        group("trajectory");
        add("trajectory","type","Type",Type.DROPDOWN,"All",0,1,new String[]{"Arrow","Pearl","All"});
        add("trajectory","line","Line",Type.TOGGLE,true,0,1,new String[0]);
        add("trajectory","impact_marker","Impact marker",Type.TOGGLE,true,0,1,new String[0]);
        group("hitboxes");
        add("hitboxes","range","Range",Type.SLIDER,5,1,10,new String[0]);
        add("hitboxes","color","Color",Type.COLOR,16711935,0,1,new String[0]);
        add("hitboxes","only_entities","Only entities",Type.TOGGLE,true,0,1,new String[0]);
        group("pop_chams");
        add("pop_chams","duration","Duration (ms)",Type.SLIDER,800,200,2000,new String[0]);
        add("pop_chams","color","Color",Type.COLOR,16711935,0,1,new String[0]);
        group("block_e_s_p");
        add("block_e_s_p","blocks","Block list",Type.LIST,"",0,1,new String[0]);
        add("block_e_s_p","color","Color",Type.COLOR,65535,0,1,new String[0]);
        add("block_e_s_p","range","Range",Type.SLIDER,64,16,256,new String[0]);
        group("search");
        add("search","blocks","Block list",Type.LIST,"",0,1,new String[0]);
        add("search","color","Color",Type.COLOR,16776960,0,1,new String[0]);
        add("search","range","Range",Type.SLIDER,64,16,256,new String[0]);
        group("logout_spots");
        add("logout_spots","color","Color",Type.COLOR,16733525,0,1,new String[0]);
        add("logout_spots","range","Range",Type.SLIDER,64,16,256,new String[0]);
        add("logout_spots","duration","Duration (ms)",Type.SLIDER,5000,500,30000,new String[0]);
        group("waypoints");
        add("waypoints","waypoints","Waypoints",Type.LIST,"",0,1,new String[0]);
        add("waypoints","color","Color",Type.COLOR,16777215,0,1,new String[0]);
        add("waypoints","line","Line",Type.TOGGLE,true,0,1,new String[0]);
        group("new_chunks");
        add("new_chunks","color","Color",Type.COLOR,65280,0,1,new String[0]);
        add("new_chunks","range","Range",Type.SLIDER,64,16,256,new String[0]);
        group("rocket_e_s_p");
        add("rocket_e_s_p","color","Color",Type.COLOR,16755200,0,1,new String[0]);
        add("rocket_e_s_p","only_self","Only self",Type.TOGGLE,true,0,1,new String[0]);
        group("no_render");
        add("no_render","fire","Fire",Type.TOGGLE,true,0,1,new String[0]);
        add("no_render","water","Water",Type.TOGGLE,true,0,1,new String[0]);
        add("no_render","lava","Lava",Type.TOGGLE,true,0,1,new String[0]);
        add("no_render","blocks","Blocks",Type.TOGGLE,false,0,1,new String[0]);
        add("no_render","entities","Entities",Type.TOGGLE,false,0,1,new String[0]);
        add("no_render","particles","Particles",Type.TOGGLE,false,0,1,new String[0]);
        add("no_render","armor","Armor",Type.TOGGLE,false,0,1,new String[0]);
        add("no_render","hurt_cam","Hurt Cam",Type.TOGGLE,false,0,1,new String[0]);
        add("no_render","blind","Blind",Type.TOGGLE,false,0,1,new String[0]);
        add("no_render","nausea","Nausea",Type.TOGGLE,false,0,1,new String[0]);
        add("no_render","totem_pop","Totem Pop",Type.TOGGLE,false,0,1,new String[0]);
        group("view_model");
        add("view_model","x","X",Type.SLIDER,0,-2,2,new String[0]);
        add("view_model","y","Y",Type.SLIDER,0,-2,2,new String[0]);
        add("view_model","z","Z",Type.SLIDER,0,-2,2,new String[0]);
        add("view_model","scale","Scale",Type.SLIDER,1,0.5,2,new String[0]);
        group("crosshair");
        add("crosshair","style","Style",Type.DROPDOWN,"Vanilla",0,1,new String[]{"Vanilla","Cross","Dot","Circle","T-Shape","Custom"});
        add("crosshair","color","Color",Type.COLOR,16777215,0,1,new String[0]);
        add("crosshair","size","Size",Type.SLIDER,10,4,20,new String[0]);
        add("crosshair","gap","Gap",Type.SLIDER,2,0,10,new String[0]);
        group("particle");
        add("particle","amount","Amount",Type.DROPDOWN,"All",0,1,new String[]{"All","Reduced","None","Custom"});
        add("particle","value","Value",Type.SLIDER,50,0,100,new String[0]);
        group("health_bar");
        add("health_bar","position","Position",Type.DROPDOWN,"Above",0,1,new String[]{"Above","Below"});
        add("health_bar","size","Size",Type.SLIDER,1,0.5,2,new String[0]);
        add("health_bar","color","Color",Type.COLOR,65280,0,1,new String[0]);
        group("armor_h_u_d");
        add("armor_h_u_d","position","Position",Type.DROPDOWN,"Left",0,1,new String[]{"Left","Right"});
        add("armor_h_u_d","style","Style",Type.DROPDOWN,"Vertical",0,1,new String[]{"Vertical","Horizontal"});
        add("armor_h_u_d","durability","Durability",Type.TOGGLE,true,0,1,new String[0]);
        group("potion_h_u_d");
        add("potion_h_u_d","position","Position",Type.DROPDOWN,"TopRight",0,1,new String[]{"TopLeft","TopRight","BottomLeft","BottomRight"});
        add("potion_h_u_d","scale","Scale",Type.SLIDER,1,0.5,2,new String[0]);
        add("potion_h_u_d","duration","Duration",Type.TOGGLE,true,0,1,new String[0]);
        group("watermark");
        add("watermark","text","Text",Type.TEXT,"R1zz",0,1,new String[0]);
        add("watermark","position","Position",Type.DROPDOWN,"TopLeft",0,1,new String[]{"TopLeft","TopRight","BottomLeft","BottomRight"});
        add("watermark","style","Style",Type.DROPDOWN,"Plain",0,1,new String[]{"Plain","Shadow","Gradient"});
        add("watermark","color","Color",Type.COLOR,16777215,0,1,new String[0]);
        group("auto_respawn");
        add("auto_respawn","delay","Delay (ms)",Type.SLIDER,50,0,500,new String[0]);
        add("auto_respawn","respawn_at_spawn","Respawn at spawn",Type.TOGGLE,true,0,1,new String[0]);
        group("fast_place");
        add("fast_place","delay","Delay (ticks)",Type.SLIDER,2,0,4,new String[0]);
        add("fast_place","only_blocks","Only blocks",Type.TOGGLE,true,0,1,new String[0]);
        group("no_rotate");
        add("no_rotate","mode","Mode",Type.DROPDOWN,"Vanilla",0,1,new String[]{"Vanilla","Packet"});
        add("no_rotate","set_back","Set back",Type.TOGGLE,true,0,1,new String[0]);
        group("auto_totem");
        add("auto_totem","hp_threshold","HP threshold",Type.SLIDER,5,1,20,new String[0]);
        add("auto_totem","delay","Delay (ms)",Type.SLIDER,100,0,500,new String[0]);
        add("auto_totem","health_potion","Health potion",Type.TOGGLE,true,0,1,new String[0]);
        group("auto_armor");
        add("auto_armor","delay","Delay (ms)",Type.SLIDER,200,0,500,new String[0]);
        add("auto_armor","only_when_idle","Only when idle",Type.TOGGLE,true,0,1,new String[0]);
        group("inv_manager");
        add("inv_manager","sort_mode","Sort mode",Type.DROPDOWN,"Type",0,1,new String[]{"Type","Name","Durability"});
        add("inv_manager","auto_trash","Auto trash",Type.TOGGLE,false,0,1,new String[0]);
        add("inv_manager","junk","Junk list",Type.LIST,"",0,1,new String[0]);
        group("chest_stealer");
        add("chest_stealer","delay","Delay (ms)",Type.SLIDER,50,0,500,new String[0]);
        add("chest_stealer","check_list","Check list",Type.LIST,"",0,1,new String[0]);
        add("chest_stealer","silent","Silent",Type.TOGGLE,true,0,1,new String[0]);
        group("auto_log");
        add("auto_log","hp_threshold","HP threshold",Type.SLIDER,6,1,20,new String[0]);
        add("auto_log","only_in_combat","Only in combat",Type.TOGGLE,true,0,1,new String[0]);
        add("auto_log","log_message","Log message",Type.TEXT,"Logging out",0,1,new String[0]);
        group("auto_heal");
        add("auto_heal","hp_threshold","HP threshold",Type.SLIDER,12,1,20,new String[0]);
        add("auto_heal","potion_type","Potion type",Type.DROPDOWN,"Healing",0,1,new String[]{"Healing","Regeneration","Both"});
        add("auto_heal","food","Food",Type.TOGGLE,true,0,1,new String[0]);
        group("auto_reconnect");
        add("auto_reconnect","delay","Delay (ms)",Type.SLIDER,3000,0,10000,new String[0]);
        add("auto_reconnect","delay_message","Delay message",Type.TEXT,"Reconnecting...",0,1,new String[0]);
        group("anti_hunger");
        add("anti_hunger","mode","Mode",Type.DROPDOWN,"NoSprint",0,1,new String[]{"NoSprint","NoJump","Both"});
        group("time_changer");
        add("time_changer","time","Time",Type.SLIDER,6000,0,24000,new String[0]);
        add("time_changer","static","Static",Type.TOGGLE,true,0,1,new String[0]);
        group("weather_changer");
        add("weather_changer","weather","Weather",Type.DROPDOWN,"Clear",0,1,new String[]{"Clear","Rain","Thunder"});
        group("nuker");
        add("nuker","radius","Radius",Type.SLIDER,3,1,6,new String[0]);
        add("nuker","target","Target",Type.DROPDOWN,"All",0,1,new String[]{"All","Ores","Specific"});
        add("nuker","blocks","Block list",Type.LIST,"",0,1,new String[0]);
        group("fast_break");
        add("fast_break","multiplier","Multiplier",Type.SLIDER,1.5,1,3,new String[0]);
        add("fast_break","only_blocks","Only blocks",Type.TOGGLE,true,0,1,new String[0]);
        group("no_break_delay");
        group("auto_mine");
        add("auto_mine","mode","Mode",Type.DROPDOWN,"Crosshair",0,1,new String[]{"Below","Crosshair","Specific"});
        add("auto_mine","blocks","Block list",Type.LIST,"",0,1,new String[0]);
        group("tunnel");
        add("tunnel","height","Height",Type.SLIDER,2,1,3,new String[0]);
        add("tunnel","width","Width",Type.SLIDER,1,1,3,new String[0]);
        add("tunnel","rotation","Rotation",Type.DROPDOWN,"Static",0,1,new String[]{"Smooth","Snap","Static"});
        group("auto_fish");
        add("auto_fish","delay","Delay (ms)",Type.SLIDER,100,0,500,new String[0]);
        add("auto_fish","catch_delay","Catch delay (ms)",Type.SLIDER,200,0,1000,new String[0]);
        group("auto_shear");
        add("auto_shear","range","Range",Type.SLIDER,3,1,4,new String[0]);
        add("auto_shear","delay","Delay (ms)",Type.SLIDER,100,0,500,new String[0]);
        group("auto_nametag");
        add("auto_nametag","name","Name",Type.TEXT,"R1zz",0,1,new String[0]);
        add("auto_nametag","range","Range",Type.SLIDER,3,1,4,new String[0]);
        group("anti_afk");
        add("anti_afk","mode","Mode",Type.DROPDOWN,"Legit",0,1,new String[]{"Legit","Blatant","Spin"});
        add("anti_afk","interval","Interval (ms)",Type.SLIDER,45000,10000,180000,new String[0]);
        group("chat_suffix");
        add("chat_suffix","text","Text",Type.TEXT," | R1zz",0,1,new String[0]);
        add("chat_suffix","only_when_visible","Only when visible",Type.TOGGLE,true,0,1,new String[0]);
        group("packet_logger");
        add("packet_logger","log_to_file","Log to file",Type.TOGGLE,false,0,1,new String[0]);
        add("packet_logger","filter","Filter",Type.TEXT,"",0,1,new String[0]);
        group("blink");
        add("blink","mode","Mode",Type.DROPDOWN,"Movement",0,1,new String[]{"Movement","Full","Send All"});
        add("blink","hold_time","Hold time (ms)",Type.SLIDER,500,0,5000,new String[0]);
        group("fake_lag");
        add("fake_lag","delay","Delay (ms)",Type.SLIDER,500,0,2000,new String[0]);
        add("fake_lag","only_in_combat","Only in combat",Type.TOGGLE,true,0,1,new String[0]);
        group("rainbow");
        add("rainbow","speed","Speed",Type.SLIDER,5,1,20,new String[0]);
        add("rainbow","saturation","Saturation",Type.SLIDER,100,0,100,new String[0]);
        group("notifications");
        add("notifications","position","Position",Type.DROPDOWN,"TopRight",0,1,new String[]{"TopLeft","TopRight","BottomLeft","BottomRight"});
        add("notifications","duration","Duration (ms)",Type.SLIDER,2000,1000,5000,new String[0]);
        add("notifications","sound","Sound",Type.TOGGLE,true,0,1,new String[0]);
        group("click_gui_sound");
        add("click_gui_sound","volume","Volume",Type.SLIDER,50,0,100,new String[0]);
        group("macro");
        add("macro","name","Name",Type.TEXT,"Macro",0,1,new String[0]);
        add("macro","actions","Actions",Type.LIST,"",0,1,new String[0]);
        add("macro","keybind","Keybind",Type.TEXT,"NONE",0,1,new String[0]);
        group("auto_chat");
        add("auto_chat","message","Message",Type.TEXT,"",0,1,new String[0]);
        add("auto_chat","delay","Delay (ms)",Type.SLIDER,3000,500,10000,new String[0]);
        group("auto_reply");
        add("auto_reply","reply","Reply",Type.TEXT,"",0,1,new String[0]);
        add("auto_reply","whisper_only","Whisper only",Type.TOGGLE,true,0,1,new String[0]);
        group("spam");
        add("spam","message","Message",Type.TEXT,"",0,1,new String[0]);
        add("spam","delay","Delay (ms)",Type.SLIDER,1000,500,5000,new String[0]);
        group("announcer");
        add("announcer","kill","Kill",Type.TOGGLE,true,0,1,new String[0]);
        add("announcer","death","Death",Type.TOGGLE,true,0,1,new String[0]);
        add("announcer","join","Join",Type.TOGGLE,true,0,1,new String[0]);
        add("announcer","leave","Leave",Type.TOGGLE,true,0,1,new String[0]);
        add("announcer","template","Template",Type.TEXT,"{event}: {name}",0,1,new String[0]);
        group("name_protect");
        add("name_protect","custom_name","Custom name",Type.TEXT,"R1zz",0,1,new String[0]);
        add("name_protect","show_in_chat","Show in chat",Type.TOGGLE,true,0,1,new String[0]);
        group("auto_tip");
        add("auto_tip","server_ip","Server IP",Type.TEXT,"",0,1,new String[0]);
        add("auto_tip","interval","Interval (ms)",Type.SLIDER,60000,10000,180000,new String[0]);
        group("auto_sell");
        add("auto_sell","item_name","Item name",Type.TEXT,"",0,1,new String[0]);
        add("auto_sell","delay","Delay (ms)",Type.SLIDER,1000,0,10000,new String[0]);
        group("auto_drop");
        add("auto_drop","item_list","Item list",Type.LIST,"",0,1,new String[0]);
        add("auto_drop","trigger","Trigger",Type.DROPDOWN,"Key",0,1,new String[]{"Key","Always"});
        group("auto_crystal");
        add("auto_crystal","place_range","Place range",Type.SLIDER,4.5,3,6,new String[0]);
        add("auto_crystal","break_range","Break range",Type.SLIDER,4.5,3,6,new String[0]);
        add("auto_crystal","place_delay","Place delay (ms)",Type.SLIDER,50,0,500,new String[0]);
        add("auto_crystal","break_delay","Break delay (ms)",Type.SLIDER,100,0,500,new String[0]);
        add("auto_crystal","auto_switch","Auto switch",Type.TOGGLE,true,0,1,new String[0]);
        add("auto_crystal","damage_min","Damage min",Type.SLIDER,6,0,20,new String[0]);
        add("auto_crystal","rotate","Rotate",Type.DROPDOWN,"Smooth",0,1,new String[]{"None","Smooth","Snap"});
        group("anchor_aura");
        add("anchor_aura","place_range","Place range",Type.SLIDER,4.5,3,6,new String[0]);
        add("anchor_aura","break_range","Break range",Type.SLIDER,4.5,3,6,new String[0]);
        add("anchor_aura","delay","Delay (ms)",Type.SLIDER,100,0,500,new String[0]);
        add("anchor_aura","auto_switch","Auto switch",Type.TOGGLE,true,0,1,new String[0]);
        group("bed_aura");
        add("bed_aura","range","Range",Type.SLIDER,5,3,6,new String[0]);
        add("bed_aura","delay","Delay (ms)",Type.SLIDER,100,0,500,new String[0]);
        add("bed_aura","auto_switch","Auto switch",Type.TOGGLE,true,0,1,new String[0]);
        group("auto_trap");
        add("auto_trap","range","Range",Type.SLIDER,4,3,5,new String[0]);
        add("auto_trap","delay","Delay (ms)",Type.SLIDER,100,0,500,new String[0]);
        add("auto_trap","block_type","Block type",Type.DROPDOWN,"Obsidian",0,1,new String[]{"Obsidian","End Stone","Any"});
        group("surround");
        add("surround","range","Range",Type.SLIDER,3,2,4,new String[0]);
        add("surround","delay","Delay (ms)",Type.SLIDER,100,0,500,new String[0]);
        add("surround","block_type","Block type",Type.DROPDOWN,"Obsidian",0,1,new String[]{"Obsidian","End Stone","Any"});
        group("hole_filler");
        add("hole_filler","range","Range",Type.SLIDER,4,3,5,new String[0]);
        add("hole_filler","delay","Delay (ms)",Type.SLIDER,100,0,500,new String[0]);
        add("hole_filler","block_type","Block type",Type.DROPDOWN,"Obsidian",0,1,new String[]{"Obsidian","End Stone","Any"});
        group("auto_city");
        add("auto_city","range","Range",Type.SLIDER,4.5,3,5,new String[0]);
        add("auto_city","delay","Delay (ms)",Type.SLIDER,100,0,500,new String[0]);
        group("offhand");
        add("offhand","mode","Mode",Type.DROPDOWN,"Totem",0,1,new String[]{"Totem","Crystal","Gapple","Auto"});
        add("offhand","hp_threshold","HP threshold",Type.SLIDER,5,1,20,new String[0]);
        group("bow_aimbot");
        add("bow_aimbot","range","Range",Type.SLIDER,20,10,30,new String[0]);
        add("bow_aimbot","predict","Predict",Type.TOGGLE,true,0,1,new String[0]);
        add("bow_aimbot","rotate","Rotate",Type.DROPDOWN,"Smooth",0,1,new String[]{"None","Smooth","Snap"});
        add("bow_aimbot","gcd_clamp","GCD clamp",Type.TOGGLE,true,0,1,new String[0]);
        group("jump_reset");
        add("jump_reset","mode","Mode",Type.DROPDOWN,"Legit",0,1,new String[]{"Auto","Legit","Blatant"});
        add("jump_reset","delay","Delay (ms)",Type.SLIDER,50,0,200,new String[0]);
        add("jump_reset","chance","Chance",Type.SLIDER,100,0,100,new String[0]);
        add("jump_reset","only_on_ground","Only on ground",Type.TOGGLE,true,0,1,new String[0]);
        add("jump_reset","only_in_combat","Only in combat",Type.TOGGLE,false,0,1,new String[0]);
        group("auto_sprint");
        group("fast_ladder");
        add("fast_ladder","speed","Speed",Type.SLIDER,1,0.5,2,new String[0]);
        group("parkour");
        add("parkour","mode","Mode",Type.DROPDOWN,"Safe",0,1,new String[]{"Auto","Edge","Safe"});
        add("parkour","jump_distance","Jump distance",Type.SLIDER,1,0.5,3,new String[0]);
    }
    private static void group(String id){MAP.computeIfAbsent(id,k->new ArrayList<>());}
    private static void add(String m,String k,String l,Type t,Object d,double min,double max,String[] o){MAP.computeIfAbsent(m,k2->new ArrayList<>()).add(new Setting(m,k,l,t,d,min,max,o));}
    public static synchronized void ensureFor(String moduleId){
        initialize();
        if(!MAP.containsKey(moduleId)) add(moduleId,"intensity","Intensity",Type.SLIDER,1.0,0,1,new String[0]);
        for(Setting s:MAP.get(moduleId))s.load();
    }
    public static synchronized List<Setting> settings(String moduleId){initialize();return Collections.unmodifiableList(MAP.getOrDefault(moduleId,List.of()));}
    public static synchronized Setting find(String id){initialize();int p=id.indexOf('.');if(p<0)return null;String m=id.substring(0,p),k=id.substring(p+1);for(Setting s:MAP.getOrDefault(m,List.of()))if(s.key.equals(k))return s;return null;}
    public static synchronized Object get(String id){Setting s=find(id);return s==null?null:s.value();}
    public static synchronized double getDouble(String id,double d){Setting s=find(id);return s==null?d:s.number();}
    public static synchronized boolean getBoolean(String id,boolean d){Setting s=find(id);return s==null?d:s.bool();}
    public static synchronized String getString(String id,String d){Setting s=find(id);return s==null?d:s.text();}
    public static synchronized void set(String id,Object value){Setting s=find(id);if(s!=null)s.set(value);}
    public static synchronized void saveAll(){for(List<Setting> list:MAP.values())for(Setting s:list)R1zzConfig.put(s.fullKey(),s.value());R1zzConfig.save();}
    /** Best-effort reflection bridge: settings automatically update conventional module setters/fields.
     * This keeps existing module implementations compatible without changing Module. */
    public static synchronized void syncToModule(com.r1zz.module.Module module){
        List<Setting> list=MAP.get(module.id()); if(list==null)return;
        for(Setting s:list){
            String suffix=camel(s.key);
            try{
                java.lang.reflect.Method chosen=null;
                for(java.lang.reflect.Method method:module.getClass().getMethods()){if(!method.getName().equals("set"+suffix)||method.getParameterCount()!=1)continue;chosen=method;break;}
                if(chosen!=null){chosen.invoke(module,coerce(s.value(),chosen.getParameterTypes()[0]));continue;}
                java.lang.reflect.Field f=null;Class<?> c=module.getClass();while(c!=null){try{f=c.getDeclaredField(s.key);break;}catch(NoSuchFieldException e){c=c.getSuperclass();}}
                if(f!=null){f.setAccessible(true);f.set(module,coerce(s.value(),f.getType()));}
            }catch(Throwable ignored){}
        }
    }
    private static String camel(String s){StringBuilder b=new StringBuilder();boolean up=true;for(char c:s.toCharArray()){if(c=='_'){up=true;continue;}b.append(up?Character.toUpperCase(c):c);up=false;}return b.toString();}
    private static Object coerce(Object v,Class<?> t){if(t==boolean.class||t==Boolean.class)return Boolean.parseBoolean(String.valueOf(v));if(t==int.class||t==Integer.class)return (int)Math.round(((Number)v).doubleValue());if(t==long.class||t==Long.class)return Math.round(((Number)v).doubleValue());if(t==float.class||t==Float.class)return ((Number)v).floatValue();if(t==double.class||t==Double.class)return ((Number)v).doubleValue();if(t==String.class)return String.valueOf(v);return v;}
}