package com.r1zz.config;

import com.r1zz.R1zzClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Legit / Balanced / Blatant tuning presets, stored as editable files in .minecraft/config/r1zz/.
 * Presets only change tuning values (ranges, delays, speeds); they never switch modules on or off.
 */
public final class Presets {
    public static final String[] NAMES = {"Legit", "Balanced", "Blatant"};

    private Presets() {}

    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("r1zz");
    }

    private static Path file(String name) {
        return dir().resolve(name.toLowerCase(java.util.Locale.ROOT) + ".properties");
    }

    /** Writes the three default preset files if they do not exist yet. */
    public static void ensureFiles() {
        try {
            Files.createDirectories(dir());
            for (String name : NAMES) {
                Path p = file(name);
                if (Files.exists(p)) continue;
                try (OutputStream out = Files.newOutputStream(p)) {
                    defaults(name).store(out, "R1zz preset: " + name + " (edit freely)");
                }
            }
        } catch (IOException e) {
            System.err.println("[R1zz] Preset setup failed: " + e.getMessage());
        }
    }

    /** Applies a preset: merges its values into the config, saves, and reloads every module. */
    public static boolean apply(String name) {
        Path p = file(name);
        Properties props = new Properties();
        try {
            ensureFiles();
            try (InputStream in = Files.newInputStream(p)) {
                props.load(in);
            }
        } catch (IOException e) {
            System.err.println("[R1zz] Preset load failed: " + e.getMessage());
            return false;
        }
        for (String key : props.stringPropertyNames()) R1zzConfig.put(key, props.getProperty(key));
        R1zzConfig.put("preset.active", name);
        R1zzConfig.save();
        R1zzClient.reloadConfiguration();
        return true;
    }

    public static String active() {
        return R1zzConfig.get("preset.active", "Balanced");
    }

    private static Properties defaults(String name) {
        Properties p = new Properties();
        switch (name) {
            case "Legit" -> {
                p.setProperty("kill_aura.range", "3.0");        p.setProperty("kill_aura.cps", "7");
                p.setProperty("kill_aura.rotation", "Smooth");
                p.setProperty("auto_clicker.cps", "9");
                p.setProperty("r1zz_assist.range", "3.2");      p.setProperty("r1zz_assist.speed", "0.55");
                p.setProperty("r1zz_assist.delay", "130");      p.setProperty("r1zz_assist.hit_verify_angle", "10.0");
                p.setProperty("r1zz_assist.human_clicks", "true"); p.setProperty("r1zz_assist.micro_jitter", "true");
                p.setProperty("reach.value", "3.1");
                p.setProperty("trigger_bot.delay", "120");      p.setProperty("trigger_bot.miss_chance", "8.0");
                p.setProperty("jump_reset.mode", "Legit");      p.setProperty("jump_reset.delay", "70");
                p.setProperty("jump_reset.chance", "85.0");     p.setProperty("jump_reset.only_in_combat", "true");
                p.setProperty("water_drain.cooldown", "750");   p.setProperty("water_drain.reaction_delay", "230");
                p.setProperty("velocity.horizontal", "0.0");    p.setProperty("velocity.vertical", "0.0");
                p.setProperty("speed.multiplier", "1.0");       p.setProperty("scaffold.delay", "4");
                p.setProperty("scaffold.rotation", "Smooth");
                p.setProperty("auto_pot.hp_threshold", "8");
                p.setProperty("bow_aimbot.range", "15.0");
            }
            case "Blatant" -> {
                p.setProperty("kill_aura.range", "5.0");        p.setProperty("kill_aura.cps", "12");
                p.setProperty("kill_aura.rotation", "Snap");
                p.setProperty("auto_clicker.cps", "12");
                p.setProperty("r1zz_assist.range", "5.0");      p.setProperty("r1zz_assist.speed", "1.0");
                p.setProperty("r1zz_assist.delay", "30");       p.setProperty("r1zz_assist.hit_verify_angle", "30.0");
                p.setProperty("r1zz_assist.human_clicks", "false"); p.setProperty("r1zz_assist.micro_jitter", "false");
                p.setProperty("reach.value", "3.5");
                p.setProperty("trigger_bot.delay", "0");        p.setProperty("trigger_bot.miss_chance", "0.0");
                p.setProperty("jump_reset.mode", "Blatant");    p.setProperty("jump_reset.delay", "0");
                p.setProperty("jump_reset.chance", "100.0");    p.setProperty("jump_reset.only_in_combat", "false");
                p.setProperty("water_drain.cooldown", "500");   p.setProperty("water_drain.reaction_delay", "150");
                p.setProperty("velocity.horizontal", "0.0");   p.setProperty("velocity.vertical", "0.0");
                p.setProperty("speed.multiplier", "1.15");       p.setProperty("scaffold.delay", "1");
                p.setProperty("scaffold.rotation", "Snap");
                p.setProperty("auto_pot.hp_threshold", "14");
                p.setProperty("bow_aimbot.range", "40.0");
            }
            default -> {
                p.setProperty("kill_aura.range", "3.5");        p.setProperty("kill_aura.cps", "10");
                p.setProperty("kill_aura.rotation", "Smooth");
                p.setProperty("auto_clicker.cps", "12");
                p.setProperty("r1zz_assist.range", "3.5");      p.setProperty("r1zz_assist.speed", "0.75");
                p.setProperty("r1zz_assist.delay", "80");       p.setProperty("r1zz_assist.hit_verify_angle", "15.0");
                p.setProperty("r1zz_assist.human_clicks", "true"); p.setProperty("r1zz_assist.micro_jitter", "true");
                p.setProperty("reach.value", "3.5");
                p.setProperty("trigger_bot.delay", "80");       p.setProperty("trigger_bot.miss_chance", "3.0");
                p.setProperty("jump_reset.mode", "Legit");      p.setProperty("jump_reset.delay", "50");
                p.setProperty("jump_reset.chance", "100.0");    p.setProperty("jump_reset.only_in_combat", "false");
                p.setProperty("water_drain.cooldown", "650");   p.setProperty("water_drain.reaction_delay", "200");
                p.setProperty("velocity.horizontal", "0.0");   p.setProperty("velocity.vertical", "0.0");
                p.setProperty("speed.multiplier", "1.15");      p.setProperty("scaffold.delay", "3");
                p.setProperty("scaffold.rotation", "Smooth");
                p.setProperty("auto_pot.hp_threshold", "10");
                p.setProperty("bow_aimbot.range", "25.0");
            }
        }
        return p;
    }
}
