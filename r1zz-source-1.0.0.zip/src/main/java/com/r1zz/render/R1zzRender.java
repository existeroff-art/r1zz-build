package com.r1zz.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.module.ModuleManager;
import com.r1zz.module.modules.ESP;
import com.r1zz.module.modules.VisualToggle;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class R1zzRender {
    private record ScreenDot(double x,double y,int color){}
    private static volatile List<ScreenDot> projected=List.of();
    private R1zzRender(){}
    public static void renderWorld(WorldRenderContext context){
        MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null||context.world()==null)return;
        Vec3d camera=context.camera().getPos(),self=mc.player.getPos();List<ScreenDot> dots=new ArrayList<>();float strength=alphaMultiplier();VisualToggle range=ModuleManager.visual("range");double maxRange=range==null?128:range.value();ESP esp=ModuleManager.esp();
        List<LivingEntity> entities=context.world().getEntitiesByClass(LivingEntity.class,mc.player.getBoundingBox().expand(Math.max(64,maxRange)),e->e!=mc.player&&e.isAlive());
        for(LivingEntity entity:entities){double distance=self.distanceTo(entity.getPos());boolean player=entity instanceof PlayerEntity;int color=entityColor(entity,strength);
            if(player&&ModuleManager.visual("dash_dots").enabled()&&distance<=32)drawBillboard(context,entity.getX(),entity.getY()+entity.getHeight()+.18,entity.getZ(),"●",color,1f);
            if(player&&ModuleManager.visual("tag_elements").enabled()&&ModuleManager.visual("tag_head").enabled()&&distance<=maxRange){String name=((PlayerEntity)entity).getGameProfile().getName();StringBuilder label=new StringBuilder();if(R1zzConfig.isFriend(name)&&ModuleManager.visual("tag_friend_prefix").enabled())label.append("[Friend] ");if(ModuleManager.visual("tag_prefix").enabled())label.append("» ");label.append(name).append("  ").append(Math.round(entity.getHealth())).append("❤");if(ModuleManager.visual("tag_suffix").enabled())label.append(" •");if(ModuleManager.visual("tag_donation").enabled())label.append(" ◈");drawBillboard(context,entity.getX(),entity.getY()+entity.getHeight()+.42,entity.getZ(),label.toString(),color,.95f);}
            if(player&&ModuleManager.get("nametags")!=null&&ModuleManager.get("nametags").enabled()){String label=((PlayerEntity)entity).getGameProfile().getName()+"  "+Math.round(entity.getHealth())+"❤  "+String.format(Locale.ROOT,"%.1fm",distance);drawBillboard(context,entity.getX(),entity.getY()+entity.getHeight()+.58,entity.getZ(),label,color,1.05f);}
            if(player&&range!=null&&range.enabled()&&distance<=maxRange){Vec3d p=entity.getPos().add(0,entity.getHeight()*.78,0).subtract(camera);Vector4f clip=new Vector4f((float)p.x,(float)p.y,(float)p.z,1).mul(context.positionMatrix()).mul(context.projectionMatrix());if(clip.w>.001f){double nx=clip.x/clip.w,ny=clip.y/clip.w;if(Math.abs(nx)<=1.2&&Math.abs(ny)<=1.2){int sw=mc.getWindow().getScaledWidth(),sh=mc.getWindow().getScaledHeight();dots.add(new ScreenDot((nx+1)*sw*.5,(1-ny)*sh*.5,color));}}}
            if(esp!=null&&esp.enabled()&&espTarget(esp,player)&&distance<=128)drawEsp(context,entity,camera,color,strength,esp);
            Module tracer=ModuleManager.get("tracers");if(tracer!=null&&tracer.enabled()&&distance<=128)drawTracer(context,entity,camera,color,strength);
        }
        projected=List.copyOf(dots);
    }
    private static boolean espTarget(ESP e,boolean player){return e.targets().equals("Both")||(e.targets().equals("Players")&&player)||(e.targets().equals("Mobs")&&!player);}
    private static void drawEsp(WorldRenderContext c,LivingEntity e,Vec3d camera,int color,float strength,ESP esp){
        if((!esp.option("box")&&!esp.option("outline")&&!esp.option("fill")&&!esp.option("health"))||strength<=0)return;double r=((color>>16)&255)/255.0,g=((color>>8)&255)/255.0,b=(color&255)/255.0,a=Math.max(0,Math.min(1,strength));Box box=e.getBoundingBox().offset(-camera.x,-camera.y,-camera.z);RenderSystem.disableDepthTest();
        if(esp.option("fill")){VertexConsumer vc=c.consumers().getBuffer(RenderLayer.getDebugFilledBox());WorldRenderer.renderFilledBox(c.matrixStack(),vc,box.minX,box.minY,box.minZ,box.maxX,box.maxY,box.maxZ,(float)r,(float)g,(float)b,(float)(a*.16));}
        if(esp.option("box")){VertexConsumer vc=c.consumers().getBuffer(RenderLayer.getLines());WorldRenderer.drawBox(c.matrixStack(),vc,box,(float)r,(float)g,(float)b,(float)a);}
        if(esp.option("outline")){VertexConsumer vc=c.consumers().getBuffer(RenderLayer.getLines());Box outer=box.expand(.025);WorldRenderer.drawBox(c.matrixStack(),vc,outer,(float)r,(float)g,(float)b,(float)(a*.8));}
        if(esp.option("health")){float ratio=Math.max(0,Math.min(1,e.getHealth()/e.getMaxHealth()));VertexConsumer vc=c.consumers().getBuffer(RenderLayer.getLines());WorldRenderer.drawBox(c.matrixStack(),vc,box.minX-.06,box.minY,box.minZ-.06,box.minX-.035,box.minY+e.getHeight()*ratio,box.minZ-.035,.15f,1-ratio,.18f,(float)a);}
        RenderSystem.enableDepthTest();
    }
    private static void drawTracer(WorldRenderContext c,LivingEntity e,Vec3d camera,int color,float strength){if(strength<=0)return;Vec3d end=e.getPos().add(0,e.getHeight()*.5,0).subtract(camera);RenderSystem.disableDepthTest();RenderSystem.lineWidth(1.5f);VertexConsumer vc=c.consumers().getBuffer(RenderLayer.getLines());MatrixStack.Entry entry=c.matrixStack().peek();float r=((color>>16)&255)/255f,g=((color>>8)&255)/255f,b=(color&255)/255f,a=Math.max(0,Math.min(1,strength));vc.vertex(entry,0,0,0).color(r,g,b,a).normal(entry,0,1,0);vc.vertex(entry,(float)end.x,(float)end.y,(float)end.z).color(r,g,b,a).normal(entry,0,1,0);RenderSystem.enableDepthTest();}
    private static void drawBillboard(WorldRenderContext c,double x,double y,double z,String label,int color,float scale){MinecraftClient mc=MinecraftClient.getInstance();TextRenderer renderer=mc.textRenderer;MatrixStack m=c.matrixStack();Vec3d camera=c.camera().getPos();m.push();m.translate(x-camera.x,y-camera.y,z-camera.z);m.multiply(c.camera().getRotation());float unit=.025f*scale;m.scale(-unit,-unit,unit);Matrix4f matrix=m.peek().getPositionMatrix();VertexConsumerProvider consumers=c.consumers();float tx=-renderer.getWidth(label)/2f;renderer.draw(label,tx,0,color,false,matrix,consumers,TextRenderer.TextLayerType.NORMAL,0,LightmapTextureManager.MAX_LIGHT_COORDINATE);m.pop();}
    public static void renderHud(DrawContext ctx){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null||mc.world==null)return;VisualToggle range=ModuleManager.visual("range");if(range!=null&&range.enabled())for(ScreenDot d:projected){int x=(int)d.x,y=(int)d.y;ctx.fill(x-3,y-3,x+4,y+4,scaleAlpha(0xCC000000|(d.color&0xFFFFFF)));ctx.fill(x-2,y-2,x+3,y+3,scaleAlpha(0xFF000000|(d.color&0xFFFFFF)));}
        if(R1zzConfig.getBoolean("hud.show_keybinds",false))drawKeybinds(ctx,mc);
        if(!ModuleManager.visual("hud_elements").enabled())return;int x=8,y=8;ctx.fill(x-4,y-4,x+184,y+46,scaleAlpha(0xA820242A));int color=scaleAlpha(0xFFEDEDED);ctx.drawTextWithShadow(mc.textRenderer,"FPS: "+mc.getCurrentFps(),x,y,color);y+=10;int ping=-1;if(mc.getNetworkHandler()!=null){var e=mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());if(e!=null)ping=e.getLatency();}ctx.drawTextWithShadow(mc.textRenderer,"Ping: "+(ping<0?"—":ping+" ms"),x,y,color);y+=10;ctx.drawTextWithShadow(mc.textRenderer,String.format(Locale.ROOT,"XYZ: %d, %d, %d",(int)mc.player.getX(),(int)mc.player.getY(),(int)mc.player.getZ()),x,y,color);y+=10;String biome=mc.world.getBiome(mc.player.getBlockPos()).getKey().map(k->k.getValue().getPath()).orElse("unknown");ctx.drawTextWithShadow(mc.textRenderer,"Biome: "+biome,x,y,color);
    }
    private static void drawKeybinds(DrawContext ctx,MinecraftClient mc){List<Module> active=ModuleManager.all().stream().filter(m->m.enabled()&&m.keyCode()>=0).toList();if(active.isEmpty())return;int x=mc.getWindow().getScaledWidth()-122,y=8;ctx.fill(x-5,y-4,x+117,y+active.size()*10+7,scaleAlpha(0xB0181A20));ctx.drawTextWithShadow(mc.textRenderer,"R1ZZ BINDS",x,y,scaleAlpha(0xFF6B7CFF));y+=11;for(Module m:active){ctx.drawTextWithShadow(mc.textRenderer,m.name()+"  "+net.minecraft.client.util.InputUtil.fromKeyCode(m.keyCode(),0).getLocalizedText().getString(),x,y,scaleAlpha(0xFFEDEDED));y+=9;}}
    private static int entityColor(LivingEntity e,float strength){int rgb;if(e instanceof PlayerEntity p){String mode=R1zzConfig.get("visual.color_mode.name","Item");Module m=ModuleManager.get("color_mode");if(m==null||!m.enabled()||mode.equals("Item"))rgb=0xFFC84A;else if(mode.equals("Friend")&&R1zzConfig.isFriend(p.getGameProfile().getName()))rgb=ModuleManager.visual("friend_color").color();else rgb=ModuleManager.visual("player_color").color();}else rgb=0xFFFF7474;return((int)(255*strength)<<24)|(rgb&0xFFFFFF);}
    private static float alphaMultiplier(){VisualToggle s=ModuleManager.visual("strength");return s==null?1f:Math.max(0,Math.min(1,(float)(s.value()/100.0)));}
    private static int scaleAlpha(int c){return((int)((c>>>24)*alphaMultiplier())<<24)|(c&0xFFFFFF);}
}
