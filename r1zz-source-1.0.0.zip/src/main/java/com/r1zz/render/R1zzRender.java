package com.r1zz.render;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gui.DrawContext;

public final class R1zzRender {
    private R1zzRender() {}
    public static void renderHud(DrawContext ctx) {}
    public static void renderWorld(WorldRenderContext context) {}
}
