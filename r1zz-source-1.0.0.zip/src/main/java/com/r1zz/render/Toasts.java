package com.r1zz.render;

import com.r1zz.config.R1zzConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Top-right toggle notifications. Each toast lives 2 seconds and fades in and out. */
public final class Toasts {
    private static final long LIFETIME_MS = 2000L, FADE_IN_MS = 150L, FADE_OUT_MS = 500L;
    private static final int MAX_VISIBLE = 5, WIDTH = 132, HEIGHT = 22;
    private static final Identifier ICON_ON = Identifier.of("r1zz", "textures/notify/on.png");
    private static final Identifier ICON_OFF = Identifier.of("r1zz", "textures/notify/off.png");
    private static final Identifier BACKGROUND = Identifier.of("r1zz", "textures/notify/toast_bg.png");
    private static final List<Toast> ACTIVE = new ArrayList<>();

    private record Toast(String name, boolean on, long created) {}

    private Toasts() {}

    public static synchronized void push(String name, boolean on) {
        if (!R1zzConfig.getBoolean("notify.toast", true)) return;
        ACTIVE.add(new Toast(name, on, System.currentTimeMillis()));
        while (ACTIVE.size() > MAX_VISIBLE) ACTIVE.remove(0);
    }

    public static synchronized void clear() {
        ACTIVE.clear();
    }

    public static synchronized void render(DrawContext ctx) {
        if (ACTIVE.isEmpty()) return;
        if (!R1zzConfig.getBoolean("notify.toast", true)) { ACTIVE.clear(); return; }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getWindow() == null || mc.textRenderer == null) return;

        long now = System.currentTimeMillis();
        ACTIVE.removeIf(t -> now - t.created >= LIFETIME_MS);
        int x = mc.getWindow().getScaledWidth() - WIDTH - 8;
        int y = 8;
        for (Toast t : ACTIVE) {
            long age = now - t.created;
            float alpha = 1.0f;
            if (age < FADE_IN_MS) alpha = age / (float) FADE_IN_MS;
            else if (age > LIFETIME_MS - FADE_OUT_MS) alpha = (LIFETIME_MS - age) / (float) FADE_OUT_MS;
            alpha = Math.max(0.0f, Math.min(1.0f, alpha));
            int a = (int) (alpha * 255.0f);
            if (a < 4) continue;

            int slide = (int) ((1.0f - Math.min(1.0f, age / (float) FADE_IN_MS)) * 14.0f);
            int tx = x + slide;
            ctx.fill(tx, y, tx + WIDTH, y + HEIGHT, (a * 0xC0 / 255) << 24 | 0x0A0A0F);
            ctx.fill(tx, y, tx + 2, y + HEIGHT, a << 24 | (t.on ? 0x4ADE80 : 0xFF6B9D));
            ctx.drawTexture(t.on ? ICON_ON : ICON_OFF, tx + 6, y + 3, 16, 16, 0.0f, 0.0f, 32, 32, 32, 32);
            ctx.drawTextWithShadow(mc.textRenderer, t.name, tx + 28, y + 3, a << 24 | 0xEDEDED);
            ctx.drawTextWithShadow(mc.textRenderer, t.on ? "enabled" : "disabled", tx + 28, y + 12, a << 24 | (t.on ? 0x4ADE80 : 0x8C8F98));
            y += HEIGHT + 4;
        }
    }
}
