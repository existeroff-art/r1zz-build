package com.r1zz;

import com.r1zz.config.R1zzConfig;
import com.r1zz.gui.ClickGUI;
import com.r1zz.module.Module;
import com.r1zz.module.ModuleManager;
import com.r1zz.module.modules.VisualToggle;
import com.r1zz.render.R1zzRender;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import java.util.HashSet;
import java.util.Set;

public final class R1zzClient implements ClientModInitializer {
    private static int guiKey=GLFW.GLFW_KEY_RIGHT_SHIFT;
    private static final Set<Integer> DOWN_LAST_TICK=new HashSet<>();
    private static boolean gammaApplied,qualityApplied;
    private static double previousGamma;
    private static int previousViewDistance;
    @Override public void onInitializeClient(){R1zzConfig.load();guiKey=R1zzConfig.getInt("gui.key",GLFW.GLFW_KEY_RIGHT_SHIFT);ModuleManager.initialize();ClientTickEvents.END_CLIENT_TICK.register(R1zzClient::tick);HudRenderCallback.EVENT.register((ctx,tick)->R1zzRender.renderHud(ctx));WorldRenderEvents.LAST.register(R1zzRender::renderWorld);}
    public static void applyLoadedGuiKey(){guiKey=R1zzConfig.getInt("gui.key",GLFW.GLFW_KEY_RIGHT_SHIFT);}
    public static int guiKey(){return guiKey;}
    public static void setGuiKey(int key){guiKey=key;R1zzConfig.put("gui.key",key);R1zzConfig.save();}
    public static void reloadConfiguration(){R1zzConfig.reload();ModuleManager.initialize();applyLoadedGuiKey();}
    private static void tick(MinecraftClient client){if(client.getWindow()==null)return;handleKeybinds(client);updateFullbright(client);updateQuality(client);ModuleManager.tick();R1zzConfig.saveIfDirty();}
    private static void handleKeybinds(MinecraftClient client){
        long window=client.getWindow().getHandle();Set<Integer> current=new HashSet<>();if(guiKey>=0&&GLFW.glfwGetKey(window,guiKey)==GLFW.GLFW_PRESS)current.add(guiKey);
        for(Module m:ModuleManager.all())if(m.keyCode()>=0&&GLFW.glfwGetKey(window,m.keyCode())==GLFW.GLFW_PRESS)current.add(m.keyCode());
        if(guiKey>=0&&current.contains(guiKey)&&!DOWN_LAST_TICK.contains(guiKey)&&client.currentScreen==null)client.setScreen(new ClickGUI());
        for(Module m:ModuleManager.all()){if(m.id().equals("zoom"))continue;int key=m.keyCode();if(key<0||key==guiKey)continue;if(current.contains(key)&&!DOWN_LAST_TICK.contains(key)&&client.currentScreen==null)m.toggle();}
        DOWN_LAST_TICK.clear();DOWN_LAST_TICK.addAll(current);
    }
    private static void updateFullbright(MinecraftClient client){if(client.options==null)return;Module m=ModuleManager.get("fullbright");boolean on=m!=null&&m.enabled();if(on){if(!gammaApplied){previousGamma=client.options.getGamma().getValue();gammaApplied=true;}if(client.options.getGamma().getValue()<1.0)client.options.getGamma().setValue(1.0);}else if(gammaApplied){client.options.getGamma().setValue(previousGamma);gammaApplied=false;}}
    private static void updateQuality(MinecraftClient client){if(client.options==null)return;VisualToggle q=ModuleManager.visual("quality");if(q==null)return;if(q.enabled()){if(!qualityApplied){previousViewDistance=client.options.getViewDistance().getValue();qualityApplied=true;}double v=q.value();int chunks=v<=5?(int)Math.round(4+v*1.6):(int)Math.round(12+(v-5)*4);if(client.options.getViewDistance().getValue()!=chunks)client.options.getViewDistance().setValue(chunks);}else if(qualityApplied){client.options.getViewDistance().setValue(previousViewDistance);qualityApplied=false;}}
}
