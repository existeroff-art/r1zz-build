package com.r1zz;

import com.r1zz.config.Presets;
import com.r1zz.config.R1zzConfig;
import com.r1zz.gui.ClickGUI;
import com.r1zz.module.Module;
import com.r1zz.module.ModuleManager;
import com.r1zz.render.R1zzRender;
import com.r1zz.render.Toasts;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

public final class R1zzClient implements ClientModInitializer {
    private static int guiKey = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private static final Set<Integer> DOWN_LAST_TICK = new HashSet<>();
    private static boolean gammaApplied;
    private static double previousGamma;

    @Override
    public void onInitializeClient() {
        R1zzConfig.load();
        Presets.ensureFiles();
        guiKey = R1zzConfig.getInt("gui.key", GLFW.GLFW_KEY_RIGHT_SHIFT);
        ModuleManager.initialize();
        ClientTickEvents.END_CLIENT_TICK.register(R1zzClient::tick);
        HudRenderCallback.EVENT.register((ctx, tick) -> {
            R1zzRender.renderHud(ctx);
            Toasts.render(ctx);
        });
        WorldRenderEvents.LAST.register(R1zzRender::renderWorld);
    }

    public static void applyLoadedGuiKey() {
        guiKey = R1zzConfig.getInt("gui.key", GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    public static int guiKey() { return guiKey; }

    public static void setGuiKey(int key) {
        guiKey = key;
        R1zzConfig.put("gui.key", key);
        R1zzConfig.save();
    }

    public static void reloadConfiguration() {
        R1zzConfig.reload();
        ModuleManager.initialize();
        applyLoadedGuiKey();
    }

    private static void tick(MinecraftClient client) {
        if (client.getWindow() == null) return;
        handleKeybinds(client);
        updateFullbright(client);
        ModuleManager.tick();
        R1zzConfig.saveIfDirty();
    }

    private static void handleKeybinds(MinecraftClient client) {
        long window = client.getWindow().getHandle();
        Set<Integer> current = new HashSet<>();
        if (guiKey >= 0 && GLFW.glfwGetKey(window, guiKey) == GLFW.GLFW_PRESS) current.add(guiKey);
        for (Module module : ModuleManager.all()) {
            if (module.keyCode() >= 0 && GLFW.glfwGetKey(window, module.keyCode()) == GLFW.GLFW_PRESS) {
                current.add(module.keyCode());
            }
        }
        if (guiKey >= 0 && current.contains(guiKey) && !DOWN_LAST_TICK.contains(guiKey) && client.currentScreen == null) {
            client.setScreen(new ClickGUI());
        }
        for (Module module : ModuleManager.all()) {
            int key = module.keyCode();
            if (key < 0 || key == guiKey) continue;
            if (current.contains(key) && !DOWN_LAST_TICK.contains(key) && client.currentScreen == null) module.toggle();
        }
        DOWN_LAST_TICK.clear();
        DOWN_LAST_TICK.addAll(current);
    }

    private static void updateFullbright(MinecraftClient client) {
        if (client.options == null) return;
        Module fullbright = ModuleManager.get("fullbright");
        boolean enabled = fullbright != null && fullbright.enabled();
        if (enabled) {
            if (!gammaApplied) {
                previousGamma = client.options.getGamma().getValue();
                gammaApplied = true;
            }
            if (client.options.getGamma().getValue() < 1.0) client.options.getGamma().setValue(1.0);
        } else if (gammaApplied) {
            client.options.getGamma().setValue(previousGamma);
            gammaApplied = false;
        }
    }
}
