package com.r1zz.gui;

import com.r1zz.module.Module;

import java.util.HashMap;
import java.util.Map;

/** One-line hover descriptions shown as tooltips in the ClickGUI. */
public final class ModuleDescriptions {
    private static final Map<String, String> TEXT = new HashMap<>();

    static {
        d("aim_assist", "Smoothly pulls your aim toward nearby targets.");
        d("fast_gap", "Halves golden apple eating time. Hold use yourself; it never auto-eats.");
        d("shield_breaker", "Swaps to an axe to disable a blocking opponent's shield.");
        d("cobweb_placer", "Places cobwebs near enemies to slow them down.");
        d("water_drain", "Fills nearby water source blocks with your held block, with human timing.");
        d("mace_swap", "Swaps to a mace for the smash attack and back to your weapon.");
        d("trigger_bot", "Attacks automatically when your crosshair is on a target.");
        d("jump_reset", "Jumps as knockback lands to cut horizontal knockback.");
        d("r1zz_assist", "Sticky lock-on: locks the nearest target and stays on it until it is invalid.");
        d("auto_crystal", "Places and breaks end crystals near the closest player.");
        d("anchor_aura", "Places, charges and detonates a respawn anchor above a target.");
        d("auto_trap", "Boxes the nearest player in with blocks.");
        d("hole_filler", "Fills nearby holes with blocks.");
        d("surround", "Keeps the four blocks around your feet filled.");
        d("auto_city", "Mines the block beside an enemy's surround.");
        d("offhand", "Keeps a chosen item (totem, crystal, gapple) in your offhand.");
        d("bow_aimbot", "Aims drawn bows with velocity lead and drop compensation.");
        d("kill_aura", "Attacks nearby targets with randomised CPS and smooth aiming.");
        d("reach", "Extends melee reach slightly with randomised distance.");
        d("auto_clicker", "Clicks for you at a jittered CPS.");
        d("criticals", "Hops just before a hit so it lands as a critical.");
        d("wtap", "Releases forward briefly after a hit to refresh sprint knockback.");
        d("stap", "Taps back after a hit to open up spacing.");
        d("auto_wtap", "Automatic W-tap on every attack.");
        d("auto_block", "Raises your shield when an enemy gets close.");
        d("auto_weapon", "Switches to your best weapon when you start hitting.");
        d("auto_tool", "Switches to the fastest tool for the block you mine.");
        d("auto_pot", "Throws or drinks healing potions below your HP threshold.");
        d("sprint", "Keeps you sprinting while moving forward.");
        d("step", "Lets you step up full blocks.");
        d("no_fall", "Cancels fall damage.");
        d("velocity", "Reduces knockback by the set percentage.");
        d("anti_void", "Teleports you back up when you fall into the void.");
        d("no_slow", "Removes slowdown from using items.");
        d("speed", "Small ground-speed boost.");
        d("scaffold", "Places blocks under your feet while you walk.");
        d("esp", "Draws boxes around players and mobs.");
        d("tracers", "Draws lines to nearby entities.");
        d("nametags", "Larger nametags with health and distance.");
        d("fullbright", "Maximum brightness everywhere.");
        d("fog_blur", "Pushes fog far away for clear distance visibility.");
        d("freecam", "Detach the camera and fly around without moving.");
        d("zoom", "Hold the bound key to zoom in.");
        d("no_hurt_cam", "Removes the screen shake when you are hit.");
        d("auto_respawn", "Respawns for you after a short human delay.");
        d("fast_place", "Shortens the delay between block placements.");
        d("auto_totem", "Moves a totem into your offhand when it is empty.");
        d("auto_armor", "Equips the best armor from your inventory.");
        d("anti_hunger", "Reduces hunger loss while sprinting.");
        d("no_rotate", "Ignores server-forced rotation changes.");
        d("time_changer", "Client-side time of day.");
        d("weather_changer", "Client-side weather.");
        d("anti_afk", "Small random actions so you are not kicked for idling.");
        d("chat_suffix", "Adds a suffix to your chat messages.");
        d("auto_reply", "Replies to chat triggers automatically.");
        d("blink", "Holds your movement packets, then releases them together.");
        d("auto_reconnect", "Reconnects after a disconnect.");
        d("packet_logger", "Logs packets to the console for debugging.");
        d("notifications", "Misc notification options.");
    }

    private ModuleDescriptions() {}

    private static void d(String id, String text) { TEXT.put(id, text); }

    public static String of(Module m) {
        String text = TEXT.get(m.id());
        if (text != null) return text;
        String cat = m.category().name().charAt(0) + m.category().name().substring(1).toLowerCase(java.util.Locale.ROOT);
        return m.name() + " - " + cat + " module. Click to expand settings.";
    }
}