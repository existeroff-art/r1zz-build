package com.r1zz.gui;

import com.r1zz.R1zzClient;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.module.ModuleManager;
import com.r1zz.module.modules.AimAssist;
import com.r1zz.module.modules.FastGap;
import com.r1zz.module.modules.ShieldBreaker;
import com.r1zz.module.modules.TriggerBot;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ClickGUI extends Screen {
    private static final int PW = 500, PH = 340, SW = 65, ACCENT = 0xFFFF6B9D;
    private static final int PANEL = 0xFF0A0A0F, BORDER = 0xFF1A1A24, CARD = 0xFF14141C, HOVER = 0xFF1F1F2A;
    private static final Module.Category[] CATEGORIES = Module.Category.values();
    private static final String[] CATEGORY_ICONS = {"◎", "↗", "◉", "●", "◌", "⚙"};

    private final List<Control> controls = new ArrayList<>();
    private int openTicks;
    private int scroll;
    private int categoryFade;
    private int bx;
    private int by;
    private Module.Category category = Module.Category.COMBAT;
    private boolean settingsOpen;
    private boolean searchCapture;
    private boolean friendEntry;
    private boolean guiKeyCapture;
    private String search = "";
    private String bindingCapture;
    private String expandedId;
    private String dropdownOpenId;
    private String dragId;
    private boolean scrollDrag;
    private final StringBuilder textBuffer = new StringBuilder();

    private static Identifier bgTexture;
    private static int bgW;
    private static int bgH;
    private static boolean bgTried;

    private record Control(String kind, String id, int x, int y, int w, int h, String option) {}

    public ClickGUI() {
        super(Text.literal("R1zz Client"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    public TextRenderer font() {
        return textRenderer;
    }

    public void beginBinding(String id) {
        bindingCapture = id;
        guiKeyCapture = false;
        friendEntry = false;
        searchCapture = false;
    }

    public void beginGuiKeyBinding() {
        bindingCapture = null;
        guiKeyCapture = true;
        friendEntry = false;
    }

    public void beginFriendEntry() {
        friendEntry = true;
        textBuffer.setLength(0);
        bindingCapture = null;
        guiKeyCapture = false;
    }

    public boolean friendEntryActive() {
        return friendEntry;
    }

    public String friendEntryText() {
        return textBuffer.toString();
    }

    public void finishFriendEntry() {
        String name = textBuffer.toString().trim();
        if (!name.isBlank()) R1zzConfig.addFriend(name);
        friendEntry = false;
        textBuffer.setLength(0);
    }

    private int px() {
        return (width - PW) / 2;
    }

    private int py() {
        return (height - PH) / 2;
    }

    private int cx() {
        return bx + SW + 12;
    }

    private int cw() {
        return PW - SW - 24;
    }

    private static void ensureBackground() {
        if (bgTried) return;
        bgTried = true;
        MinecraftClient mc = MinecraftClient.getInstance();
        try (java.io.InputStream in = mc.getResourceManager().open(Identifier.of("r1zz", "gui/luffy.png"))) {
            NativeImage image = NativeImage.read(in);
            bgW = image.getWidth();
            bgH = image.getHeight();
            Identifier id = Identifier.of("r1zz", "dynamic/luffy_bg");
            mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(image));
            bgTexture = id;
        } catch (Exception e) {
            System.err.println("[R1zz] GUI background unavailable: " + e.getMessage());
        }
    }

    private void drawBackground(DrawContext ctx) {
        ensureBackground();
        if (bgTexture == null || bgW <= 0 || bgH <= 0) return;
        float t = (System.currentTimeMillis() % 60000L) / 60000f * (float) (Math.PI * 2);
        int regionW = (int) (bgW * 0.9f);
        int regionH = Math.min(bgH, (int) (regionW * (PH / (float) PW)));
        int u = (int) ((bgW - regionW) * (0.5f + 0.5f * Math.sin(t)));
        int v = (int) ((bgH - regionH) * (0.5f + 0.5f * Math.cos(t * 0.7f)));
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1f, 1f, 1f, 0x60 / 255f);
        ctx.enableScissor(bx + 1, by + 1, bx + PW - 1, by + PH - 1);
        ctx.drawTexture(bgTexture, bx, by, PW, PH, (float) u, (float) v, regionW, regionH, bgW, bgH);
        ctx.disableScissor();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        bx = px();
        by = py();
        controls.clear();
        openTicks = Math.min(5, openTicks + 1);
        scroll = Math.min(scroll, maxScroll());

        ctx.fill(0, 0, width, height, 0x90000000);
        float scale = 0.9f + 0.1f * ease(Math.min(1, openTicks / 5f));
        ctx.getMatrices().push();
        ctx.getMatrices().translate(width / 2.0, height / 2.0, 0);
        ctx.getMatrices().scale(scale, scale, 1);
        ctx.getMatrices().translate(-width / 2.0, -height / 2.0, 0);

        Widget.roundRect(ctx, bx + 5, by + 5, bx + PW + 5, by + PH + 5, 0x50000000, 7);
        Widget.roundRect(ctx, bx, by, bx + PW, by + PH, PANEL, 6);
        ctx.fill(bx, by, bx + 1, by + PH, BORDER);
        ctx.fill(bx + PW - 1, by, bx + PW, by + PH, BORDER);
        ctx.fill(bx, by, bx + PW, by + 1, BORDER);
        ctx.fill(bx, by + PH - 1, bx + PW, by + PH, BORDER);
        drawBackground(ctx);
        drawSidebar(ctx, mouseX, mouseY);

        if (settingsOpen) {
            drawTopbar(ctx, "Settings");
            SettingsPanel.render(this, ctx, cx(), by + 52, mouseX, mouseY, bindingCapture, guiKeyCapture);
        } else {
            drawCategory(ctx, mouseX, mouseY);
        }

        if (bindingCapture != null || guiKeyCapture || friendEntry) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Press key / enter text · Esc cancels"), bx + PW / 2, by + PH - 15, ACCENT);
        }
        if (categoryFade > 0 && !settingsOpen) {
            ctx.fill(cx(), by + 40, bx + PW - 8, by + PH - 8, ((categoryFade * 25 / 3) << 24));
            categoryFade--;
        }

        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawSidebar(DrawContext ctx, int mx, int my) {
        ctx.fill(bx + 1, by + 1, bx + SW, by + PH - 1, 0xB0050508);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("R1ZZ"), bx + SW / 2, by + 14, 0xFFFFFFFF);
        ctx.fill(bx + 18, by + 26, bx + SW - 18, by + 27, ACCENT);

        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = by + 42 + i * 37;
            boolean active = !settingsOpen && category == CATEGORIES[i];
            boolean hover = inside(mx, my, bx + 5, y, SW - 10, 33);
            if (active || hover) Widget.roundRect(ctx, bx + 6, y, bx + SW - 5, y + 31, active ? CARD : HOVER, 5);
            if (active) ctx.fill(bx + 2, y + 4, bx + 5, y + 27, ACCENT);
            String label = switch (CATEGORIES[i]) {
                case MOVEMENT -> "Move";
                case RENDER -> "Render";
                case PLAYER -> "Player";
                case WORLD -> "World";
                case MISC -> "Misc";
                default -> "Combat";
            };
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(CATEGORY_ICONS[i]), bx + SW / 2, y + 2, active ? ACCENT : 0xFF6E7078);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(label), bx + SW / 2, y + 16, active ? ACCENT : 0xFF6E7078);
        }

        int gy = by + PH - 39;
        boolean hover = inside(mx, my, bx + 6, gy, SW - 12, 28);
        if (settingsOpen || hover) Widget.roundRect(ctx, bx + 6, gy, bx + SW - 5, gy + 27, settingsOpen ? CARD : HOVER, 5);
        if (settingsOpen) ctx.fill(bx + 2, gy + 3, bx + 5, gy + 24, ACCENT);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("⚙ Settings"), bx + SW / 2, gy + 9, settingsOpen ? ACCENT : 0xFF6E7078);
    }

    private void drawTopbar(DrawContext ctx, String title) {
        ctx.getMatrices().push();
        ctx.getMatrices().translate(cx(), by + 11, 0);
        ctx.getMatrices().scale(1.2f, 1.2f, 1);
        ctx.drawText(textRenderer, Text.literal(title), 0, 0, 0xFFFFFFFF, false);
        ctx.getMatrices().pop();

        if (!settingsOpen) {
            int sx = bx + PW - 181;
            int sy = by + 9;
            Widget.roundRect(ctx, sx, sy, sx + 171, sy + 24, CARD, 5);
            String shown = searchCapture ? search + "_" : search.isEmpty() ? "Search modules..." : search;
            ctx.drawText(textRenderer, Text.literal(shown), sx + 8, sy + 8, searchCapture ? 0xFFFFFFFF : 0xFF6E7078, false);
        }
        ctx.fill(cx(), by + 39, bx + PW - 10, by + 40, BORDER);
    }

    private void drawCategory(DrawContext ctx, int mx, int my) {
        String title = category.name().charAt(0) + category.name().substring(1).toLowerCase(Locale.ROOT);
        drawTopbar(ctx, title);

        int x = cx();
        int w = cw();
        int top = by + 47;
        int bottom = by + PH - 9;
        ctx.enableScissor(x, top, bx + PW - 9, bottom);
        int y = top - scroll;

        for (Module module : visibleModules()) {
            int cardY = y;
            int expanded = expandedHeight(module);
            if (cardY + Math.max(expanded, 28) < top || cardY > bottom) {
                y += 29 + expanded + 5;
                continue;
            }

            boolean hover = inside(mx, my, x, cardY, w, 28);
            Widget.roundRect(ctx, x, cardY, x + w, cardY + 28, hover ? HOVER : CARD, 6);
            boolean hasSettings = hasSettings(module);
            ctx.drawText(textRenderer, Text.literal(hasSettings ? "▸" : "·"), x + 9, cardY + 9, Objects.equals(expandedId, module.id()) ? ACCENT : 0xFF6E7078, false);
            ctx.drawText(textRenderer, Text.literal(module.name()), x + 24, cardY + 9, 0xFFEDEDED, false);

            int keyX = x + w - 94;
            Widget.roundRect(ctx, keyX, cardY + 6, keyX + 48, cardY + 22, 0xFF1A1A24, 4);
            String key = module.id().equals(bindingCapture) ? "[...]" : keyName(module.keyCode());
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(key), keyX + 24, cardY + 10, 0xFFFF6B9D);
            Widget.toggle(ctx, x + w - 37, cardY + 8, module.enabled(), module.enabled() ? 1 : 0);

            if (expanded > 0 && Objects.equals(expandedId, module.id())) {
                int ey = cardY + 29;
                Widget.roundRect(ctx, x, ey, x + w, ey + expanded, PANEL, 4);
                drawModuleSettings(ctx, module, x + 10, ey + 6, w - 20);
            }
            y += 29 + expanded + 5;
        }

        ctx.disableScissor();
    }

    private void drawModuleSettings(DrawContext ctx, Module module, int x, int y, int w) {
        if (module instanceof AimAssist aim) {
            slider(ctx, "aim.speed", "Speed", aim.speed(), 0.1, 1.0, x, y, w);
            slider(ctx, "aim.range", "Range", aim.range(), 2.0, 8.0, x, y + 39, w);
            dropdown(ctx, "aim.target_type", "Target Type", aim.targetType(), new String[]{"Players", "Entities", "Both"}, x, y + 78, w);
        } else if (module instanceof ShieldBreaker shieldBreaker) {
            slider(ctx, "shield_breaker.cooldown", "Cooldown", shieldBreaker.cooldown(), 0, 500, x, y, w);
        }
    }

    private void slider(DrawContext ctx, String id, String label, double value, double min, double max, int x, int y, int w) {
        Widget.slider(ctx, textRenderer, label, x, y, w, value, min, max, format(value));
        controls.add(new Control("slider", id, x, y + 12, w, 22, null));
    }

    private void dropdown(DrawContext ctx, String id, String label, String value, String[] options, int x, int y, int w) {
        boolean open = id.equals(dropdownOpenId);
        Widget.dropdown(ctx, textRenderer, label, x, y, w, value, open);
        controls.add(new Control("dropdown", id, x, y + 11, w, 19, null));
        if (open) {
            for (int i = 0; i < options.length; i++) {
                int oy = y + 32 + i * 16;
                boolean selected = options[i].equals(value);
                Widget.roundRect(ctx, x, oy, x + w, oy + 16, selected ? ACCENT : CARD, 2);
                ctx.drawText(textRenderer, Text.literal(options[i]), x + 6, oy + 4, selected ? 0xFFFFFFFF : 0xFFEDEDED, false);
                controls.add(new Control("option", id, x, oy, w, 16, options[i]));
            }
        }
    }

    private List<Module> visibleModules() {
        List<Module> modules = new ArrayList<>();
        String query = search.toLowerCase(Locale.ROOT);
        for (Module module : ModuleManager.in(category)) {
            if (!query.isBlank() && !module.name().toLowerCase(Locale.ROOT).contains(query)) continue;
            modules.add(module);
        }
        return modules;
    }

    private boolean hasSettings(Module module) {
        return module instanceof AimAssist || module instanceof ShieldBreaker;
    }

    private int expandedHeight(Module module) {
        if (module instanceof AimAssist) return dropdownOpenId != null && dropdownOpenId.equals("aim.target_type") ? 171 : 123;
        if (module instanceof ShieldBreaker) return 39;
        return 0;
    }

    private int maxScroll() {
        int total = 0;
        for (Module module : visibleModules()) total += 29 + expandedHeight(module) + 5;
        return Math.max(0, total - (PH - 56));
    }

    private void setSlider(Control control, double mouseX) {
        double p = Math.max(0, Math.min(1, (mouseX - control.x) / (double) control.w));
        double[] bounds = sliderBounds(control.id);
        applySlider(control.id, bounds[0] + (bounds[1] - bounds[0]) * p);
    }

    private void applySlider(String id, double value) {
        switch (id) {
            case "aim.speed" -> ModuleManager.aimAssist().setSpeed(value);
            case "aim.range" -> ModuleManager.aimAssist().setRange(value);
            case "shield_breaker.cooldown" -> ModuleManager.shieldBreaker().setCooldown((int) Math.round(value));
            default -> {
            }
        }
    }

    private double[] sliderBounds(String id) {
        return switch (id) {
            case "aim.speed" -> new double[]{0.1, 1.0};
            case "aim.range" -> new double[]{2.0, 8.0};
            case "shield_breaker.cooldown" -> new double[]{0, 500};
            default -> new double[]{0, 1};
        };
    }

    private double sliderValue(String id) {
        return switch (id) {
            case "aim.speed" -> ModuleManager.aimAssist().speed();
            case "aim.range" -> ModuleManager.aimAssist().range();
            case "shield_breaker.cooldown" -> ModuleManager.shieldBreaker().cooldown();
            default -> 0;
        };
    }

    private void snapSlider(String id) {
        double step = switch (id) {
            case "shield_breaker.cooldown" -> 1;
            default -> 0.01;
        };
        if (step > 0) applySlider(id, Math.round(sliderValue(id) / step) * step);
        R1zzConfig.save();
    }

    private void setDropdown(String id, String option) {
        if (option == null) return;
        if (id.equals("aim.target_type")) ModuleManager.aimAssist().setTargetType(option);
        R1zzConfig.save();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            if (!settingsOpen && maxScroll() > 0 && inside(mx, my, bx + PW - 11, by + 47, 9, PH - 56)) {
                scrollDrag = true;
                return true;
            }

            for (int i = 0; i < CATEGORIES.length; i++) {
                int y = by + 42 + i * 37;
                if (inside(mx, my, bx + 5, y, SW - 10, 33)) {
                    category = CATEGORIES[i];
                    settingsOpen = false;
                    scroll = 0;
                    expandedId = null;
                    dropdownOpenId = null;
                    categoryFade = 3;
                    return true;
                }
            }

            int gy = by + PH - 39;
            if (inside(mx, my, bx + 5, gy, SW - 10, 28)) {
                settingsOpen = !settingsOpen;
                scroll = 0;
                return true;
            }

            int sx = bx + PW - 181;
            int sy2 = by + 9;
            if (!settingsOpen && inside(mx, my, sx, sy2, 171, 24)) {
                searchCapture = true;
                return true;
            }

            if (settingsOpen) {
                if (SettingsPanel.click(this, mx, my, cx(), by + 52)) return true;
            } else if (inside(mx, my, cx(), by + 47, cw(), PH - 56)) {
                for (Control control : controls) {
                    if (!inside(mx, my, control.x, control.y, control.w, control.h)) continue;
                    if (control.kind.equals("slider")) {
                        dragId = control.id;
                        setSlider(control, mx);
                        return true;
                    }
                    if (control.kind.equals("dropdown")) {
                        dropdownOpenId = control.id.equals(dropdownOpenId) ? null : control.id;
                        return true;
                    }
                    if (control.kind.equals("option")) {
                        setDropdown(control.id, control.option);
                        dropdownOpenId = null;
                        return true;
                    }
                }

                for (Module module : visibleModules()) {
                    int cardY = moduleCardY(module);
                    if (!inside(mx, my, cx(), cardY, cw(), 28)) continue;
                    int localX = (int) mx - cx();
                    if (localX >= cw() - 38) {
                        module.toggle();
                        return true;
                    }
                    if (localX >= cw() - 98) {
                        beginBinding(module.id());
                        return true;
                    }
                    if (hasSettings(module)) {
                        expandedId = module.id().equals(expandedId) ? null : module.id();
                        dropdownOpenId = null;
                    }
                    return true;
                }
            }
        } else if (button == 1) {
            for (Module module : visibleModules()) {
                int cardY = moduleCardY(module);
                if (inside(mx, my, cx() + cw() - 94, cardY, 48, 28)) {
                    module.setKeyCode(-1);
                    return true;
                }
            }
        }

        return super.mouseClicked(mx, my, button);
    }

    private int moduleCardY(Module target) {
        int y = by + 47 - scroll;
        for (Module module : visibleModules()) {
            if (module == target) return y;
            y += 29 + expandedHeight(module) + 5;
        }
        return y;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && scrollDrag) {
            double ratio = (my - (by + 47)) / (double) Math.max(1, PH - 56);
            scroll = (int) Math.round(Math.max(0, Math.min(1, ratio)) * maxScroll());
            return true;
        }
        if (button == 0 && dragId != null) {
            for (Control control : controls) {
                if (control.id.equals(dragId) && control.kind.equals("slider")) {
                    setSlider(control, mx);
                    return true;
                }
            }
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0) {
            scrollDrag = false;
            if (dragId != null) {
                snapSlider(dragId);
                dragId = null;
            }
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (vertical == 0) return false;
        for (Control control : controls) {
            if (control.kind.equals("slider") && inside(mx, my, control.x, control.y, control.w, control.h)) {
                double[] bounds = sliderBounds(control.id);
                double value = sliderValue(control.id) + (bounds[1] - bounds[0]) * Math.signum(vertical) * 0.05;
                applySlider(control.id, Math.max(bounds[0], Math.min(bounds[1], value)));
                snapSlider(control.id);
                return true;
            }
        }
        if (settingsOpen) return SettingsPanel.scroll(mx, my, vertical);
        if (inside(mx, my, cx(), by + 45, cw(), PH - 54)) {
            scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) (vertical * 24)));
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (friendEntry) {
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) finishFriendEntry();
            else if (key == GLFW.GLFW_KEY_ESCAPE) {
                friendEntry = false;
                textBuffer.setLength(0);
            } else if (key == GLFW.GLFW_KEY_BACKSPACE && textBuffer.length() > 0) {
                textBuffer.deleteCharAt(textBuffer.length() - 1);
            }
            return true;
        }

        if (guiKeyCapture) {
            if (key != GLFW.GLFW_KEY_ESCAPE) R1zzClient.setGuiKey(key);
            guiKeyCapture = false;
            return true;
        }

        if (bindingCapture != null) {
            if (key != GLFW.GLFW_KEY_ESCAPE) {
                Module module = ModuleManager.get(bindingCapture);
                if (module != null) module.setKeyCode(key);
            }
            bindingCapture = null;
            return true;
        }

        if (searchCapture) {
            if (key == GLFW.GLFW_KEY_ESCAPE) searchCapture = false;
            else if (key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) search = search.substring(0, search.length() - 1);
            else if (key == GLFW.GLFW_KEY_ENTER) searchCapture = false;
            return true;
        }

        if (key == GLFW.GLFW_KEY_ESCAPE || key == R1zzClient.guiKey()) {
            close();
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char c, int modifiers) {
        if (friendEntry) {
            if (textBuffer.length() < 48 && !Character.isISOControl(c)) textBuffer.append(c);
            return true;
        }
        if (searchCapture) {
            if (search.length() < 32 && !Character.isISOControl(c)) search += c;
            return true;
        }
        return super.charTyped(c, modifiers);
    }

    private static String format(double value) {
        return value == Math.rint(value)
                ? String.format(Locale.ROOT, "%.0f", value)
                : String.format(Locale.ROOT, "%.2f", value);
    }

    private static String keyName(int key) {
        if (key < 0) return "NONE";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        return net.minecraft.client.util.InputUtil.fromKeyCode(key, 0).getLocalizedText().getString().toUpperCase(Locale.ROOT);
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private static float ease(float t) {
        t = Math.max(0, Math.min(1, t));
        float u = 1 - t;
        return 1 - u * u * u;
    }
}
