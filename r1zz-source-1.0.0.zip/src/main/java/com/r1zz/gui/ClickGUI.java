package com.r1zz.gui;

import com.r1zz.R1zzClient;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.module.ModuleManager;
import com.r1zz.module.modules.AimAssist;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public final class ClickGUI extends Screen {
    private static final int PW = 500, PH = 340, SW = 65;
    private static final int ACCENT = 0xFFFF6B9D;
    private static final int PANEL = 0xFF0A0A0F, CARD = 0xFF14141C, HOVER = 0xFF1F1F2A, BORDER = 0xFF1A1A24;
    private static final Module.Category[] CATEGORIES = Module.Category.values();
    private static final String[] ICONS = {"◎", "↗", "◉", "●", "◌", "⚙"};

    private int bx, by;
    private Module.Category category = Module.Category.COMBAT;
    private boolean settingsOpen, searchCapture, friendEntry, guiKeyCapture, draggingSlider;
    private String search = "";
    private String bindingCapture, sliderId, dropdownOpenId;
    private final StringBuilder textBuffer = new StringBuilder();
    private static Identifier bgTexture;
    private static int bgW, bgH;
    private static boolean bgTried;

    public ClickGUI() {
        super(Text.literal("R1zz Client"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    public net.minecraft.client.font.TextRenderer font() {
        return textRenderer;
    }

    public void beginBinding(String id) {
        bindingCapture = id;
        guiKeyCapture = false;
        friendEntry = false;
        searchCapture = false;
    }

    public void beginGuiKeyBinding() {
        bindingCapture = null;
        guiKeyCapture = true;
        friendEntry = false;
    }

    public void beginFriendEntry() {
        friendEntry = true;
        textBuffer.setLength(0);
        bindingCapture = null;
        guiKeyCapture = false;
        searchCapture = false;
    }

    public boolean friendEntryActive() {
        return friendEntry;
    }

    public String friendEntryText() {
        return textBuffer.toString();
    }

    public void finishFriendEntry() {
        String name = textBuffer.toString().trim();
        if (!name.isBlank()) R1zzConfig.addFriend(name);
        friendEntry = false;
        textBuffer.setLength(0);
    }

    private int px() { return (width - PW) / 2; }
    private int py() { return (height - PH) / 2; }
    private int cx() { return bx + SW + 12; }
    private int cw() { return PW - SW - 24; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        bx = px();
        by = py();
        ctx.fill(0, 0, width, height, 0x90000000);
        Widget.roundRect(ctx, bx + 5, by + 5, bx + PW + 5, by + PH + 5, 0x50000000, 7);
        Widget.roundRect(ctx, bx, by, bx + PW, by + PH, PANEL, 6);
        drawBackground(ctx);
        drawSidebar(ctx, mouseX, mouseY);
        if (settingsOpen) {
            drawTopbar(ctx, "Settings");
            SettingsPanel.render(this, ctx, cx(), by + 52, mouseX, mouseY, bindingCapture, guiKeyCapture);
        } else {
            drawCategory(ctx, mouseX, mouseY);
        }
        if (bindingCapture != null || guiKeyCapture || friendEntry || searchCapture) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Press key / enter text · Esc cancels"), bx + PW / 2, by + PH - 15, ACCENT);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    private static void ensureBackground() {
        if (bgTried) return;
        bgTried = true;
        MinecraftClient mc = MinecraftClient.getInstance();
        try (java.io.InputStream in = mc.getResourceManager().open(Identifier.of("r1zz", "gui/luffy.png"))) {
            NativeImage image = NativeImage.read(in);
            bgW = image.getWidth();
            bgH = image.getHeight();
            bgTexture = Identifier.of("r1zz", "dynamic/luffy_bg");
            mc.getTextureManager().registerTexture(bgTexture, new NativeImageBackedTexture(image));
        } catch (Exception ignored) {
            bgTexture = null;
        }
    }

    private void drawBackground(DrawContext ctx) {
        ensureBackground();
        if (bgTexture == null || bgW <= 0 || bgH <= 0) return;
        int regionW = Math.min(bgW, Math.max(1, (int) (bgW * 0.9f)));
        int regionH = Math.min(bgH, Math.max(1, (int) (regionW * (PH / (float) PW))));
        int u = Math.max(0, (bgW - regionW) / 2);
        int v = Math.max(0, (bgH - regionH) / 2);
        ctx.enableScissor(bx + 1, by + 1, bx + PW - 1, by + PH - 1);
        ctx.drawTexture(bgTexture, bx, by, PW, PH, u, v, regionW, regionH, bgW, bgH);
        ctx.disableScissor();
    }

    private void drawSidebar(DrawContext ctx, int mx, int my) {
        ctx.fill(bx + 1, by + 1, bx + SW, by + PH - 1, 0xB0050508);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("R1ZZ"), bx + SW / 2, by + 14, 0xFFFFFFFF);
        ctx.fill(bx + 18, by + 26, bx + SW - 18, by + 27, ACCENT);
        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = by + 42 + i * 37;
            boolean active = !settingsOpen && category == CATEGORIES[i];
            boolean hover = inside(mx, my, bx + 5, y, SW - 10, 33);
            if (active || hover) Widget.roundRect(ctx, bx + 6, y, bx + SW - 5, y + 31, active ? CARD : HOVER, 5);
            if (active) ctx.fill(bx + 2, y + 4, bx + 5, y + 27, ACCENT);
            String label = switch (CATEGORIES[i]) {
                case COMBAT -> "Combat";
                case MOVEMENT -> "Move";
                case RENDER -> "Render";
                case PLAYER -> "Player";
                case WORLD -> "World";
                case MISC -> "Misc";
            };
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(ICONS[i]), bx + SW / 2, y + 2, active ? ACCENT : 0xFF6E7078);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(label), bx + SW / 2, y + 16, active ? ACCENT : 0xFF6E7078);
        }
        int gy = by + PH - 39;
        if (settingsOpen || inside(mx, my, bx + 6, gy, SW - 12, 28)) Widget.roundRect(ctx, bx + 6, gy, bx + SW - 5, gy + 27, settingsOpen ? CARD : HOVER, 5);
        if (settingsOpen) ctx.fill(bx + 2, gy + 3, bx + 5, gy + 24, ACCENT);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("⚙ Settings"), bx + SW / 2, gy + 9, settingsOpen ? ACCENT : 0xFF6E7078);
    }

    private void drawTopbar(DrawContext ctx, String title) {
        ctx.drawText(textRenderer, Text.literal(title), cx(), by + 11, 0xFFFFFFFF, false);
        if (!settingsOpen) {
            int sx = bx + PW - 181, sy = by + 9;
            Widget.roundRect(ctx, sx, sy, sx + 171, sy + 24, CARD, 5);
            String value = searchCapture ? search + "_" : search.isEmpty() ? "Search modules..." : search;
            ctx.drawText(textRenderer, Text.literal(value), sx + 8, sy + 8, searchCapture ? 0xFFFFFFFF : 0xFF6E7078, false);
        }
        ctx.fill(cx(), by + 39, bx + PW - 10, by + 40, BORDER);
    }

    private void drawCategory(DrawContext ctx, int mx, int my) {
        drawTopbar(ctx, category.name().substring(0, 1) + category.name().substring(1).toLowerCase(Locale.ROOT));
        int x = cx(), w = cw(), y = by + 47;
        for (Module module : ModuleManager.in(category)) {
            if (!search.isBlank() && !module.name().toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))) continue;
            drawModuleCard(ctx, module, x, y, w, mx, my);
            y += module instanceof AimAssist ? 142 : 34;
        }
        if (ModuleManager.in(category).isEmpty()) {
            ctx.drawText(textRenderer, Text.literal("No modules registered in this category."), x + 8, y + 8, 0xFF6E7078, false);
        }
    }

    private void drawModuleCard(DrawContext ctx, Module module, int x, int y, int w, int mx, int my) {
        boolean hover = inside(mx, my, x, y, w, 28);
        Widget.roundRect(ctx, x, y, x + w, y + 28, hover ? HOVER : CARD, 6);
        ctx.drawText(textRenderer, Text.literal(module.name()), x + 12, y + 9, 0xFFEDEDED, false);
        Widget.roundRect(ctx, x + w - 94, y + 6, x + w - 46, y + 22, 0xFF1A1A24, 4);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(module.id().equals(bindingCapture) ? "[...]" : keyName(module.keyCode())), x + w - 70, y + 10, ACCENT);
        Widget.toggle(ctx, x + w - 37, y + 8, module.enabled(), module.enabled() ? 1f : 0f);
        if (module instanceof AimAssist aim) {
            int sy = y + 34;
            Widget.slider(ctx, textRenderer, "Speed", x + 10, sy, w - 20, aim.speed(), 0.1, 1.0, format(aim.speed()));
            Widget.slider(ctx, textRenderer, "Range", x + 10, sy + 34, w - 20, aim.range(), 2.0, 8.0, format(aim.range()));
            Widget.dropdown(ctx, textRenderer, "Target Type", x + 10, sy + 68, w - 20, aim.targetType(), dropdownOpenId != null && dropdownOpenId.equals("aim.target_type"));
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        if (settingsOpen) {
            if (SettingsPanel.click(this, mx, my, cx(), by + 52)) return true;
        }
        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = by + 42 + i * 37;
            if (inside(mx, my, bx + 5, y, SW - 10, 33)) {
                category = CATEGORIES[i];
                settingsOpen = false;
                dropdownOpenId = null;
                return true;
            }
        }
        int gy = by + PH - 39;
        if (inside(mx, my, bx + 5, gy, SW - 10, 28)) {
            settingsOpen = !settingsOpen;
            return true;
        }
        if (!settingsOpen) {
            int sx = bx + PW - 181, sy = by + 9;
            if (inside(mx, my, sx, sy, 171, 24)) {
                searchCapture = true;
                return true;
            }
            int x = cx(), w = cw(), y = by + 47;
            for (Module module : ModuleManager.in(category)) {
                if (!search.isBlank() && !module.name().toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))) continue;
                if (inside(mx, my, x, y, w, 28)) {
                    if (mx >= x + w - 38) module.toggle();
                    else if (mx >= x + w - 100) beginBinding(module.id());
                    else if (module instanceof AimAssist && my >= y + 34 && my < y + 68) {
                        sliderId = "aim.speed";
                        draggingSlider = true;
                        setSliderFromMouse((AimAssist) module, mx, x + 10, w - 20, "aim.speed");
                    } else if (module instanceof AimAssist && my >= y + 68 && my < y + 102) {
                        sliderId = "aim.range";
                        draggingSlider = true;
                        setSliderFromMouse((AimAssist) module, mx, x + 10, w - 20, "aim.range");
                    } else if (module instanceof AimAssist && my >= y + 102 && my < y + 135) {
                        dropdownOpenId = "aim.target_type";
                    } else {
                        dropdownOpenId = null;
                    }
                    return true;
                }
                if (module instanceof AimAssist && "aim.target_type".equals(dropdownOpenId)) {
                    int sy = y + 102;
                    if (inside(mx, my, x + 10, sy + 30, w - 20, 48)) {
                        int index = Math.max(0, Math.min(2, (int) ((my - sy - 30) / 16)));
                        ((AimAssist) module).setTargetType(new String[]{"Players", "Entities", "Both"}[index]);
                        dropdownOpenId = null;
                        return true;
                    }
                }
                y += module instanceof AimAssist ? 142 : 34;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    private void setSliderFromMouse(AimAssist aim, double mx, int x, int w, String id) {
        double p = Math.max(0.0, Math.min(1.0, (mx - x) / (double) w));
        if (id.equals("aim.speed")) aim.setSpeed(0.1 + p * 0.9);
        else aim.setRange(2.0 + p * 6.0);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && draggingSlider && sliderId != null) {
            AimAssist aim = ModuleManager.aimAssist();
            if (aim != null) setSliderFromMouse(aim, mx, cx() + 10, cw() - 20, sliderId);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0) {
            draggingSlider = false;
            sliderId = null;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (friendEntry) {
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) finishFriendEntry();
            else if (key == GLFW.GLFW_KEY_ESCAPE) { friendEntry = false; textBuffer.setLength(0); }
            else if (key == GLFW.GLFW_KEY_BACKSPACE && textBuffer.length() > 0) textBuffer.deleteCharAt(textBuffer.length() - 1);
            return true;
        }
        if (guiKeyCapture) {
            if (key != GLFW.GLFW_KEY_ESCAPE) R1zzClient.setGuiKey(key);
            guiKeyCapture = false;
            return true;
        }
        if (bindingCapture != null) {
            if (key != GLFW.GLFW_KEY_ESCAPE) {
                Module module = ModuleManager.get(bindingCapture);
                if (module != null) module.setKeyCode(key);
            }
            bindingCapture = null;
            return true;
        }
        if (searchCapture) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER) searchCapture = false;
            else if (key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) search = search.substring(0, search.length() - 1);
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE || key == R1zzClient.guiKey()) {
            close();
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (friendEntry) {
            if (textBuffer.length() < 48 && !Character.isISOControl(chr)) textBuffer.append(chr);
            return true;
        }
        if (searchCapture) {
            if (search.length() < 32 && !Character.isISOControl(chr)) search += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private static String keyName(int key) {
        if (key < 0) return "NONE";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        return net.minecraft.client.util.InputUtil.fromKeyCode(key, 0).getLocalizedText().getString().toUpperCase(Locale.ROOT);
    }

    private static String format(double value) {
        return value == Math.rint(value) ? String.format(Locale.ROOT, "%.0f", value) : String.format(Locale.ROOT, "%.2f", value);
    }
}
