package com.r1zz.gui;

import com.r1zz.R1zzClient;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.module.ModuleManager;
import com.r1zz.module.modules.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public final class ClickGUI extends Screen {
    private static final int PW=500,PH=340,SW=65,ACCENT=0xFF6B7CFF;
    private static final Module.Category[] CATEGORIES=Module.Category.values();
    private static final String[] CATEGORY_ICONS={"◎","↗","◉","●","◌","⚙"};
    private final Map<String,Float> toggleProgress=new HashMap<>(),hoverProgress=new HashMap<>(),expandProgress=new HashMap<>();
    private final List<Card> cards=new ArrayList<>();private final List<Control> controls=new ArrayList<>();
    private int openTicks,scroll,categoryFade;private Module.Category category=Module.Category.COMBAT;
    private boolean settingsOpen,searchCapture,friendEntry,guiKeyCapture,suffixCapture;
    private String search="",bindingCapture,expandedId,dropdownOpenId,colorPickerId,dragId;
    private final StringBuilder textBuffer=new StringBuilder();private int bx,by;
    private record Card(Module module,int x,int y,int w,int h,int expandedHeight){}
    private record Control(String kind,String id,int x,int y,int w,int h,String option){}
    public ClickGUI(){super(Text.literal("R1zz Client"));}
    @Override public boolean shouldPause(){return false;}
    public net.minecraft.client.font.TextRenderer font(){return textRenderer;}
    public void beginBinding(String id){bindingCapture=id;guiKeyCapture=false;friendEntry=false;suffixCapture=false;searchCapture=false;}
    public void beginGuiKeyBinding(){bindingCapture=null;guiKeyCapture=true;friendEntry=false;suffixCapture=false;}
    public void beginFriendEntry(){friendEntry=true;textBuffer.setLength(0);bindingCapture=null;guiKeyCapture=false;suffixCapture=false;}
    public boolean friendEntryActive(){return friendEntry;}
    public String friendEntryText(){return textBuffer.toString();}
    public void finishFriendEntry(){String n=textBuffer.toString().trim();if(!n.isBlank())R1zzConfig.addFriend(n);friendEntry=false;textBuffer.setLength(0);}
    private void finishSuffixEntry(){Module m=ModuleManager.get("chat_suffix");if(m instanceof ChatSuffix c)c.setSuffix(textBuffer.toString());R1zzConfig.save();suffixCapture=false;textBuffer.setLength(0);}
    private int px(){return(width-PW)/2;}private int py(){return(height-PH)/2;}private int cx(){return bx+SW+12;}private int cw(){return PW-SW-24;}

    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta){
        bx=px();by=py();cards.clear();controls.clear();openTicks=Math.min(5,openTicks+1);
        for(Module m:ModuleManager.in(category)){float p=expandProgress.getOrDefault(m.id(),0f),target=Objects.equals(expandedId,m.id())?1f:0f;expandProgress.put(m.id(),moveToward(p,target,.25f));}
        scroll=Math.min(scroll,maxScroll());
        ctx.fill(0,0,width,height,0x90000000);float scale=.9f+.1f*ease(Math.min(1,openTicks/5f));ctx.getMatrices().push();ctx.getMatrices().translate(width/2.0,height/2.0,0);ctx.getMatrices().scale(scale,scale,1);ctx.getMatrices().translate(-width/2.0,-height/2.0,0);
        Widget.roundRect(ctx,bx+5,by+5,bx+PW+5,by+PH+5,0x50000000,7);Widget.roundRect(ctx,bx,by,bx+PW,by+PH,0xF01A1C22,6);ctx.fill(bx,by,bx+1,by+PH,0xFF2A2D35);ctx.fill(bx+PW-1,by,bx+PW,by+PH,0xFF2A2D35);ctx.fill(bx,by,bx+PW,by+1,0xFF2A2D35);ctx.fill(bx,by+PH-1,bx+PW,by+PH,0xFF2A2D35);
        drawSidebar(ctx,mouseX,mouseY);
        if(settingsOpen){drawTopbar(ctx,"Settings");SettingsPanel.render(this,ctx,cx(),by+52,mouseX,mouseY,bindingCapture,guiKeyCapture);}
        else drawCategory(ctx,mouseX,mouseY);
        if(colorPickerId!=null)drawColorPicker(ctx);
        if(bindingCapture!=null||guiKeyCapture||friendEntry||suffixCapture)ctx.drawCenteredTextWithShadow(textRenderer,Text.literal("Press key / enter text · Esc cancels"),bx+PW/2,by+PH-15,ACCENT);
        if(categoryFade>0&&!settingsOpen){ctx.fill(cx(),by+40,bx+PW-8,by+PH-8,((categoryFade*25/3)<<24));categoryFade--;}
        ctx.getMatrices().pop();super.render(ctx,mouseX,mouseY,delta);
    }
    private void drawSidebar(DrawContext ctx,int mx,int my){
        ctx.fill(bx+1,by+1,bx+SW,by+PH-1,0xFF14161B);ctx.drawCenteredTextWithShadow(textRenderer,Text.literal("R1ZZ"),bx+SW/2,by+14,0xFFFFFFFF);
        for(int i=0;i<CATEGORIES.length;i++){int y=by+42+i*37;boolean active=!settingsOpen&&category==CATEGORIES[i],hover=inside(mx,my,bx+5,y,SW-10,33);if(active||hover)Widget.roundRect(ctx,bx+6,y,bx+SW-5,y+31,active?0xFF20232B:0xFF1B1E25,5);if(active)ctx.fill(bx+2,y+4,bx+5,y+27,ACCENT);String label=switch(CATEGORIES[i]){case MOVEMENT->"Move";case RENDER->"Render";case PLAYER->"Player";case WORLD->"World";case MISC->"Misc";default->"Combat";};ctx.drawCenteredTextWithShadow(textRenderer,Text.literal(CATEGORY_ICONS[i]),bx+SW/2,y+2,active?ACCENT:0xFFA8AAB0);ctx.drawCenteredTextWithShadow(textRenderer,Text.literal(label),bx+SW/2,y+16,active?0xFFFFFFFF:0xFF8C8F98);}
        int gy=by+PH-39;boolean gh=inside(mx,my,bx+6,gy,SW-12,28);if(settingsOpen||gh)Widget.roundRect(ctx,bx+6,gy,bx+SW-5,gy+27,settingsOpen?0xFF20232B:0xFF1B1E25,5);if(settingsOpen)ctx.fill(bx+2,gy+3,bx+5,gy+24,ACCENT);ctx.drawCenteredTextWithShadow(textRenderer,Text.literal("⚙ Settings"),bx+SW/2,gy+9,settingsOpen?ACCENT:0xFFA8AAB0);
    }
    private void drawTopbar(DrawContext ctx,String title){
        ctx.getMatrices().push();ctx.getMatrices().translate(cx(),by+11,0);ctx.getMatrices().scale(1.2f,1.2f,1);ctx.drawText(textRenderer,Text.literal(title),0,0,0xFFFFFFFF,false);ctx.getMatrices().pop();
        if(!settingsOpen){int sx=bx+PW-181,sy=by+9;Widget.roundRect(ctx,sx,sy,sx+171,sy+24,0xFF23262E,5);ctx.drawText(textRenderer,Text.literal(searchCapture?search+"_":search.isEmpty()?"Search modules...":search),sx+8,sy+8,searchCapture?0xFFFFFFFF:0xFF6E7078,false);}
        ctx.fill(cx(),by+39,bx+PW-10,by+40,0xFF2A2D35);
    }
    private void drawCategory(DrawContext ctx,int mx,int my){
        String title=category.name().charAt(0)+category.name().substring(1).toLowerCase(Locale.ROOT);drawTopbar(ctx,title);int x=cx(),w=cw(),top=by+47,bottom=by+PH-9;ctx.enableScissor(x,top,bx+PW-9,bottom);int y=top-scroll;
        for(Module m:visibleModules()){
            int h=expandedHeight(m),cardY=y;float hover=hoverProgress.compute(m.id(),(k,v)->moveToward(v==null?0:v,inside(mx,my,x,cardY,w,30)?1:0,.5f));Widget.roundRect(ctx,x,cardY,x+w,cardY+28,blend(0xFF23262E,0xFF2D3039,hover*.55f),6);
            ctx.drawText(textRenderer,Text.literal(hasSettings(m)?"▸":"·"),x+9,cardY+9,Objects.equals(expandedId,m.id())?ACCENT:0xFF6E7078,false);ctx.drawText(textRenderer,Text.literal(m.name()),x+24,cardY+9,0xFFEDEDED,false);
            int keyX=x+w-94;Widget.roundRect(ctx,keyX,cardY+6,keyX+48,cardY+22,0xFF1A1C22,4);ctx.drawCenteredTextWithShadow(textRenderer,Text.literal(m.id().equals(bindingCapture)?"[...]":keyName(m.keyCode())),keyX+24,cardY+10,m.id().equals(bindingCapture)?0xFFFFFFFF:0xFF8C8F98);
            float p=toggleProgress.compute(m.id(),(k,v)->moveToward(v==null?(m.enabled()?1:0):v,m.enabled()?1:0,.25f));Widget.toggle(ctx,x+w-37,cardY+8,m.enabled(),p);cards.add(new Card(m,x,cardY,w,28,h));
            float ep=expandProgress.getOrDefault(m.id(),0f);if(ep>.005f){int full=expandedContentHeight(m);int eh=Math.min(h,full);int ey=cardY+29;Widget.roundRect(ctx,x,ey,x+w,ey+eh,0xFF1E2028,4);ctx.enableScissor(x,ey,x+w,ey+eh);drawSettings(ctx,m,x+10,ey+6,w-20,mx,my);ctx.disableScissor();}
            y+=29+h+5;
        }
        ctx.disableScissor();
    }
    private List<Module> visibleModules(){List<Module> out=new ArrayList<>();String q=search.toLowerCase(Locale.ROOT);for(Module m:ModuleManager.in(category)){if(isChild(m.id()))continue;if(!q.isBlank()&&!m.name().toLowerCase(Locale.ROOT).contains(q))continue;out.add(m);}return out;}
    private static boolean isChild(String id){return id.equals("tag_head")||id.equals("tag_friend_prefix")||id.equals("tag_donation")||id.equals("tag_prefix")||id.equals("tag_suffix");}
    private boolean hasSettings(Module m){return m instanceof AimAssist||m instanceof Velocity||m instanceof ESP||m instanceof Zoom||m instanceof TimeChanger||m instanceof WeatherChanger||m instanceof ChatSuffix||m instanceof VisualToggle v&&(v.hasSlider()||m.id().endsWith("color")||m.id().equals("color_mode")||m.id().equals("tag_elements"));}
    private int expandedHeight(Module m){return(int)Math.round(expandedContentHeight(m)*expandProgress.getOrDefault(m.id(),0f));}
    private int expandedContentHeight(Module m){if(!hasSettings(m))return 0;if(m instanceof AimAssist)return 190+(dropdownOpenId!=null&&dropdownOpenId.startsWith("aim.")?48:0);if(m instanceof Velocity)return 58;if(m instanceof ESP)return 91+("esp.targets".equals(dropdownOpenId)?48:0);if(m instanceof Zoom||m instanceof TimeChanger||m instanceof VisualToggle v&&v.hasSlider())return 33;if(m instanceof WeatherChanger)return 39+("world.weather".equals(dropdownOpenId)?48:0);if(m instanceof ChatSuffix)return 34;if(m instanceof VisualToggle&&m.id().equals("tag_elements"))return 48;if(m instanceof VisualToggle&&m.id().equals("color_mode"))return 39+("visual.color_mode.name".equals(dropdownOpenId)?48:0);if(m instanceof VisualToggle&&m.id().endsWith("color"))return 32;return 0;}
    private void drawSettings(DrawContext ctx,Module m,int x,int y,int w,int mx,int my){
        if(m instanceof AimAssist a){slider(ctx,"aim.speed","Speed",a.speed(),.1,1,x,y,w,28);slider(ctx,"aim.range","Range",a.range(),3,12,x,y+28,w,28);slider(ctx,"aim.noise","Noise",a.noise(),0,2,x,y+56,w,28);slider(ctx,"aim.fov","FOV",a.fov(),30,360,x,y+84,w,28);dropdown(ctx,"aim.target_type","Target Type",a.targetType(),new String[]{"Players","Entities","Both"},x,y+112,w);int second=y+151+("aim.target_type".equals(dropdownOpenId)?48:0);dropdown(ctx,"aim.weapon_filter","Weapon Filter",a.weaponFilter(),new String[]{"Sword Only","Weapon","All Items"},x,second,w);}
        else if(m instanceof Velocity v){slider(ctx,"velocity.horizontal","Horizontal",v.horizontal(),0,100,x,y,w,28);slider(ctx,"velocity.vertical","Vertical",v.vertical(),0,100,x,y+28,w,28);}
        else if(m instanceof ESP e){String[] ids={"box","outline","fill","health"},names={"Box","Outline","Fill","Health bar"};for(int i=0;i<4;i++){int col=i%2,row=i/2,tx=x+col*(w/2),ty=y+row*26;ctx.drawText(textRenderer,Text.literal(names[i]),tx+2,ty+5,0xFFA8AAB0,false);Widget.toggle(ctx,tx+w/2-31,ty+3,e.option(ids[i]),e.option(ids[i])?1:0);controls.add(new Control("espToggle","esp."+ids[i],tx,ty,w/2,24,null));}dropdown(ctx,"esp.targets","Targets",e.targets(),new String[]{"Players","Mobs","Both"},x,y+52,w);}
        else if(m instanceof Zoom z)slider(ctx,"zoom.factor","Zoom factor",z.factor(),2,10,x,y,w,33);
        else if(m instanceof TimeChanger t)slider(ctx,"world.time","Time",t.time(),0,24000,x,y,w,33);
        else if(m instanceof WeatherChanger wc)dropdown(ctx,"world.weather","Weather",wc.weather(),new String[]{"Clear","Rain","Thunder"},x,y,w);
        else if(m instanceof ChatSuffix cs){ctx.drawText(textRenderer,Text.literal("Suffix"),x,y+5,0xFFA8AAB0,false);int fx=x+47;Widget.roundRect(ctx,fx,y,fx+w-47,y+22,0xFF23262E,4);ctx.drawText(textRenderer,Text.literal(suffixCapture?textBuffer+"_":cs.suffix()),fx+6,y+7,0xFFEDEDED,false);controls.add(new Control("suffix","misc.chat_suffix",fx,y,w-47,22,null));}
        else if(m instanceof VisualToggle v&&v.hasSlider())slider(ctx,"visual."+m.id(),m.name(),v.value(),v.min(),v.max(),x,y,w,33);
        else if(m instanceof VisualToggle&&m.id().equals("tag_elements")){String[] ids={"tag_head","tag_friend_prefix","tag_donation","tag_prefix","tag_suffix"},names={"Head","Friend","Donate","Prefix","Suffix"};int sw=w/5;for(int i=0;i<ids.length;i++){int tx=x+i*sw;boolean on=ModuleManager.visual(ids[i]).enabled();ctx.drawCenteredTextWithShadow(textRenderer,Text.literal(names[i]),tx+sw/2,y+4,0xFFA8AAB0);Widget.toggle(ctx,tx+(sw-28)/2,y+22,on,on?1:0);controls.add(new Control("moduleToggle",ids[i],tx,y+19,sw,20,null));}}
        else if(m instanceof VisualToggle&&m.id().equals("color_mode"))dropdown(ctx,"visual.color_mode.name","Color Mode",R1zzConfig.get("visual.color_mode.name","Item"),new String[]{"Item","Player","Friend"},x,y,w);
        else if(m instanceof VisualToggle&&m.id().endsWith("color")){VisualToggle v=(VisualToggle)m;ctx.drawText(textRenderer,Text.literal(String.format(Locale.ROOT,"#%06X",v.color())),x,y+5,0xFF6B7CFF,false);Widget.swatch(ctx,x+w-25,y,v.color());controls.add(new Control("color",m.id(),x,y,w,26,null));}
    }
    private void slider(DrawContext ctx,String id,String label,double value,double min,double max,int x,int y,int w,int rowH){Widget.slider(ctx,textRenderer,label,x,y,w,value,min,max,format(value));controls.add(new Control("slider",id,x,y+12,w,rowH-10,null));}
    private void dropdown(DrawContext ctx,String id,String label,String value,String[] options,int x,int y,int w){boolean open=id.equals(dropdownOpenId);Widget.dropdown(ctx,textRenderer,label,x,y,w,value,open);controls.add(new Control("dropdown",id,x,y+11,w,19,null));if(open){for(int i=0;i<options.length;i++){int oy=y+32+i*16;Widget.roundRect(ctx,x,oy,x+w,oy+16,options[i].equals(value)?0xFF33384A:0xFF23262E,2);ctx.drawText(textRenderer,Text.literal(options[i]),x+6,oy+4,options[i].equals(value)?ACCENT:0xFFEDEDED,false);controls.add(new Control("option",id,x,oy,w,16,options[i]));}}}

    @Override public boolean mouseClicked(double mx,double my,int button){
        if(colorPickerId!=null&&button==0){if(!inside(mx,my,bx+PW-212,by+PH-133,200,120)){colorPickerId=null;return true;}if(inside(mx,my,bx+PW-28,by+PH-130,15,15)){colorPickerId=null;return true;}for(Control c:controls)if(c.kind.equals("rgb")&&inside(mx,my,c.x,c.y,c.w,c.h)){dragId=c.id;setColorChannel(c.id,mx);return true;}return true;}
        if(button==0){for(int i=0;i<CATEGORIES.length;i++){int y=by+42+i*37;if(inside(mx,my,bx+5,y,SW-10,33)){category=CATEGORIES[i];settingsOpen=false;scroll=0;expandedId=null;categoryFade=3;return true;}}
            int gy=by+PH-39;if(inside(mx,my,bx+5,gy,SW-10,28)){settingsOpen=!settingsOpen;scroll=0;return true;}
            int sx=bx+PW-181,sy=by+9;if(!settingsOpen&&inside(mx,my,sx,sy,171,24)){searchCapture=true;return true;}
            if(settingsOpen){if(SettingsPanel.click(this,mx,my,cx(),by+52))return true;}
            else if(inside(mx,my,cx(),by+47,cw(),PH-56)){
                for(Control c:controls){if(!inside(mx,my,c.x,c.y,c.w,c.h))continue;if(c.kind.equals("slider")){dragId=c.id;setSlider(c,mx);return true;}if(c.kind.equals("dropdown")){dropdownOpenId=Objects.equals(dropdownOpenId,c.id)?null:c.id;return true;}if(c.kind.equals("option")){setDropdown(c.id,c.option);dropdownOpenId=null;return true;}if(c.kind.equals("moduleToggle")){Module mm=ModuleManager.get(c.id);if(mm!=null)mm.toggle();return true;}if(c.kind.equals("espToggle")){ESP e=ModuleManager.esp();String id=c.id.substring(4);e.setOption(id,!e.option(id));return true;}if(c.kind.equals("color")){colorPickerId=c.id;return true;}if(c.kind.equals("suffix")){suffixCapture=true;textBuffer.setLength(0);textBuffer.append(((ChatSuffix)ModuleManager.get("chat_suffix")).suffix());return true;}}
                for(Card card:cards)if(inside(mx,my,card.x,card.y,card.w,28)){int local=(int)mx-card.x;if(local>=card.w-38){card.module.toggle();return true;}if(local>=card.w-98){beginBinding(card.module.id());return true;}if(hasSettings(card.module))expandedId=Objects.equals(expandedId,card.module.id())?null:card.module.id();return true;}
            }
        }else if(button==1){for(Card card:cards)if(inside(mx,my,card.x+card.w-94,card.y,48,28)){card.module.setKeyCode(-1);return true;}}
        return super.mouseClicked(mx,my,button);
    }
    @Override public boolean mouseDragged(double mx,double my,int button,double dx,double dy){if(button==0&&dragId!=null){for(Control c:controls)if(c.id.equals(dragId)&&c.kind.equals("slider")){setSlider(c,mx);return true;}if(dragId.startsWith("rgb")){setColorChannel(dragId,mx);return true;}return true;}return super.mouseDragged(mx,my,button,dx,dy);}
    @Override public boolean mouseReleased(double mx,double my,int button){if(button==0&&dragId!=null){snapSlider(dragId);dragId=null;}return super.mouseReleased(mx,my,button);}
    @Override public boolean mouseScrolled(double mx,double my,double horizontal,double vertical){if(vertical==0)return false;for(Control c:controls)if(c.kind.equals("slider")&&inside(mx,my,c.x,c.y,c.w,c.h)){adjustSlider(c.id,Math.signum(vertical)*.05);return true;}if(settingsOpen)return SettingsPanel.scroll(mx,my,vertical);if(inside(mx,my,cx(),by+45,cw(),PH-54)){scroll=Math.max(0,Math.min(maxScroll(),scroll-(int)(vertical*24)));return true;}return super.mouseScrolled(mx,my,horizontal,vertical);}
    @Override public boolean keyPressed(int key,int scan,int modifiers){
        if(friendEntry){if(key==GLFW.GLFW_KEY_ENTER||key==GLFW.GLFW_KEY_KP_ENTER)finishFriendEntry();else if(key==GLFW.GLFW_KEY_ESCAPE){friendEntry=false;textBuffer.setLength(0);}else if(key==GLFW.GLFW_KEY_BACKSPACE&&textBuffer.length()>0)textBuffer.deleteCharAt(textBuffer.length()-1);return true;}
        if(suffixCapture){if(key==GLFW.GLFW_KEY_ENTER||key==GLFW.GLFW_KEY_KP_ENTER)finishSuffixEntry();else if(key==GLFW.GLFW_KEY_ESCAPE){suffixCapture=false;textBuffer.setLength(0);}else if(key==GLFW.GLFW_KEY_BACKSPACE&&textBuffer.length()>0)textBuffer.deleteCharAt(textBuffer.length()-1);return true;}
        if(guiKeyCapture){if(key!=GLFW.GLFW_KEY_ESCAPE)R1zzClient.setGuiKey(key);guiKeyCapture=false;return true;}if(bindingCapture!=null){if(key!=GLFW.GLFW_KEY_ESCAPE){Module m=ModuleManager.get(bindingCapture);if(m!=null)m.setKeyCode(key);}bindingCapture=null;return true;}
        if(searchCapture){if(key==GLFW.GLFW_KEY_ESCAPE)searchCapture=false;else if(key==GLFW.GLFW_KEY_BACKSPACE&&!search.isEmpty())search=search.substring(0,search.length()-1);else if(key==GLFW.GLFW_KEY_ENTER)searchCapture=false;return true;}
        if(key==GLFW.GLFW_KEY_ESCAPE||key==R1zzClient.guiKey()){close();return true;}return super.keyPressed(key,scan,modifiers);
    }
    @Override public boolean charTyped(char c,int modifiers){if(friendEntry||suffixCapture){if(textBuffer.length()<48&&!Character.isISOControl(c))textBuffer.append(c);return true;}if(searchCapture){if(search.length()<32&&!Character.isISOControl(c))search+=c;return true;}return super.charTyped(c,modifiers);}
    private void drawColorPicker(DrawContext ctx){int x=bx+PW-212,y=by+PH-133;Widget.roundRect(ctx,x,y,x+200,y+120,0xFF17191F,6);ctx.fill(x,y,x+200,y+1,0xFF2A2D35);VisualToggle v=ModuleManager.visual(colorPickerId);if(v==null)return;ctx.drawText(textRenderer,Text.literal("RGB · "+colorPickerId),x+8,y+6,0xFFEDEDED,false);Widget.roundRect(ctx,x+8,y+24,x+50,y+42,0xFF000000|v.color(),3);ctx.drawText(textRenderer,Text.literal(String.format(Locale.ROOT,"#%06X",v.color())),x+58,y+29,ACCENT,false);int[] cols={0xFFFF4040,0xFF42D66B,0xFF4C83FF};for(int i=0;i<3;i++){int sy=y+52+i*19;Widget.roundRect(ctx,x+10,sy,x+180,sy+3,0xFF2E323A,2);int val=(v.color()>>(16-i*8))&255;Widget.roundRect(ctx,x+10,sy,x+10+(int)(170*val/255.0),sy+3,cols[i],2);int hx=x+10+(int)(170*val/255.0);Widget.roundRect(ctx,hx-4,sy-2,hx+4,sy+6,0xFFFFFFFF,4);controls.add(new Control("rgb","rgb"+i,x+7,sy-3,176,10,null));}ctx.drawText(textRenderer,Text.literal("×"),x+184,y+5,0xFFFFFFFF,false);}
    private void setColorChannel(String id,double mx){if(colorPickerId==null)return;int i=Integer.parseInt(id.substring(3));double pct=Math.max(0,Math.min(1,(mx-(bx+PW-212+17))/170.0));int value=(int)Math.round(pct*255);VisualToggle m=ModuleManager.visual(colorPickerId);if(m==null)return;int c=m.color();if(i==0)c=(c&0x00FFFF)|(value<<16);else if(i==1)c=(c&0xFF00FF)|(value<<8);else c=(c&0xFFFF00)|value;m.setColor(c);}
    private void setSlider(Control c,double mx){double min,max;switch(c.id){case"aim.speed"->{min=.1;max=1;}case"aim.range"->{min=3;max=12;}case"aim.noise"->{min=0;max=2;}case"aim.fov"->{min=30;max=360;}case"velocity.horizontal","velocity.vertical"->{min=0;max=100;}case"zoom.factor"->{min=2;max=10;}case"world.time"->{min=0;max=24000;}default->{VisualToggle v=ModuleManager.visual(c.id.substring("visual.".length()));min=v.min();max=v.max();}}setValue(c.id,min+Math.max(0,Math.min(1,(mx-c.x)/c.w))*(max-min));}
    private void setValue(String id,double v){switch(id){case"aim.speed"->ModuleManager.aimAssist().setSpeed(v);case"aim.range"->ModuleManager.aimAssist().setRange(v);case"aim.noise"->ModuleManager.aimAssist().setNoise(v);case"aim.fov"->ModuleManager.aimAssist().setFov(v);case"velocity.horizontal"->ModuleManager.velocity().setHorizontal(v);case"velocity.vertical"->ModuleManager.velocity().setVertical(v);case"zoom.factor"->ModuleManager.zoom().setFactor(v);case"world.time"->((TimeChanger)ModuleManager.get("time_changer")).setTime((int)v);default->{if(id.startsWith("visual.")){VisualToggle t=ModuleManager.visual(id.substring(7));if(t!=null)t.setValue(v);}}}}
    private void adjustSlider(String id,double d){switch(id){case"aim.speed"->ModuleManager.aimAssist().setSpeed(ModuleManager.aimAssist().speed()+d);case"aim.range"->ModuleManager.aimAssist().setRange(ModuleManager.aimAssist().range()+d);case"aim.noise"->ModuleManager.aimAssist().setNoise(ModuleManager.aimAssist().noise()+d);case"aim.fov"->ModuleManager.aimAssist().setFov(ModuleManager.aimAssist().fov()+d);case"velocity.horizontal"->ModuleManager.velocity().setHorizontal(ModuleManager.velocity().horizontal()+d);case"velocity.vertical"->ModuleManager.velocity().setVertical(ModuleManager.velocity().vertical()+d);case"zoom.factor"->ModuleManager.zoom().setFactor(ModuleManager.zoom().factor()+d);case"world.time"->((TimeChanger)ModuleManager.get("time_changer")).setTime((int)(((TimeChanger)ModuleManager.get("time_changer")).time()+d*1000));default->{if(id.startsWith("visual.")){VisualToggle t=ModuleManager.visual(id.substring(7));if(t!=null)t.setValue(t.value()+d);}}}}
    private void snapSlider(String id){if(id.equals("aim.speed"))ModuleManager.aimAssist().setSpeed(Math.round(ModuleManager.aimAssist().speed()*20)/20.0);else if(id.equals("aim.range"))ModuleManager.aimAssist().setRange(Math.round(ModuleManager.aimAssist().range()*2)/2.0);else if(id.equals("aim.noise"))ModuleManager.aimAssist().setNoise(Math.round(ModuleManager.aimAssist().noise()*2)/2.0);else if(id.equals("aim.fov"))ModuleManager.aimAssist().setFov(Math.round(ModuleManager.aimAssist().fov()/5)*5);else if(id.equals("zoom.factor"))ModuleManager.zoom().setFactor(Math.round(ModuleManager.zoom().factor()*2)/2.0);else if(id.startsWith("visual.")){VisualToggle v=ModuleManager.visual(id.substring(7));if(v!=null)v.setValue(Math.round(v.value()*2)/2.0);}else if(id.startsWith("velocity.")){Velocity v=ModuleManager.velocity();if(id.endsWith("horizontal"))v.setHorizontal(Math.round(v.horizontal()*2)/2.0);else v.setVertical(Math.round(v.vertical()*2)/2.0);}}
    private void setDropdown(String id,String value){switch(id){case"aim.target_type"->ModuleManager.aimAssist().setTargetType(value);case"aim.weapon_filter"->ModuleManager.aimAssist().setWeaponFilter(value);case"esp.targets"->ModuleManager.esp().setTargets(value);case"world.weather"->((WeatherChanger)ModuleManager.get("weather_changer")).setWeather(value);case"visual.color_mode.name"->{R1zzConfig.put(id,value);R1zzConfig.save();}}}
    private int maxScroll(){int total=0;for(Module m:visibleModules())total+=29+expandedHeight(m)+5;return Math.max(0,total-(PH-56));}
    private static float approach(float a,float b,float t){return a+(b-a)*t;}private static float moveToward(float a,float b,float step){return a<b?Math.min(b,a+step):Math.max(b,a-step);}private static float ease(float x){return 1-(1-x)*(1-x)*(1-x);}
    private static int blend(int a,int b,float t){t=Math.max(0,Math.min(1,t));int r=(int)(((a>>16)&255)*(1-t)+((b>>16)&255)*t),g=(int)(((a>>8)&255)*(1-t)+((b>>8)&255)*t),bl=(int)((a&255)*(1-t)+(b&255)*t);return 0xFF000000|(r<<16)|(g<<8)|bl;}
    private static boolean inside(double mx,double my,int x,int y,int w,int h){return mx>=x&&mx<=x+w&&my>=y&&my<=y+h;}
    private static String format(double v){return Math.abs(v-Math.rint(v))<.001?String.format(Locale.ROOT,"%.0f",v):String.format(Locale.ROOT,"%.2f",v);}
    private static String keyName(int key){if(key<0)return"NONE";if(key==GLFW.GLFW_KEY_RIGHT_SHIFT)return"RSHIFT";if(key==GLFW.GLFW_KEY_LEFT_SHIFT)return"SHIFT";return net.minecraft.client.util.InputUtil.fromKeyCode(key,0).getLocalizedText().getString().toUpperCase(Locale.ROOT);}
    @Override public void close(){R1zzConfig.save();if(client!=null)client.setScreen(null);}
}
