package com.r1zz.gui;

import com.r1zz.R1zzClient;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.module.ModuleManager;
import com.r1zz.module.modules.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public final class ClickGUI extends Screen {
    private static final int PW=500,PH=340,SW=65,ACCENT=0xFFC41E3A;
    private static final int PANEL=0xFF0A0505,SIDEBAR=0xFF050202,BORDER=0xFF3D1A1A,CARD=0xFF150808,HOVER=0xFF1F0E0E;
    private static final Module.Category[] CATEGORIES=Module.Category.values();
    private static final String[] CATEGORY_ICONS={"◎","↗","◉","●","◌","⚙"};
    private final Map<String,Float> toggleProgress=new HashMap<>(),hoverProgress=new HashMap<>(),expandProgress=new HashMap<>();
    private final List<Card> cards=new ArrayList<>();private final List<Control> controls=new ArrayList<>();private final List<Module> visibleCache=new ArrayList<>();
    private int openTicks,scroll,categoryFade;private Module.Category category=Module.Category.COMBAT;
    private boolean settingsOpen,searchCapture,friendEntry,guiKeyCapture,suffixCapture,scrollDrag;
    private String search="",bindingCapture,expandedId,dropdownOpenId,colorPickerId,dragId;
    private final StringBuilder textBuffer=new StringBuilder();private int bx,by;
    private record Card(Module module,int x,int y,int w,int h,int expandedHeight){}
    private record Control(String kind,String id,int x,int y,int w,int h,String option){}
    public ClickGUI(){super(Text.literal("R1zz Client"));}
    @Override public boolean shouldPause(){return false;}
    public net.minecraft.client.font.TextRenderer font(){return textRenderer;}
    public void beginBinding(String id){bindingCapture=id;guiKeyCapture=false;friendEntry=false;suffixCapture=false;searchCapture=false;}
    public void beginGuiKeyBinding(){bindingCapture=null;guiKeyCapture=true;friendEntry=false;suffixCapture=false;}
    public void beginFriendEntry(){friendEntry=true;textBuffer.setLength(0);bindingCapture=null;guiKeyCapture=false;suffixCapture=false;}
    public boolean friendEntryActive(){return friendEntry;}
    public String friendEntryText(){return textBuffer.toString();}
    public void finishFriendEntry(){String n=textBuffer.toString().trim();if(!n.isBlank())R1zzConfig.addFriend(n);friendEntry=false;textBuffer.setLength(0);}
    private void finishSuffixEntry(){Module m=ModuleManager.get("chat_suffix");if(m instanceof ChatSuffix c)c.setSuffix(textBuffer.toString());R1zzConfig.save();suffixCapture=false;textBuffer.setLength(0);}
    private int px(){return(width-PW)/2;}private int py(){return(height-PH)/2;}private int cx(){return bx+SW+12;}private int cw(){return PW-SW-24;}

    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta){
        bx=px();by=py();cards.clear();controls.clear();openTicks=Math.min(5,openTicks+1);
        float animStep=Math.min(1.0f,Math.max(0.0f,delta)*12.0f);for(Module m:ModuleManager.in(category)){float p=expandProgress.getOrDefault(m.id(),0f),target=Objects.equals(expandedId,m.id())?1f:0f;if(Math.abs(p-target)>0.001f)expandProgress.put(m.id(),moveToward(p,target,animStep));}
        scroll=Math.min(scroll,maxScroll());
        ctx.fill(0,0,width,height,0x90000000);float scale=.9f+.1f*ease(Math.min(1,openTicks/5f));ctx.getMatrices().push();ctx.getMatrices().translate(width/2.0,height/2.0,0);ctx.getMatrices().scale(scale,scale,1);ctx.getMatrices().translate(-width/2.0,-height/2.0,0);
        Widget.roundRect(ctx,bx+5,by+5,bx+PW+5,by+PH+5,0x50000000,7);Widget.roundRect(ctx,bx,by,bx+PW,by+PH,PANEL,6);
        ctx.fill(bx,by,bx+1,by+PH,BORDER);ctx.fill(bx+PW-1,by,bx+PW,by+PH,BORDER);ctx.fill(bx,by,bx+PW,by+1,BORDER);ctx.fill(bx,by+PH-1,bx+PW,by+PH,BORDER);
        drawSidebar(ctx,mouseX,mouseY);
        if(settingsOpen){drawTopbar(ctx,"Settings");SettingsPanel.render(this,ctx,cx(),by+52,mouseX,mouseY,bindingCapture,guiKeyCapture);}
        else drawCategory(ctx,mouseX,mouseY);
        if(colorPickerId!=null)drawColorPicker(ctx);
        if(bindingCapture!=null||guiKeyCapture||friendEntry||suffixCapture)ctx.drawCenteredTextWithShadow(textRenderer,Text.literal("Press key / enter text · Esc cancels"),bx+PW/2,by+PH-15,ACCENT);
        if(categoryFade>0&&!settingsOpen){ctx.fill(cx(),by+40,bx+PW-8,by+PH-8,((categoryFade*25/3)<<24));categoryFade--;}
        ctx.getMatrices().pop();super.render(ctx,mouseX,mouseY,delta);
    }

    private void drawSidebar(DrawContext ctx,int mx,int my){
        ctx.fill(bx+1,by+1,bx+SW,by+PH-1,SIDEBAR);
        ctx.drawCenteredTextWithShadow(textRenderer,Text.literal("R1ZZ"),bx+SW/2,by+14,0xFFFFFFFF);
        ctx.fill(bx+18,by+26,bx+SW-18,by+27,ACCENT);
        for(int i=0;i<CATEGORIES.length;i++){
            int y=by+42+i*37;
            boolean active=!settingsOpen&&category==CATEGORIES[i],hover=inside(mx,my,bx+5,y,SW-10,33);
            if(active||hover)Widget.roundRect(ctx,bx+6,y,bx+SW-5,y+31,active?CARD:HOVER,5);
            if(active)ctx.fill(bx+2,y+4,bx+5,y+27,ACCENT);
            String label=switch(CATEGORIES[i]){case MOVEMENT->"Move";case RENDER->"Render";case PLAYER->"Player";case WORLD->"World";case MISC->"Misc";default->"Combat";};
            ctx.drawCenteredTextWithShadow(textRenderer,Text.literal(CATEGORY_ICONS[i]),bx+SW/2,y+2,active?ACCENT:0xFFA8AAB0);
            ctx.drawCenteredTextWithShadow(textRenderer,Text.literal(label),bx+SW/2,y+16,active?0xFFFFFFFF:0xFF8C8F98);
        }
        int gy=by+PH-39;boolean gh=inside(mx,my,bx+6,gy,SW-12,28);
        if(settingsOpen||gh)Widget.roundRect(ctx,bx+6,gy,bx+SW-5,gy+27,settingsOpen?CARD:HOVER,5);
        if(settingsOpen)ctx.fill(bx+2,gy+3,bx+5,gy+24,ACCENT);
        ctx.drawCenteredTextWithShadow(textRenderer,Text.literal("⚙ Settings"),bx+SW/2,gy+9,settingsOpen?ACCENT:0xFFA8AAB0);
    }

    private void drawTopbar(DrawContext ctx,String title){
        ctx.getMatrices().push();ctx.getMatrices().translate(cx(),by+11,0);ctx.getMatrices().scale(1.2f,1.2f,1);
        ctx.drawText(textRenderer,Text.literal(title),0,0,0xFFFFFFFF,false);ctx.getMatrices().pop();
        if(!settingsOpen){int sx=bx+PW-181,sy=by+9;Widget.roundRect(ctx,sx,sy,sx+171,sy+24,CARD,5);ctx.drawText(textRenderer,Text.literal(searchCapture?search+"_":search.isEmpty()?"Search modules...":search),sx+8,sy+8,searchCapture?0xFFFFFFFF:0xFFA8AAB0,false);}
        ctx.fill(cx(),by+39,bx+PW-10,by+40,BORDER);
    }

    private void drawCategory(DrawContext ctx,int mx,int my){
        String title=category.name().charAt(0)+category.name().substring(1).toLowerCase(Locale.ROOT);drawTopbar(ctx,title);
        int x=cx(),w=cw(),top=by+47,bottom=by+PH-9;ctx.enableScissor(x,top,bx+PW-9,bottom);int y=top-scroll;
        for(Module m:visibleModules()){
            int h=expandedHeight(m),cardY=y;
            if(cardY+Math.max(h,28)<top || cardY>bottom){ y+=29+h+5; continue; }
            float oldHover=hoverProgress.getOrDefault(m.id(),0f),targetHover=inside(mx,my,x,cardY,w,30)?1f:0f;float hover=Math.abs(oldHover-targetHover)>0.001f?moveToward(oldHover,targetHover,0.3f):oldHover;if(Math.abs(hover-oldHover)>0.001f)hoverProgress.put(m.id(),hover);
            Widget.roundRect(ctx,x,cardY,x+w,cardY+28,blend(CARD,HOVER,hover*.55f),6);
            ctx.drawText(textRenderer,Text.literal(hasSettings(m)?"▸":"·"),x+9,cardY+9,Objects.equals(expandedId,m.id())?ACCENT:0xFFA8AAB0,false);
            ctx.drawText(textRenderer,Text.literal(m.name()),x+24,cardY+9,0xFFEDEDED,false);
            int keyX=x+w-94;Widget.roundRect(ctx,keyX,cardY+6,keyX+48,cardY+22,0xFF1A0A0A,4);
            ctx.drawCenteredTextWithShadow(textRenderer,Text.literal(m.id().equals(bindingCapture)?"[...]":keyName(m.keyCode())),keyX+24,cardY+10,m.id().equals(bindingCapture)?0xFFFFFFFF:0xFFE0A0A0);
            float oldToggle=toggleProgress.getOrDefault(m.id(),m.enabled()?1f:0f),targetToggle=m.enabled()?1f:0f;float p=Math.abs(oldToggle-targetToggle)>0.001f?moveToward(oldToggle,targetToggle,0.3f):oldToggle;if(Math.abs(p-oldToggle)>0.001f)toggleProgress.put(m.id(),p);
            Widget.toggle(ctx,x+w-37,cardY+8,m.enabled(),p);
            cards.add(new Card(m,x,cardY,w,28,h));
            float ep=expandProgress.getOrDefault(m.id(),0f);
            if(ep>.005f){int full=expandedContentHeight(m);int eh=Math.min(h,full);int ey=cardY+29;Widget.roundRect(ctx,x,ey,x+w,ey+eh,PANEL,4);ctx.enableScissor(x,ey,x+w,ey+eh);drawSettings(ctx,m,x+10,ey+6,w-20,mx,my);ctx.disableScissor();}
            y+=29+h+5;
        }
        ctx.disableScissor();
        drawScrollbar(ctx);
    }

    private void drawScrollbar(DrawContext ctx){
        int max=maxScroll();if(max<=0)return;
        int trackX=bx+PW-8,trackTop=by+47,trackH=PH-56,handleH=scrollHandleHeight(max,trackH);
        Widget.roundRect(ctx,trackX,trackTop,trackX+3,trackTop+trackH,CARD,1);
        int handleY=trackTop+Math.round((trackH-handleH)*(scroll/(float)max));
        Widget.roundRect(ctx,trackX,handleY,trackX+3,handleY+handleH,ACCENT,1);
    }
    private static int scrollHandleHeight(int max,int trackH){return Math.max(16,Math.round(trackH*(trackH/(float)(trackH+max))));}
    private void dragScrollbarTo(double my){
        int max=maxScroll();if(max<=0)return;
        int trackTop=by+47,trackH=PH-56,handleH=scrollHandleHeight(max,trackH);
        double ratio=(my-trackTop-handleH/2.0)/Math.max(1,trackH-handleH);
        scroll=(int)Math.round(Math.max(0,Math.min(1,ratio))*max);
    }

    private List<Module> visibleModules(){visibleCache.clear();String q=search.toLowerCase(Locale.ROOT);for(Module m:ModuleManager.all()){if(m.category()!=category||isChild(m.id()))continue;if(!q.isBlank()&&!m.name().toLowerCase(Locale.ROOT).contains(q))continue;visibleCache.add(m);}return visibleCache;}
    private static boolean isChild(String id){return id.equals("tag_head")||id.equals("tag_friend_prefix")||id.equals("tag_donation")||id.equals("tag_prefix")||id.equals("tag_suffix");}
    private boolean hasSettings(Module m){return !m.id().equals("shield_breaker")&&!m.id().equals("fast_gapple");}
    private int expandedHeight(Module m){return(int)Math.round(expandedContentHeight(m)*expandProgress.getOrDefault(m.id(),0f));}
    private int expandedContentHeight(Module m){if(!hasSettings(m))return 0;if(m instanceof AimAssist)return 190+(dropdownOpenId!=null&&dropdownOpenId.startsWith("aim.")?48:0);if(m instanceof PearlCatch)return 99;if(m instanceof TriggerBot)return 420;if(m instanceof R1zzAssist)return 165;if(m instanceof WaterDrain)return 132;if(m instanceof CobwebPlacer)return 99;if(m instanceof AutoPot)return 33;if(m instanceof AutoCrystal)return 33;if(m instanceof KillAura)return 5*28+48;if(m instanceof AutoClicker)return 56;if(m instanceof Velocity)return 58;if(m instanceof ESP)return 91+("esp.targets".equals(dropdownOpenId)?48:0);if(m instanceof Zoom||m instanceof TimeChanger||m instanceof VisualToggle v&&v.hasSlider())return 33;if(m instanceof WeatherChanger)return 39+("world.weather".equals(dropdownOpenId)?48:0);if(m instanceof ChatSuffix)return 34;if(m instanceof VisualToggle&&m.id().equals("tag_elements"))return 48;if(m instanceof VisualToggle&&m.id().equals("color_mode"))return 39+("visual.color_mode.name".equals(dropdownOpenId)?48:0);if(m instanceof VisualToggle&&m.id().endsWith("color"))return 32;return 33;}

    private void toggleRow(DrawContext ctx,String id,String label,boolean value,int x,int y,int w,String kind){
        ctx.drawText(textRenderer,Text.literal(label),x,y+7,0xFFA8AAB0,false);
        Widget.toggle(ctx,x+w-34,y+4,value,value?1:0);
        controls.add(new Control(kind,id,x,y,w,28,null));
    }

    private void drawSettings(DrawContext ctx,Module m,int x,int y,int w,int mx,int my){
        if(m instanceof AimAssist a){
            slider(ctx,"aim.speed","Speed",a.speed(),.1,1,x,y,w,28);
            slider(ctx,"aim.range","Range",a.range(),3,12,x,y+28,w,28);
            slider(ctx,"aim.noise","Noise",a.noise(),0,2,x,y+56,w,28);
            slider(ctx,"aim.fov","FOV",a.fov(),30,360,x,y+84,w,28);
            dropdown(ctx,"aim.target_type","Target Type",a.targetType(),new String[]{"Players","Entities","Both"},x,y+112,w);
            int second=y+151+("aim.target_type".equals(dropdownOpenId)?48:0);
            dropdown(ctx,"aim.weapon_filter","Weapon Filter",a.weaponFilter(),new String[]{"Sword Only","Weapon","All Items"},x,second,w);
        }
        else if(m instanceof PearlCatch p){slider(ctx,"pearl_catch.window","Window",p.window(),10,40,x,y,w,33); toggleRow(ctx,"pearl_catch.auto_aim","Auto-aim",p.autoAim(),x,y+33,w,"pearlAutoAim"); slider(ctx,"pearl_catch.delay","Delay",p.delay(),0,5,x,y+66,w,33);}
        else if(m instanceof R1zzAssist a){slider(ctx,"r1zz_assist.range","Range",a.range(),2.5,6,x,y,w,33);slider(ctx,"r1zz_assist.speed","Speed",a.speed(),.1,1,x,y+33,w,33);dropdown(ctx,"r1zz_assist.target_type","Target Type",a.targetType(),new String[]{"Players","Entities","Both"},x,y+66,w);slider(ctx,"r1zz_assist.delay","Delay",a.delay(),0,500,x,y+99,w,33);}
        else if(m instanceof WaterDrain d){slider(ctx,"water_drain.range","Range",d.range(),1,5,x,y,w,33);slider(ctx,"water_drain.cooldown","Cooldown",d.cooldown(),100,500,x,y+33,w,33);dropdown(ctx,"water_drain.target","Target",d.target(),new String[]{"Water","Lava","Both"},x,y+66,w);toggleRow(ctx,"waterDrainAuto","Auto Switch",d.autoSwitch(),x,y+105,w,"waterDrainAuto");}
        else if(m instanceof CobwebPlacer c){slider(ctx,"cobweb_placer.range","Range",c.range(),1,4,x,y,w,33);slider(ctx,"cobweb_placer.cooldown","Cooldown",c.cooldown(),100,500,x,y+33,w,33);toggleRow(ctx,"cobweb_placer.auto_switch","Auto Switch",c.autoSwitch(),x,y+66,w,"cobwebAuto");}
        else if(m instanceof TriggerBot t){
            dropdown(ctx,"trigger_bot.hit_mode","Hit Mode",t.hitMode(),new String[]{"Prioritize crits","Prioritize damage","Normal"},x,y,w);
            int y1=y+39+("trigger_bot.hit_mode".equals(dropdownOpenId)?48:0);
            dropdown(ctx,"trigger_bot.reach","Reach",t.reachMode(),new String[]{"Default","3.0","3.5","4.0"},x,y1,w);
            int y2=y1+39+("trigger_bot.reach".equals(dropdownOpenId)?48:0);
            slider(ctx,"trigger_bot.miss_chance","Miss Chance",t.missChance(),0,50,x,y2,w,33);
            int y3=y2+33;
            toggleRow(ctx,"trigger_bot.when_use_hand","When use hand",t.whenUseHand(),x,y3,w,"triggerBotWhenUse");
            toggleRow(ctx,"trigger_bot.simulate_clicks","Simulate clicks",t.simulateClicks(),x,y3+33,w,"triggerBotSim");
            toggleRow(ctx,"trigger_bot.only_weapon","Only weapon",t.onlyWeapon(),x,y3+66,w,"triggerBotWeapon");
            toggleRow(ctx,"trigger_bot.anti_zombie_bot","Anti zombie bot",t.antiZombieBot(),x,y3+99,w,"triggerBotZombie");
            toggleRow(ctx,"trigger_bot.ignore_shield","Ignore shield",t.ignoreShield(),x,y3+132,w,"triggerBotShield");
            toggleRow(ctx,"trigger_bot.focus_mode","Focus mode",t.focusMode(),x,y3+165,w,"triggerBotFocus");
            slider(ctx,"trigger_bot.delay","Delay",t.delay(),0,500,x,y3+198,w,33);
        }
        else if(m instanceof AutoPot ap){slider(ctx,"auto_pot.hp_threshold","HP Threshold",ap.hpThreshold(),1,20,x,y,w,33);}
        else if(m instanceof AutoCrystal ac){slider(ctx,"auto_crystal.range","Range",ac.range(),3,6,x,y,w,33);}
        else if(m instanceof KillAura ka){
            slider(ctx,"kill_aura.range","Range",ka.range(),2.5,6,x,y,w,28);
            slider(ctx,"kill_aura.cps","CPS",ka.cps(),1,20,x,y+28,w,28);
            dropdown(ctx,"kill_aura.rotation","Rotation",ka.rotation(),new String[]{"None","Smooth","Snap"},x,y+56,w);
            int ky=y+95+("kill_aura.rotation".equals(dropdownOpenId)?48:0);
            dropdown(ctx,"kill_aura.target","Target",ka.target(),new String[]{"Players","Entities","Both"},x,ky,w);
            int sy=ky+39+("kill_aura.target".equals(dropdownOpenId)?48:0);
            ctx.drawText(textRenderer,Text.literal("Swing Only"),x,sy+5,0xFFA8AAB0,false);
            Widget.toggle(ctx,x+w-34,sy+2,ka.swingOnly(),ka.swingOnly()?1:0);
            controls.add(new Control("killAuraSwing","kill_aura.swing_only",x,sy,w,24,null));
        }
        else if(m instanceof AutoClicker ac){
            slider(ctx,"auto_clicker.cps","CPS",ac.cps(),1,20,x,y,w,28);
            ctx.drawText(textRenderer,Text.literal("Hold"),x,y+34,0xFFA8AAB0,false);
            Widget.toggle(ctx,x+w-34,y+31,ac.hold(),ac.hold()?1:0);
            controls.add(new Control("autoClickHold","auto_clicker.hold",x,y+29,w,24,null));
        }
        else if(m instanceof Velocity v){slider(ctx,"velocity.horizontal","Horizontal",v.horizontal(),0,100,x,y,w,28);slider(ctx,"velocity.vertical","Vertical",v.vertical(),0,100,x,y+28,w,28);}
        else if(m instanceof ESP e){
            String[] ids={"box","outline","fill","health"},names={"Box","Outline","Fill","Health bar"};
            for(int i=0;i<4;i++){int col=i%2,row=i/2,tx=x+col*(w/2),ty=y+row*26;
                ctx.drawText(textRenderer,Text.literal(names[i]),tx+2,ty+5,0xFFA8AAB0,false);
                Widget.toggle(ctx,tx+w/2-31,ty+3,e.option(ids[i]),e.option(ids[i])?1:0);
                controls.add(new Control("espToggle","esp."+ids[i],tx,ty,w/2,24,null));
            }
            dropdown(ctx,"esp.targets","Targets",e.targets(),new String[]{"Players","Mobs","Both"},x,y+52,w);
        }
        else if(m instanceof Zoom z)slider(ctx,"zoom.factor","Zoom factor",z.factor(),2,10,x,y,w,33);
        else if(m instanceof TimeChanger t)slider(ctx,"world.time","Time",t.time(),0,24000,x,y,w,33);
        else if(m instanceof WeatherChanger wc)dropdown(ctx,"world.weather","Weather",wc.weather(),new String[]{"Clear","Rain","Thunder"},x,y,w);
        else if(m instanceof ChatSuffix cs){
            ctx.drawText(textRenderer,Text.literal("Suffix"),x,y+5,0xFFA8AAB0,false);
            int fx=x+47;Widget.roundRect(ctx,fx,y,fx+w-47,y+22,CARD,4);
            ctx.drawText(textRenderer,Text.literal(suffixCapture?textBuffer+"_":cs.suffix()),fx+6,y+7,0xFFEDEDED,false);
            controls.add(new Control("suffix","misc.chat_suffix",fx,y,w-47,22,null));
        }
        else if(m instanceof VisualToggle v&&v.hasSlider())slider(ctx,"visual."+m.id(),m.name(),v.value(),v.min(),v.max(),x,y,w,33);
        else if(m instanceof VisualToggle&&m.id().equals("tag_elements")){
            String[] ids={"tag_head","tag_friend_prefix","tag_donation","tag_prefix","tag_suffix"},names={"Head","Friend","Donate","Prefix","Suffix"};
            int sw=w/5;
            for(int i=0;i<ids.length;i++){int tx=x+i*sw;boolean on=ModuleManager.visual(ids[i]).enabled();
                ctx.drawCenteredTextWithShadow(textRenderer,Text.literal(names[i]),tx+sw/2,y+4,0xFFA8AAB0);
                Widget.toggle(ctx,tx+(sw-28)/2,y+22,on,on?1:0);
                controls.add(new Control("moduleToggle",ids[i],tx,y+19,sw,20,null));
            }
        }
        else if(m instanceof VisualToggle&&m.id().equals("color_mode"))dropdown(ctx,"visual.color_mode.name","Color Mode",R1zzConfig.get("visual.color_mode.name","Item"),new String[]{"Item","Player","Friend"},x,y,w);
        else if(m instanceof VisualToggle&&m.id().endsWith("color")){VisualToggle v=(VisualToggle)m;ctx.drawText(textRenderer,Text.literal(String.format(Locale.ROOT,"#%06X",v.color())),x,y+5,ACCENT,false);Widget.swatch(ctx,x+w-25,y,v.color());controls.add(new Control("color",m.id(),x,y,w,26,null));}
        else { slider(ctx,"setting."+m.id()+".intensity","Intensity",m.genericSetting(),0.0,1.0,x,y,w,33); }
    }

    private void slider(DrawContext ctx,String id,String label,double value,double min,double max,int x,int y,int w,int rowH){Widget.slider(ctx,textRenderer,label,x,y,w,value,min,max,format(value));controls.add(new Control("slider",id,x,y+12,w,rowH-10,null));}

    private void dropdown(DrawContext ctx,String id,String label,String value,String[] options,int x,int y,int w){
        boolean open=id.equals(dropdownOpenId);Widget.dropdown(ctx,textRenderer,label,x,y,w,value,open);
        controls.add(new Control("dropdown",id,x,y+11,w,19,null));
        if(open){for(int i=0;i<options.length;i++){int oy=y+32+i*16;Widget.roundRect(ctx,x,oy,x+w,oy+16,options[i].equals(value)?ACCENT:CARD,2);ctx.drawText(textRenderer,Text.literal(options[i]),x+6,oy+4,options[i].equals(value)?0xFFFFFFFF:0xFFEDEDED,false);controls.add(new Control("option",id,x,oy,w,16,options[i]));}}
    }

    @Override public boolean mouseClicked(double mx,double my,int button){
        if(colorPickerId!=null&&button==0){
            if(!inside(mx,my,bx+PW-212,by+PH-133,200,120)){colorPickerId=null;return true;}
            if(inside(mx,my,bx+PW-28,by+PH-130,15,15)){colorPickerId=null;return true;}
            for(Control c:controls)if(c.kind.equals("rgb")&&inside(mx,my,c.x,c.y,c.w,c.h)){dragId=c.id;setColorChannel(c.id,mx);return true;}
            return true;
        }
        if(button==0){
            if(!settingsOpen&&maxScroll()>0&&inside(mx,my,bx+PW-11,by+47,9,PH-56)){scrollDrag=true;dragScrollbarTo(my);return true;}
            for(int i=0;i<CATEGORIES.length;i++){int y=by+42+i*37;if(inside(mx,my,bx+5,y,SW-10,33)){category=CATEGORIES[i];settingsOpen=false;scroll=0;expandedId=null;categoryFade=3;return true;}}
            int gy=by+PH-39;if(inside(mx,my,bx+5,gy,SW-10,28)){settingsOpen=!settingsOpen;scroll=0;return true;}
            int sx=bx+PW-181,sy=by+9;if(!settingsOpen&&inside(mx,my,sx,sy,171,24)){searchCapture=true;return true;}
            if(settingsOpen){if(SettingsPanel.click(this,mx,my,cx(),by+52))return true;}
            else if(inside(mx,my,cx(),by+47,cw(),PH-56)){
                for(Control c:controls){
                    if(!inside(mx,my,c.x,c.y,c.w,c.h))continue;
                    if(c.kind.equals("slider")){dragId=c.id;setSlider(c,mx);return true;}
                    if(c.kind.equals("dropdown")){dropdownOpenId=Objects.equals(dropdownOpenId,c.id)?null:c.id;return true;}
                    if(c.kind.equals("option")){setDropdown(c.id,c.option);dropdownOpenId=null;return true;}
                    if(c.kind.equals("pearlAutoAim")){Module m=ModuleManager.get("pearl_catch");if(m instanceof PearlCatch v)v.setAutoAim(!v.autoAim());return true;}
                    if(c.kind.startsWith("triggerBot")){
                        Module m=ModuleManager.get("trigger_bot");
                        if(m instanceof TriggerBot t){
                            switch(c.id){
                                case "trigger_bot.when_use_hand" -> t.setWhenUseHand(!t.whenUseHand());
                                case "trigger_bot.simulate_clicks" -> t.setSimulateClicks(!t.simulateClicks());
                                case "trigger_bot.only_weapon" -> t.setOnlyWeapon(!t.onlyWeapon());
                                case "trigger_bot.anti_zombie_bot" -> t.setAntiZombieBot(!t.antiZombieBot());
                                case "trigger_bot.ignore_shield" -> t.setIgnoreShield(!t.ignoreShield());
                                case "trigger_bot.focus_mode" -> t.setFocusMode(!t.focusMode());
                            }
                        }
                        return true;
                    }
                    if(c.kind.equals("killAuraSwing")){Module m=ModuleManager.get("kill_aura");if(m instanceof KillAura v)v.setSwingOnly(!v.swingOnly());return true;}
                    if(c.kind.equals("autoClickHold")){Module m=ModuleManager.get("auto_clicker");if(m instanceof AutoClicker v)v.setHold(!v.hold());return true;}
                    if(c.kind.equals("waterDrainAuto")){Module m=ModuleManager.get("water_drain");if(m instanceof WaterDrain v)v.setAutoSwitch(!v.autoSwitch());return true;}
                    if(c.kind.equals("cobwebAuto")){Module m=ModuleManager.get("cobweb_placer");if(m instanceof CobwebPlacer v)v.setAutoSwitch(!v.autoSwitch());return true;}
                    if(c.kind.equals("moduleToggle")){Module mm=ModuleManager.get(c.id);if(mm!=null)mm.toggle();return true;}
                    if(c.kind.equals("espToggle")){ESP e=ModuleManager.esp();String id=c.id.substring(4);e.setOption(id,!e.option(id));return true;}
                    if(c.kind.equals("color")){colorPickerId=c.id;return true;}
                    if(c.kind.equals("suffix")){suffixCapture=true;textBuffer.setLength(0);textBuffer.append(((ChatSuffix)ModuleManager.get("chat_suffix")).suffix());return true;}
                }
                for(Card card:cards)if(inside(mx,my,card.x,card.y,card.w,28)){
                    int local=(int)mx-card.x;
                    if(local>=card.w-38){card.module.toggle();return true;}
                    if(local>=card.w-98){beginBinding(card.module.id());return true;}
                    if(hasSettings(card.module))expandedId=Objects.equals(expandedId,card.module.id())?null:card.module.id();
                    return true;
                }
            }
        }else if(button==1){for(Card card:cards)if(inside(mx,my,card.x+card.w-94,card.y,48,28)){card.module.setKeyCode(-1);return true;}}
        return super.mouseClicked(mx,my,button);
    }

    @Override public boolean mouseDragged(double mx,double my,int button,double dx,double dy){if(button==0&&scrollDrag){dragScrollbarTo(my);return true;}if(button==0&&dragId!=null){for(Control c:controls)if(c.id.equals(dragId)&&c.kind.equals("slider")){setSlider(c,mx);return true;}if(dragId.startsWith("rgb")){setColorChannel(dragId,mx);return true;}return true;}return super.mouseDragged(mx,my,button,dx,dy);}
    @Override public boolean mouseReleased(double mx,double my,int button){if(button==0)scrollDrag=false;if(button==0&&dragId!=null){snapSlider(dragId);dragId=null;}return super.mouseReleased(mx,my,button);}
    @Override public boolean mouseScrolled(double mx,double my,double horizontal,double vertical){if(vertical==0)return false;for(Control c:controls)if(c.kind.equals("slider")&&inside(mx,my,c.x,c.y,c.w,c.h)){adjustSlider(c.id,Math.signum(vertical)*.05);return true;}if(settingsOpen)return SettingsPanel.scroll(mx,my,vertical);if(inside(mx,my,cx(),by+45,cw(),PH-54)){scroll=Math.max(0,Math.min(maxScroll(),scroll-(int)(vertical*24)));return true;}return super.mouseScrolled(mx,my,horizontal,vertical);}

    @Override public boolean keyPressed(int key,int scan,int modifiers){
        if(friendEntry){if(key==GLFW.GLFW_KEY_ENTER||key==GLFW.GLFW_KEY_KP_ENTER)finishFriendEntry();else if(key==GLFW.GLFW_KEY_ESCAPE){friendEntry=false;textBuffer.setLength(0);}else if(key==GLFW.GLFW_KEY_BACKSPACE&&textBuffer.length()>0)textBuffer.deleteCharAt(textBuffer.length()-1);return true;}
        if(suffixCapture){if(key==GLFW.GLFW_KEY_ENTER||key==GLFW.GLFW_KEY_KP_ENTER)finishSuffixEntry();else if(key==GLFW.GLFW_KEY_ESCAPE){suffixCapture=false;textBuffer.setLength(0);}else if(key==GLFW.GLFW_KEY_BACKSPACE&&textBuffer.length()>0)textBuffer.deleteCharAt(textBuffer.length()-1);return true;}
        if(guiKeyCapture){if(key!=GLFW.GLFW_KEY_ESCAPE)R1zzClient.setGuiKey(key);guiKeyCapture=false;return true;}
        if(bindingCapture!=null){if(key!=GLFW.GLFW_KEY_ESCAPE){Module m=ModuleManager.get(bindingCapture);if(m!=null)m.setKeyCode(key);}bindingCapture=null;return true;}
        if(searchCapture){if(key==GLFW.GLFW_KEY_ESCAPE)searchCapture=false;else if(key==GLFW.GLFW_KEY_BACKSPACE&&!search.isEmpty())search=search.substring(0,search.length()-1);else if(key==GLFW.GLFW_KEY_ENTER)searchCapture=false;return true;}
        if(key==GLFW.GLFW_KEY_ESCAPE||key==R1zzClient.guiKey()){close();return true;}
        return super.keyPressed(key,scan,modifiers);
    }

    @Override public boolean charTyped(char c,int modifiers){if(friendEntry||suffixCapture){if(textBuffer.length()<48&&!Character.isISOControl(c))textBuffer.append(c);return true;}if(searchCapture){if(search.length()<32&&!Character.isISOControl(c))search+=c;return true;}return super.charTyped(c,modifiers);}

    private void drawColorPicker(DrawContext ctx){
        int x=bx+PW-212,y=by+PH-133;
        Widget.roundRect(ctx,x,y,x+200,y+120,PANEL,6);ctx.fill(x,y,x+200,y+1,ACCENT);
        VisualToggle v=ModuleManager.visual(colorPickerId);
        if(v==null){colorPickerId=null;return;}
        int rgb=v.color();
        ctx.fill(x,y,x+1,y+120,ACCENT);ctx.fill(x+199,y,x+200,y+120,ACCENT);ctx.fill(x,y+119,x+200,y+120,ACCENT);
        ctx.drawText(textRenderer,Text.literal(v.name()),x+10,y+8,0xFFEDEDED,false);
        ctx.drawText(textRenderer,Text.literal("×"),x+188,y+7,0xFFE0A0A0,false);
        String[] ids={"rgb.r","rgb.g","rgb.b"},names={"R","G","B"};
        int[] shifts={16,8,0},tints={0xFFC41E3A,0xFF3FA06B,0xFF3F6BA0};
        int tx=x+26,tw=120;
        for(int i=0;i<3;i++){
            int ty=y+28+i*22,val=(rgb>>shifts[i])&255;
            ctx.drawText(textRenderer,Text.literal(names[i]),x+10,ty,0xFFA8AAB0,false);
            Widget.roundRect(ctx,tx,ty+2,tx+tw,ty+6,CARD,2);
            int end=tx+Math.round(tw*val/255f);
            if(end>tx)Widget.roundRect(ctx,tx,ty+2,end,ty+6,tints[i],2);
            Widget.roundRect(ctx,end-3,ty,end+3,ty+8,0xFFFFFFFF,3);
            ctx.drawText(textRenderer,Text.literal(String.valueOf(val)),tx+tw+8,ty,ACCENT,false);
            controls.add(new Control("rgb",ids[i],tx,ty-3,tw,14,null));
        }
        Widget.swatch(ctx,x+10,y+98,rgb);
        ctx.drawText(textRenderer,Text.literal(String.format(Locale.ROOT,"#%06X",rgb)),x+32,y+102,ACCENT,false);
    }

    private void setColorChannel(String id,double mx){
        VisualToggle v=ModuleManager.visual(colorPickerId);if(v==null)return;
        for(Control c:controls){
            if(!c.kind.equals("rgb")||!c.id.equals(id))continue;
            int shift=switch(id){case"rgb.r"->16;case"rgb.g"->8;default->0;};
            double p=Math.max(0,Math.min(1,(mx-c.x)/(double)c.w));
            int value=(int)Math.round(p*255);
            v.setColor((v.color()&~(255<<shift))|(value<<shift));
            return;
        }
    }

    private VisualToggle visualForSlider(String id){return id.startsWith("visual.")?ModuleManager.visual(id.substring(7)):null;}

    private double[] sliderBounds(String id){
        return switch(id){
            case"aim.speed"->new double[]{.1,1};
            case"aim.range"->new double[]{3,12};
            case"aim.noise"->new double[]{0,2};
            case"aim.fov"->new double[]{30,360};
            case"pearl_catch.window"->new double[]{10,40}; case"pearl_catch.delay"->new double[]{0,5}; case"r1zz_assist.range"->new double[]{2.5,6}; case"r1zz_assist.speed"->new double[]{.1,1}; case"r1zz_assist.delay"->new double[]{0,500};
            case"water_drain.range"->new double[]{1,5}; case"water_drain.cooldown"->new double[]{100,500}; case"cobweb_placer.range"->new double[]{1,4}; case"cobweb_placer.cooldown"->new double[]{100,500}; case"trigger_bot.miss_chance"->new double[]{0,50}; case"trigger_bot.delay"->new double[]{0,500};
            case"auto_pot.hp_threshold"->new double[]{1,20};
            case"auto_crystal.range","kill_aura.range"->new double[]{3,6};
            case"kill_aura.cps","auto_clicker.cps"->new double[]{1,20};
            case"velocity.horizontal","velocity.vertical"->new double[]{0,100};
            case"zoom.factor"->new double[]{2,10};
            case"world.time"->new double[]{0,24000};
            default->{VisualToggle v=visualForSlider(id);yield v==null?new double[]{0,1}:new double[]{v.min(),v.max()};}
        };
    }

    private double sliderValue(String id){
        switch(id){
            case"aim.speed":return ModuleManager.aimAssist().speed();
            case"aim.range":return ModuleManager.aimAssist().range();
            case"aim.noise":return ModuleManager.aimAssist().noise();
            case"aim.fov":return ModuleManager.aimAssist().fov();
            case"pearl_catch.window":return ModuleManager.get("pearl_catch") instanceof PearlCatch v?v.window():20; case"pearl_catch.delay":return ModuleManager.get("pearl_catch") instanceof PearlCatch v?v.delay():0; case"r1zz_assist.range":return ModuleManager.get("r1zz_assist") instanceof R1zzAssist v?v.range():3.5; case"r1zz_assist.speed":return ModuleManager.get("r1zz_assist") instanceof R1zzAssist v?v.speed():.6; case"r1zz_assist.delay":return ModuleManager.get("r1zz_assist") instanceof R1zzAssist v?v.delay():80;
            case"water_drain.range":return ModuleManager.get("water_drain") instanceof WaterDrain v?v.range():4; case"water_drain.cooldown":return ModuleManager.get("water_drain") instanceof WaterDrain v?v.cooldown():400; case"cobweb_placer.range":return ModuleManager.get("cobweb_placer") instanceof CobwebPlacer v?v.range():3; case"cobweb_placer.cooldown":return ModuleManager.get("cobweb_placer") instanceof CobwebPlacer v?v.cooldown():500;
            case"trigger_bot.miss_chance":return ModuleManager.get("trigger_bot") instanceof TriggerBot v?v.missChance():0; case"trigger_bot.delay":return ModuleManager.get("trigger_bot") instanceof TriggerBot v?v.delay():80;
            case"auto_pot.hp_threshold":return ModuleManager.get("auto_pot") instanceof AutoPot v?v.hpThreshold():0;
            case"auto_crystal.range":return ModuleManager.get("auto_crystal") instanceof AutoCrystal v?v.range():0;
            case"kill_aura.range":return ModuleManager.get("kill_aura") instanceof KillAura v?v.range():0;
            case"kill_aura.cps":return ModuleManager.get("kill_aura") instanceof KillAura v?v.cps():0;
            case"auto_clicker.cps":return ModuleManager.get("auto_clicker") instanceof AutoClicker v?v.cps():0;
            case"velocity.horizontal":return ModuleManager.velocity().horizontal();
            case"velocity.vertical":return ModuleManager.velocity().vertical();
            case"zoom.factor":return ModuleManager.zoom().factor();
            case"world.time":{Module t=ModuleManager.get("time_changer");return t instanceof TimeChanger tc?tc.time():0;}
            default:{VisualToggle v=visualForSlider(id);if(v!=null)return v.value();if(id.startsWith("setting.")){String moduleId=id.substring("setting.".length(),id.length()-".intensity".length());Module m=ModuleManager.get(moduleId);return m==null?0:m.genericSetting();}return 0;}
        }
    }

    private void applySlider(String id,double value){
        switch(id){
            case"aim.speed":ModuleManager.aimAssist().setSpeed(value);break;
            case"aim.range":ModuleManager.aimAssist().setRange(value);break;
            case"aim.noise":ModuleManager.aimAssist().setNoise(value);break;
            case"aim.fov":ModuleManager.aimAssist().setFov(value);break;
            case"pearl_catch.window":{Module m=ModuleManager.get("pearl_catch");if(m instanceof PearlCatch v)v.setWindow((int)Math.round(value));break;} case"pearl_catch.delay":{Module m=ModuleManager.get("pearl_catch");if(m instanceof PearlCatch v)v.setDelay((int)Math.round(value));break;} case"r1zz_assist.range":{Module m=ModuleManager.get("r1zz_assist");if(m instanceof R1zzAssist v)v.setRange(value);break;} case"r1zz_assist.speed":{Module m=ModuleManager.get("r1zz_assist");if(m instanceof R1zzAssist v)v.setSpeed(value);break;} case"r1zz_assist.delay":{Module m=ModuleManager.get("r1zz_assist");if(m instanceof R1zzAssist v)v.setDelay((int)Math.round(value));break;}
            case"water_drain.range":{Module m=ModuleManager.get("water_drain");if(m instanceof WaterDrain v)v.setRange(value);break;} case"water_drain.cooldown":{Module m=ModuleManager.get("water_drain");if(m instanceof WaterDrain v)v.setCooldown((int)Math.round(value));break;} case"cobweb_placer.range":{Module m=ModuleManager.get("cobweb_placer");if(m instanceof CobwebPlacer v)v.setRange(value);break;} case"cobweb_placer.cooldown":{Module m=ModuleManager.get("cobweb_placer");if(m instanceof CobwebPlacer v)v.setCooldown((int)Math.round(value));break;}
            case"trigger_bot.miss_chance":{Module m=ModuleManager.get("trigger_bot");if(m instanceof TriggerBot v)v.setMissChance(value);break;} case"trigger_bot.delay":{Module m=ModuleManager.get("trigger_bot");if(m instanceof TriggerBot v)v.setDelay((int)Math.round(value));break;}
            case"auto_pot.hp_threshold":{Module m=ModuleManager.get("auto_pot");if(m instanceof AutoPot v)v.setHpThreshold((int)Math.round(value));break;}
            case"auto_crystal.range":{Module m=ModuleManager.get("auto_crystal");if(m instanceof AutoCrystal v)v.setRange(value);break;}
            case"kill_aura.range":{Module m=ModuleManager.get("kill_aura");if(m instanceof KillAura v)v.setRange(value);break;}
            case"kill_aura.cps":{Module m=ModuleManager.get("kill_aura");if(m instanceof KillAura v)v.setCps((int)Math.round(value));break;}
            case"auto_clicker.cps":{Module m=ModuleManager.get("auto_clicker");if(m instanceof AutoClicker v)v.setCps((int)Math.round(value));break;}
            case"velocity.horizontal":ModuleManager.velocity().setHorizontal(value);break;
            case"velocity.vertical":ModuleManager.velocity().setVertical(value);break;
            case"zoom.factor":ModuleManager.zoom().setFactor(value);break;
            case"world.time":{Module t=ModuleManager.get("time_changer");if(t instanceof TimeChanger tc)tc.setTime((int)Math.round(value));break;}
            default:{VisualToggle v=visualForSlider(id);if(v!=null)v.setValue(value);else if(id.startsWith("setting.")){String moduleId=id.substring("setting.".length(),id.length()-".intensity".length());Module m=ModuleManager.get(moduleId);if(m!=null)m.setGenericSetting(value);}}
        }
    }

    private void setSlider(Control c,double mx){
        double p=Math.max(0,Math.min(1,(mx-c.x)/(double)c.w));
        double[] b=sliderBounds(c.id);
        applySlider(c.id,b[0]+(b[1]-b[0])*p);
    }

    private void snapSlider(String id){
        if(!id.startsWith("rgb")){
            double step=switch(id){
                case"aim.speed","aim.range","aim.noise","r1zz_assist.speed","water_drain.range","cobweb_placer.range"->.01; case"r1zz_assist.delay","water_drain.cooldown","cobweb_placer.cooldown"->1;
                case"aim.fov","velocity.horizontal","velocity.vertical","auto_pot.hp_threshold"->1; case"trigger_bot.miss_chance"->.1;
                case"pearl_catch.window","pearl_catch.delay","kill_aura.cps","auto_clicker.cps"->1;
                case"auto_crystal.range","kill_aura.range"->.1;
                case"zoom.factor"->.1;
                case"world.time"->10;
                default->0;
            };
            if(step>0)applySlider(id,Math.round(sliderValue(id)/step)*step);
        }
        R1zzConfig.save();
    }

    private void adjustSlider(String id,double fraction){
        double[] b=sliderBounds(id);
        applySlider(id,sliderValue(id)+(b[1]-b[0])*fraction);
        snapSlider(id);
    }

    private void setDropdown(String id,String option){
        if(option==null)return;
        switch(id){
            case"aim.target_type":ModuleManager.aimAssist().setTargetType(option);break;
            case"aim.weapon_filter":ModuleManager.aimAssist().setWeaponFilter(option);break;
            case"pearl_catch.auto_aim":break; case"r1zz_assist.target_type":{Module m=ModuleManager.get("r1zz_assist");if(m instanceof R1zzAssist v)v.setTargetType(option);break;} case"water_drain.target":{Module m=ModuleManager.get("water_drain");if(m instanceof WaterDrain v)v.setTarget(option);break;} case"trigger_bot.hit_mode":{Module m=ModuleManager.get("trigger_bot");if(m instanceof TriggerBot v)v.setHitMode(option);break;}
            case"trigger_bot.reach":{Module m=ModuleManager.get("trigger_bot");if(m instanceof TriggerBot v)v.setReachMode(option);break;}
            case"kill_aura.rotation":{Module m=ModuleManager.get("kill_aura");if(m instanceof KillAura v)v.setRotation(option);break;}
            case"kill_aura.target":{Module m=ModuleManager.get("kill_aura");if(m instanceof KillAura v)v.setTarget(option);break;}
            case"esp.targets":ModuleManager.esp().setTargets(option);break;
            case"world.weather":{Module w=ModuleManager.get("weather_changer");if(w instanceof WeatherChanger wc)wc.setWeather(option);break;}
            case"visual.color_mode.name":R1zzConfig.put(id,option);break;
            default:break;
        }
        R1zzConfig.save();
    }

    private int maxScroll(){
        int total=0;
        for(Module m:visibleModules())total+=29+expandedHeight(m)+5;
        return Math.max(0,total-(PH-56));
    }

    private static float moveToward(float current,float target,float step){
        if(current<target)return Math.min(target,current+step);
        return Math.max(target,current-step);
    }

    private static float ease(float t){t=Math.max(0,Math.min(1,t));float u=1-t;return 1-u*u*u;}

    private static int blend(int a,int b,float t){
        t=Math.max(0,Math.min(1,t));
        int r=(int)(((a>>16)&255)*(1-t)+((b>>16)&255)*t),g=(int)(((a>>8)&255)*(1-t)+((b>>8)&255)*t),bl=(int)((a&255)*(1-t)+(b&255)*t);
        return 0xFF000000|(r<<16)|(g<<8)|bl;
    }

    private static String format(double v){
        return v==Math.rint(v)?String.format(Locale.ROOT,"%.0f",v):String.format(Locale.ROOT,"%.2f",v);
    }

    private static String keyName(int key){
        if(key<0)return"NONE";
        if(key==GLFW.GLFW_KEY_RIGHT_SHIFT)return"RSHIFT";
        return net.minecraft.client.util.InputUtil.fromKeyCode(key,0).getLocalizedText().getString().toUpperCase(Locale.ROOT);
    }

    private static boolean inside(double mx,double my,int x,int y,int w,int h){return mx>=x&&mx<=x+w&&my>=y&&my<=y+h;}
}
