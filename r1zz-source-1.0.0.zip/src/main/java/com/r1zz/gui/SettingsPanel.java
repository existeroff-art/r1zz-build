package com.r1zz.gui;

import com.r1zz.R1zzClient;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.module.ModuleManager;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;

public final class SettingsPanel {
    private static int moduleScroll,friendScroll,layoutX,layoutY;
    private static final int ROW=17,CONTENT_W=411;
    private SettingsPanel(){}
    public static void render(ClickGUI gui,DrawContext ctx,int x,int y,int mx,int my,String capture,boolean guiCapture){
        layoutX=x;layoutY=y;TextRenderer f=gui.font();ctx.drawText(f,Text.literal("Client Settings"),x,y,0xFFFFFFFF,false);
        ctx.drawText(f,Text.literal("GUI key"),x,y+21,Widget.LABEL,false);field(ctx,f,x+82,y+17,84,18,guiCapture?"[...]":keyName(R1zzClient.guiKey()),guiCapture);
        preference(ctx,f,x+178,y+19,"Show keybinds","hud.show_keybinds",false);preference(ctx,f,x+295,y+19,"Keybind notices","notify.chat",true);
        button(ctx,f,x,y+43,86,"Save config");button(ctx,f,x+92,y+43,86,"Load config");
        ctx.fill(x,y+67,x+CONTENT_W,y+68,0xFF3D1A1A);ctx.drawText(f,Text.literal("Friends"),x,y+73,0xFFFFFFFF,false);
        field(ctx,f,x,y+88,198,18,gui.friendEntryActive()?gui.friendEntryText()+"_":"Add username · Enter",gui.friendEntryActive());
        List<String> friends=new ArrayList<>(R1zzConfig.friends());int base=friendScroll*4;
        for(int i=0;i<Math.min(4,Math.max(0,friends.size()-base));i++){int col=i%2,row=i/2,fx=x+col*207,fy=y+110+row*17;String n=friends.get(base+i);Widget.roundRect(ctx,fx,fy,fx+201,fy+15,0xFF150808,4);ctx.drawText(f,Text.literal(n),fx+6,fy+4,0xFFE0A0A0,false);ctx.drawText(f,Text.literal("×"),fx+188,fy+3,0xFFEDEDED,false);}
        if(friends.size()>4)ctx.drawText(f,Text.literal("scroll · "+friends.size()+" saved"),x+212,y+116,0xFFA8AAB0,false);
        int listY=y+151;ctx.fill(x,listY-4,x+CONTENT_W,listY-3,0xFF3D1A1A);ctx.drawText(f,Text.literal("Module keybinds"),x,listY,0xFFFFFFFF,false);
        int start=listY+17;List<Module> modules=ModuleManager.all();ctx.enableScissor(x,start,x+CONTENT_W,y+277);
        for(int i=0;i<modules.size();i++){int col=i%2,row=i/2,rx=x+col*207,ry=start+row*ROW-moduleScroll;Module m=modules.get(i);Widget.roundRect(ctx,rx,ry,rx+201,ry+15,0xFF150808,4);ctx.drawText(f,Text.literal(m.name()),rx+5,ry+3,0xFFEDEDED,false);field(ctx,f,rx+142,ry+1,55,12,m.id().equals(capture)?"[...]":keyName(m.keyCode()),m.id().equals(capture));}
        ctx.disableScissor();if(gui.friendEntryActive())ctx.drawText(f,Text.literal("Type username; Enter saves; Esc cancels"),x+205,y+93,0xFFA8AAB0,false);
    }
    public static boolean click(ClickGUI gui,double mx,double my,int x,int y){
        layoutX=x;layoutY=y;
        if(inside(mx,my,x+82,y+17,84,18)){gui.beginGuiKeyBinding();return true;}
        if(inside(mx,my,x+178,y+19,113,20)){flip("hud.show_keybinds",false);return true;}
        if(inside(mx,my,x+295,y+19,115,20)){flip("notify.chat",true);return true;}
        if(inside(mx,my,x,y+43,86,19)){R1zzConfig.save();return true;}
        if(inside(mx,my,x+92,y+43,86,19)){R1zzClient.reloadConfiguration();moduleScroll=0;friendScroll=0;return true;}
        if(inside(mx,my,x,y+88,198,18)){gui.beginFriendEntry();return true;}
        List<String> friends=new ArrayList<>(R1zzConfig.friends());int base=friendScroll*4;for(int i=0;i<Math.min(4,Math.max(0,friends.size()-base));i++){int col=i%2,row=i/2,fx=x+col*207,fy=y+110+row*17;if(inside(mx,my,fx+181,fy,20,15)){R1zzConfig.removeFriend(friends.get(base+i));return true;}}
        int start=y+168;List<Module> modules=ModuleManager.all();for(int i=0;i<modules.size();i++){int col=i%2,row=i/2,rx=x+col*207,ry=start+row*ROW-moduleScroll;if(inside(mx,my,rx+140,ry,61,15)){gui.beginBinding(modules.get(i).id());return true;}}
        return true;
    }
    public static boolean scroll(double mx,double my,double amount){if(amount==0)return false;if(my>=layoutY+110&&my<=layoutY+145){int pages=Math.max(0,(R1zzConfig.friends().size()+3)/4-1);friendScroll=Math.max(0,Math.min(pages,friendScroll-(int)Math.signum(amount)));return true;}if(my>=layoutY+168&&my<=layoutY+277){int rows=(ModuleManager.all().size()+1)/2;int max=Math.max(0,rows*ROW-(layoutY+277-(layoutY+168)));moduleScroll=Math.max(0,Math.min(max,moduleScroll-(int)(amount*ROW)));return true;}return false;}
    private static void preference(DrawContext ctx,TextRenderer f,int x,int y,String label,String key,boolean def){boolean on=R1zzConfig.getBoolean(key,def);ctx.drawText(f,Text.literal(label),x,y+4,Widget.LABEL,false);Widget.toggle(ctx,x+88,y+3,on,on?1:0);}
    private static void button(DrawContext ctx,TextRenderer f,int x,int y,int w,String s){Widget.roundRect(ctx,x,y,x+w,y+19,0xFF150808,4);ctx.drawCenteredTextWithShadow(f,Text.literal(s),x+w/2,y+6,0xFFEDEDED);}
    private static void field(DrawContext ctx,TextRenderer f,int x,int y,int w,int h,String s,boolean active){Widget.roundRect(ctx,x,y,x+w,y+h,active?0xFFC41E3A:0xFF1A0A0A,4);if(active)ctx.fill(x+3,y,x+w-3,y+1,0xFFFFFFFF);ctx.drawCenteredTextWithShadow(f,Text.literal(s),x+w/2,y+(h-8)/2,active?0xFFFFFFFF:0xFFE0A0A0);}
    private static void flip(String key,boolean def){R1zzConfig.put(key,!R1zzConfig.getBoolean(key,def));R1zzConfig.save();}
    private static String keyName(int key){if(key<0)return"NONE";if(key==GLFW.GLFW_KEY_RIGHT_SHIFT)return"RSHIFT";return InputUtil.fromKeyCode(key,0).getLocalizedText().getString().toUpperCase();}
    private static boolean inside(double mx,double my,int x,int y,int w,int h){return mx>=x&&mx<=x+w&&my>=y&&my<=y+h;}
}