package com.r1zz.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public final class Widget {
    private static final int[][] CORNER_INSETS = buildCornerInsets();
    public static final int ACCENT=0xFFC41E3A,ACCENT_DARK=0xFF8B0000,CARD=0xFF150808,SETTING=0xFF0A0505,LABEL=0xFFA8AAB0,VALUE=0xFFC41E3A;
    private Widget(){}
    public static void roundRect(DrawContext ctx,int x1,int y1,int x2,int y2,int color,int radius){
        int w=x2-x1,h=y2-y1,r=Math.max(0,Math.min(15,Math.min(radius,Math.min(w/2,h/2))));if(r==0){ctx.fill(x1,y1,x2,y2,color);return;}
        ctx.fill(x1+r,y1,x2-r,y2,color);ctx.fill(x1,y1+r,x2,y2-r,color);
        for(int i=0;i<r;i++){int inset=CORNER_INSETS[Math.min(r,15)][i];ctx.fill(x1+inset,y1+i,x2-inset,y1+i+1,color);ctx.fill(x1+inset,y2-i-1,x2-inset,y2-i,color);}
    }
    public static void toggle(DrawContext ctx,int x,int y,boolean on,float progress){
        roundRect(ctx,x,y,x+28,y+12,on?ACCENT:0xFF3D1A1A,6);
        int knobX=x+2+(int)Math.round(Math.max(0,Math.min(1,progress))*14);
        roundRect(ctx,knobX,y+2,knobX+8,y+10,on?0xFFFFFFFF:0xFF888888,4);
    }
    public static void slider(DrawContext ctx,TextRenderer font,String label,int x,int y,int w,double value,double min,double max,String valueText){
        ctx.drawText(font,Text.literal(label),x,y,LABEL,false);ctx.drawText(font,Text.literal(valueText),x+w-50,y,VALUE,false);
        int ty=y+14;roundRect(ctx,x,ty,x+w,ty+4,CARD,2);
        double p=max==min?0:Math.max(0,Math.min(1,(value-min)/(max-min)));
        int end=x+(int)Math.round(w*p);
        if(end>x){int segments=Math.max(1,Math.min(32,end-x));for(int i=0;i<segments;i++){int sx=x+(end-x)*i/segments;int ex=x+(end-x)*(i+1)/segments;int c=blend(ACCENT,ACCENT_DARK,(float)i/Math.max(1,segments-1));roundRect(ctx,sx,ty,Math.max(sx+1,ex),ty+4,c,2);}}
        roundRect(ctx,end-4,ty-2,end+4,ty+6,0xFFFFFFFF,4);
    }
    public static void dropdown(DrawContext ctx,TextRenderer font,String label,int x,int y,int w,String value,boolean open){
        ctx.drawText(font,Text.literal(label),x,y,LABEL,false);roundRect(ctx,x,y+11,x+w,y+30,CARD,4);ctx.drawText(font,Text.literal(value),x+7,y+17,0xFFEDEDED,false);ctx.drawText(font,Text.literal(open?"▴":"▾"),x+w-13,y+16,ACCENT,false);
    }
    public static void swatch(DrawContext ctx,int x,int y,int rgb){roundRect(ctx,x,y,x+16,y+16,0xFF3D1A1A,8);roundRect(ctx,x+3,y+3,x+13,y+13,0xFF000000|(rgb&0xFFFFFF),5);}
    private static int[][] buildCornerInsets(){int[][] out=new int[16][];for(int r=0;r<16;r++){out[r]=new int[Math.max(1,r)];for(int i=0;i<r;i++){double dy=r-i-.5;out[r][i]=(int)Math.ceil(r-Math.sqrt(Math.max(0,r*r-dy*dy)));}}return out;}
    private static int blend(int a,int b,float t){t=Math.max(0,Math.min(1,t));int r=(int)(((a>>16)&255)*(1-t)+((b>>16)&255)*t),g=(int)(((a>>8)&255)*(1-t)+((b>>8)&255)*t),bl=(int)((a&255)*(1-t)+(b&255)*t);return 0xFF000000|(r<<16)|(g<<8)|bl;}
}