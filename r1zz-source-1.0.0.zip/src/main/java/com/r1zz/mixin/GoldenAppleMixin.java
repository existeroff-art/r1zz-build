package com.r1zz.mixin;

import com.r1zz.module.Module;
import com.r1zz.module.ModuleManager;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
public class GoldenAppleMixin {
    @Inject(method="getMaxUseTime",at=@At("RETURN"),cancellable=true)
    private void r1zz$fastGap(LivingEntity user,CallbackInfoReturnable<Integer> cir){
        ItemStack self=(ItemStack)(Object)this;
        if(self.isOf(Items.GOLDEN_APPLE)||self.isOf(Items.ENCHANTED_GOLDEN_APPLE)){Module m=ModuleManager.get("fast_gap");if(m!=null&&m.enabled())cir.setReturnValue(cir.getReturnValue()/2);}
    }
}
