package com.r1zz.mixin;
import com.r1zz.module.ModuleManager;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Item.class)
abstract class GoldenAppleMixin {
    @Inject(method="getMaxUseTime",at=@At("RETURN"),cancellable=true)
    private void r1zz$fastGoldenApple(ItemStack stack,LivingEntity user,CallbackInfoReturnable<Integer> cir){
        if(ModuleManager.fastGap()!=null&&ModuleManager.fastGap().enabled()&&(stack.isOf(Items.GOLDEN_APPLE)||stack.isOf(Items.ENCHANTED_GOLDEN_APPLE))&&cir.getReturnValue()==32)cir.setReturnValue(16);
    }
}
