package com.r1zz.mixin;
import com.r1zz.module.ModuleManager;
import com.r1zz.module.modules.Blink;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientConnection.class)
abstract class ConnectionMixin {
    @Inject(method="handlePacket",at=@At("HEAD"))
    private static void r1zz$logIncoming(Packet<?> packet,PacketListener listener,CallbackInfo ci){
        if(ModuleManager.get("packet_logger")!=null&&ModuleManager.get("packet_logger").enabled())
            System.out.println("[R1zz packet IN] "+packet.getClass().getSimpleName());
    }
    @Inject(method="send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;Z)V",at=@At("HEAD"),cancellable=true,require=0)
    private void r1zz$blinkAndLog(Packet<?> packet,PacketCallbacks callbacks,boolean flush,CallbackInfo ci){
        if(Blink.intercept((ClientConnection)(Object)this,packet,callbacks,flush)){ci.cancel();return;}
        if(ModuleManager.get("packet_logger")!=null&&ModuleManager.get("packet_logger").enabled())
            System.out.println("[R1zz packet OUT] "+packet.getClass().getSimpleName());
    }
}
