package com.r1zz.mixin;
import com.r1zz.module.ModuleManager;
import com.r1zz.module.modules.TimeChanger;
import com.r1zz.module.modules.WeatherChanger;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(World.class)
abstract class WorldMixin {
    @Inject(method="getTimeOfDay",at=@At("RETURN"),cancellable=true)
    private void r1zz$time(CallbackInfoReturnable<Long> cir){var m=ModuleManager.get("time_changer");if((Object)this instanceof ClientWorld&&m!=null&&m.enabled())cir.setReturnValue((long)((TimeChanger)m).time());}
    @Inject(method="getRainGradient",at=@At("RETURN"),cancellable=true)
    private void r1zz$rain(float tickDelta,CallbackInfoReturnable<Float> cir){String w=weather();if(w!=null)cir.setReturnValue(w.equals("Clear")?0f:1f);}
    @Inject(method="getThunderGradient",at=@At("RETURN"),cancellable=true)
    private void r1zz$thunder(float tickDelta,CallbackInfoReturnable<Float> cir){String w=weather();if(w!=null)cir.setReturnValue(w.equals("Thunder")?1f:0f);}
    private String weather(){if(!((Object)this instanceof ClientWorld))return null;var m=ModuleManager.get("weather_changer");return m!=null&&m.enabled()?((WeatherChanger)m).weather():null;}
}
