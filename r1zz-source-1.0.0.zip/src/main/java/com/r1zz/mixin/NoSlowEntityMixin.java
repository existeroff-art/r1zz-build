package com.r1zz.mixin;

import com.r1zz.module.ModuleManager;
import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
abstract class NoSlowEntityMixin {
    @org.spongepowered.asm.mixin.Unique private boolean r1zz$travelNoSlow;
    @Inject(method="travel",at=@At("HEAD"))
    private void r1zz$beginTravel(Vec3d movementInput, CallbackInfo ci){
        r1zz$travelNoSlow=((Object)this instanceof PlayerEntity)&&ModuleManager.get("no_slow")!=null&&ModuleManager.get("no_slow").enabled();
    }
    @Inject(method="travel",at=@At("RETURN"))
    private void r1zz$endTravel(Vec3d movementInput, CallbackInfo ci){r1zz$travelNoSlow=false;}
    @Inject(method="isUsingItem",at=@At("HEAD"),cancellable=true)
    private void r1zz$noSlowUse(CallbackInfo ci){if(r1zz$travelNoSlow)ci.cancel();}
    @Inject(method="getVelocityMultiplier",at=@At("HEAD"),cancellable=true)
    private void r1zz$noSlowBlock(CallbackInfoReturnable<Float> cir){
        var m=ModuleManager.get("no_slow");if(m!=null&&m.enabled())cir.setReturnValue(1.0f);
    }
    @Inject(method="slowMovement",at=@At("HEAD"),cancellable=true)
    private void r1zz$noSlow(BlockState state, Vec3d multiplier, CallbackInfo ci){
        var m=ModuleManager.get("no_slow");
        if(m!=null&&m.enabled())ci.cancel();
    }
}
