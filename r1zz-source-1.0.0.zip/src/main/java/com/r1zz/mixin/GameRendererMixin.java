package com.r1zz.mixin;
import com.r1zz.module.ModuleManager;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(GameRenderer.class)
abstract class GameRendererMixin {
    @Inject(method="tiltViewWhenHurt",at=@At("HEAD"),cancellable=true)
    private void r1zz$removeHurtCamera(net.minecraft.client.util.math.MatrixStack matrices,float tickDelta,CallbackInfo ci){if(ModuleManager.get("no_hurt_cam")!=null&&ModuleManager.get("no_hurt_cam").enabled())ci.cancel();}
}
