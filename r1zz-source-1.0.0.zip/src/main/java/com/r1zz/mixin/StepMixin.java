package com.r1zz.mixin;

import com.r1zz.module.ModuleManager;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
abstract class StepMixin {
    @Inject(method="getStepHeight", at=@At("RETURN"), cancellable=true)
    private void r1zz$step(CallbackInfoReturnable<Float> cir) {
        if ((Object)this instanceof ClientPlayerEntity p) {
            var m=ModuleManager.get("step");
            if (m!=null && m.enabled() && p.isOnGround()) cir.setReturnValue(0.6f);
        }
    }
}
