package com.r1zz.mixin;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import com.r1zz.module.modules.AutoReply;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ClientPlayNetworkHandler.class)
abstract class ClientNetworkMixin {
    @Unique private float r1zz$yaw,r1zz$pitch;
    @Inject(method="onPlayerPositionLook",at=@At("HEAD")) private void r1zz$saveRotation(PlayerPositionLookS2CPacket packet,CallbackInfo ci){var p=MinecraftClient.getInstance().player;if(p!=null){r1zz$yaw=p.getYaw();r1zz$pitch=p.getPitch();}}
    @Inject(method="onPlayerPositionLook",at=@At("TAIL")) private void r1zz$restoreRotation(PlayerPositionLookS2CPacket packet,CallbackInfo ci){var p=MinecraftClient.getInstance().player;if(p!=null&&ModuleManager.get("no_rotate")!=null&&ModuleManager.get("no_rotate").enabled()){p.setYaw(r1zz$yaw);p.setPitch(r1zz$pitch);}}
    @Inject(method="onEntityVelocityUpdate",at=@At("TAIL")) private void r1zz$scaleKnockback(EntityVelocityUpdateS2CPacket packet,CallbackInfo ci){var mc=MinecraftClient.getInstance();var m=ModuleManager.velocity();if(mc.player==null||m==null||!m.enabled()||packet.getEntityId()!=mc.player.getId())return;double h=1-m.horizontal()/100.0,v=1-m.vertical()/100.0;mc.player.setVelocity(new Vec3d(packet.getVelocityX()*h,packet.getVelocityY()*v,packet.getVelocityZ()*h));}
    @Inject(method="onExplosion",at=@At("TAIL")) private void r1zz$scaleExplosion(ExplosionS2CPacket packet,CallbackInfo ci){var mc=MinecraftClient.getInstance();var m=ModuleManager.velocity();if(mc.player==null||m==null||!m.enabled())return;double h=1-m.horizontal()/100.0,v=1-m.vertical()/100.0;Vec3d old=mc.player.getVelocity();mc.player.setVelocity(old.x-packet.getPlayerVelocityX()+packet.getPlayerVelocityX()*h,old.y-packet.getPlayerVelocityY()+packet.getPlayerVelocityY()*v,old.z-packet.getPlayerVelocityZ()+packet.getPlayerVelocityZ()*h);}
    @Inject(method="onGameMessage",at=@At("HEAD"),require=0)
    private void r1zz$autoReply(GameMessageS2CPacket packet,CallbackInfo ci){
        var m=ModuleManager.get("auto_reply");
        if(m instanceof AutoReply a && m.enabled())a.tryReply(packet.content().getString());
    }
    @Inject(method="onChatMessage",at=@At("HEAD"),require=0)
    private void r1zz$autoReplyChat(ChatMessageS2CPacket packet,CallbackInfo ci){
        var m=ModuleManager.get("auto_reply");
        if(m instanceof AutoReply a && m.enabled())a.tryReply(packet.body().content());
    }
    @ModifyVariable(method="sendChatMessage",at=@At("HEAD"),argsOnly=true,ordinal=0)
    private String r1zz$chatSuffix(String message){var m=ModuleManager.get("chat_suffix");String suffix=R1zzConfig.get("misc.chat_suffix"," | R1zz");if(m!=null&&m.enabled()&&!message.startsWith("/")&&!suffix.isEmpty())return message+suffix;return message;}
}
