package com.r1zz.mixin;

import com.r1zz.module.ModuleManager;
import net.minecraft.client.render.BackgroundRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(BackgroundRenderer.class)
abstract class FogMixin {
    @ModifyVariable(method = "applyFog", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private static float r1zz$extendFogDistance(float original) {
        return ModuleManager.visual("fog_blur") != null && ModuleManager.visual("fog_blur").enabled() ? Math.max(original, 4096.0f) : original;
    }
}
