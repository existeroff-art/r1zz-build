package com.r1zz.mixin;
import com.r1zz.module.ModuleManager;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LivingEntity.class)
abstract class NoHurtOverlayMixin {
    @Shadow public int hurtTime;
    @Shadow public int maxHurtTime;
    @Inject(method="tick",at=@At("TAIL"))
    private void r1zz$clearLocalHurtTint(CallbackInfo ci){if((Object)this instanceof ClientPlayerEntity&&ModuleManager.get("no_hurt_cam")!=null&&ModuleManager.get("no_hurt_cam").enabled()){hurtTime=0;maxHurtTime=0;}}
}
