package com.r1zz.mixin;

import com.r1zz.module.ModuleManager;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.item.HeldItemRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(HeldItemRenderer.class)
abstract class HeldItemRendererMixin {
    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private int r1zz$glowHeldItem(int packedLight) {
        return ModuleManager.visual("hands") != null && ModuleManager.visual("hands").enabled()
                ? LightmapTextureManager.MAX_LIGHT_COORDINATE : packedLight;
    }
}
