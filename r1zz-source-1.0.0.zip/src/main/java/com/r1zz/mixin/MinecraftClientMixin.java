package com.r1zz.mixin;
import com.r1zz.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MinecraftClient.class)
abstract class MinecraftClientMixin {
    @Shadow private int itemUseCooldown;
    @Inject(method="tick",at=@At("HEAD")) private void r1zz$fastPlace(CallbackInfo ci){if(ModuleManager.get("fast_place")!=null&&ModuleManager.get("fast_place").enabled())itemUseCooldown=Math.min(itemUseCooldown,3);}
}
