package com.r1zz.mixin;

import com.r1zz.module.ModuleManager;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
abstract class InteractionManagerMixin {
    @Inject(method="attackEntity",at=@At("TAIL"))
    private void r1zz$attack(Entity target, CallbackInfo ci){
        var m=ModuleManager.get("auto_wtap");
        if(m instanceof com.r1zz.module.modules.AutoWTap w && w.enabled())w.onAttack();
    }
}
