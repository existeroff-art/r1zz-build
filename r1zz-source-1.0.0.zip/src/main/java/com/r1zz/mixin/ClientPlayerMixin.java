package com.r1zz.mixin;
import com.r1zz.module.ModuleManager;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ClientPlayerEntity.class)
abstract class ClientPlayerMixin {
    @Inject(method="sendMovementPackets",at=@At("HEAD"),cancellable=true)
    private void r1zz$movementPackets(CallbackInfo ci){
        ClientPlayerEntity p=(ClientPlayerEntity)(Object)this;
        if(ModuleManager.get("freecam")!=null&&ModuleManager.get("freecam").enabled()){ci.cancel();return;}
        if(ModuleManager.get("no_fall")!=null&&ModuleManager.get("no_fall").enabled()&&p.fallDistance>3.0f)p.setOnGround(true);
    }
}
