package com.r1zz.mixin;
import com.r1zz.module.ModuleManager;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Camera.class)
abstract class CameraMixin {
    @Shadow protected abstract void setPos(double x,double y,double z);
    @Inject(method="update",at=@At("TAIL"))
    private void r1zz$freecam(net.minecraft.world.BlockView area,net.minecraft.entity.Entity focusedEntity,boolean thirdPerson,boolean inverseView,float tickDelta,CallbackInfo ci){
        if(ModuleManager.freecam()!=null&&ModuleManager.freecam().enabled()){Vec3d p=ModuleManager.freecam().cameraPos();if(p!=null)setPos(p.x,p.y,p.z);}
    }
}
