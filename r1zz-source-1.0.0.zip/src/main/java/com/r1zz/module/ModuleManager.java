package com.r1zz.module;

import com.r1zz.R1zzClient;
import com.r1zz.module.modules.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private ModuleManager() {}
    public static void initialize() {
        MODULES.clear();
        add(new AimAssist()); add(new FastGapple());
        add(new FastGap());
        add(new ShieldBreaker()); add(new PearlCatch()); add(new CobwebPlacer()); add(new WaterDrain()); add(new MaceSwap()); add(new TriggerBot()); add(new JumpReset()); add(new R1zzAssist());
        add(new AutoCrystal()); add(new AnchorAura()); add(new AutoTrap()); add(new HoleFiller());
        add(new Surround()); add(new AutoCity()); add(new Offhand()); add(new BowAimbot());
        add(new KillAura()); add(new Reach()); add(new AutoClicker()); add(new Criticals());
        add(new WTap()); add(new STap()); add(new AutoWTap()); add(new AutoBlock()); add(new AutoWeapon()); add(new AutoTool());
        add(new AutoPot());
        add(new Sprint()); add(new Step()); add(new NoFall()); add(new Velocity()); add(new AntiVoid()); add(new NoSlow());
        add(new DashDots()); add(new ESP()); add(new Tracers()); add(new Nametags()); add(new Fullbright()); add(new FogBlur());
        add(new Quality()); add(new Strength()); add(new HudElements()); add(new TagElements());
        add(new VisualToggle("tag_head", "Head", true)); add(new VisualToggle("tag_friend_prefix", "Friend Prefix", true));
        add(new VisualToggle("tag_donation", "Donation", true)); add(new VisualToggle("tag_prefix", "Prefix", true)); add(new VisualToggle("tag_suffix", "Suffix", true));
        add(new Range()); add(new PlayerColor()); add(new FriendColor()); add(new Hands()); add(new ColorMode());
        add(new NoHurtCam()); add(new Freecam()); add(new Zoom());
        add(new AutoRespawn()); add(new FastPlace()); add(new AutoTotem()); add(new AntiHunger()); add(new NoRotate());
        add(new TimeChanger()); add(new WeatherChanger());
        add(new AntiAFK()); add(new ChatSuffix()); add(new AutoReply()); add(new Blink()); add(new AutoReconnect()); add(new PacketLogger());
        add(new Ambience());
        add(new Announcer());
        add(new ArmorHUD());
        add(new AutoArmor());
        add(new AutoChat());
        add(new AutoDrop());
        add(new AutoEat());
        add(new AutoFish());
        add(new AutoHeal());
        add(new AutoLog());
        add(new AutoMine());
        add(new AutoNametag());
        add(new AutoSell());
        add(new AutoShear());
        add(new AutoSword());
        add(new AutoTip());
        add(new BedAura());
        add(new BlockESP());
        add(new Chams());
        add(new ChestStealer());
        add(new ClickGUISound());
        add(new Crosshair());
        add(new DiscordRPC());
        add(new ElytraFly());
        add(new FPSBoost());
        add(new FakeLag());
        add(new FastBreak());
        add(new FastLadder());
        add(new Fly());
        add(new HealthBar());
        add(new Hitboxes());
        add(new InvManager());
        add(new ItemPhysics());
        add(new ItemScroller());
        add(new Jesus());
        add(new LogoutSpots());
        add(new LongJump());
        add(new Macro());
        add(new MouseTweaks());
        add(new NameProtect());
        add(new NewChunks());
        add(new NoBreakDelay());
        add(new NoClip());
        add(new NoRender());
        add(new Notifications());
        add(new Nuker());
        add(new PacketFly());
        add(new Parkour());
        add(new Particle());
        add(new Phase());
        add(new PopChams());
        add(new PotionHUD());
        add(new Rainbow());
        add(new RocketESP());
        add(new Scaffold());
        add(new Search());
        add(new SkeletonESP());
        add(new Spam());
        add(new Speed());
        add(new Spider());
        add(new StorageESP());
        add(new Trajectory());
        add(new Tunnel());
        add(new ViewModel());
        add(new Watermark());
        add(new Waypoints());
        for (Module m : MODULES) m.load(); R1zzClient.applyLoadedGuiKey();
    }
    private static void add(Module m) { MODULES.add(m); }
    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }
    public static List<Module> in(Module.Category c) { return MODULES.stream().filter(m -> m.category() == c).toList(); }
    public static Module get(String id) { return MODULES.stream().filter(m -> m.id().equals(id)).findFirst().orElse(null); }
    public static VisualToggle visual(String id) { Module m=get(id); return m instanceof VisualToggle v?v:null; }
    public static AimAssist aimAssist(){return (AimAssist)get("aim_assist");}
    public static FastGap fastGap(){return (FastGap)get("fast_gap");}
    public static FastGapple fastGapple(){return (FastGapple)get("fast_gapple");}
    public static boolean fastGappleEnabled(){FastGapple m=fastGapple();return m!=null&&m.enabled();}
    public static Velocity velocity(){return (Velocity)get("velocity");}
    public static ESP esp(){return (ESP)get("esp");}
    public static Freecam freecam(){return (Freecam)get("freecam");}
    public static Zoom zoom(){return (Zoom)get("zoom");}
    public static void tick(){for(Module m:MODULES) if(m.enabled() || m instanceof Zoom) m.onTick();}
    public static void saveAll(){for(Module m:MODULES)m.persist();}
}
