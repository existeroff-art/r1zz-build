package com.r1zz.module;

import com.r1zz.R1zzClient;
import com.r1zz.module.modules.*;
import com.r1zz.render.Toasts;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static final Map<String, Boolean> LAST_STATE = new HashMap<>();
    private static final Map<String, Long> LAST_ERROR = new HashMap<>();
    private static boolean primed;
    private ModuleManager() {}
    public static void initialize() {
        MODULES.clear();
        LAST_STATE.clear();
        primed = false;
        Toasts.clear();
        add(new AimAssist());
        add(new TriggerBot());
        add(new FastGap());
        for (Module m : MODULES) m.load(); R1zzClient.applyLoadedGuiKey();
    }
    private static void add(Module m) { MODULES.add(m); }
    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }
    public static List<Module> in(Module.Category c) { return MODULES.stream().filter(m -> m.category() == c).toList(); }
    public static Module get(String id) { return MODULES.stream().filter(m -> m.id().equals(id)).findFirst().orElse(null); }
    public static VisualToggle visual(String id) { Module m=get(id); return m instanceof VisualToggle v?v:null; }
    public static AimAssist aimAssist(){return (AimAssist)get("aim_assist");}
    public static FastGap fastGap(){return (FastGap)get("fast_gap");}
    public static Velocity velocity(){return (Velocity)get("velocity");}
    public static ESP esp(){return (ESP)get("esp");}
    public static Freecam freecam(){return (Freecam)get("freecam");}
    public static Zoom zoom(){return (Zoom)get("zoom");}
    public static void tick(){
        trackToggles();
        for(Module m:MODULES){
            if(!(m.enabled() || m instanceof Zoom)) continue;
            try { m.onTick(); }
            catch (Throwable t) { reportError(m, t); }
        }
    }
    /** Fires a toast whenever a module's enabled state changes (by key, GUI or config load after startup). */
    private static void trackToggles(){
        for(Module m:MODULES){
            if(m instanceof Zoom || m.id().startsWith("tag_")) continue;
            Boolean previous=LAST_STATE.put(m.id(), m.enabled());
            if(primed && previous!=null && previous!=m.enabled()) Toasts.push(m.name(), m.enabled());
        }
        primed=true;
    }
    /** A faulty module must never crash the game; log at most once every 10 seconds per module. */
    private static void reportError(Module m, Throwable t){
        long now=System.currentTimeMillis();
        Long last=LAST_ERROR.get(m.id());
        if(last==null || now-last>10_000L){
            LAST_ERROR.put(m.id(), now);
            System.err.println("[R1zz] " + m.name() + " tick failed: " + t);
        }
    }
    public static void saveAll(){for(Module m:MODULES)m.persist();}
}
