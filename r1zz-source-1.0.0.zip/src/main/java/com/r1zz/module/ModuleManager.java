package com.r1zz.module;

import com.r1zz.R1zzClient;
import com.r1zz.config.R1zzSettings;
import com.r1zz.module.modules.*;
import com.r1zz.render.Toasts;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static final Map<String, Boolean> LAST_STATE = new HashMap<>();
    private static final Map<String, Long> LAST_ERROR = new HashMap<>();
    private static boolean primed;
    private ModuleManager() {}
    public static void initialize() {
        MODULES.clear();
        LAST_STATE.clear();
        primed = false;
        Toasts.clear();
        add(new AimAssist());
        add(new ShieldBreaker()); add(new CobwebPlacer()); add(new WaterDrain()); add(new MaceSwap()); add(new TriggerBot()); add(new JumpReset()); add(new R1zzAssist());
        add(new AutoCrystal()); add(new Backtrack()); add(new NoHitDelay()); add(new AnchorAura()); add(new AutoTrap()); add(new HoleFiller());
        add(new Surround()); add(new AutoCity()); add(new Offhand()); add(new BowAimbot());
        add(new KillAura()); add(new Reach()); add(new AutoClicker()); add(new Criticals());
        add(new WTap()); add(new STap()); add(new AutoWTap()); add(new AutoBlock()); add(new AutoWeapon()); add(new AutoTool());
        add(new AutoPot());
        add(new Sprint()); add(new AutoSprint()); add(new Step()); add(new NoFall()); add(new Velocity()); add(new AntiVoid()); add(new NoSlow());
        add(new DashDots()); add(new ESP()); add(new Tracers()); add(new Nametags()); add(new Fullbright()); add(new FogBlur());
        add(new Quality()); add(new Strength()); add(new HudElements()); add(new TagElements());
        add(new VisualToggle("tag_head", "Head", true)); add(new VisualToggle("tag_friend_prefix", "Friend Prefix", true));
        add(new VisualToggle("tag_donation", "Donation", true)); add(new VisualToggle("tag_prefix", "Prefix", true)); add(new VisualToggle("tag_suffix", "Suffix", true));
        add(new Range()); add(new PlayerColor()); add(new FriendColor()); add(new Hands()); add(new ColorMode());
        add(new NoHurtCam()); add(new Freecam()); add(new Zoom());
        add(new AutoRespawn()); add(new FastPlace()); add(new AutoTotem()); add(new AntiHunger()); add(new NoRotate());
        add(new TimeChanger()); add(new WeatherChanger());
        add(new AntiAFK()); add(new ChatSuffix()); add(new AutoReply()); add(new Blink()); add(new AutoReconnect()); add(new PacketLogger());
        add(new Ambience());
        add(new Announcer());
        add(new ArmorHUD());
        add(new AutoArmor());
        add(new AutoChat());
        add(new AutoDrop());
        add(new AutoEat());
        add(new AutoFish());
        add(new AutoHeal());
        add(new AutoLog());
        add(new AutoMine());
        add(new AutoNametag());
        add(new AutoSell());
        add(new AutoShear());
        add(new AutoSword());
        add(new AutoTip());
        add(new BedAura());
        add(new BlockESP());
        add(new Chams());
        add(new ChestStealer());
        add(new ClickGUISound());
        add(new Crosshair());
        add(new DiscordRPC());
        add(new ElytraFly());
        add(new FPSBoost());
        add(new FakeLag());
        add(new FastBreak());
        add(new FastLadder());
        add(new Fly());
        add(new HealthBar());
        add(new Hitboxes());
        add(new InvManager());
        add(new ItemPhysics());
        add(new ItemScroller());
        add(new Jesus());
        add(new LogoutSpots());
        add(new LongJump());
        add(new Macro());
        add(new MouseTweaks());
        add(new NameProtect());
        add(new NewChunks());
        add(new NoBreakDelay());
        add(new NoClip());
        add(new NoRender());
        add(new Notifications());
        add(new Nuker());
        add(new PacketFly());
        add(new Parkour());
        add(new Particle());
        add(new Phase());
        add(new PopChams());
        add(new PotionHUD());
        add(new Rainbow());
        add(new RocketESP());
        add(new Scaffold());
        add(new Search());
        add(new SkeletonESP());
        add(new Spam());
        add(new Speed());
        add(new Spider());
        add(new StorageESP());
        add(new Trajectory());
        add(new Tunnel());
        add(new ViewModel());
        add(new Watermark());
        add(new Waypoints());
        R1zzSettings.initialize(); for (Module m : MODULES) { m.load(); R1zzSettings.ensureFor(m.id()); } R1zzSettings.saveAll(); R1zzClient.applyLoadedGuiKey();
    }
    private static void add(Module m) { MODULES.add(m); }
    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }
    public static List<Module> in(Module.Category c) { return MODULES.stream().filter(m -> m.category() == c).toList(); }
    public static Module get(String id) { return MODULES.stream().filter(m -> m.id().equals(id)).findFirst().orElse(null); }
    public static VisualToggle visual(String id) { Module m=get(id); return m instanceof VisualToggle v?v:null; }
    public static AimAssist aimAssist(){return (AimAssist)get("aim_assist");}
    public static Velocity velocity(){return (Velocity)get("velocity");}
    public static ESP esp(){return (ESP)get("esp");}
    public static Freecam freecam(){return (Freecam)get("freecam");}
    public static Zoom zoom(){return (Zoom)get("zoom");}
    public static void tick(){
        trackToggles();
        for(Module m:MODULES){
            if(!(m.enabled() || m instanceof Zoom)) continue;
            try { R1zzSettings.syncToModule(m); m.onTick(); }
            catch (Throwable t) { reportError(m, t); }
        }
    }
    /** Fires a toast whenever a module's enabled state changes (by key, GUI or config load after startup). */
    private static void trackToggles(){
        for(Module m:MODULES){
            if(m instanceof Zoom || m.id().startsWith("tag_")) continue;
            Boolean previous=LAST_STATE.put(m.id(), m.enabled());
            if(primed && previous!=null && previous!=m.enabled()) Toasts.push(m.name(), m.enabled());
        }
        primed=true;
    }
    /** A faulty module must never crash the game; log at most once every 10 seconds per module. */
    private static void reportError(Module m, Throwable t){
        long now=System.currentTimeMillis();
        Long last=LAST_ERROR.get(m.id());
        if(last==null || now-last>10_000L){
            LAST_ERROR.put(m.id(), now);
            System.err.println("[R1zz] " + m.name() + " tick failed: " + t);
        }
    }
    public static void saveAll(){for(Module m:MODULES)m.persist(); R1zzSettings.saveAll();}
}
