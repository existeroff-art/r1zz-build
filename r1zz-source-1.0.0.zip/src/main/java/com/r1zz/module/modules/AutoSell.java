package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoSell extends Module {
    public AutoSell() { super("auto_sell", "AutoSell", Category.MISC, false); }
    private String itemName = "";
    @Override protected void loadSettings() {
        itemName=R1zzConfig.get("auto_sell.itemName","");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("auto_sell.itemName", itemName);
    }
    @Override protected void resetSettings() {
        itemName="";
    }
    public String itemName() { return itemName; }
    public void setItemName(String v) { itemName=v == null ? "" : v; persist(); }
}
