package com.r1zz.module.modules;
public final class Range extends VisualToggle { public Range() { super("range", "Range", 16, 256, 128); } }
