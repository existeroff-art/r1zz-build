package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class LogoutSpots extends Module {
    public LogoutSpots() { super("logout_spots", "LogoutSpots", Category.RENDER, false); }
}
