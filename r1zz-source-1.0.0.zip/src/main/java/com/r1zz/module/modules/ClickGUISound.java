package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class ClickGUISound extends Module {
    public ClickGUISound() { super("click_g_u_i_sound", "ClickGUISound", Category.MISC, false); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
