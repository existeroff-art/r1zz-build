package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class SkeletonESP extends Module {
    public SkeletonESP() { super("skeleton_e_s_p", "SkeletonESP", Category.RENDER, false); }
    private String color = "#FFFFFF";
    @Override protected void loadSettings() {
        color=R1zzConfig.get("skeleton_e_s_p.color","#FFFFFF");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("skeleton_e_s_p.color", color);
    }
    @Override protected void resetSettings() {
        color="#FFFFFF";
    }
    public String color() { return color; }
    public void setColor(String v) { color=v == null ? "" : v; persist(); }
}
