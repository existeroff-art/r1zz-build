package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public class VisualToggle extends Module {
    private final double min, max, defaultValue;
    private final int defaultColor;
    private double value;
    private int color;
    public VisualToggle(String id, String name, boolean enabled) { this(id, name, enabled, Double.NaN, Double.NaN, Double.NaN); }
    public VisualToggle(String id, String name, double min, double max, double value) { this(id, name, false, min, max, value); }
    protected VisualToggle(String id, String name, boolean enabled, double min, double max, double value) {
        super(id, name, Category.RENDER, enabled); this.min = min; this.max = max; this.defaultValue = value; this.value = value;
        defaultColor = switch (id) { case "player_color" -> 0x66CCFF; case "friend_color" -> 0x22DD55; default -> 0x66CCFF; }; color = defaultColor;
    }
    @Override protected void loadSettings() {
        if (hasSlider()) value = clamp(R1zzConfig.getDouble("visual." + id() + ".value", defaultValue), min, max);
        color = R1zzConfig.getInt("visual." + id() + ".color", defaultColor) & 0xFFFFFF;
    }
    @Override protected void saveSettings() { if (hasSlider()) R1zzConfig.put("visual." + id() + ".value", value); R1zzConfig.put("visual." + id() + ".color", color); }
    @Override protected void resetSettings() { value = defaultValue; color = defaultColor; }
    public boolean hasSlider() { return Double.isFinite(min) && Double.isFinite(max); }
    public double min() { return min; } public double max() { return max; } public double value() { return value; }
    public void setValue(double v) { if (hasSlider()) value = clamp(v, min, max); persist(); }
    public int color() { return color; } public void setColor(int v) { color = v & 0xFFFFFF; persist(); }
    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
}
