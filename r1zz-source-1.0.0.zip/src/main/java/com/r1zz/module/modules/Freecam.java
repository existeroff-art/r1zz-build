package com.r1zz.module.modules;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
public final class Freecam extends Module {
    private static Vec3d cameraPos;
    public Freecam(){super("freecam","Freecam",Category.RENDER,false);}
    @Override public void onEnable(){var p=MinecraftClient.getInstance().player;if(p!=null)cameraPos=p.getEyePos();}
    @Override public void onDisable(){cameraPos=null;}
    @Override public void onTick(){var mc=MinecraftClient.getInstance();if(mc.player==null)return;if(cameraPos==null)cameraPos=mc.player.getEyePos();float yaw=(float)Math.toRadians(mc.player.getYaw());Vec3d forward=new Vec3d(-Math.sin(yaw),0,Math.cos(yaw));Vec3d right=new Vec3d(Math.cos(yaw),0,Math.sin(yaw));Vec3d d=Vec3d.ZERO;if(mc.options.forwardKey.isPressed())d=d.add(forward);if(mc.options.backKey.isPressed())d=d.subtract(forward);if(mc.options.rightKey.isPressed())d=d.add(right);if(mc.options.leftKey.isPressed())d=d.subtract(right);if(mc.options.jumpKey.isPressed())d=d.add(0,1,0);if(mc.options.sneakKey.isPressed())d=d.add(0,-1,0);if(d.lengthSquared()>0)cameraPos=cameraPos.add(d.normalize().multiply(.45));}
    public static Vec3d cameraPos(){return cameraPos;}
}
