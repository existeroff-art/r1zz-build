package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoReply extends Module {
    private String reply="";
    private long lastReply;
    public AutoReply(){super("auto_reply","AutoReply",Category.MISC,false);}
    @Override protected void loadSettings(){reply=R1zzConfig.get("misc.auto_reply","");}
    @Override protected void saveSettings(){R1zzConfig.put("misc.auto_reply",reply);}
    @Override protected void resetSettings(){reply="";lastReply=0;}
    public boolean tryReply(String message){
        if(reply.isBlank()||System.currentTimeMillis()-lastReply<500||message==null)return false;
        String lower=message.toLowerCase(java.util.Locale.ROOT);
        if(!lower.contains("whispers to you")&&!lower.contains("whispers:")&&!lower.contains("whispered to you"))return false;
        net.minecraft.client.MinecraftClient mc=net.minecraft.client.MinecraftClient.getInstance();
        if(mc.player==null)return false;
        lastReply=System.currentTimeMillis();
        mc.player.networkHandler.sendChatCommand("r "+reply);
        return true;
    }
    public String reply(){return reply;}
    public void setReply(String v){reply=v==null?"":v.substring(0,Math.min(128,v.length()));persist();}
}
