package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class ChatSuffix extends Module {
    private String suffix=" | R1zz";
    public ChatSuffix(){super("chat_suffix","ChatSuffix",Category.MISC,false);}
    @Override protected void loadSettings(){suffix=R1zzConfig.get("misc.chat_suffix"," | R1zz");}
    @Override protected void saveSettings(){R1zzConfig.put("misc.chat_suffix",suffix);}
    @Override protected void resetSettings(){suffix=" | R1zz";}
    public String suffix(){return suffix;}
    public void setSuffix(String v){suffix=v==null?"":v.substring(0,Math.min(48,v.length()));persist();}
}
