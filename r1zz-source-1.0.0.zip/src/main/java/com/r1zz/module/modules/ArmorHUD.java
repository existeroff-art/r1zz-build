package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class ArmorHUD extends Module {
    public ArmorHUD() { super("armor_h_u_d", "ArmorHUD", Category.RENDER, false); }
}
