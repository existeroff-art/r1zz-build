package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class PotionHUD extends Module {
    public PotionHUD() { super("potion_h_u_d", "PotionHUD", Category.RENDER, false); }
}
