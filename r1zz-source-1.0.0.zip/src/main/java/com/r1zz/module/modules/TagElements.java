package com.r1zz.module.modules;
public final class TagElements extends VisualToggle { public TagElements() { super("tag_elements", "Tag Elements", true); } }
