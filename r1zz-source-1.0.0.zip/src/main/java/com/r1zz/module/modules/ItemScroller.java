package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class ItemScroller extends Module {
    public ItemScroller() { super("item_scroller", "ItemScroller", Category.MISC, false); }
}
