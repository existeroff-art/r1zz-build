package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class ItemPhysics extends Module {
    public ItemPhysics() { super("item_physics", "ItemPhysics", Category.RENDER, false); }
}
