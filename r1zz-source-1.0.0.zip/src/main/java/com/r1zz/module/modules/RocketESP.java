package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class RocketESP extends Module {
    public RocketESP() { super("rocket_e_s_p", "RocketESP", Category.RENDER, false); }
}
