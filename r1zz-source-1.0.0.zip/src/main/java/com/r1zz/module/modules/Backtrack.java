package com.r1zz.module.modules;
import com.r1zz.config.R1zzSettings;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
/** Stores the current combat target briefly; the configured delay is used as a retention window. */
public final class Backtrack extends Module {
    private LivingEntity target; private long since;
    public Backtrack(){super("backtrack","Backtrack",Category.COMBAT,false);}
    @Override public void onTick(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null||mc.world==null){target=null;return;}LivingEntity t=CombatModuleUtil.nearest(mc,6,true);if(t!=null&&mc.player.canSee(t)){target=t;since=System.currentTimeMillis();}if(target!=null&&!target.isAlive()||target!=null&&System.currentTimeMillis()-since>R1zzSettings.getDouble("backtrack.delay",200))target=null;}
    public int delay(){return (int)R1zzSettings.getDouble("backtrack.delay",200);}
    public void setDelay(int v){R1zzSettings.set("backtrack.delay",Math.max(0,Math.min(500,v)));}
}
