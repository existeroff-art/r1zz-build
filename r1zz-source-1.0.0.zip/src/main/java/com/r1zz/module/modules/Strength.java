package com.r1zz.module.modules;
public final class Strength extends VisualToggle { public Strength() { super("strength", "Strength", 0, 100, 15); } }
