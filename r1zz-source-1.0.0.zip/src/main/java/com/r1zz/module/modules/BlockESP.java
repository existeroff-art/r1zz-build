package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class BlockESP extends Module {
    public BlockESP() { super("block_e_s_p", "BlockESP", Category.RENDER, false); }
    private String blocks = "diamond_ore";
    @Override protected void loadSettings() {
        blocks=R1zzConfig.get("block_e_s_p.blocks","diamond_ore");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("block_e_s_p.blocks", blocks);
    }
    @Override protected void resetSettings() {
        blocks="diamond_ore";
    }
    public String blocks() { return blocks; }
    public void setBlocks(String v) { blocks=v == null ? "" : v; persist(); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
