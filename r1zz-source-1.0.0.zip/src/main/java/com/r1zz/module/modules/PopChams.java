package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class PopChams extends Module {
    public PopChams() { super("pop_chams", "PopChams", Category.RENDER, false); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
