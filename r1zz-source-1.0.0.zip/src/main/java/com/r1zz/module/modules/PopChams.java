package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class PopChams extends Module {
    public PopChams() { super("pop_chams", "PopChams", Category.RENDER, false); }
}
