package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.HitResult;

/** Holds attack while your crosshair is on a block, releases it when you look away. */
public final class AutoMine extends Module {
    private boolean holding;

    public AutoMine() { super("auto_mine", "AutoMine", Category.WORLD, false); }

    @Override
    public void onDisable() { release(MinecraftClient.getInstance()); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options == null) return;
        boolean onBlock = mc.currentScreen == null && mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK;
        if (onBlock) {
            mc.options.attackKey.setPressed(true);
            holding = true;
        } else {
            release(mc);
        }
    }

    private void release(MinecraftClient mc) {
        if (holding && mc.options != null) mc.options.attackKey.setPressed(false);
        holding = false;
    }
}
