package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoMine extends Module {
    public AutoMine() { super("auto_mine", "AutoMine", Category.WORLD, false); }
}
