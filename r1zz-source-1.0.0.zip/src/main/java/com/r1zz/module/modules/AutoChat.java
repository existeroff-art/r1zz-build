package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoChat extends Module {
    public AutoChat() { super("auto_chat", "AutoChat", Category.MISC, false); }
    private String message = "";
    private int delay = 3000;
    @Override protected void loadSettings() {
        message=R1zzConfig.get("auto_chat.message","");
        delay=R1zzConfig.getInt("auto_chat.delay",3000);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("auto_chat.message", message);
        R1zzConfig.put("auto_chat.delay", delay);
    }
    @Override protected void resetSettings() {
        message="";
        delay=3000;
    }
    public String message() { return message; }
    public void setMessage(String v) { message=v == null ? "" : v; persist(); }
    public int delay() { return delay; }
    public void setDelay(int v) { delay=Math.max(100,Math.min(10000,v)); persist(); }
}
