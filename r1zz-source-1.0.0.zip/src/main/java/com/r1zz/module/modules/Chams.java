package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class Chams extends Module {
    public Chams() { super("chams", "Chams", Category.RENDER, false); }
    private String color = "#FF0000";
    @Override protected void loadSettings() {
        color=R1zzConfig.get("chams.color","#FF0000");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("chams.color", color);
    }
    @Override protected void resetSettings() {
        color="#FF0000";
    }
    public String color() { return color; }
    public void setColor(String v) { color=v == null ? "" : v; persist(); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
