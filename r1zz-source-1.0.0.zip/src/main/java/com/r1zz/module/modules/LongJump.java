package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class LongJump extends Module {
    public LongJump() { super("long_jump", "LongJump", Category.MOVEMENT, false); }
    private double multiplier = 2;
    private boolean wasOnGround;
    @Override protected void loadSettings() {
        multiplier=R1zzConfig.getDouble("long_jump.multiplier",2);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("long_jump.multiplier", multiplier);
    }
    @Override protected void resetSettings() {
        multiplier=2;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        boolean onGround = p.isOnGround();
        Vec3d v = p.getVelocity();
        // The tick a jump leaves the ground: boost the horizontal launch speed once.
        if (wasOnGround && !onGround && v.y > 0.1 && (p.input.movementForward != 0.0f || p.input.movementSideways != 0.0f)) {
            p.setVelocity(v.x * multiplier, v.y, v.z * multiplier);
        }
        wasOnGround = onGround;
    }

    public double multiplier() { return multiplier; }
    public void setMultiplier(double v) { multiplier=Math.max(1,Math.min(5,v)); persist(); }
}
