package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class LongJump extends Module {
    public LongJump() { super("long_jump", "LongJump", Category.MOVEMENT, false); }
    private double multiplier = 2;
    @Override protected void loadSettings() {
        multiplier=R1zzConfig.getDouble("long_jump.multiplier",2);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("long_jump.multiplier", multiplier);
    }
    @Override protected void resetSettings() {
        multiplier=2;
    }
    public double multiplier() { return multiplier; }
    public void setMultiplier(double v) { multiplier=Math.max(1,Math.min(5,v)); persist(); }
}
