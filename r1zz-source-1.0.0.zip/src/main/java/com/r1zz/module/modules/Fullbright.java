package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class Fullbright extends Module { public Fullbright(){super("fullbright","Fullbright",Category.RENDER,false);} }
