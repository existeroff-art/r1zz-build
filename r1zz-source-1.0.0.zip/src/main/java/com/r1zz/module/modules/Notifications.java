package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Notifications extends Module {
    public Notifications() { super("notifications", "Notifications", Category.MISC, false); }
}
