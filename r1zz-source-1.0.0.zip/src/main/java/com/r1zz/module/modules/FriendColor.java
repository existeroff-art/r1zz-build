package com.r1zz.module.modules;
public final class FriendColor extends VisualToggle { public FriendColor() { super("friend_color", "Friend Color", false); } }
