package com.r1zz.module.modules;

import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.packet.Packet;

import java.util.ArrayList;
import java.util.List;

public final class Blink extends Module {
    private static final List<Queued> QUEUE=new ArrayList<>();
    private static boolean releasing;
    private record Queued(ClientConnection connection,Packet<?> packet,PacketCallbacks callbacks,boolean flush){}
    public Blink(){super("blink","Blink",Category.MISC,false);}
    public static boolean intercept(ClientConnection c,Packet<?> p,PacketCallbacks cb,boolean flush){
        Module m=com.r1zz.module.ModuleManager.get("blink");
        if(releasing||m==null||!m.enabled())return false;
        QUEUE.add(new Queued(c,p,cb,flush));return true;
    }
    @Override public void onDisable(){
        releasing=true;
        try{
            for(Queued q:List.copyOf(QUEUE))q.connection().send(q.packet(),q.callbacks(),q.flush());
            QUEUE.clear();
        }finally{releasing=false;}
    }
    @Override public void onEnable(){QUEUE.clear();}
    public int queued(){return QUEUE.size();}
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
