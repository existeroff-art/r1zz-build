package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class HealthBar extends Module {
    public HealthBar() { super("health_bar", "HealthBar", Category.RENDER, false); }
}
