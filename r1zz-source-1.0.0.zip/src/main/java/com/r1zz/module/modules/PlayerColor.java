package com.r1zz.module.modules;
public final class PlayerColor extends VisualToggle { public PlayerColor() { super("player_color", "Player Color", false); } }
