package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class Particle extends Module {
    public Particle() { super("particle", "Particle", Category.RENDER, false); }
    private String amount = "All";
    @Override protected void loadSettings() {
        amount=R1zzConfig.get("particle.amount","All");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("particle.amount", amount);
    }
    @Override protected void resetSettings() {
        amount="All";
    }
    public String amount() { return amount; }
    public void setAmount(String v) { amount=v == null ? "" : v; persist(); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
