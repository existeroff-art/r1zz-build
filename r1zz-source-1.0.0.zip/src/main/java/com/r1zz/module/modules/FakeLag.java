package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class FakeLag extends Module {
    public FakeLag() { super("fake_lag", "FakeLag", Category.MISC, false); }
    private int delay = 500;
    @Override protected void loadSettings() {
        delay=R1zzConfig.getInt("fake_lag.delay",500);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("fake_lag.delay", delay);
    }
    @Override protected void resetSettings() {
        delay=500;
    }
    public int delay() { return delay; }
    public void setDelay(int v) { delay=Math.max(0,Math.min(2000,v)); persist(); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
