package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Boxes the nearest player in: four blocks at feet level, four at head level and one on top. */
public final class AutoTrap extends Module {
    private double range = 4.0;
    private int cooldown;

    public AutoTrap() { super("auto_trap", "AutoTrap", Category.COMBAT, false); }

    @Override protected void loadSettings() { range = Math.max(3, Math.min(6, R1zzConfig.getDouble("auto_trap.range", 4.0))); }
    @Override protected void saveSettings() { R1zzConfig.put("auto_trap.range", range); }
    @Override protected void resetSettings() { range = 4.0; cooldown = 0; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        LivingEntity target = CombatModuleUtil.nearest(mc, range, true);
        if (target == null) return;
        int slot = CombatModuleUtil.findPlaceSlot(mc);
        if (slot < 0) return;
        BlockPos base = target.getBlockPos();
        BlockPos[] order = new BlockPos[9];
        int n = 0;
        for (Direction d : Direction.Type.HORIZONTAL) order[n++] = base.offset(d);
        for (Direction d : Direction.Type.HORIZONTAL) order[n++] = base.offset(d).up();
        order[n] = base.up(2);
        for (BlockPos pos : order) {
            if (!mc.world.getBlockState(pos).isReplaceable()) continue;
            if (!CombatModuleUtil.reach(mc, pos, 5.0)) continue;
            if (CombatModuleUtil.placeWithSlot(mc, pos, slot)) { cooldown = 1; return; }
        }
    }

    public double range() { return range; }
    public void setRange(double v) { range = Math.max(3, Math.min(6, v)); persist(); }
}
