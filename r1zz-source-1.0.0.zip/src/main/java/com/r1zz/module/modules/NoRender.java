package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class NoRender extends Module {
    public NoRender() { super("no_render", "NoRender", Category.RENDER, false); }
    private boolean fire = true;
    private boolean water = true;
    private boolean lava = true;
    private boolean blocks = false;
    private boolean entities = false;
    private boolean particles = false;
    private boolean armor = false;
    @Override protected void loadSettings() {
        fire=R1zzConfig.getBoolean("no_render.fire",true);
        water=R1zzConfig.getBoolean("no_render.water",true);
        lava=R1zzConfig.getBoolean("no_render.lava",true);
        blocks=R1zzConfig.getBoolean("no_render.blocks",false);
        entities=R1zzConfig.getBoolean("no_render.entities",false);
        particles=R1zzConfig.getBoolean("no_render.particles",false);
        armor=R1zzConfig.getBoolean("no_render.armor",false);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("no_render.fire", fire);
        R1zzConfig.put("no_render.water", water);
        R1zzConfig.put("no_render.lava", lava);
        R1zzConfig.put("no_render.blocks", blocks);
        R1zzConfig.put("no_render.entities", entities);
        R1zzConfig.put("no_render.particles", particles);
        R1zzConfig.put("no_render.armor", armor);
    }
    @Override protected void resetSettings() {
        fire=true;
        water=true;
        lava=true;
        blocks=false;
        entities=false;
        particles=false;
        armor=false;
    }
    public boolean fire() { return fire; }
    public void setFire(boolean v) { fire=v; persist(); }
    public boolean water() { return water; }
    public void setWater(boolean v) { water=v; persist(); }
    public boolean lava() { return lava; }
    public void setLava(boolean v) { lava=v; persist(); }
    public boolean blocks() { return blocks; }
    public void setBlocks(boolean v) { blocks=v; persist(); }
    public boolean entities() { return entities; }
    public void setEntities(boolean v) { entities=v; persist(); }
    public boolean particles() { return particles; }
    public void setParticles(boolean v) { particles=v; persist(); }
    public boolean armor() { return armor; }
    public void setArmor(boolean v) { armor=v; persist(); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
