package com.r1zz.module.modules;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;
public final class PacketLogger extends Module { public PacketLogger(){super("packet_logger","PacketLogger",Category.MISC,false);}     @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
