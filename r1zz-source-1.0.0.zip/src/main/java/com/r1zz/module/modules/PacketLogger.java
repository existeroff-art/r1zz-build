package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class PacketLogger extends Module { public PacketLogger(){super("packet_logger","PacketLogger",Category.MISC,false);} }
