package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Macro extends Module {
    public Macro() { super("macro", "Macro", Category.MISC, false); }
    private String name = "macro";
    private int keybind = -1;
    private String actions = "";
    @Override protected void loadSettings() {
        name=R1zzConfig.get("macro.name","macro");
        keybind=R1zzConfig.getInt("macro.keybind",-1);
        actions=R1zzConfig.get("macro.actions","");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("macro.name", name);
        R1zzConfig.put("macro.keybind", keybind);
        R1zzConfig.put("macro.actions", actions);
    }
    @Override protected void resetSettings() {
        name="macro";
        keybind=-1;
        actions="";
    }
    public String name() { return name; }
    public void setName(String v) { name=v == null ? "" : v; persist(); }
    public int keybind() { return keybind; }
    public void setKeybind(int v) { keybind=Math.max(-1,Math.min(348,v)); persist(); }
    public String actions() { return actions; }
    public void setActions(String v) { actions=v == null ? "" : v; persist(); }
}
