package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public final class Macro extends Module {
    public Macro() { super("macro", "Macro", Category.MISC, false); }
    private String name = "macro";
    private int keybind = -1;
    private String actions = "";
    private boolean keyWasDown;
    @Override protected void loadSettings() {
        name=R1zzConfig.get("macro.name","macro");
        keybind=R1zzConfig.getInt("macro.keybind",-1);
        actions=R1zzConfig.get("macro.actions","");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("macro.name", name);
        R1zzConfig.put("macro.keybind", keybind);
        R1zzConfig.put("macro.actions", actions);
    }
    @Override protected void resetSettings() {
        name="macro";
        keybind=-1;
        actions="";
    }

    /** Runs the semicolon separated actions (chat messages or /commands) when the macro key is pressed. */
    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.getWindow() == null || keybind < 0) { keyWasDown = false; return; }
        boolean down = mc.currentScreen == null && GLFW.glfwGetKey(mc.getWindow().getHandle(), keybind) == GLFW.GLFW_PRESS;
        if (down && !keyWasDown) {
            for (String action : actions.split(";")) {
                String trimmed = action.trim();
                if (!trimmed.isEmpty()) CombatModuleUtil.chat(mc, trimmed);
            }
        }
        keyWasDown = down;
    }
    public String name() { return name; }
    public void setName(String v) { name=v == null ? "" : v; persist(); }
    public int keybind() { return keybind; }
    public void setKeybind(int v) { keybind=Math.max(-1,Math.min(348,v)); persist(); }
    public String actions() { return actions; }
    public void setActions(String v) { actions=v == null ? "" : v; persist(); }
}
