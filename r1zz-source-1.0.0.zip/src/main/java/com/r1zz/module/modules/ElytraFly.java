package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class ElytraFly extends Module {
    public ElytraFly() { super("elytra_fly", "ElytraFly", Category.MOVEMENT, false); }
    private double speed = 1.5;
    @Override protected void loadSettings() {
        speed=R1zzConfig.getDouble("elytra_fly.speed",1.5);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("elytra_fly.speed", speed);
    }
    @Override protected void resetSettings() {
        speed=1.5;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options == null || mc.currentScreen != null || !p.isFallFlying()) return;
        if (mc.options.forwardKey.isPressed()) {
            Vec3d look = p.getRotationVec(1.0f);
            p.setVelocity(look.multiply(speed));
        } else if (mc.options.sneakKey.isPressed()) {
            p.setVelocity(Vec3d.ZERO);
        }
    }

    public double speed() { return speed; }
    public void setSpeed(double v) { speed=Math.max(0.1,Math.min(5,v)); persist(); }
}
