package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class ElytraFly extends Module {
    public ElytraFly() { super("elytra_fly", "ElytraFly", Category.MOVEMENT, false); }
    private double speed = 1.5;
    @Override protected void loadSettings() {
        speed=R1zzConfig.getDouble("elytra_fly.speed",1.5);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("elytra_fly.speed", speed);
    }
    @Override protected void resetSettings() {
        speed=1.5;
    }
    public double speed() { return speed; }
    public void setSpeed(double v) { speed=Math.max(0.1,Math.min(5,v)); persist(); }
}
