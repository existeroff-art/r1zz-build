package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class ViewModel extends Module {
    public ViewModel() { super("view_model", "ViewModel", Category.RENDER, false); }
    private double x = 0;
    private double y = 0;
    private double z = 0;
    private double scale = 1;
    @Override protected void loadSettings() {
        x=R1zzConfig.getDouble("view_model.x",0);
        y=R1zzConfig.getDouble("view_model.y",0);
        z=R1zzConfig.getDouble("view_model.z",0);
        scale=R1zzConfig.getDouble("view_model.scale",1);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("view_model.x", x);
        R1zzConfig.put("view_model.y", y);
        R1zzConfig.put("view_model.z", z);
        R1zzConfig.put("view_model.scale", scale);
    }
    @Override protected void resetSettings() {
        x=0;
        y=0;
        z=0;
        scale=1;
    }
    public double x() { return x; }
    public void setX(double v) { x=Math.max(-2,Math.min(2,v)); persist(); }
    public double y() { return y; }
    public void setY(double v) { y=Math.max(-2,Math.min(2,v)); persist(); }
    public double z() { return z; }
    public void setZ(double v) { z=Math.max(-2,Math.min(2,v)); persist(); }
    public double scale() { return scale; }
    public void setScale(double v) { scale=Math.max(0.1,Math.min(3,v)); persist(); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
