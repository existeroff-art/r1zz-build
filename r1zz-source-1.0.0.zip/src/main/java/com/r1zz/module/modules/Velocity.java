package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
public final class Velocity extends Module {
    private double horizontal, vertical;
    public Velocity(){super("velocity","Velocity",Category.MOVEMENT,false);}
    @Override protected void loadSettings(){horizontal=clamp(R1zzConfig.getDouble("velocity.horizontal",0),0,100);vertical=clamp(R1zzConfig.getDouble("velocity.vertical",0),0,100);}
    @Override protected void saveSettings(){R1zzConfig.put("velocity.horizontal",horizontal);R1zzConfig.put("velocity.vertical",vertical);}
    @Override protected void resetSettings(){horizontal=0;vertical=0;}
    public double horizontal(){return horizontal;} public void setHorizontal(double v){horizontal=clamp(v,0,100);persist();}
    public double vertical(){return vertical;} public void setVertical(double v){vertical=clamp(v,0,100);persist();}
    private static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}
}
