package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import java.util.Comparator;

final class CombatModuleUtil {
    private CombatModuleUtil() {}
    static LivingEntity nearest(MinecraftClient mc, double range, boolean playersOnly) {
        if (mc.player == null || mc.world == null) return null;
        Box box = mc.player.getBoundingBox().expand(range);
        return mc.world.getEntitiesByClass(LivingEntity.class, box,
                e -> e != mc.player && e.isAlive() && !e.isSpectator() &&
                        (!playersOnly || e instanceof PlayerEntity))
                .stream().min(Comparator.comparingDouble(mc.player::distanceTo)).orElse(null);
    }
    static void attack(MinecraftClient mc, LivingEntity target) {
        if (mc.player == null || mc.interactionManager == null || target == null) return;
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
    }
    static int findHotbar(PlayerEntity p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }
    static int findHotbarAny(PlayerEntity p, Item... items) {
        for (int i = 0; i < 9; i++) {
            ItemStack s=p.getInventory().getStack(i);
            for(Item item:items) if(s.isOf(item)) return i;
        }
        return -1;
    }
    static boolean validTarget(MinecraftClient mc, LivingEntity e, double range, String targetType) {
        if (e == null || mc.player == null || e == mc.player || !e.isAlive() || e.isSpectator()) return false;
        if (mc.player.distanceTo(e) > range) return false;
        if ("Players".equals(targetType) && !(e instanceof PlayerEntity)) return false;
        if ("Entities".equals(targetType) && e instanceof PlayerEntity) return false;
        return true;
    }
    static int bestToolSlot(PlayerEntity p, BlockState state) {
        int best = p.getInventory().selectedSlot;
        float bestSpeed = p.getInventory().getStack(best).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            ItemStack stack = p.getInventory().getStack(i);
            float speed = stack.getMiningSpeedMultiplier(state);
            if (speed > bestSpeed) { bestSpeed = speed; best = i; }
        }
        return best;
    }
    static void select(PlayerEntity p, int slot) { if (slot >= 0 && slot < 9) p.getInventory().selectedSlot = slot; }
}
