package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import java.util.Comparator;

final class CombatModuleUtil {
    private CombatModuleUtil() {}
    static LivingEntity nearest(MinecraftClient mc, double range, boolean playersOnly) {
        if (mc.player == null || mc.world == null) return null;
        Box box = mc.player.getBoundingBox().expand(range);
        return mc.world.getEntitiesByClass(LivingEntity.class, box,
                e -> e != mc.player && e.isAlive() && !e.isSpectator() &&
                        (!playersOnly || e instanceof PlayerEntity))
                .stream().min(Comparator.comparingDouble(mc.player::distanceTo)).orElse(null);
    }
    static void attack(MinecraftClient mc, LivingEntity target) {
        if (mc.player == null || mc.interactionManager == null || target == null) return;
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
    }
    static int findHotbar(PlayerEntity p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }
    static int findHotbarAny(PlayerEntity p, Item... items) {
        for (int i = 0; i < 9; i++) {
            ItemStack s=p.getInventory().getStack(i);
            for(Item item:items) if(s.isOf(item)) return i;
        }
        return -1;
    }
    static boolean validTarget(MinecraftClient mc, LivingEntity e, double range, String targetType) {
        if (e == null || mc.player == null || e == mc.player || !e.isAlive() || e.isSpectator()) return false;
        if (mc.player.distanceTo(e) > range) return false;
        if ("Players".equals(targetType) && !(e instanceof PlayerEntity)) return false;
        if ("Entities".equals(targetType) && e instanceof PlayerEntity) return false;
        return true;
    }
    static int bestToolSlot(PlayerEntity p, BlockState state) {
        int best = p.getInventory().selectedSlot;
        float bestSpeed = p.getInventory().getStack(best).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            ItemStack stack = p.getInventory().getStack(i);
            float speed = stack.getMiningSpeedMultiplier(state);
            if (speed > bestSpeed) { bestSpeed = speed; best = i; }
        }
        return best;
    }
    static void select(PlayerEntity p, int slot) { if (slot >= 0 && slot < 9) p.getInventory().selectedSlot = slot; }

    // ---------------------------------------------------------------- helpers used by the gameplay modules
    static int weaponRank(Item item) {
        if (item == Items.NETHERITE_SWORD) return 100;
        if (item == Items.DIAMOND_SWORD) return 90;
        if (item == Items.IRON_SWORD) return 80;
        if (item == Items.STONE_SWORD) return 70;
        if (item == Items.GOLDEN_SWORD) return 60;
        if (item == Items.WOODEN_SWORD) return 50;
        if (item == Items.NETHERITE_AXE) return 45;
        if (item == Items.DIAMOND_AXE) return 44;
        if (item == Items.IRON_AXE) return 43;
        if (item == Items.STONE_AXE) return 42;
        if (item == Items.GOLDEN_AXE) return 41;
        if (item == Items.WOODEN_AXE) return 40;
        if (item instanceof MaceItem) return 30;
        if (item instanceof TridentItem) return 20;
        return 0;
    }
    static boolean isSword(Item item) { return item instanceof SwordItem; }
    static boolean isWeapon(Item item) { return item instanceof SwordItem || item instanceof AxeItem || item instanceof MaceItem || item instanceof TridentItem; }

    static boolean isHealingPotion(ItemStack stack) {
        if (!(stack.isOf(Items.POTION) || stack.isOf(Items.SPLASH_POTION))) return false;
        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) return false;
        for (StatusEffectInstance effect : contents.getEffects()) {
            if (effect.getEffectType() == StatusEffects.INSTANT_HEALTH || effect.getEffectType() == StatusEffects.REGENERATION) return true;
        }
        return false;
    }

    /** Hotbar slot of the preferred placement block: obsidian first, then any full solid block. */
    static int findPlaceSlot(MinecraftClient mc) {
        int obsidian = findHotbar(mc.player, Items.OBSIDIAN);
        if (obsidian >= 0) return obsidian;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!(stack.getItem() instanceof BlockItem blockItem)) continue;
            Block block = blockItem.getBlock();
            BlockState state = block.getDefaultState();
            if (!state.isReplaceable() && state.isSolidBlock(mc.world, mc.player.getBlockPos())
                    && !(block instanceof net.minecraft.block.FallingBlock)) return i;
        }
        return -1;
    }

    /** Places the held block at pos by clicking any solid neighbour. Returns true when the click was accepted. */
    static boolean placeAt(MinecraftClient mc, BlockPos pos) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return false;
        if (!mc.world.getBlockState(pos).isReplaceable()) return false;
        for (Direction d : Direction.values()) {
            BlockPos neighbour = pos.offset(d);
            BlockState state = mc.world.getBlockState(neighbour);
            if (state.isAir() || state.isReplaceable()) continue;
            Direction face = d.getOpposite();
            Vec3d hitPos = Vec3d.ofCenter(neighbour).add(Vec3d.of(face.getVector()).multiply(0.5));
            var result = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hitPos, face, neighbour, false));
            if (result.isAccepted()) { mc.player.swingHand(Hand.MAIN_HAND); return true; }
        }
        return false;
    }

    /** Selects slot, places a block at pos, restores the previous slot. */
    static boolean placeWithSlot(MinecraftClient mc, BlockPos pos, int slot) {
        if (slot < 0) return false;
        int old = mc.player.getInventory().selectedSlot;
        select(mc.player, slot);
        boolean ok = placeAt(mc, pos);
        select(mc.player, old);
        return ok;
    }

    static boolean reach(MinecraftClient mc, BlockPos pos, double range) {
        return mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= range * range;
    }

    /** Whether the physical key behind a KeyBinding is currently held (ignores programmatic overrides). */
    static boolean physicalDown(MinecraftClient mc, KeyBinding key) {
        if (mc.getWindow() == null) return false;
        int code = KeyBindingHelper.getBoundKeyOf(key).getCode();
        return code >= 0 && InputUtil.isKeyPressed(mc.getWindow().getHandle(), code);
    }

    /** Smooth GCD-clamped rotation toward a world position. */
    static void rotateToward(MinecraftClient mc, Vec3d target, float factor, float yawCap, float pitchCap) {
        Vec3d diff = target.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));
        float yawStep = net.minecraft.util.math.MathHelper.wrapDegrees(targetYaw - mc.player.getYaw()) * factor;
        float pitchStep = (targetPitch - mc.player.getPitch()) * factor;
        yawStep = net.minecraft.util.math.MathHelper.clamp(yawStep, -yawCap, yawCap);
        pitchStep = net.minecraft.util.math.MathHelper.clamp(pitchStep, -pitchCap, pitchCap);
        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }
        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(net.minecraft.util.math.MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    /** Horizontal movement vector from the player's current input, scaled to speed (zero when not moving). */
    static Vec3d inputDirection(net.minecraft.client.network.ClientPlayerEntity p, double speed) {
        float f = p.input.movementForward;
        float s = p.input.movementSideways;
        if (f == 0.0f && s == 0.0f) return Vec3d.ZERO;
        double yaw = Math.toRadians(p.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double x = s * cos - f * sin;
        double z = f * cos + s * sin;
        double len = Math.sqrt(x * x + z * z);
        if (len < 1.0e-6) return Vec3d.ZERO;
        return new Vec3d(x / len * speed, 0.0, z / len * speed);
    }

    /** Screen-handler slot index for a player-inventory index (0-8 hotbar, 9-35 main). */
    static int screenSlot(int inventoryIndex) { return inventoryIndex < 9 ? 36 + inventoryIndex : inventoryIndex; }

    /** Sends a chat message, or a command when it starts with a slash. */
    static void chat(MinecraftClient mc, String message) {
        if (mc.player == null || mc.player.networkHandler == null || message == null || message.isBlank()) return;
        if (message.startsWith("/")) mc.player.networkHandler.sendChatCommand(message.substring(1));
        else mc.player.networkHandler.sendChatMessage(message);
    }
}
