package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Comparator;

public final class BedAura extends Module {
    private double range = 5.0;
    private int delay = 6;
    private BlockPos targetBed;
    private int delayTicks;

    public BedAura() {
        super("bed_aura", "BedAura", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        range = clamp(R1zzConfig.getDouble("bed_aura.range", 5.0), 1.0, 6.0);
        delay = Math.max(1, Math.min(20, R1zzConfig.getInt("bed_aura.delay", 6)));
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("bed_aura.range", range);
        R1zzConfig.put("bed_aura.delay", delay);
    }

    @Override
    protected void resetSettings() {
        range = 5.0;
        delay = 6;
        clearTarget();
    }

    @Override
    public void onDisable() {
        clearTarget();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        if (targetBed != null && (!isBed(mc, targetBed) || !inRange(mc, targetBed) || !hasLineOfSight(mc, targetBed))) {
            clearTarget();
        }
        if (targetBed == null) {
            targetBed = findBed(mc);
            if (targetBed == null) return;
            delayTicks = delay;
        }
        if (delayTicks > 0) {
            delayTicks--;
            return;
        }

        BlockHitResult hit = new BlockHitResult(
                Vec3d.ofCenter(targetBed),
                Direction.UP,
                targetBed,
                false
        );
        mc.interactionManager.updateBlockBreakingProgress(targetBed, hit.getSide());
        mc.player.swingHand(Hand.MAIN_HAND);
        if (!isBed(mc, targetBed)) clearTarget();
    }

    private BlockPos findBed(MinecraftClient mc) {
        BlockPos origin = mc.player.getBlockPos();
        int radius = (int) Math.ceil(range);
        return BlockPos.stream(origin.add(-radius, -radius, -radius), origin.add(radius, radius, radius))
                .map(BlockPos::toImmutable)
                .filter(pos -> inRange(mc, pos))
                .filter(pos -> isBed(mc, pos))
                .filter(pos -> hasLineOfSight(mc, pos))
                .min(Comparator.comparingDouble(pos -> mc.player.squaredDistanceTo(Vec3d.ofCenter(pos))))
                .orElse(null);
    }

    private boolean isBed(MinecraftClient mc, BlockPos pos) {
        BlockState state = mc.world.getBlockState(pos);
        return state.isIn(net.minecraft.registry.tag.BlockTags.BEDS) && !state.isOf(Blocks.AIR);
    }

    private boolean inRange(MinecraftClient mc, BlockPos pos) {
        return mc.player.squaredDistanceTo(Vec3d.ofCenter(pos)) <= range * range;
    }

    private boolean hasLineOfSight(MinecraftClient mc, BlockPos pos) {
        Vec3d start = mc.player.getEyePos();
        Vec3d end = Vec3d.ofCenter(pos);
        BlockHitResult hit = mc.world.raycast(new RaycastContext(
                start,
                end,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                mc.player
        ));
        return hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(pos);
    }

    private void clearTarget() {
        targetBed = null;
        delayTicks = 0;
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    public double range() { return range; }
    public void setRange(double value) { range = clamp(value, 1.0, 6.0); persist(); }
    public int delay() { return delay; }
    public void setDelay(int value) { delay = Math.max(1, Math.min(20, value)); persist(); }
}
