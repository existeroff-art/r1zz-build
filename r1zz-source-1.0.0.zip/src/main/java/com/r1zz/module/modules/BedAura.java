package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class BedAura extends Module {
    public BedAura() { super("bed_aura", "BedAura", Category.COMBAT, false); }
    private double range = 5;
    private int delay = 6;
    @Override protected void loadSettings() {
        range=R1zzConfig.getDouble("bed_aura.range",5);
        delay=R1zzConfig.getInt("bed_aura.delay",6);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("bed_aura.range", range);
        R1zzConfig.put("bed_aura.delay", delay);
    }
    @Override protected void resetSettings() {
        range=5;
        delay=6;
    }
    public double range() { return range; }
    public void setRange(double v) { range=Math.max(1,Math.min(6,v)); persist(); }
    public int delay() { return delay; }
    public void setDelay(int v) { delay=Math.max(1,Math.min(20,v)); persist(); }
}
