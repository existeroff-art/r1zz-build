package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;

public final class AntiHunger extends Module {
    public AntiHunger(){super("anti_hunger","AntiHunger",Category.PLAYER,false);}
    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null)return;
        // Client-side saturation preservation; the server may correct this on servers that validate hunger.
        float s=mc.player.getHungerManager().getSaturationLevel();
        if(mc.player.isSprinting() && s<1.0f)mc.player.getHungerManager().setSaturationLevel(Math.min(1.0f,s+0.001f));
    }
}
