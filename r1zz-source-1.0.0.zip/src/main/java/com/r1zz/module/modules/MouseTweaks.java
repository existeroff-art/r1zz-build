package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class MouseTweaks extends Module {
    public MouseTweaks() { super("mouse_tweaks", "MouseTweaks", Category.MISC, false); }
}
