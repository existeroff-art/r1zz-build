package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
public final class TimeChanger extends Module {
    private int time=6000;
    public TimeChanger(){super("time_changer","TimeChanger",Category.WORLD,false);}
    @Override protected void loadSettings(){time=Math.max(0,Math.min(24000,R1zzConfig.getInt("world.time",6000)));}
    @Override protected void saveSettings(){R1zzConfig.put("world.time",time);}
    @Override protected void resetSettings(){time=6000;}
    public int time(){return time;}
    public void setTime(int value){time=Math.max(0,Math.min(24000,value));persist();}
}
