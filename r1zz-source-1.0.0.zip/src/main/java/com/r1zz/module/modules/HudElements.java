package com.r1zz.module.modules;
public final class HudElements extends VisualToggle { public HudElements() { super("hud_elements", "HUD Elements", false); } }
