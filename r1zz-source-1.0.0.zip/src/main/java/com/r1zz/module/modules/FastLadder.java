package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Climb ladders and vines much faster while pushing into them. */
public final class FastLadder extends Module {
    public FastLadder() { super("fast_ladder", "FastLadder", Category.MOVEMENT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options == null || mc.currentScreen != null) return;
        if (!p.isClimbing() || !p.horizontalCollision || p.isSneaking()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, 0.3, v.z);
    }
}
