package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class FastLadder extends Module {
    public FastLadder() { super("fast_ladder", "FastLadder", Category.MOVEMENT, false); }
}
