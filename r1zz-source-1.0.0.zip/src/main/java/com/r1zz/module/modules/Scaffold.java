package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Scaffold extends Module {
    public Scaffold() { super("scaffold", "Scaffold", Category.MOVEMENT, false); }
    private int delay = 3;
    private String rotation = "Smooth";
    @Override protected void loadSettings() {
        delay=R1zzConfig.getInt("scaffold.delay",3);
        rotation=R1zzConfig.get("scaffold.rotation","Smooth");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("scaffold.delay", delay);
        R1zzConfig.put("scaffold.rotation", rotation);
    }
    @Override protected void resetSettings() {
        delay=3;
        rotation="Smooth";
    }
    public int delay() { return delay; }
    public void setDelay(int v) { delay=Math.max(1,Math.min(10,v)); persist(); }
    public String rotation() { return rotation; }
    public void setRotation(String v) { rotation=v == null ? "" : v; persist(); }
}
