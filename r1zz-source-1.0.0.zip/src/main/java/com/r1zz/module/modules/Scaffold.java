package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public final class Scaffold extends Module {
    public Scaffold() { super("scaffold", "Scaffold", Category.MOVEMENT, false); }
    private int delay = 3;
    private String rotation = "Smooth";
    private int ticks;
    @Override protected void loadSettings() {
        delay=R1zzConfig.getInt("scaffold.delay",3);
        rotation=R1zzConfig.get("scaffold.rotation","Smooth");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("scaffold.delay", delay);
        R1zzConfig.put("scaffold.rotation", rotation);
    }
    @Override protected void resetSettings() {
        delay=3;
        rotation="Smooth";
        ticks=0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try { tick(mc); } catch (RuntimeException ignored) { }
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (ticks > 0) { ticks--; return; }
        int slot = CombatModuleUtil.findPlaceSlot(mc);
        if (slot < 0) return;

        Vec3d v = p.getVelocity();
        BlockPos under = BlockPos.ofFloored(p.getX(), p.getY() - 1.0, p.getZ());
        BlockPos ahead = BlockPos.ofFloored(p.getX() + v.x * 3.0, p.getY() - 1.0, p.getZ() + v.z * 3.0);
        BlockPos target = mc.world.getBlockState(under).isReplaceable() ? under
                : (mc.world.getBlockState(ahead).isReplaceable() ? ahead : null);
        if (target == null) return;

        if (!"None".equals(rotation)) {
            float gcd = Humanizer.gcd(mc);
            float want = 78.0f + (float) (Math.random() * 6.0);
            float factor = "Snap".equals(rotation) ? 0.85f : 0.35f;
            float step = Humanizer.snap((want - p.getPitch()) * factor, gcd);
            p.setPitch(Math.max(-90.0f, Math.min(90.0f, p.getPitch() + Math.max(-20.0f, Math.min(20.0f, step)))));
        }

        if (CombatModuleUtil.placeWithSlot(mc, target, slot)) ticks = Math.max(0, delay - 1 + Humanizer.ticks(0, 2));
    }

    public int delay() { return delay; }
    public void setDelay(int v) { delay=Math.max(1,Math.min(10,v)); persist(); }
    public String rotation() { return rotation; }
    public void setRotation(String v) { rotation=v == null ? "" : v; persist(); }
}
