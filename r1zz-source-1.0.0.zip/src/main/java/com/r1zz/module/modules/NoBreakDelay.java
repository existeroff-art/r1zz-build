package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Starts the next block immediately after one breaks instead of waiting out the vanilla break cooldown. */
public final class NoBreakDelay extends Module {
    public NoBreakDelay() { super("no_break_delay", "NoBreakDelay", Category.WORLD, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.options == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed() || mc.interactionManager.isBreakingBlock()) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        if (mc.world.getBlockState(hit.getBlockPos()).isAir()) return;
        mc.interactionManager.attackBlock(hit.getBlockPos(), hit.getSide());
        mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
    }
}
