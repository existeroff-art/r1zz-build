package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class NoBreakDelay extends Module {
    public NoBreakDelay() { super("no_break_delay", "NoBreakDelay", Category.WORLD, false); }
}
