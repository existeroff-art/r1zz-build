package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public final class AntiVoid extends Module {
    private long lastUse;
    public AntiVoid(){super("anti_void","AntiVoid",Category.MOVEMENT,false);}
    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.player.getY()>=-60||System.currentTimeMillis()-lastUse<2000)return;
        lastUse=System.currentTimeMillis();
        mc.player.setPosition(mc.player.getX(),64,mc.player.getZ());
        mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(),64,mc.player.getZ(),true));
    }
    @Override public void onDisable(){lastUse=0;}
}
