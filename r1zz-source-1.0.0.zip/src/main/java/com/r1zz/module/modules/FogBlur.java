package com.r1zz.module.modules;
public final class FogBlur extends VisualToggle { public FogBlur() { super("fog_blur", "Fog Blur", false); } }
