package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class FastGapple extends Module {
    public FastGapple(){super("fast_gapple","Fast Gapple",Category.COMBAT,false);}
}