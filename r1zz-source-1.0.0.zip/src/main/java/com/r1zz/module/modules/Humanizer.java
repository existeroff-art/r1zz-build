package com.r1zz.module.modules;

import net.minecraft.client.MinecraftClient;

import java.util.concurrent.ThreadLocalRandom;

/** Shared helpers that keep module behaviour human-looking: randomised delays and GCD-aligned rotation steps. */
final class Humanizer {
    private Humanizer() {}

    /** base +/- frac (0.2 = +/-20%). */
    static long jitter(long base, double frac) {
        if (base <= 0L) return 0L;
        double f = 1.0 + ThreadLocalRandom.current().nextDouble(-frac, frac);
        return Math.max(1L, Math.round(base * f));
    }

    static long between(long min, long max) {
        if (max <= min) return min;
        return ThreadLocalRandom.current().nextLong(min, max + 1L);
    }

    static int ticks(int min, int max) {
        if (max <= min) return min;
        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }

    /** True with the given probability (0..1). */
    static boolean chance(double p) {
        return ThreadLocalRandom.current().nextDouble() < p;
    }

    /** Minimum rotation step the vanilla mouse can produce at the current sensitivity. */
    static float gcd(MinecraftClient mc) {
        if (mc.options == null) return 0.0f;
        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        return f * f * f * 1.2f;
    }

    static float snap(float delta, float gcd) {
        return gcd > 0.0f ? Math.round(delta / gcd) * gcd : delta;
    }
}
