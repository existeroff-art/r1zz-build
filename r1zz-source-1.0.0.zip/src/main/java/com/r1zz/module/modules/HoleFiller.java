package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.Comparator;

/** Fills 1x1 holes (solid floor and four solid walls) near you while an enemy player is close. */
public final class HoleFiller extends Module {
    private double range = 4.0;
    private int cooldown;

    public HoleFiller() { super("hole_filler", "HoleFiller", Category.COMBAT, false); }

    @Override protected void loadSettings() { range = Math.max(3, Math.min(6, R1zzConfig.getDouble("hole_filler.range", 4.0))); }
    @Override protected void saveSettings() { R1zzConfig.put("hole_filler.range", range); }
    @Override protected void resetSettings() { range = 4.0; cooldown = 0; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        LivingEntity enemy = CombatModuleUtil.nearest(mc, range + 4.0, true);
        if (enemy == null) return;
        int slot = CombatModuleUtil.findPlaceSlot(mc);
        if (slot < 0) return;
        BlockPos origin = mc.player.getBlockPos();
        BlockPos own = mc.player.getBlockPos();
        int r = (int) Math.ceil(range);
        BlockPos hole = BlockPos.stream(origin.add(-r, -2, -r), origin.add(r, 2, r))
                .map(BlockPos::toImmutable)
                .filter(p -> !p.equals(own) && CombatModuleUtil.reach(mc, p, range) && isHole(mc, p))
                .min(Comparator.comparingDouble(p -> p.getSquaredDistance(enemy.getPos())))
                .orElse(null);
        if (hole == null) return;
        if (CombatModuleUtil.placeWithSlot(mc, hole, slot)) cooldown = 1;
    }

    private boolean isHole(MinecraftClient mc, BlockPos pos) {
        if (!mc.world.getBlockState(pos).isReplaceable() || !mc.world.getBlockState(pos.up()).isReplaceable()) return false;
        if (mc.world.getBlockState(pos.down()).isReplaceable()) return false;
        for (Direction d : Direction.Type.HORIZONTAL) {
            if (mc.world.getBlockState(pos.offset(d)).isReplaceable()) return false;
        }
        return true;
    }

    public double range() { return range; }
    public void setRange(double v) { range = Math.max(3, Math.min(6, v)); persist(); }
}
