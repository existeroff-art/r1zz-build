package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class DiscordRPC extends Module {
    public DiscordRPC() { super("discord_r_p_c", "DiscordRPC", Category.MISC, false); }
}
