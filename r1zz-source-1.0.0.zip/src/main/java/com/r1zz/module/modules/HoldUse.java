package com.r1zz.module.modules;

import net.minecraft.client.MinecraftClient;

/** Holds the use key on a hotbar slot until the item finishes (food, drinkable potions), then restores the slot. */
final class HoldUse {
    private int oldSlot = -1;
    private boolean active;
    private int held;

    boolean active() { return active; }

    void begin(MinecraftClient mc, int slot) {
        if (active || mc.player == null || mc.options == null || slot < 0) return;
        oldSlot = mc.player.getInventory().selectedSlot;
        CombatModuleUtil.select(mc.player, slot);
        mc.options.useKey.setPressed(true);
        active = true;
        held = 0;
    }

    /** Call every tick. Returns true while the item is still being used. */
    boolean tick(MinecraftClient mc) {
        if (!active) return false;
        held++;
        if (mc.player == null) { active = false; return false; }
        if ((held > 2 && !mc.player.isUsingItem()) || held > 80) { end(mc); return false; }
        return true;
    }

    void end(MinecraftClient mc) {
        if (!active) return;
        active = false;
        if (mc.options != null) mc.options.useKey.setPressed(false);
        if (mc.player != null && oldSlot >= 0) CombatModuleUtil.select(mc.player, oldSlot);
        oldSlot = -1;
    }
}
