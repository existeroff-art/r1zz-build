package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoSword extends Module {
    public AutoSword() { super("auto_sword", "AutoSword", Category.PLAYER, false); }
}
