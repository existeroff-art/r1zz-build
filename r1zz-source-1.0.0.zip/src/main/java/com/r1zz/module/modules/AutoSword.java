package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

/** Switches to the best sword in the hotbar when you attack something. */
public final class AutoSword extends Module {
    public AutoSword() { super("auto_sword", "AutoSword", Category.PLAYER, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options == null) return;
        if (!mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof LivingEntity)) return;
        int best = -1;
        int bestRank = CombatModuleUtil.isSword(mc.player.getMainHandStack().getItem()) ? CombatModuleUtil.weaponRank(mc.player.getMainHandStack().getItem()) : 0;
        for (int i = 0; i < 9; i++) {
            net.minecraft.item.Item item = mc.player.getInventory().getStack(i).getItem();
            if (!CombatModuleUtil.isSword(item)) continue;
            int rank = CombatModuleUtil.weaponRank(item);
            if (rank > bestRank) { bestRank = rank; best = i; }
        }
        if (best >= 0) CombatModuleUtil.select(mc.player, best);
    }
}
