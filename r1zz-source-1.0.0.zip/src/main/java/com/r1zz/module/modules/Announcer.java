package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class Announcer extends Module {
    public Announcer() { super("announcer", "Announcer", Category.MISC, false); }
    private boolean kill = true;
    private boolean death = true;
    private boolean join = true;
    private boolean leave = true;
    @Override protected void loadSettings() {
        kill=R1zzConfig.getBoolean("announcer.kill",true);
        death=R1zzConfig.getBoolean("announcer.death",true);
        join=R1zzConfig.getBoolean("announcer.join",true);
        leave=R1zzConfig.getBoolean("announcer.leave",true);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("announcer.kill", kill);
        R1zzConfig.put("announcer.death", death);
        R1zzConfig.put("announcer.join", join);
        R1zzConfig.put("announcer.leave", leave);
    }
    @Override protected void resetSettings() {
        kill=true;
        death=true;
        join=true;
        leave=true;
    }
    public boolean kill() { return kill; }
    public void setKill(boolean v) { kill=v; persist(); }
    public boolean death() { return death; }
    public void setDeath(boolean v) { death=v; persist(); }
    public boolean join() { return join; }
    public void setJoin(boolean v) { join=v; persist(); }
    public boolean leave() { return leave; }
    public void setLeave(boolean v) { leave=v; persist(); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
