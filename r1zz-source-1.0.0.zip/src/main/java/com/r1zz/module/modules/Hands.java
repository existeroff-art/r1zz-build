package com.r1zz.module.modules;
public final class Hands extends VisualToggle { public Hands() { super("hands", "Hands", false); } }
