package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class PacketFly extends Module {
    public PacketFly() { super("packet_fly", "PacketFly", Category.MOVEMENT, false); }
    private double speed = 1;
    @Override protected void loadSettings() {
        speed=R1zzConfig.getDouble("packet_fly.speed",1);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("packet_fly.speed", speed);
    }
    @Override protected void resetSettings() {
        speed=1;
    }
    public double speed() { return speed; }
    public void setSpeed(double v) { speed=Math.max(0.1,Math.min(5,v)); persist(); }
}
