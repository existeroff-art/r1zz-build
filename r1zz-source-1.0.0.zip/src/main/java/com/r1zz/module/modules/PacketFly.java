package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;

public final class PacketFly extends Module {
    public PacketFly() { super("packet_fly", "PacketFly", Category.MOVEMENT, false); }
    private double speed = 1;
    @Override protected void loadSettings() {
        speed=R1zzConfig.getDouble("packet_fly.speed",1);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("packet_fly.speed", speed);
    }
    @Override protected void resetSettings() {
        speed=1;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options == null || mc.currentScreen != null || p.networkHandler == null) return;
        double s = speed * 0.06;
        Vec3d d = CombatModuleUtil.inputDirection(p, s);
        double dy = mc.options.jumpKey.isPressed() ? s : (mc.options.sneakKey.isPressed() ? -s : 0.0);
        p.setVelocity(Vec3d.ZERO);
        if (d == Vec3d.ZERO && dy == 0.0) return;
        double nx = p.getX() + d.x, ny = p.getY() + dy, nz = p.getZ() + d.z;
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(nx, ny, nz, false));
        p.setPosition(nx, ny, nz);
        p.fallDistance = 0.0f;
    }

    public double speed() { return speed; }
    public void setSpeed(double v) { speed=Math.max(0.1,Math.min(5,v)); persist(); }
}
