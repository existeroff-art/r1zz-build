package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
public final class Zoom extends Module {
    private double factor=4; private Integer oldFov; private boolean applied;
    public Zoom(){super("zoom","Zoom",Category.RENDER,false);}
    @Override protected void loadSettings(){factor=Math.max(2,Math.min(10,R1zzConfig.getDouble("zoom.factor",4)));}
    @Override protected void saveSettings(){R1zzConfig.put("zoom.factor",factor);}
    @Override protected void resetSettings(){factor=4;}
    @Override public void onTick(){var mc=MinecraftClient.getInstance();boolean held=enabled()&&keyCode()>=0&&mc.getWindow()!=null&&GLFW.glfwGetKey(mc.getWindow().getHandle(),keyCode())==GLFW.GLFW_PRESS;if(held&&mc.options!=null){if(!applied){oldFov=mc.options.getFov().getValue();applied=true;}int f=(int)Math.max(30,Math.min(110,oldFov/factor));mc.options.getFov().setValue(f);}else restore();}
    @Override public void onDisable(){restore();}
    private void restore(){var mc=MinecraftClient.getInstance();if(applied&&oldFov!=null&&mc.options!=null)mc.options.getFov().setValue(oldFov);applied=false;oldFov=null;}
    public double factor(){return factor;}public void setFactor(double v){factor=Math.max(2,Math.min(10,v));persist();}
}
