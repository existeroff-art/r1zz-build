package com.r1zz.module.modules;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
public final class AntiAFK extends Module {
    private int ticks;
    public AntiAFK(){super("anti_afk","AntiAFK",Category.MISC,false);}
    @Override public void onTick(){var mc=MinecraftClient.getInstance();if(mc.player==null||mc.getNetworkHandler()==null||mc.currentScreen!=null)return;if(++ticks>=1200){ticks=0;if(mc.player.isOnGround()&&!mc.player.isSpectator())mc.player.jump();else mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(mc.player.getYaw()+.25f,mc.player.getPitch(),mc.player.isOnGround()));}}
    @Override public void onDisable(){ticks=0;}
}
