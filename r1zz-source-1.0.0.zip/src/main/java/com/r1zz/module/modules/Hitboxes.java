package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Hitboxes extends Module {
    public Hitboxes() { super("hitboxes", "Hitboxes", Category.RENDER, false); }
}
