package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class AutoTotem extends Module {
    private long lastSwap;
    private long nextGap = 150L;
    public AutoTotem(){super("auto_totem","AutoTotem",Category.PLAYER,false);}
    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        try { if(mc.player==null||mc.interactionManager==null||mc.currentScreen!=null||System.currentTimeMillis()-lastSwap<nextGap)return;
        if(mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING))return;
        int inv=-1;
        for(int i=0;i<36;i++)if(mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)){inv=i;break;}
        if(inv<0)return;
        int slot=inv<9?36+inv:inv;
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,slot,40,SlotActionType.SWAP,mc.player);
        lastSwap=System.currentTimeMillis();
        nextGap=Humanizer.between(110,260);
        } catch (RuntimeException ignored) { }
    }
}
