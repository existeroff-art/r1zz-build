package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Speed extends Module {
    public Speed() { super("speed", "Speed", Category.MOVEMENT, false); }
    private double multiplier = 1.15;
    @Override protected void loadSettings() {
        multiplier=R1zzConfig.getDouble("speed.multiplier",1.15);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("speed.multiplier", multiplier);
    }
    @Override protected void resetSettings() {
        multiplier=1.15;
    }
    public double multiplier() { return multiplier; }
    public void setMultiplier(double v) { multiplier=Math.max(1,Math.min(3,v)); persist(); }
}
