package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class Speed extends Module {
    public Speed() { super("speed", "Speed", Category.MOVEMENT, false); }
    private double multiplier = 1.15;
    @Override protected void loadSettings() {
        multiplier=R1zzConfig.getDouble("speed.multiplier",1.15);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("speed.multiplier", multiplier);
    }
    @Override protected void resetSettings() {
        multiplier=1.15;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || p.isFallFlying() || p.isClimbing() || p.isTouchingWater() || p.isInLava()) return;
        double base = p.isSprinting() ? 0.2806 : 0.2158;
        if (p.hurtTime > 0 || p.isUsingItem()) return;
        Vec3d d = CombatModuleUtil.inputDirection(p, base * multiplier * (0.97 + Math.random() * 0.03));
        if (d == Vec3d.ZERO) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(d.x, v.y, d.z);
    }

    public double multiplier() { return multiplier; }
    public void setMultiplier(double v) { multiplier=Math.max(1,Math.min(3,v)); persist(); }
}
