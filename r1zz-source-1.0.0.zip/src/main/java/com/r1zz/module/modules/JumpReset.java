package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Jump reset: jumps when knockback lands so horizontal knockback is reduced.
 * Auto   - jumps if the hit landed within the last 100 ms.
 * Legit  - jumps after the configured delay, only while the jump key is physically held.
 * Blatant- jumps whenever on the ground.
 */
public final class JumpReset extends Module {
    private String mode = "Legit";
    private int delayMs = 50;
    private double chance = 100.0;
    private boolean onlyOnGround = true;
    private boolean onlyInCombat = false;

    private int lastHurtTime;
    private long hitAt;
    private boolean hitPending;
    private boolean hitAccepted;
    private long lastJump;
    private boolean restoreJumpKey;

    public JumpReset() {
        super("jump_reset", "Jump Reset", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        mode = choice(R1zzConfig.get("jump_reset.mode", "Legit"));
        delayMs = MathHelper.clamp(R1zzConfig.getInt("jump_reset.delay", 50), 0, 200);
        chance = MathHelper.clamp(R1zzConfig.getDouble("jump_reset.chance", 100.0), 0.0, 100.0);
        onlyOnGround = R1zzConfig.getBoolean("jump_reset.only_on_ground", true);
        onlyInCombat = R1zzConfig.getBoolean("jump_reset.only_in_combat", false);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("jump_reset.mode", mode);
        R1zzConfig.put("jump_reset.delay", delayMs);
        R1zzConfig.put("jump_reset.chance", chance);
        R1zzConfig.put("jump_reset.only_on_ground", onlyOnGround);
        R1zzConfig.put("jump_reset.only_in_combat", onlyInCombat);
    }

    @Override
    protected void resetSettings() {
        mode = "Legit";
        delayMs = 50;
        chance = 100.0;
        onlyOnGround = true;
        onlyInCombat = false;
        clearState();
    }

    @Override
    public void onEnable() {
        clearState();
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (restoreJumpKey) restoreJumpKey(mc);
        clearState();
    }

    private void clearState() {
        lastHurtTime = 0;
        hitAt = 0L;
        hitPending = false;
        hitAccepted = false;
        lastJump = 0L;
        restoreJumpKey = false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (mc.player == null || mc.world == null || mc.options == null) return;
            if (restoreJumpKey) restoreJumpKey(mc);
            if (mc.currentScreen != null) return;

            long now = System.currentTimeMillis();

            // A fresh hit shows up as hurtTime jumping up from zero (or rising).
            int hurt = mc.player.hurtTime;
            if (hurt > 0 && hurt > lastHurtTime) {
                hitAt = now;
                hitPending = true;
                hitAccepted = ThreadLocalRandom.current().nextDouble() * 100.0 <= chance;
            }
            lastHurtTime = hurt;
            if (hitPending && now - hitAt > 600L) hitPending = false;

            if (now - lastJump < 250L) return;
            if (onlyOnGround && !mc.player.isOnGround()) return;
            if (onlyInCombat && CombatModuleUtil.nearest(mc, 6.0, true) == null) return;
            if (mc.player.isTouchingWater() || mc.player.isInLava() || mc.player.isClimbing()) return;

            switch (mode) {
                case "Auto" -> {
                    if (hitPending && hitAccepted && now - hitAt <= 100L) doJump(mc, now);
                }
                case "Blatant" -> {
                    if (mc.player.isOnGround()
                            && ThreadLocalRandom.current().nextDouble() * 100.0 <= chance) doJump(mc, now);
                }
                default -> {
                    boolean held = CombatModuleUtil.physicalDown(mc, mc.options.jumpKey);
                    long wait = Humanizer.jitter(delayMs, 0.25);
                    if (hitPending && hitAccepted && mc.player.isOnGround() && held && now - hitAt >= wait) {
                        doJump(mc, now);
                    }
                }
            }
        } catch (RuntimeException e) {
            clearState();
        }
    }

    private void doJump(MinecraftClient mc, long now) {
        mc.player.jump();
        mc.options.jumpKey.setPressed(false);
        restoreJumpKey = true;
        hitPending = false;
        lastJump = now;
    }

    /** Gives the jump key back to the real keyboard state on the next tick. */
    private void restoreJumpKey(MinecraftClient mc) {
        if (mc.options != null) mc.options.jumpKey.setPressed(CombatModuleUtil.physicalDown(mc, mc.options.jumpKey));
        restoreJumpKey = false;
    }

    private static String choice(String value) {
        return switch (value) {
            case "Auto", "Blatant" -> value;
            default -> "Legit";
        };
    }

    public String mode() { return mode; }
    public void setMode(String value) { mode = choice(value); persist(); }
    public int delay() { return delayMs; }
    public void setDelay(int value) { delayMs = MathHelper.clamp(value, 0, 200); persist(); }
    public double chance() { return chance; }
    public void setChance(double value) { chance = MathHelper.clamp(value, 0.0, 100.0); persist(); }
    public boolean onlyOnGround() { return onlyOnGround; }
    public void setOnlyOnGround(boolean value) { onlyOnGround = value; persist(); }
    public boolean onlyInCombat() { return onlyInCombat; }
    public void setOnlyInCombat(boolean value) { onlyInCombat = value; persist(); }
}
