package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class JumpReset extends Module {
    private Vec3d lastVelocity = Vec3d.ZERO;
    private long lastJump;
    private boolean pending;

    public JumpReset() {
        super("jump_reset", "Jump Reset", Category.COMBAT, false);
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        lastVelocity = mc.player == null ? Vec3d.ZERO : mc.player.getVelocity();
        pending = false;
        lastJump = 0L;
    }

    @Override
    public void onDisable() {
        pending = false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;

        Vec3d velocity = mc.player.getVelocity();
        double delta = velocity.subtract(lastVelocity).length();
        boolean knockback = delta > 0.18 && Math.abs(velocity.y - lastVelocity.y) > 0.02;
        lastVelocity = velocity;

        if (knockback && mc.player.isOnGround()
                && System.currentTimeMillis() - lastJump >= 500L) {
            pending = true;
        }

        if (pending) {
            if (mc.player.isOnGround() && System.currentTimeMillis() - lastJump >= 500L) {
                mc.player.jump();
                lastJump = System.currentTimeMillis();
            }
            pending = false;
        }
    }
}
