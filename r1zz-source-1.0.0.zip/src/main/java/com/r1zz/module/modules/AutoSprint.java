package com.r1zz.module.modules;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
/** Simple automatic sprint toggle. */
public final class AutoSprint extends Module {
    public AutoSprint(){super("auto_sprint","AutoSprint",Category.MOVEMENT,false);}
    @Override public void onTick(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null||mc.currentScreen!=null)return;if(mc.player.input.movementForward>0.01f&&!mc.player.isUsingItem()&&mc.player.getHungerManager().getFoodLevel()>6)mc.player.setSprinting(true);}
}
