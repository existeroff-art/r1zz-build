package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;

/** Sends /tip all every five minutes (Hypixel style tipping). */
public final class AutoTip extends Module {
    private static final int INTERVAL_TICKS = 6000;
    private int ticks = INTERVAL_TICKS - 100;

    public AutoTip() { super("auto_tip", "AutoTip", Category.MISC, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (++ticks < INTERVAL_TICKS) return;
        ticks = 0;
        CombatModuleUtil.chat(mc, "/tip all");
    }
}
