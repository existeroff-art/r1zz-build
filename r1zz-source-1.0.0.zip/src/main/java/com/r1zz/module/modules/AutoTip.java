package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoTip extends Module {
    public AutoTip() { super("auto_tip", "AutoTip", Category.MISC, false); }
}
