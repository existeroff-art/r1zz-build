package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class NoHurtCam extends Module { public NoHurtCam(){super("no_hurt_cam","NoHurtCam",Category.RENDER,false);} }
