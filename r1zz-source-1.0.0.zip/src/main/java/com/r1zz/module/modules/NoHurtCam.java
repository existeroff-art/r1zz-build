package com.r1zz.module.modules;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;
public final class NoHurtCam extends Module { public NoHurtCam(){super("no_hurt_cam","NoHurtCam",Category.RENDER,false);}     @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
