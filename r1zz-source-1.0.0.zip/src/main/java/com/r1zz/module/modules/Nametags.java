package com.r1zz.module.modules;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;
public final class Nametags extends Module { public Nametags(){super("nametags","Nametags",Category.RENDER,false);}     @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
