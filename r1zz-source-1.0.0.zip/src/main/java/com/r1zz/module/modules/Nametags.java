package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class Nametags extends Module { public Nametags(){super("nametags","Nametags",Category.RENDER,false);} }
