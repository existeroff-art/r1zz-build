package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;
public final class WeatherChanger extends Module {
    private String weather="Clear";
    public WeatherChanger(){super("weather_changer","WeatherChanger",Category.WORLD,false);}
    @Override protected void loadSettings(){weather=choice(R1zzConfig.get("world.weather","Clear"));}
    @Override protected void saveSettings(){R1zzConfig.put("world.weather",weather);}
    @Override protected void resetSettings(){weather="Clear";}
    public String weather(){return weather;}public void setWeather(String v){weather=choice(v);persist();}
    private static String choice(String v){return v.equals("Rain")||v.equals("Thunder")?v:"Clear";}
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
