package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;

public final class AutoWTap extends Module {
    private int releaseTicks;
    public AutoWTap(){super("auto_wtap","AutoWTap",Category.COMBAT,false);}
    public void onAttack(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player!=null&&mc.player.isSprinting()&&mc.options.forwardKey.isPressed())releaseTicks=2;}
    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null)return;
        if(releaseTicks>0){mc.options.forwardKey.setPressed(false);releaseTicks--;if(releaseTicks==0)mc.options.forwardKey.setPressed(true);}
    }
}
