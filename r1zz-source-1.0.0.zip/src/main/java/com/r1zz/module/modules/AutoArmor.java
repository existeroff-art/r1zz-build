package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoArmor extends Module {
    public AutoArmor() { super("auto_armor", "AutoArmor", Category.PLAYER, false); }
}
