package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/** Equips armor from the inventory into empty slots and upgrades worn pieces when a better one is available. */
public final class AutoArmor extends Module {
    // {equipment slot, PlayerInventory armor index, armor screen slot}
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final int[] ARMOR_INDEX = {3, 2, 1, 0};
    private static final int[] SCREEN_SLOT = {5, 6, 7, 8};
    private int cooldown;

    public AutoArmor() { super("auto_armor", "AutoArmor", Category.PLAYER, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        int syncId = mc.player.playerScreenHandler.syncId;
        for (int s = 0; s < 4; s++) {
            ItemStack worn = mc.player.getInventory().getArmorStack(ARMOR_INDEX[s]);
            int wornScore = score(worn, SLOTS[s]);
            int best = -1, bestScore = wornScore;
            for (int i = 0; i < 36; i++) {
                int sc = score(mc.player.getInventory().getStack(i), SLOTS[s]);
                if (sc > bestScore) { bestScore = sc; best = i; }
            }
            if (best < 0) continue;
            if (worn.isEmpty()) {
                mc.interactionManager.clickSlot(syncId, CombatModuleUtil.screenSlot(best), 0, SlotActionType.QUICK_MOVE, mc.player);
            } else {
                // Take the worn piece off first; the better one is moved in on the next pass.
                mc.interactionManager.clickSlot(syncId, SCREEN_SLOT[s], 0, SlotActionType.QUICK_MOVE, mc.player);
            }
            cooldown = 4;
            return;
        }
    }

    private static int score(ItemStack stack, EquipmentSlot slot) {
        if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem armor)) return -1;
        if (armor.getType().getEquipmentSlot() != slot) return -1;
        return armor.getProtection() * 10 + (int) (armor.getToughness() * 5.0f);
    }
}
