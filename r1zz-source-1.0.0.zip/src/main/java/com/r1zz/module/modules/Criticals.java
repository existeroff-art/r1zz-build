package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class Criticals extends Module { public Criticals(){super("criticals","Criticals",Category.COMBAT,false);} }