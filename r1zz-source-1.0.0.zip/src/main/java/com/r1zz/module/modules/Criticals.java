package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

/** Performs a vanilla jump, waits one client tick, then lands the attack. */
public final class Criticals extends Module {
    private long lastAction;
    private long nextGap = 400L;
    private long reactionReadyAt;
    private LivingEntity pendingTarget;
    private int waitTicks;

    public Criticals() { super("criticals", "Criticals", Category.COMBAT, false); }

    @Override public void onDisable() { pendingTarget=null; waitTicks=0; reactionReadyAt=0L; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null || mc.options == null) return;
            long now = System.currentTimeMillis();
            if (pendingTarget != null) {
                if (--waitTicks > 0) return;
                LivingEntity target = pendingTarget;
                pendingTarget = null;
                if (target.isAlive() && !target.isRemoved() && mc.player.distanceTo(target) <= 3.2f
                        && mc.player.getAttackCooldownProgress(0.5f) >= 0.85f) {
                    CombatModuleUtil.attack(mc, target);
                    lastAction = now;
                    nextGap = Humanizer.between(350, 700);
                }
                return;
            }
            if (!mc.options.attackKey.isPressed() || now-lastAction < nextGap) return;
            if (!(mc.targetedEntity instanceof LivingEntity target) || !target.isAlive()) return;
            if (mc.player.getAttackCooldownProgress(0.5f) < 0.85f || !mc.player.isOnGround()
                    || mc.player.isClimbing() || mc.player.isTouchingWater() || mc.player.isInLava()
                    || mc.player.distanceTo(target) > 3.2f) return;
            if (reactionReadyAt == 0L) reactionReadyAt = now + Humanizer.between(50, 200);
            if (now < reactionReadyAt) return;
            reactionReadyAt = 0L;
            mc.player.jump();
            pendingTarget = target;
            waitTicks = 1;
        } catch (RuntimeException ignored) { pendingTarget=null; waitTicks=0; }
    }
}
