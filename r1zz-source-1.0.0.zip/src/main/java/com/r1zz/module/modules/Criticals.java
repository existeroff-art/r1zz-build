package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

public final class Criticals extends Module {
    public Criticals(){super("criticals","Criticals",Category.COMBAT,false);}
    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.currentScreen!=null||mc.targetedEntity==null)return;
        if(mc.targetedEntity instanceof LivingEntity target && target.isAlive() && mc.player.getAttackCooldownProgress(0.5f)>=1.0f && mc.player.isOnGround() && !mc.player.isClimbing() && !mc.player.isTouchingWater() && !mc.player.isInLava()) mc.player.jump();
    }
}
