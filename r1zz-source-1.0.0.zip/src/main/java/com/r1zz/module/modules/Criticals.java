package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

/** Hops just before a hit so it lands while falling (critical). Randomised timing, never spams. */
public final class Criticals extends Module {
    private long lastHop;
    private long nextGap = 400L;

    public Criticals() { super("criticals", "Criticals", Category.COMBAT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (mc.player == null || mc.currentScreen != null || mc.targetedEntity == null || mc.options == null) return;
            if (!mc.options.attackKey.isPressed()) return;
            long now = System.currentTimeMillis();
            if (now - lastHop < nextGap) return;
            if (mc.targetedEntity instanceof LivingEntity target && target.isAlive()
                    && mc.player.getAttackCooldownProgress(0.5f) >= 0.85f
                    && mc.player.isOnGround() && !mc.player.isClimbing()
                    && !mc.player.isTouchingWater() && !mc.player.isInLava()
                    && mc.player.distanceTo(target) <= 3.2f) {
                lastHop = now;
                nextGap = Humanizer.between(350, 700);
                if (Humanizer.chance(0.9)) mc.player.jump();
            }
        } catch (RuntimeException ignored) { }
    }
}
