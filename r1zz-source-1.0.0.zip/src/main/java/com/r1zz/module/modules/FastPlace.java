package com.r1zz.module.modules;

import com.r1zz.module.Module;

/** Toggle only: MinecraftClientMixin lowers the item-use cooldown (randomised 2-4 ticks) while this is on. */
public final class FastPlace extends Module {
    public FastPlace(){super("fast_place","FastPlace",Category.PLAYER,false);}
}
