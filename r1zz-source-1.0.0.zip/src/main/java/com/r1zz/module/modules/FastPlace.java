package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class FastPlace extends Module { public FastPlace(){super("fast_place","FastPlace",Category.PLAYER,false);} }
