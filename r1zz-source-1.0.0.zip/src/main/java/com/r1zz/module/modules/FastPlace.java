package com.r1zz.module.modules;

import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

/** Toggle only: MinecraftClientMixin lowers the item-use cooldown (randomised 2-4 ticks) while this is on. */
public final class FastPlace extends Module {
    public FastPlace(){super("fast_place","FastPlace",Category.PLAYER,false);}
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
