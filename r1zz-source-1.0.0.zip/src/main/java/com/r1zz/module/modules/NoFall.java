package com.r1zz.module.modules;

import com.r1zz.module.Module;

public final class NoFall extends Module {
    public NoFall(){super("no_fall","NoFall",Category.MOVEMENT,false);}
    @Override public void onTick() { }
}
