package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class Crosshair extends Module {
    public Crosshair() { super("crosshair", "Crosshair", Category.RENDER, false); }
    private String style = "Cross";
    private String color = "#FFFFFF";
    private double size = 10;
    @Override protected void loadSettings() {
        style=R1zzConfig.get("crosshair.style","Cross");
        color=R1zzConfig.get("crosshair.color","#FFFFFF");
        size=R1zzConfig.getDouble("crosshair.size",10);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("crosshair.style", style);
        R1zzConfig.put("crosshair.color", color);
        R1zzConfig.put("crosshair.size", size);
    }
    @Override protected void resetSettings() {
        style="Cross";
        color="#FFFFFF";
        size=10;
    }
    public String style() { return style; }
    public void setStyle(String v) { style=v == null ? "" : v; persist(); }
    public String color() { return color; }
    public void setColor(String v) { color=v == null ? "" : v; persist(); }
    public double size() { return size; }
    public void setSize(double v) { size=Math.max(2,Math.min(30,v)); persist(); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
