package com.r1zz.module.modules;
public final class Quality extends VisualToggle { public Quality() { super("quality", "Quality", 0, 10, 5); } }
