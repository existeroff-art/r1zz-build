package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

public final class AutoWeapon extends Module {
    public AutoWeapon() { super("auto_weapon", "AutoWeapon", Category.COMBAT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options == null) return;
        if (!mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof LivingEntity)) return;
        int best = -1;
        int bestRank = CombatModuleUtil.weaponRank(mc.player.getMainHandStack().getItem());
        for (int i = 0; i < 9; i++) {
            int rank = CombatModuleUtil.weaponRank(mc.player.getInventory().getStack(i).getItem());
            if (rank > bestRank) { bestRank = rank; best = i; }
        }
        if (best >= 0) CombatModuleUtil.select(mc.player, best);
    }
}
