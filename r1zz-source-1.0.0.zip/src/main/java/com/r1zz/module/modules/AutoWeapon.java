package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class AutoWeapon extends Module { public AutoWeapon(){super("auto_weapon","AutoWeapon",Category.COMBAT,false);} }