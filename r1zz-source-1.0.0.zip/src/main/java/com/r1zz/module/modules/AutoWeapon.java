package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

/** Switches to the best hotbar weapon when you start hitting an entity, after a short human delay. */
public final class AutoWeapon extends Module {
    private long targetSince;
    private int originalSlot=-1;
    private long revertAt;
    private long reaction = 90L;

    public AutoWeapon() { super("auto_weapon", "AutoWeapon", Category.COMBAT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options == null) return;
            long now = System.currentTimeMillis();
            if (revertAt > 0L && now >= revertAt && originalSlot >= 0) { CombatModuleUtil.select(mc.player, originalSlot); originalSlot=-1; revertAt=0L; }
            if (!mc.options.attackKey.isPressed()
                    || !(mc.crosshairTarget instanceof EntityHitResult hit)
                    || !(hit.getEntity() instanceof LivingEntity)) {
                targetSince = 0L;
                return;
            }
            if (targetSince == 0L) { targetSince = now; reaction = Humanizer.between(60, 150); }
            if (now - targetSince < reaction) return;
            int best = -1;
            int bestRank = CombatModuleUtil.weaponRank(mc.player.getMainHandStack().getItem());
            for (int i = 0; i < 9; i++) {
                int rank = CombatModuleUtil.weaponRank(mc.player.getInventory().getStack(i).getItem());
                if (rank > bestRank) { bestRank = rank; best = i; }
            }
            if (best >= 0) { if (originalSlot < 0) originalSlot=mc.player.getInventory().selectedSlot; CombatModuleUtil.select(mc.player, best); revertAt=now+200L; }
        } catch (RuntimeException ignored) { }
    }
}
