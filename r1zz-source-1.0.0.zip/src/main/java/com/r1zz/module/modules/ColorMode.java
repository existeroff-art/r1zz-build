package com.r1zz.module.modules;
public final class ColorMode extends VisualToggle { public ColorMode() { super("color_mode", "Color Mode", true); } }
