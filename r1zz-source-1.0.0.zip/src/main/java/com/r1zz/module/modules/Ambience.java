package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Ambience extends Module {
    public Ambience() { super("ambience", "Ambience", Category.RENDER, false); }
}
