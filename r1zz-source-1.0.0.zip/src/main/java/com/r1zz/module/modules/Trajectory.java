package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Trajectory extends Module {
    public Trajectory() { super("trajectory", "Trajectory", Category.RENDER, false); }
}
