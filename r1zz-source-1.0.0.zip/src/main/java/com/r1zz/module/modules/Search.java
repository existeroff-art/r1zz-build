package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Search extends Module {
    public Search() { super("search", "Search", Category.RENDER, false); }
    private String blockName = "diamond_ore";
    @Override protected void loadSettings() {
        blockName=R1zzConfig.get("search.blockName","diamond_ore");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("search.blockName", blockName);
    }
    @Override protected void resetSettings() {
        blockName="diamond_ore";
    }
    public String blockName() { return blockName; }
    public void setBlockName(String v) { blockName=v == null ? "" : v; persist(); }
}
