package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class NameProtect extends Module {
    public NameProtect() { super("name_protect", "NameProtect", Category.MISC, false); }
    private String customName = "R1zz";
    @Override protected void loadSettings() {
        customName=R1zzConfig.get("name_protect.customName","R1zz");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("name_protect.customName", customName);
    }
    @Override protected void resetSettings() {
        customName="R1zz";
    }
    public String customName() { return customName; }
    public void setCustomName(String v) { customName=v == null ? "" : v; persist(); }
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
