package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Raises a shield when an enemy player gets close. Reacts after a human delay and releases a beat late. */
public final class AutoBlock extends Module {
    private boolean holding;
    private long threatSince;
    private long reaction = 140L;
    private long releaseAt;

    public AutoBlock() { super("auto_block", "AutoBlock", Category.COMBAT, false); }

    @Override
    public void onDisable() {
        release(MinecraftClient.getInstance());
        threatSince = 0L;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (mc.player == null || mc.world == null || mc.options == null) return;
            ItemStack main = mc.player.getMainHandStack();
            boolean shield = mc.player.getOffHandStack().isOf(Items.SHIELD) || main.isOf(Items.SHIELD);
            boolean mainIsPassive = main.isEmpty() || main.isOf(Items.SHIELD) || CombatModuleUtil.isWeapon(main.getItem());
            LivingEntity threat = CombatModuleUtil.nearest(mc, 4.5, true);
            long now = System.currentTimeMillis();
            boolean want = shield && mainIsPassive && threat != null && mc.currentScreen == null;
            if (want) {
                if (threatSince == 0L) { threatSince = now; reaction = Humanizer.between(110, 220); }
                releaseAt = 0L;
                if (now - threatSince >= reaction) {
                    mc.options.useKey.setPressed(true);
                    holding = true;
                }
            } else {
                threatSince = 0L;
                if (holding) {
                    if (releaseAt == 0L) releaseAt = now + Humanizer.between(60, 160);
                    if (now >= releaseAt) release(mc);
                }
            }
        } catch (RuntimeException ignored) { }
    }

    private void release(MinecraftClient mc) {
        if (holding && mc.options != null) mc.options.useKey.setPressed(CombatModuleUtil.physicalDown(mc, mc.options.useKey));
        holding = false;
        releaseAt = 0L;
    }
}
