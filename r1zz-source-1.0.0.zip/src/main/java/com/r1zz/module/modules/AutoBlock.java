package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public final class AutoBlock extends Module {
    private boolean holding;

    public AutoBlock() { super("auto_block", "AutoBlock", Category.COMBAT, false); }

    @Override
    public void onDisable() {
        release(MinecraftClient.getInstance());
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options == null) return;
        ItemStack main = mc.player.getMainHandStack();
        boolean shield = mc.player.getOffHandStack().isOf(Items.SHIELD) || main.isOf(Items.SHIELD);
        boolean mainIsPassive = main.isEmpty() || main.isOf(Items.SHIELD) || CombatModuleUtil.isWeapon(main.getItem());
        LivingEntity threat = CombatModuleUtil.nearest(mc, 4.5, true);
        boolean want = shield && mainIsPassive && threat != null && mc.currentScreen == null;
        if (want) {
            mc.options.useKey.setPressed(true);
            holding = true;
        } else {
            release(mc);
        }
    }

    private void release(MinecraftClient mc) {
        if (holding && mc.options != null) mc.options.useKey.setPressed(false);
        holding = false;
    }
}
