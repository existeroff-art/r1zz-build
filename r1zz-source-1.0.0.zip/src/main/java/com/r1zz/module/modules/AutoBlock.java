package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class AutoBlock extends Module { public AutoBlock(){super("auto_block","AutoBlock",Category.COMBAT,false);} }