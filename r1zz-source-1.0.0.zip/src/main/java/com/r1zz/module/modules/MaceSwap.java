package com.r1zz.module.modules;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
public final class MaceSwap extends Module {
 public MaceSwap(){super("mace_swap","Mace Swap",Category.COMBAT,false);}
 public void onTick(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null)return;LivingEntity t=CombatModuleUtil.nearest(mc,6,true);if(t!=null&&t.getVelocity().y<-.05){int s=CombatModuleUtil.findHotbar(mc.player,Items.MACE);if(s>=0)CombatModuleUtil.select(mc.player,s);}}
}