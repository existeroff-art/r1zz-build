package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;

public final class MaceSwap extends Module {
    public MaceSwap() { super("mace_swap", "Mace Swap", Category.COMBAT, false); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        LivingEntity target = CombatModuleUtil.nearest(mc, 6.0, true);
        if (target != null && target.getVelocity().y < -0.05 && !target.isOnGround()) {
            int slot = CombatModuleUtil.findHotbar(mc.player, Items.MACE);
            if (slot >= 0) CombatModuleUtil.select(mc.player, slot);
        }
    }
}
