package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Phase extends Module {
    public Phase() { super("phase", "Phase", Category.MOVEMENT, false); }
}
