package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** When you push into a wall, slides you forward through it. */
public final class Phase extends Module {
    public Phase() { super("phase", "Phase", Category.MOVEMENT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || !p.horizontalCollision) return;
        Vec3d d = CombatModuleUtil.inputDirection(p, 0.1);
        if (d == Vec3d.ZERO) return;
        p.setPosition(p.getX() + d.x, p.getY(), p.getZ() + d.z);
    }
}
