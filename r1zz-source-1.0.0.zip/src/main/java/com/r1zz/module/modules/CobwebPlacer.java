package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class CobwebPlacer extends Module {
    private double range = 3.0;
    private int cooldown = 200;
    private boolean autoSwitch = true;
    private long lastPlacement;
    private int rotationDelay = -1;
    private BlockPos pendingPos;

    public CobwebPlacer() {
        super("cobweb_placer", "Cobweb Placer", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        range = Math.max(1.0, Math.min(4.0, R1zzConfig.getDouble("cobweb_placer.range", 3.0)));
        cooldown = MathHelper.clamp(R1zzConfig.getInt("cobweb_placer.cooldown", 200), 100, 500);
        autoSwitch = R1zzConfig.getBoolean("cobweb_placer.auto_switch", true);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("cobweb_placer.range", range);
        R1zzConfig.put("cobweb_placer.cooldown", cooldown);
        R1zzConfig.put("cobweb_placer.auto_switch", autoSwitch);
    }

    @Override
    protected void resetSettings() {
        range = 3.0;
        cooldown = 200;
        autoSwitch = true;
        lastPlacement = 0L;
        rotationDelay = -1;
        pendingPos = null;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        if (rotationDelay == 0 && pendingPos != null) {
            place(mc, pendingPos);
            rotationDelay = -1;
            pendingPos = null;
            return;
        }
        if (rotationDelay > 0) rotationDelay--;
        if (System.currentTimeMillis() - lastPlacement < cooldown) return;

        PlayerEntity target = findTarget(mc);
        if (target == null) return;

        BlockPos feet = target.getBlockPos();
        BlockPos below = feet.down();
        if (!mc.world.getBlockState(below).isSolidBlock(mc.world, below)) return;
        if (!mc.world.getBlockState(feet).isAir() && !mc.world.getBlockState(feet).isOf(Blocks.COBWEB)) return;
        if (mc.world.getBlockState(feet).isOf(Blocks.COBWEB)) return;
        if (!mc.player.canSee(target)) return;

        int cobweb = CombatModuleUtil.findHotbar(mc.player, Items.COBWEB);
        if (cobweb < 0) return;
        if (!autoSwitch && !mc.player.getMainHandStack().isOf(Items.COBWEB)) return;

        if (autoSwitch) CombatModuleUtil.select(mc.player, cobweb);
        Vec3d aim = Vec3d.ofCenter(feet);
        rotateSmoothly(mc, aim);
        pendingPos = feet;
        rotationDelay = 1;
    }

    private PlayerEntity findTarget(MinecraftClient mc) {
        return mc.world.getPlayers().stream()
                .filter(p -> p != mc.player && p.isAlive() && !p.isSpectator())
                .filter(p -> mc.player.distanceTo(p) <= range)
                .filter(p -> inFront(mc.player, p))
                .filter(mc.player::canSee)
                .min((a, b) -> Double.compare(mc.player.distanceTo(a), mc.player.distanceTo(b)))
                .orElse(null);
    }

    private boolean inFront(PlayerEntity player, PlayerEntity target) {
        Vec3d look = player.getRotationVec(1.0f).normalize();
        Vec3d toTarget = target.getEyePos().subtract(player.getEyePos()).normalize();
        return look.dotProduct(toTarget) > 0.35;
    }

    private void rotateSmoothly(MinecraftClient mc, Vec3d target) {
        Vec3d diff = target.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));
        float yawStep = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw()) * 0.45f;
        float pitchStep = (targetPitch - mc.player.getPitch()) * 0.45f;
        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        yawStep = Math.round(yawStep / gcd) * gcd;
        pitchStep = Math.round(pitchStep / gcd) * gcd;
        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(yawStep, -20.0f, 20.0f));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(pitchStep, -15.0f, 15.0f), -90.0f, 90.0f));
    }

    private void place(MinecraftClient mc, BlockPos pos) {
        if (!mc.world.getBlockState(pos).isAir()) return;
        BlockPos below = pos.down();
        if (!mc.world.getBlockState(below).isSolidBlock(mc.world, below)) return;
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, below, false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        lastPlacement = System.currentTimeMillis();
    }

    public double range() { return range; }
    public void setRange(double value) { range = Math.max(1.0, Math.min(4.0, value)); persist(); }
    public int cooldown() { return cooldown; }
    public void setCooldown(int value) { cooldown = MathHelper.clamp(value, 100, 500); persist(); }
    public boolean autoSwitch() { return autoSwitch; }
    public void setAutoSwitch(boolean value) { autoSwitch = value; persist(); }
}
