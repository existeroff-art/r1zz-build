package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

public final class CobwebPlacer extends Module {
    private double range=3.0; private int cooldown=500; private boolean autoSwitch=true;
    private long lastPlacement; private int rotationDelay=-1; private BlockPos pendingPos; private boolean manualTrigger;
    public CobwebPlacer(){super("cobweb_placer","Cobweb Placer",Category.COMBAT,false);}
    @Override protected void loadSettings(){range=MathHelper.clamp(R1zzConfig.getDouble("cobweb_placer.range",3.0),1.0,3.0);cooldown=MathHelper.clamp(R1zzConfig.getInt("cobweb_placer.cooldown",500),100,500);autoSwitch=R1zzConfig.getBoolean("cobweb_placer.auto_switch",true);}
    @Override protected void saveSettings(){R1zzConfig.put("cobweb_placer.range",range);R1zzConfig.put("cobweb_placer.cooldown",cooldown);R1zzConfig.put("cobweb_placer.auto_switch",autoSwitch);}
    @Override protected void resetSettings(){range=3.0;cooldown=500;autoSwitch=true;lastPlacement=0;rotationDelay=-1;pendingPos=null;manualTrigger=false;}
    @Override public void onEnable(){manualTrigger=true;}
    @Override public void onDisable(){pendingPos=null;rotationDelay=-1;manualTrigger=false;}
    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance(); if(mc.player==null||mc.world==null||mc.interactionManager==null||mc.currentScreen!=null)return;
        boolean rightClick=mc.player.isUsingItem()&&mc.player.getMainHandStack().isOf(Items.COBWEB);
        boolean trigger=manualTrigger||rightClick;
        if(rotationDelay==0&&pendingPos!=null){place(mc,pendingPos);pendingPos=null;rotationDelay=-1;manualTrigger=false;return;}
        if(rotationDelay>0){rotationDelay--;return;}
        if(!trigger||System.currentTimeMillis()-lastPlacement<cooldown)return;
        PlayerEntity target=findTarget(mc); if(target==null)return;
        BlockPos feet=target.getBlockPos(); BlockPos below=feet.down();
        if(!target.isOnGround()||!mc.world.getBlockState(below).isSolidBlock(mc.world,below)||!mc.world.getBlockState(feet).isAir())return;
        int slot=CombatModuleUtil.findHotbar(mc.player,Items.COBWEB); if(slot<0)return;
        if(!autoSwitch&&!mc.player.getMainHandStack().isOf(Items.COBWEB))return;
        if(autoSwitch)CombatModuleUtil.select(mc.player,slot);
        rotateTo(mc,Vec3d.ofCenter(feet)); pendingPos=feet;rotationDelay=1;
    }
    private PlayerEntity findTarget(MinecraftClient mc){
        Vec3d selfVel=mc.player.getVelocity();
        return mc.world.getPlayers().stream().filter(p->p!=mc.player&&p.isAlive()&&!p.isSpectator()&&p.isOnGround())
                .filter(p->mc.player.distanceTo(p)<=range).filter(p->p.getVelocity().subtract(selfVel).dotProduct(mc.player.getPos().subtract(p.getPos()))>0.0)
                .filter(p->canSee(mc,p)).min((a,b)->Double.compare(mc.player.distanceTo(a),mc.player.distanceTo(b))).orElse(null);
    }
    private boolean canSee(MinecraftClient mc,PlayerEntity p){Vec3d a=mc.player.getEyePos(),b=p.getEyePos();BlockHitResult hit=mc.world.raycast(new RaycastContext(a,b,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,mc.player));return hit.getType()==HitResult.Type.MISS;}
    private void rotateTo(MinecraftClient mc,Vec3d target){Vec3d d=target.subtract(mc.player.getEyePos());double h=Math.sqrt(d.x*d.x+d.z*d.z);float yaw=(float)(Math.toDegrees(Math.atan2(d.z,d.x))-90),pitch=(float)-Math.toDegrees(Math.atan2(d.y,h));float sens=mc.options.getMouseSensitivity().getValue().floatValue(),f=sens*.6f+.2f,gcd=f*f*f*1.2f;float ys=Math.round(MathHelper.wrapDegrees(yaw-mc.player.getYaw())*.6f/gcd)*gcd,ps=Math.round((pitch-mc.player.getPitch())*.6f/gcd)*gcd;mc.player.setYaw(mc.player.getYaw()+MathHelper.clamp(ys,-30,30));mc.player.setPitch(MathHelper.clamp(mc.player.getPitch()+MathHelper.clamp(ps,-25,25),-90,90));}
    private void place(MinecraftClient mc,BlockPos pos){if(!mc.world.getBlockState(pos).isAir()||!mc.world.getBlockState(pos.down()).isSolidBlock(mc.world,pos.down()))return;BlockHitResult hit=new BlockHitResult(Vec3d.ofCenter(pos.down()),Direction.UP,pos.down(),false);mc.interactionManager.interactBlock(mc.player,Hand.MAIN_HAND,hit);lastPlacement=System.currentTimeMillis();}
    public double range(){return range;} public void setRange(double v){range=MathHelper.clamp(v,1,3);persist();}
    public int cooldown(){return cooldown;} public void setCooldown(int v){cooldown=MathHelper.clamp(v,100,500);persist();}
    public boolean autoSwitch(){return autoSwitch;} public void setAutoSwitch(boolean v){autoSwitch=v;persist();}
}
