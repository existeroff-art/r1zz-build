package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class NewChunks extends Module {
    public NewChunks() { super("new_chunks", "NewChunks", Category.RENDER, false); }
}
