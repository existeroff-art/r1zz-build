package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Rainbow extends Module {
    public Rainbow() { super("rainbow", "Rainbow", Category.MISC, false); }
    private double speed = 5;
    @Override protected void loadSettings() {
        speed=R1zzConfig.getDouble("rainbow.speed",5);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("rainbow.speed", speed);
    }
    @Override protected void resetSettings() {
        speed=5;
    }
    public double speed() { return speed; }
    public void setSpeed(double v) { speed=Math.max(0,Math.min(20,v)); persist(); }
}
