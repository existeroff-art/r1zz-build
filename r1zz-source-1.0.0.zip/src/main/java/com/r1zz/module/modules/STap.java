package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class STap extends Module { public STap(){super("stap","STap",Category.COMBAT,false);} }