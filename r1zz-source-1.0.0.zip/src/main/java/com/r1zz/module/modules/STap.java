package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;

/** Taps back for one tick right after every attack to reset sprint and open the spacing back up. */
public final class STap extends Module {
    private float previousCooldown = 1.0f;
    private boolean tapping;
    private long tapUntil;

    public STap() { super("stap", "STap", Category.COMBAT, false); }

    @Override
    public void onDisable() {
        restore(MinecraftClient.getInstance());
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options == null) return;
        float cooldown = mc.player.getAttackCooldownProgress(0.0f);
        boolean attacked = previousCooldown > 0.85f && cooldown < 0.3f;
        previousCooldown = cooldown;

        if (tapping) {
            if (System.currentTimeMillis() >= tapUntil) restore(mc);
            else { mc.options.backKey.setPressed(true); mc.options.forwardKey.setPressed(false); }
            return;
        }
        if (attacked && mc.player.isSprinting() && Humanizer.chance(0.85)) {
            tapping = true;
            tapUntil = System.currentTimeMillis() + 50L;
            mc.options.forwardKey.setPressed(false);
            mc.options.backKey.setPressed(true);
        }
    }

    private void restore(MinecraftClient mc) {
        if (tapping && mc.options != null) {
            mc.options.backKey.setPressed(CombatModuleUtil.physicalDown(mc, mc.options.backKey));
            mc.options.forwardKey.setPressed(CombatModuleUtil.physicalDown(mc, mc.options.forwardKey));
        }
        tapping = false;
    }
}
