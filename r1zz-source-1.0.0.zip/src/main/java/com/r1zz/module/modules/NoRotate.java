package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class NoRotate extends Module { public NoRotate(){super("no_rotate","NoRotate",Category.PLAYER,false);} }
