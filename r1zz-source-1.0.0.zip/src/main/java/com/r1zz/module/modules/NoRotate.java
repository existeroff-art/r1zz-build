package com.r1zz.module.modules;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;
public final class NoRotate extends Module { public NoRotate(){super("no_rotate","NoRotate",Category.PLAYER,false);}     @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
