package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class Fly extends Module {
    public Fly() { super("fly", "Fly", Category.MOVEMENT, false); }
    private double speed = 1;
    @Override protected void loadSettings() {
        speed=R1zzConfig.getDouble("fly.speed",1);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("fly.speed", speed);
    }
    @Override protected void resetSettings() {
        speed=1;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options == null || mc.currentScreen != null || p.isFallFlying()) return;
        double s = speed * 0.5;
        Vec3d d = CombatModuleUtil.inputDirection(p, s);
        double vy = mc.options.jumpKey.isPressed() ? s : (mc.options.sneakKey.isPressed() ? -s : 0.0);
        p.setVelocity(d.x, vy, d.z);
        p.fallDistance = 0.0f;
    }

    public double speed() { return speed; }
    public void setSpeed(double v) { speed=Math.max(0.1,Math.min(5,v)); persist(); }
}
