package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Free movement straight through blocks: forward/strafe, jump to rise, sneak to descend. */
public final class NoClip extends Module {
    private static final double SPEED = 0.35;

    public NoClip() { super("no_clip", "NoClip", Category.MOVEMENT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options == null || mc.currentScreen != null) return;
        Vec3d d = CombatModuleUtil.inputDirection(p, SPEED);
        double dy = mc.options.jumpKey.isPressed() ? SPEED : (mc.options.sneakKey.isPressed() ? -SPEED : 0.0);
        p.setVelocity(Vec3d.ZERO);
        p.setPosition(p.getX() + d.x, p.getY() + dy, p.getZ() + d.z);
        p.fallDistance = 0.0f;
    }
}
