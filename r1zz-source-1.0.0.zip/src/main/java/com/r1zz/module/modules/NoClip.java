package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class NoClip extends Module {
    public NoClip() { super("no_clip", "NoClip", Category.MOVEMENT, false); }
}
