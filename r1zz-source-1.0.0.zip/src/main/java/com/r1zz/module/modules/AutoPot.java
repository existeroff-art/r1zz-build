package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
public final class AutoPot extends Module {private int hp=10;public AutoPot(){super("auto_pot","AutoPot",Category.COMBAT,false);}protected void loadSettings(){hp=Math.max(1,Math.min(20,R1zzConfig.getInt("auto_pot.hp_threshold",10)));}protected void saveSettings(){R1zzConfig.put("auto_pot.hp_threshold",hp);}protected void resetSettings(){hp=10;}public void onTick(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null)return;}public int hpThreshold(){return hp;}public void setHpThreshold(int v){hp=Math.max(1,Math.min(20,v));persist();}}