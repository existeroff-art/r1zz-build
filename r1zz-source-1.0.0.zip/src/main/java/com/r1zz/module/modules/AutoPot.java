package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Below the HP threshold: throws a splash healing potion at your feet, or drinks a healing potion. */
public final class AutoPot extends Module {
    private int hp = 10;
    private long lastUse;
    private long lowSince;
    private long reaction = 150L;
    private final HoldUse holdUse = new HoldUse();

    public AutoPot() { super("auto_pot", "AutoPot", Category.COMBAT, false); }

    @Override protected void loadSettings() { hp = Math.max(1, Math.min(20, R1zzConfig.getInt("auto_pot.hp_threshold", 10))); }
    @Override protected void saveSettings() { R1zzConfig.put("auto_pot.hp_threshold", hp); }
    @Override protected void resetSettings() { hp = 10; lastUse = 0; }
    @Override public void onDisable() { holdUse.end(MinecraftClient.getInstance()); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try { tick(mc); } catch (RuntimeException ignored) { }
    }

    private void tick(MinecraftClient mc) {
        if (mc.player == null || mc.interactionManager == null || mc.options == null) return;
        if (holdUse.tick(mc)) return;
        if (mc.currentScreen != null || mc.player.getHealth() > hp) { lowSince = 0L; return; }
        long now = System.currentTimeMillis();
        if (lowSince == 0L) { lowSince = now; reaction = Humanizer.between(120, 260); }
        if (now - lowSince < reaction || now - lastUse < Humanizer.between(900, 1300)) return;

        int splash = -1, drink = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!CombatModuleUtil.isHealingPotion(stack)) continue;
            if (stack.isOf(Items.SPLASH_POTION) && splash < 0) splash = i;
            if (stack.isOf(Items.POTION) && drink < 0) drink = i;
        }
        if (splash >= 0) {
            int old = mc.player.getInventory().selectedSlot;
            float pitch = mc.player.getPitch();
            CombatModuleUtil.select(mc.player, splash);
            mc.player.setPitch(90.0f);
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.player.setPitch(pitch);
            CombatModuleUtil.select(mc.player, old);
            lastUse = System.currentTimeMillis();
        } else if (drink >= 0 && !mc.player.isUsingItem()) {
            holdUse.begin(mc, drink);
            lastUse = System.currentTimeMillis();
        }
    }

    public int hpThreshold() { return hp; }
    public void setHpThreshold(int v) { hp = Math.max(1, Math.min(20, v)); persist(); }
}
