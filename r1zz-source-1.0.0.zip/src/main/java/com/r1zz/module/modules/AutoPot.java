package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public final class AutoPot extends Module {
    private int hp = 10;
    private long lastUse;
    public AutoPot() { super("auto_pot", "AutoPot", Category.COMBAT, false); }
    @Override protected void loadSettings() { hp = Math.max(1, Math.min(20, R1zzConfig.getInt("auto_pot.hp_threshold", 10))); }
    @Override protected void saveSettings() { R1zzConfig.put("auto_pot.hp_threshold", hp); }
    @Override protected void resetSettings() { hp = 10; lastUse = 0; }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null || mc.player.getHealth() > hp || System.currentTimeMillis() - lastUse < 1000) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isOf(Items.POTION)) { slot = i; break; }
        }
        if (slot < 0) return;
        int old = mc.player.getInventory().selectedSlot;
        CombatModuleUtil.select(mc.player, slot);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        CombatModuleUtil.select(mc.player, old);
        lastUse = System.currentTimeMillis();
    }
    public int hpThreshold() { return hp; }
    public void setHpThreshold(int v) { hp = Math.max(1, Math.min(20, v)); persist(); }
}
