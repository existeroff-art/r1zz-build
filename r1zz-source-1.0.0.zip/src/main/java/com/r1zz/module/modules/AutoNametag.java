package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

import java.util.Comparator;

/** Uses a renamed name tag from your hotbar on the nearest unnamed mob. */
public final class AutoNametag extends Module {
    private int cooldown;

    public AutoNametag() { super("auto_nametag", "AutoNametag", Category.WORLD, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        int tag = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isOf(Items.NAME_TAG) && stack.contains(DataComponentTypes.CUSTOM_NAME)) { tag = i; break; }
        }
        if (tag < 0) return;
        LivingEntity mob = mc.world.getEntitiesByClass(LivingEntity.class, mc.player.getBoundingBox().expand(4.0),
                        e -> e.isAlive() && !(e instanceof PlayerEntity) && !e.hasCustomName() && mc.player.distanceTo(e) <= 4.0)
                .stream().min(Comparator.comparingDouble(mc.player::distanceTo)).orElse(null);
        if (mob == null) return;
        int old = mc.player.getInventory().selectedSlot;
        CombatModuleUtil.select(mc.player, tag);
        mc.interactionManager.interactEntity(mc.player, mob, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        CombatModuleUtil.select(mc.player, old);
        cooldown = 10;
    }
}
