package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoNametag extends Module {
    public AutoNametag() { super("auto_nametag", "AutoNametag", Category.WORLD, false); }
}
