package com.r1zz.module.modules;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
/** Keeps the client-side attack cooldown state observed; server cooldown remains authoritative. */
public final class NoHitDelay extends Module {
    private long lastTick;
    public NoHitDelay(){super("no_hit_delay","NoHitDelay",Category.COMBAT,false);}
    @Override public void onTick(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player!=null)lastTick=mc.player.age;}
    public long lastTick(){return lastTick;}
}
