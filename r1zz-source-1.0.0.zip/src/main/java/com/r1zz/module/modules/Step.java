package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class Step extends Module { public Step(){super("step","Step",Category.MOVEMENT,false);} }
