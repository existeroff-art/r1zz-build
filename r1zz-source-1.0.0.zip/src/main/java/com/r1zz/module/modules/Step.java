package com.r1zz.module.modules;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;
public final class Step extends Module { public Step(){super("step","Step",Category.MOVEMENT,false);}     @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
