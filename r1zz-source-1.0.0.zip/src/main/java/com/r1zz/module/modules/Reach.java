package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Optional;

/** Extends melee reach: when attack is held and nothing is hit, attacks the entity under the crosshair within the set reach. */
public final class Reach extends Module {
    private double reach = 3.5;
    private long nextAllowed;

    public Reach() { super("reach", "Reach", Category.COMBAT, false); }

    @Override protected void loadSettings() { reach = Math.max(3, Math.min(6, R1zzConfig.getDouble("reach.value", 3.5))); }
    @Override protected void saveSettings() { R1zzConfig.put("reach.value", reach); }
    @Override protected void resetSettings() { reach = 3.5; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try { tick(mc); } catch (RuntimeException ignored) { }
    }

    private void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.options == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed() || mc.player.isUsingItem()) return;
        long nowMs = System.currentTimeMillis();
        if (nowMs < nextAllowed) return;
        if (mc.crosshairTarget instanceof EntityHitResult) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        Vec3d eye = mc.player.getEyePos();
        double effective = reach * (0.94 + Math.random() * 0.06); // never the exact same reach twice
        Vec3d end = eye.add(mc.player.getRotationVec(1.0f).multiply(effective));
        LivingEntity best = null;
        double bestDistance = Double.MAX_VALUE;
        Box search = mc.player.getBoundingBox().expand(reach + 1.0);
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class, search, x -> x != mc.player && x.isAlive() && !x.isSpectator())) {
            Optional<Vec3d> hit = e.getBoundingBox().expand(e.getTargetingMargin()).raycast(eye, end);
            if (hit.isEmpty()) continue;
            double d = eye.distanceTo(hit.get());
            if (d < bestDistance) { bestDistance = d; best = e; }
        }
        if (best == null || bestDistance <= 3.0) return;
        // Don't hit through walls.
        Vec3d hitPoint = eye.add(end.subtract(eye).normalize().multiply(bestDistance));
        HitResult block = mc.world.raycast(new RaycastContext(eye, hitPoint, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        if (block.getType() != HitResult.Type.MISS) return;
        if (Humanizer.chance(0.06)) { nextAllowed = nowMs + Humanizer.between(60, 140); return; }
        CombatModuleUtil.attack(mc, best);
        nextAllowed = nowMs + Humanizer.between(70, 160);
    }

    public double reach() { return reach; }
    public void setReach(double v) { reach = Math.max(3, Math.min(6, v)); persist(); }
}
