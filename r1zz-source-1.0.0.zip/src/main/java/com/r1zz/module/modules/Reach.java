package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
public final class Reach extends Module {private double reach=3.5;public Reach(){super("reach","Reach",Category.COMBAT,false);}protected void loadSettings(){reach=Math.max(3,Math.min(6,R1zzConfig.getDouble("reach.value",3.5)));}protected void saveSettings(){R1zzConfig.put("reach.value",reach);}protected void resetSettings(){reach=3.5;}public double reach(){return reach;}public void setReach(double v){reach=Math.max(3,Math.min(6,v));persist();}}