package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public final class Tunnel extends Module {
    public Tunnel() { super("tunnel", "Tunnel", Category.WORLD, false); }
    private int height = 2;
    private int width = 1;
    @Override protected void loadSettings() {
        height=R1zzConfig.getInt("tunnel.height",2);
        width=R1zzConfig.getInt("tunnel.width",1);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("tunnel.height", height);
        R1zzConfig.put("tunnel.width", width);
    }
    @Override protected void resetSettings() {
        height=2;
        width=1;
    }

    /** Mines a width x height tunnel in the direction you are facing, nearest block first. */
    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        Direction facing = mc.player.getHorizontalFacing();
        Direction side = facing.rotateYClockwise();
        BlockPos base = mc.player.getBlockPos();
        int lo = -((width - 1) / 2), hi = width / 2;
        for (int step = 1; step <= 3; step++) {
            for (int w = lo; w <= hi; w++) {
                for (int h = 0; h < height; h++) {
                    BlockPos pos = base.offset(facing, step).offset(side, w).up(h);
                    if (!CombatModuleUtil.reach(mc, pos, 4.5)) continue;
                    BlockState state = mc.world.getBlockState(pos);
                    if (state.isAir() || state.isReplaceable() || state.getHardness(mc.world, pos) < 0.0f) continue;
                    CombatModuleUtil.select(mc.player, CombatModuleUtil.bestToolSlot(mc.player, state));
                    mc.interactionManager.updateBlockBreakingProgress(pos, facing.getOpposite());
                    mc.player.swingHand(Hand.MAIN_HAND);
                    return;
                }
            }
        }
    }

    public int height() { return height; }
    public void setHeight(int v) { height=Math.max(1,Math.min(4,v)); persist(); }
    public int width() { return width; }
    public void setWidth(int v) { width=Math.max(1,Math.min(3,v)); persist(); }
}
