package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Tunnel extends Module {
    public Tunnel() { super("tunnel", "Tunnel", Category.WORLD, false); }
    private int height = 2;
    private int width = 1;
    @Override protected void loadSettings() {
        height=R1zzConfig.getInt("tunnel.height",2);
        width=R1zzConfig.getInt("tunnel.width",1);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("tunnel.height", height);
        R1zzConfig.put("tunnel.width", width);
    }
    @Override protected void resetSettings() {
        height=2;
        width=1;
    }
    public int height() { return height; }
    public void setHeight(int v) { height=Math.max(1,Math.min(4,v)); persist(); }
    public int width() { return width; }
    public void setWidth(int v) { width=Math.max(1,Math.min(3,v)); persist(); }
}
