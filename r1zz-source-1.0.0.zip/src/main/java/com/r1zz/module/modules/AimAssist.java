package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public final class AimAssist extends Module {
    private double speed=0.50, range=24.0;
    private String targetType="Players";
    private LivingEntity lockedTarget;
    private int swingSkipTicks;
    public AimAssist(){super("aim_assist","AimAssist",Category.COMBAT,false);}
    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.world==null){lockedTarget=null;swingSkipTicks=0;return;}
        if(!enabled()){lockedTarget=null;swingSkipTicks=0;return;}
        if(swingSkipTicks>0)swingSkipTicks--; if(mc.player.handSwinging)swingSkipTicks=1;
        if(lockedTarget==null||!lockedTarget.isAlive()||lockedTarget.isRemoved()){lockedTarget=find(mc,range);if(lockedTarget==null)lockedTarget=find(mc,64.0);}
        if(lockedTarget==null||mc.player.isUsingItem()||mc.currentScreen!=null||swingSkipTicks>0)return;
        double dist=mc.player.distanceTo(lockedTarget);
        double df=MathHelper.clamp(1.0-dist/range,0.75,1.0), sf=(0.45+speed*0.70)*df;
        double dx=lockedTarget.getX()-mc.player.getX(), dz=lockedTarget.getZ()-mc.player.getZ(), h=Math.sqrt(dx*dx+dz*dz);
        double ty=Math.toDegrees(Math.atan2(dz,dx))-90.0;
        double tp=Math.toDegrees(Math.atan2(lockedTarget.getY()+lockedTarget.getHeight()*0.5-(mc.player.getY()+mc.player.getEyeHeight(mc.player.getPose())),h));
        double yd=MathHelper.wrapDegrees((float)(ty-mc.player.getYaw())), pd=tp-mc.player.getPitch();
        if(Math.abs(yd)<0.3)yd=0; if(Math.abs(pd)<0.8)pd=0;
        double s=1.0-Math.exp(-sf), ys=MathHelper.clamp(yd*s,-35.0,35.0), ps=MathHelper.clamp(pd*s*0.5,-20.0,20.0);
        float sens=mc.options.getMouseSensitivity().getValue().floatValue(), f=sens*0.6f+0.2f, gcd=f*f*f*1.2f;
        ys=Math.round(ys/gcd)*gcd; ps=Math.round(ps/gcd)*gcd;
        mc.player.setYaw(mc.player.getYaw()+(float)ys); mc.player.setPitch(MathHelper.clamp(mc.player.getPitch()+(float)ps,-90.0f,90.0f));
    }
    private LivingEntity find(MinecraftClient mc,double max){for(Entity e:mc.world.getEntitiesByClass(Entity.class,mc.player.getBoundingBox().expand(max),x->x instanceof LivingEntity&&x!=mc.player)){LivingEntity l=(LivingEntity)e;if(valid(l,max))return l;}return null;}
    private boolean valid(LivingEntity t,double max){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null||!t.isAlive()||t.isRemoved()||mc.player.distanceTo(t)>max)return false;return switch(targetType){case "Entities","Both"->true;default->t instanceof PlayerEntity;};}
    public double speed(){return speed;} public void setSpeed(double v){speed=MathHelper.clamp(v,0.1,1.0);}
    public double range(){return range;} public void setRange(double v){range=MathHelper.clamp(v,3.0,64.0);}
    public String targetType(){return targetType;} public void setTargetType(String v){if("Players".equals(v)||"Entities".equals(v)||"Both".equals(v))targetType=v;}
}
