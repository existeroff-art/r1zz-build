package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class AimAssist extends Module {

    private final Random random = new Random();

    private double speed = 0.9;
    private double range = 8.0;
    private double noise = 0.10;
    private double fov = 180.0;
    private String targetType = "Players";
    private String weaponFilter = "Sword Only";

    private LivingEntity lockedTarget = null;
    private long outOfViewSince = 0L;
    private long lastTargetSwitch = 0L;
    private boolean lastTickSwung = false;

    public AimAssist() {
        super("aim_assist", "AimAssist", Category.COMBAT, false);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) {
            lockedTarget = null;
            return;
        }

        if (mc.player.isUsingItem() || mc.currentScreen != null) {
            lastTickSwung = mc.player.handSwinging;
            return;
        }

        if (!weaponFilterAllows(mc.player.getMainHandStack())) {
            lastTickSwung = mc.player.handSwinging;
            return;
        }

        if (lastTickSwung) {
            lastTickSwung = mc.player.handSwinging;
            return;
        }

        long now = System.currentTimeMillis();

        if (lockedTarget != null && (!lockedTarget.isAlive() || lockedTarget.isRemoved())) {
            lockedTarget = null;
        }

        if (lockedTarget != null) {
            double dist = mc.player.distanceTo(lockedTarget);
            if (dist > range) lockedTarget = null;
        }

        if (lockedTarget != null && !mc.player.canSee(lockedTarget)) {
            if (outOfViewSince == 0L) outOfViewSince = now;
            else if (now - outOfViewSince > 400L) {
                lockedTarget = null;
                outOfViewSince = 0L;
            }
        } else {
            outOfViewSince = 0L;
        }

        if (lockedTarget == null) {
            if (now - lastTargetSwitch < 300L) {
                lastTickSwung = mc.player.handSwinging;
                return;
            }
            lockedTarget = findTarget(mc);
            if (lockedTarget != null) lastTargetSwitch = now;
            else {
                lastTickSwung = mc.player.handSwinging;
                return;
            }
        }

        if (lockedTarget != null) rotateTo(mc, lockedTarget);

        lastTickSwung = mc.player.handSwinging;
    }

    private boolean weaponFilterAllows(ItemStack stack) {
        if (weaponFilter == null) return true;
        return switch (weaponFilter) {
            case "Sword Only" -> stack.getItem() instanceof SwordItem;
            case "Weapon" -> stack.getItem() instanceof SwordItem
                    || stack.getItem() instanceof AxeItem
                    || stack.getItem() instanceof TridentItem
                    || stack.getItem() instanceof MaceItem;
            case "All Items" -> true;
            default -> true;
        };
    }

    private LivingEntity findTarget(MinecraftClient mc) {
        List<LivingEntity> candidates = mc.world.getEntitiesByClass(
                LivingEntity.class,
                mc.player.getBoundingBox().expand(range),
                e -> e != mc.player && e.isAlive() && !e.isSpectator()
                        && matchesTargetType(e)
                        && mc.player.canSee(e)
                        && withinFov(mc, e)
        );

        if (candidates.isEmpty()) return null;

        if (targetType.equals("Players") || targetType.equals("Both")) {
            LivingEntity np = candidates.stream()
                    .filter(e -> e instanceof PlayerEntity)
                    .min(Comparator.comparingDouble(mc.player::distanceTo))
                    .orElse(null);
            if (np != null) return np;
        }

        return candidates.stream()
                .min(Comparator.comparingDouble(mc.player::distanceTo))
                .orElse(null);
    }

    private boolean matchesTargetType(LivingEntity e) {
        return switch (targetType) {
            case "Players" -> e instanceof PlayerEntity;
            case "Entities" -> !(e instanceof PlayerEntity);
            case "Both" -> true;
            default -> true;
        };
    }

    private boolean withinFov(MinecraftClient mc, LivingEntity target) {
        Vec3d look = mc.player.getRotationVec(1.0f).normalize();
        Vec3d toTarget = target.getPos().add(0, target.getHeight() * 0.5, 0)
                .subtract(mc.player.getEyePos()).normalize();
        double dot = look.dotProduct(toTarget);
        double angle = Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, dot))));
        return angle <= fov / 2.0;
    }

    private void rotateTo(MinecraftClient mc, LivingEntity target) {
        Vec3d targetPos = target.getPos().add(0, target.getHeight() * 0.5, 0);
        Vec3d eyePos = mc.player.getEyePos();
        Vec3d diff = targetPos.subtract(eyePos);

        double distXZ = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, distXZ));

        float currentYaw = mc.player.getYaw();
        float currentPitch = mc.player.getPitch();

        float yawDelta = MathHelper.wrapDegrees(targetYaw - currentYaw);
        float pitchDelta = targetPitch - currentPitch;

        double dist = mc.player.distanceTo(target);
        double distanceFactor = Math.max(0.7, Math.min(1.0, 1.0 - (dist / range)));
        double speedFactor = (0.75 + speed * 1.10) * distanceFactor;

        float yawStep = (float) (yawDelta * (1.0 - Math.exp(-speedFactor)));
        float pitchStep = (float) (pitchDelta * (1.0 - Math.exp(-speedFactor)));

        if (Math.abs(yawDelta) < 6.0f) yawStep = yawDelta;
        if (Math.abs(yawDelta) > 6.0f) {
            float ov = 1.12f + random.nextFloat() * 0.08f;
            yawStep *= ov;
        }
        if (Math.abs(yawDelta) < 1.5f) yawStep *= 0.95f;
        if (Math.abs(pitchDelta) < 0.8f) pitchStep = 0.0f;

        yawStep += (random.nextFloat() - 0.5f) * (float) (noise * 0.20);
        yawStep += (float) (random.nextGaussian() * Math.abs(yawStep) * 0.04);

        float yawCap = 55.0f * (0.97f + random.nextFloat() * 0.06f);
        float pitchCap = 32.0f * (0.97f + random.nextFloat() * 0.06f);

        if (Math.abs(yawDelta) > 90.0f) yawCap = 30.0f;
        else if (Math.abs(yawDelta) > 45.0f) yawCap = 40.0f;

        yawStep = MathHelper.clamp(yawStep, -yawCap, yawCap);
        pitchStep = MathHelper.clamp(pitchStep, -pitchCap, pitchCap);

        double sens = mc.options.getMouseSensitivity().getValue();
        double f = sens * 0.6 + 0.2;
        double gcd = f * f * f * 1.2;
        if (gcd > 0.0) {
            yawStep = (float) (Math.round(yawStep / gcd) * gcd);
            pitchStep = (float) (Math.round(pitchStep / gcd) * gcd);
        }

        mc.player.setYaw(currentYaw + yawStep);
        mc.player.setPitch(MathHelper.clamp(currentPitch + pitchStep, -90.0f, 90.0f));
    }

    // Getters/setters matching ClickGUI
    public double speed() { return speed; }
    public void setSpeed(double v) { speed = Math.max(0.1, Math.min(1.0, v)); }

    public double range() { return range; }
    public void setRange(double v) { range = Math.max(3.0, Math.min(12.0, v)); }

    public double noise() { return noise; }
    public void setNoise(double v) { noise = Math.max(0.0, Math.min(2.0, v)); }

    public double fov() { return fov; }
    public void setFov(double v) { fov = Math.max(30.0, Math.min(360.0, v)); }

    public String targetType() { return targetType; }
    public void setTargetType(String v) { targetType = v; }

    public String weaponFilter() { return weaponFilter; }
    public void setWeaponFilter(String v) { weaponFilter = v; }

    @Override
    public void onDisable() {
        lockedTarget = null;
        outOfViewSince = 0L;
    }
}