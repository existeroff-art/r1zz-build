package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Blatant, sticky aim assist.
 *
 * Tuning notes:
 * - If flagged: speed 0.6, max yaw 40 degrees.
 * - If too subtle: speed 1.0, noise 0.05.
 */
public final class AimAssist extends Module {
    private double speed = 0.9;
    private double range = 8.0;
    private double noise = 0.10;
    private double fov = 180.0;
    private String targetType = "Players";
    private String weaponFilter = "Sword Only";
    private boolean humanization = true;

    private LivingEntity lockedTarget;
    private long invalidSince;
    private long lastSwitchTime;
    private boolean skipAfterSwing;

    public AimAssist() {
        super("aim_assist", "AimAssist", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        speed = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.speed", 0.9), 0.1, 1.0);
        range = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.range", 8.0), 1.0, 12.0);
        noise = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.noise", 0.10), 0.0, 1.0);
        fov = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.fov", 180.0), 30.0, 360.0);
        targetType = choice(R1zzConfig.get("aim_assist.target_type", "Players"), "Players", "Entities", "Both");
        weaponFilter = choice(R1zzConfig.get("aim_assist.weapon_filter", "Sword Only"), "Sword Only", "Weapon", "All Items");
        humanization = R1zzConfig.getBoolean("aim_assist.humanization", true);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("aim_assist.speed", speed);
        R1zzConfig.put("aim_assist.range", range);
        R1zzConfig.put("aim_assist.noise", noise);
        R1zzConfig.put("aim_assist.fov", fov);
        R1zzConfig.put("aim_assist.target_type", targetType);
        R1zzConfig.put("aim_assist.weapon_filter", weaponFilter);
        R1zzConfig.put("aim_assist.humanization", humanization);
    }

    @Override
    protected void resetSettings() {
        speed = 0.9;
        range = 8.0;
        noise = 0.10;
        fov = 180.0;
        targetType = "Players";
        weaponFilter = "Sword Only";
        humanization = true;
        clearLock();
    }

    @Override
    public void onEnable() {
        clearLock();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.world != null) {
            lockedTarget = findTarget(mc);
            lastSwitchTime = System.currentTimeMillis();
        }
    }

    @Override
    public void onDisable() {
        clearLock();
    }

    private void clearLock() {
        lockedTarget = null;
        invalidSince = 0L;
        lastSwitchTime = 0L;
        skipAfterSwing = false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) {
            clearLock();
            return;
        }

        if (skipAfterSwing) {
            skipAfterSwing = false;
            return;
        }
        if (mc.player.handSwinging) {
            skipAfterSwing = true;
            return;
        }

        if (lockedTarget == null) {
            lockedTarget = findTarget(mc);
            invalidSince = 0L;
            if (lockedTarget == null) return;
            lastSwitchTime = System.currentTimeMillis();
        }

        boolean valid = lockedTarget.isAlive()
                && !lockedTarget.isRemoved()
                && !lockedTarget.isSpectator()
                && mc.player.distanceTo(lockedTarget) <= range
                && withinFov(mc, lockedTarget)
                && matchesTargetType(lockedTarget);

        if (!valid) {
            if (invalidSince == 0L) invalidSince = System.currentTimeMillis();
            if (System.currentTimeMillis() - invalidSince >= 400L) {
                clearLock();
            }
            return;
        }
        invalidSince = 0L;

        if (mc.currentScreen != null
                || mc.player.isUsingItem()
                || mc.player.isBlocking()
                || mc.player.getOffHandStack().isOf(net.minecraft.item.Items.SHIELD)
                || !weaponFilterAllows(mc.player.getMainHandStack())) {
            return;
        }

        rotateTo(mc, lockedTarget);
    }

    private LivingEntity findTarget(MinecraftClient mc) {
        List<LivingEntity> candidates = mc.world.getEntitiesByClass(
                LivingEntity.class,
                mc.player.getBoundingBox().expand(range),
                e -> e != mc.player
                        && e.isAlive()
                        && !e.isRemoved()
                        && !e.isSpectator()
                        && matchesTargetType(e)
                        && withinFov(mc, e)
        );
        return candidates.stream()
                .min(Comparator.comparingDouble(mc.player::distanceTo))
                .orElse(null);
    }

    private boolean matchesTargetType(LivingEntity entity) {
        return switch (targetType) {
            case "Players" -> entity instanceof PlayerEntity;
            case "Entities" -> !(entity instanceof PlayerEntity);
            default -> true;
        };
    }

    private boolean withinFov(MinecraftClient mc, LivingEntity target) {
        Vec3d look = mc.player.getRotationVec(1.0f).normalize();
        Vec3d to = target.getPos()
                .add(0.0, target.getHeight() * 0.5, 0.0)
                .subtract(mc.player.getEyePos())
                .normalize();
        double angle = Math.toDegrees(Math.acos(
                MathHelper.clamp(look.dotProduct(to), -1.0, 1.0)
        ));
        return angle <= fov * 0.5;
    }

    private boolean weaponFilterAllows(ItemStack stack) {
        return switch (weaponFilter) {
            case "Sword Only" -> stack.getItem() instanceof SwordItem;
            case "Weapon" -> stack.getItem() instanceof SwordItem
                    || stack.getItem() instanceof AxeItem
                    || stack.getItem() instanceof TridentItem
                    || stack.getItem() instanceof MaceItem;
            default -> true;
        };
    }

    private void rotateTo(MinecraftClient mc, LivingEntity target) {
        Vec3d diff = target.getPos()
                .add(0.0, target.getHeight() * 0.5, 0.0)
                .subtract(mc.player.getEyePos());

        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();

        if (Math.abs(pitchDelta) < 0.8f) pitchDelta = 0.0f;

        double distanceFactor = MathHelper.clamp(
                1.0 - mc.player.distanceTo(target) / Math.max(range, 0.001),
                0.7, 1.0
        );
        double speedFactor = (0.75 + speed * 1.10) * distanceFactor;

        float yawStep = (float) (yawDelta * (1.0 - Math.exp(-speedFactor)));
        float pitchStep = (float) (pitchDelta * (1.0 - Math.exp(-speedFactor)));

        if (Math.abs(yawDelta) < 6.0f) {
            yawStep = yawDelta;
        } else {
            float overshoot = 0.12f + ThreadLocalRandom.current().nextFloat() * 0.08f;
            yawStep += Math.copySign(Math.abs(yawStep) * overshoot, yawDelta);
        }

        if (Math.abs(yawDelta) < 1.5f) yawStep *= 0.95f;

        if (humanization) {
            float capVariance = 0.95f + ThreadLocalRandom.current().nextFloat() * 0.10f;
            float speedVariance = 0.90f + ThreadLocalRandom.current().nextFloat() * 0.20f;
            yawStep *= speedVariance;
            pitchStep *= speedVariance;

            if (Math.abs(yawDelta) > 0.5f) {
                yawStep += (float) ThreadLocalRandom.current().nextGaussian() * Math.max(Math.abs(yawStep), 0.01f) * 0.04f;
                yawStep += ThreadLocalRandom.current().nextDouble(-noise * 0.10, noise * 0.10);
                yawStep += ThreadLocalRandom.current().nextDouble(-0.15, 0.15);
                pitchStep += ThreadLocalRandom.current().nextDouble(-0.08, 0.08);
            }

            float yawCap = 55.0f * capVariance;
            float pitchCap = 32.0f * capVariance;
            if (Math.abs(yawDelta) > 90.0f) {
                yawCap = Math.max(30.0f, 30.0f * capVariance);
                if (Math.abs(yawStep) < 4.0f) yawStep = Math.copySign(4.0f, yawDelta);
            } else if (Math.abs(yawDelta) > 45.0f) {
                yawCap = 40.0f * capVariance;
            }
            if (Math.abs(yawDelta) <= 8.0f && mc.player.distanceTo(target) <= 8.0f) {
                yawCap = Math.min(yawCap, 55.0f * capVariance);
            }

            yawStep = MathHelper.clamp(yawStep, -yawCap, yawCap);
            pitchStep = MathHelper.clamp(pitchStep, -pitchCap, pitchCap);
        } else {
            float yawCap = 55.0f;
            if (Math.abs(yawDelta) > 90.0f) {
                yawCap = 30.0f;
                if (Math.abs(yawStep) < 4.0f) yawStep = Math.copySign(4.0f, yawDelta);
            } else if (Math.abs(yawDelta) > 45.0f) {
                yawCap = 40.0f;
            }
            yawStep = MathHelper.clamp(yawStep, -yawCap, yawCap);
            pitchStep = MathHelper.clamp(pitchStep, -32.0f, 32.0f);
        }

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    private static String choice(String value, String... values) {
        for (String v : values) if (v.equals(value)) return value;
        return values[0];
    }

    public double speed() { return speed; }
    public void setSpeed(double v) { speed = MathHelper.clamp(v, 0.1, 1.0); persist(); }
    public double range() { return range; }
    public void setRange(double v) { range = MathHelper.clamp(v, 1.0, 12.0); persist(); }
    public double noise() { return noise; }
    public void setNoise(double v) { noise = MathHelper.clamp(v, 0.0, 1.0); persist(); }
    public double fov() { return fov; }
    public void setFov(double v) { fov = MathHelper.clamp(v, 30.0, 360.0); persist(); }
    public String targetType() { return targetType; }
    public void setTargetType(String v) { targetType = choice(v, "Players", "Entities", "Both"); persist(); }
    public String weaponFilter() { return weaponFilter; }
    public void setWeaponFilter(String v) { weaponFilter = choice(v, "Sword Only", "Weapon", "All Items"); persist(); }
    public boolean humanization() { return humanization; }
    public void setHumanization(boolean v) { humanization = v; persist(); }
}
