package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class AimAssist extends Module {
    private double speed = 0.8, range = 8.0, noise = 0.35, fov = 180.0;
    private String targetType = "Players", weaponFilter = "Sword Only";
    private UUID lockedTarget;
    private long invalidSince;
    private boolean wasSwinging;
    private boolean releasedIdle;

    public AimAssist() { super("aim_assist", "Aim Assist", Category.COMBAT, false); }

    @Override protected void loadSettings() {
        speed = clamp(R1zzConfig.getDouble("aim.speed", 0.8), 0.0, 1.0);
        range = clamp(R1zzConfig.getDouble("aim.range", 8.0), 3.0, 12.0);
        noise = clamp(R1zzConfig.getDouble("aim.noise", 0.20), 0.0, 2.0);
        fov = clamp(R1zzConfig.getDouble("aim.fov", 180.0), 30.0, 360.0);
        targetType = choice(R1zzConfig.get("aim.target_type", "Players"), "Players", "Entities", "Both");
        weaponFilter = choice(R1zzConfig.get("aim.weapon_filter", "Sword Only"), "Sword Only", "Weapon", "All Items");
    }

    @Override protected void saveSettings() {
        R1zzConfig.put("aim.speed", speed); R1zzConfig.put("aim.range", range);
        R1zzConfig.put("aim.noise", noise); R1zzConfig.put("aim.fov", fov);
        R1zzConfig.put("aim.target_type", targetType); R1zzConfig.put("aim.weapon_filter", weaponFilter);
    }

    @Override protected void resetSettings() {
        speed=.8; range=8.0; noise=.20; fov=180.0;
        targetType="Players"; weaponFilter="Sword Only"; lockedTarget=null; invalidSince=0;
    }

    @Override public void onDisable() { lockedTarget=null; invalidSince=0; releasedIdle=false; }

    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        boolean swinging = mc.player.handSwinging;
        boolean justFinished = wasSwinging && !swinging;
        wasSwinging = swinging;

        if (mc.currentScreen != null || mc.player.isUsingItem() || mc.player.isBlocking() ||
                !weaponAllowed(mc.player.getMainHandStack().getItem()) || swinging || justFinished) return;

        LivingEntity target = lockedTarget == null ? null : findByUuid(mc, lockedTarget);

        if (lockedTarget == null && releasedIdle) {
            releasedIdle = false;
            return;
        }

        if (target == null) {
            target = chooseNearest(mc);
            if (target != null) {
                lockedTarget = target.getUuid();
                invalidSince = 0;
            } else {
                return;
            }
        }

        if (!validLocked(mc, target)) {
            if (invalidSince == 0) invalidSince = System.currentTimeMillis();
            if (System.currentTimeMillis() - invalidSince >= 400) {
                lockedTarget = null;
                invalidSince = 0;
                releasedIdle = true;
            }
            return;
        }
        invalidSince = 0;

        Vec3d point = target.getPos().add(0, target.getHeight() * 0.5, 0);
        Vec3d diff = point.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float)(Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float)-Math.toDegrees(Math.atan2(diff.y, horizontal));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();
        if (Math.abs(pitchDelta) <= 0.8f) pitchDelta = 0;

        double dist = mc.player.distanceTo(target);
        double distanceFactor = clamp(1.0 - (dist / range), 0.5, 1.0);
        double speedFactor = (0.50 + speed * 0.90) * distanceFactor;
        double dt = 1.0 / 20.0;
        double smooth = 1.0 - Math.exp(-speedFactor * dt);

        float yawStep = (float)(yawDelta * smooth);
        float pitchStep = (float)(pitchDelta * smooth);

        if (Math.abs(yawDelta) > 8.0f) {
            float overshoot = (float)ThreadLocalRandom.current().nextDouble(0.08, 0.14);
            yawStep *= 1.0f + Math.copySign(overshoot, yawDelta);
        }
        if (Math.abs(yawDelta) < 1.5f) yawStep *= 0.8f;

        float jitter = (float)ThreadLocalRandom.current().nextDouble(-noise * 0.25, noise * 0.25);
        yawStep += jitter;

        double capVariance = ThreadLocalRandom.current().nextDouble(0.95, 1.05);
        float yawCap = (float)((dist <= 8.0 ? 45.0 : 32.0) * capVariance);
        float pitchCap = (float)(25.0 * ThreadLocalRandom.current().nextDouble(0.95, 1.05));

        if (Math.abs(yawDelta) > 90.0f)
            yawStep = Math.copySign(Math.min(Math.abs(yawStep), Math.abs(yawDelta) / 5.0f), yawStep);

        yawStep = MathHelper.clamp(yawStep, -yawCap, yawCap);
        pitchStep = MathHelper.clamp(pitchStep, -pitchCap, pitchCap);

        double sens = mc.options.getMouseSensitivity().getValue();
        double f = sens * 0.6 + 0.2;
        double gcd = f * f * f * 1.2;
        if (gcd > 0) {
            yawStep = (float)(Math.round(yawStep / gcd) * gcd);
            pitchStep = (float)(Math.round(pitchStep / gcd) * gcd);
        }

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    private LivingEntity chooseNearest(MinecraftClient mc) {
        if (targetType.equals("Players") || targetType.equals("Both")) {
            PlayerEntity p = mc.world.getPlayers().stream()
                    .filter(e -> e != mc.player && validCandidate(mc, e))
                    .min((a,b) -> Double.compare(mc.player.distanceTo(a), mc.player.distanceTo(b))).orElse(null);
            if (p != null) return p;
        }
        if (targetType.equals("Entities") || targetType.equals("Both")) {
            return mc.world.getEntitiesByClass(LivingEntity.class, mc.player.getBoundingBox().expand(range),
                    e -> !(e instanceof PlayerEntity) && validCandidate(mc, e))
                    .stream().min((a,b) -> Double.compare(mc.player.distanceTo(a), mc.player.distanceTo(b))).orElse(null);
        }
        return null;
    }

    private boolean validCandidate(MinecraftClient mc, LivingEntity e) {
        if (e == null || !e.isAlive() || e == mc.player || e.isSpectator()) return false;
        if (mc.player.distanceTo(e) > range || !mc.player.canSee(e)) return false;
        return withinFov(mc, e);
    }

    private boolean validLocked(MinecraftClient mc, LivingEntity e) {
        if (e == null || !e.isAlive() || e == mc.player || e.isSpectator()) return false;
        return mc.player.distanceTo(e) <= range && withinFov(mc, e);
    }

    private boolean withinFov(MinecraftClient mc, LivingEntity e) {
        Vec3d to = e.getPos().add(0, e.getHeight() * 0.5, 0)
                .subtract(mc.player.getEyePos()).normalize();
        double dot = Math.max(-1, Math.min(1, mc.player.getRotationVec(1).normalize().dotProduct(to)));
        double angle = Math.toDegrees(Math.acos(dot));
        return angle <= fov * 0.5;
    }

    private static LivingEntity findByUuid(MinecraftClient mc, UUID id) {
        return mc.world.getEntitiesByClass(LivingEntity.class, mc.player.getBoundingBox().expand(16),
                e -> e.getUuid().equals(id)).stream().findFirst().orElse(null);
    }

    private boolean weaponAllowed(Item item) {
        if (weaponFilter.equals("All Items")) return true;
        if (weaponFilter.equals("Sword Only")) return item instanceof SwordItem;
        return item instanceof SwordItem || item instanceof AxeItem || item instanceof TridentItem || item instanceof MaceItem;
    }

    private static String choice(String v, String... allowed) {
        for (String a : allowed) if (a.equals(v)) return v;
        return allowed[0];
    }
    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }

    public double speed(){return speed;} public void setSpeed(double v){speed=clamp(v,0,1);persist();}
    public double range(){return range;} public void setRange(double v){range=clamp(v,3,12);persist();}
    public double noise(){return noise;} public void setNoise(double v){noise=clamp(v,0,2);persist();}
    public double fov(){return fov;} public void setFov(double v){fov=clamp(v,30,360);persist();}
    public String targetType(){return targetType;} public void setTargetType(String v){targetType=choice(v,"Players","Entities","Both");persist();}
    public String weaponFilter(){return weaponFilter;} public void setWeaponFilter(String v){weaponFilter=choice(v,"Sword Only","Weapon","All Items");persist();}
}
