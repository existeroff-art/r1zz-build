package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;

/** Sticky body-center aim assist. Rotation only; never attacks. */
public final class AimAssist extends Module {
    private double speed = 0.45;
    private double range = 6.0;
    private String targetType = "Players";
    private LivingEntity lockedTarget;
    private float previousPitch;
    private boolean previousHandSwinging;
    private int swingSkipTicks;

    public AimAssist() {
        super("aim_assist", "AimAssist", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        speed = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.speed", 0.45), 0.1, 1.0);
        range = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.range", 6.0), 2.0, 8.0);
        targetType = choice(R1zzConfig.get("aim_assist.target_type", "Players"), "Players", "Entities", "Both");
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("aim_assist.speed", speed);
        R1zzConfig.put("aim_assist.range", range);
        R1zzConfig.put("aim_assist.target_type", targetType);
    }

    @Override
    protected void resetSettings() {
        speed = 0.45;
        range = 6.0;
        targetType = "Players";
        lockedTarget = null;
    }

    @Override
    public void onEnable() {
        lockedTarget = null;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        previousPitch = mc.player.getPitch();
        previousHandSwinging = mc.player.handSwinging;
        swingSkipTicks = 0;

        lockedTarget = mc.world.getEntitiesByClass(
                        LivingEntity.class,
                        mc.player.getBoundingBox().expand(range),
                        entity -> validTarget(mc, entity))
                .stream()
                .min(Comparator.comparingDouble(mc.player::distanceTo))
                .orElse(null);
    }

    @Override
    public void onDisable() {
        lockedTarget = null;
        swingSkipTicks = 0;
    }

    @Override
    public void onTick() {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;

            LivingEntity target = lockedTarget;
            if (target == null || !target.isAlive() || target.isRemoved()) {
                previousPitch = mc.player.getPitch();
                previousHandSwinging = mc.player.handSwinging;
                return;
            }

            boolean justSwung = swingSkipTicks > 0;
            if (mc.player.handSwinging && !previousHandSwinging) {
                swingSkipTicks = 1;
            } else if (swingSkipTicks > 0) {
                swingSkipTicks--;
            }
            previousHandSwinging = mc.player.handSwinging;

            float currentPitch = mc.player.getPitch();
            float userPitchDelta = Math.abs(currentPitch - previousPitch);
            previousPitch = currentPitch;

            if (mc.player.isUsingItem() || mc.currentScreen != null || justSwung) return;

            Vec3d bodyCenter = target.getPos().add(0.0, target.getHeight() * 0.5, 0.0);
            Vec3d delta = bodyCenter.subtract(mc.player.getEyePos());
            double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);

            float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
            float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));

            float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
            float pitchDelta = targetPitch - mc.player.getPitch();

            double speedFactor = 0.30 + (speed * 0.40);
            float yawStep = (float) (yawDelta * (1.0 - Math.exp(-speedFactor)));
            float pitchStep = (float) (pitchDelta * (1.0 - Math.exp(-speedFactor)) * 0.4);

            if (Math.abs(yawDelta) < 0.5f) yawStep = 0.0f;
            if (Math.abs(pitchDelta) < 1.5f || userPitchDelta > 0.05f) pitchStep = 0.0f;
            if (Math.abs(yawDelta) > 10.0f) yawStep *= 1.05f;

            yawStep = MathHelper.clamp(yawStep, -30.0f, 30.0f);
            pitchStep = MathHelper.clamp(pitchStep, -15.0f, 15.0f);

            float sensitivity = mc.options.getMouseSensitivity().getValue().floatValue();
            float f = sensitivity * 0.6f + 0.2f;
            float gcd = f * f * f * 1.2f;
            if (gcd > 0.0f) {
                yawStep = Math.round(yawStep / gcd) * gcd;
                pitchStep = Math.round(pitchStep / gcd) * gcd;
            }

            mc.player.setYaw(mc.player.getYaw() + yawStep);
            mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
        } catch (Throwable ignored) {
            // A bad client state must not take down the game.
        }
    }

    private boolean validTarget(MinecraftClient mc, LivingEntity entity) {
        if (entity == mc.player || !entity.isAlive() || entity.isRemoved() || entity.isSpectator()) return false;
        if (entity instanceof PlayerEntity) {
            return targetType.equals("Players") || targetType.equals("Both");
        }
        return targetType.equals("Entities") || targetType.equals("Both");
    }

    private static String choice(String value, String a, String b, String c) {
        return value.equals(a) || value.equals(b) || value.equals(c) ? value : a;
    }

    public double speed() {
        return speed;
    }

    public void setSpeed(double value) {
        speed = MathHelper.clamp(value, 0.1, 1.0);
        persist();
    }

    public double range() {
        return range;
    }

    public void setRange(double value) {
        range = MathHelper.clamp(value, 2.0, 8.0);
        persist();
    }

    public String targetType() {
        return targetType;
    }

    public void setTargetType(String value) {
        if (value.equals("Players") || value.equals("Entities") || value.equals("Both")) {
            targetType = value;
            persist();
        }
    }
}
