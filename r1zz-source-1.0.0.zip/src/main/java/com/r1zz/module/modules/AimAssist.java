package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class AimAssist extends Module {
    private double speed = 0.50;
    private double range = 24.0;
    private String targetType = "Players";
    private LivingEntity lockedTarget;
    private boolean wasEnabled;
    private int swingSkipTicks;

    public AimAssist() {
        super("aim_assist", "AimAssist", Category.COMBAT, false);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) {
            lockedTarget = null;
            wasEnabled = false;
            swingSkipTicks = 0;
            return;
        }
        if (!enabled()) {
            lockedTarget = null;
            wasEnabled = false;
            swingSkipTicks = 0;
            return;
        }
        if (!wasEnabled) {
            lockedTarget = null;
            wasEnabled = true;
        }
        if (swingSkipTicks > 0) swingSkipTicks--;
        if (mc.player.handSwinging) swingSkipTicks = 1;
        if (lockedTarget == null || !lockedTarget.isAlive() || lockedTarget.isRemoved()) {
            lockedTarget = findFirstValidTarget(mc, range);
            if (lockedTarget == null) lockedTarget = findFirstValidTarget(mc, 64.0);
        }
        if (lockedTarget == null || mc.player.isUsingItem() || mc.currentScreen != null || swingSkipTicks > 0) return;

        double dist = mc.player.distanceTo(lockedTarget);
        double distanceFactor = MathHelper.clamp(1.0 - (dist / range), 0.75, 1.0);
        double speedFactor = (0.45 + speed * 0.70) * distanceFactor;
        double smoothing = 1.0 - Math.exp(-speedFactor);

        Vec3d aimPoint = new Vec3d(
                lockedTarget.getX(),
                lockedTarget.getY() + (lockedTarget.getHeight() / 2.0),
                lockedTarget.getZ()
        );

        double dx = aimPoint.x - mc.player.getX();
        double dy = aimPoint.y - (mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()));
        double dz = aimPoint.z - mc.player.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        double targetYaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
        double targetPitch = -Math.toDegrees(Math.atan2(dy, horizontal));

        double yawDelta = MathHelper.wrapDegrees((float) (targetYaw - mc.player.getYaw()));
        double pitchDelta = targetPitch - mc.player.getPitch();
        if (Math.abs(yawDelta) < 0.3) yawDelta = 0.0;
        if (Math.abs(pitchDelta) < 0.5) pitchDelta = 0.0;

        double yawStep = MathHelper.clamp(yawDelta * smoothing, -35.0, 35.0);
        double pitchStep = MathHelper.clamp(pitchDelta * smoothing, -20.0, 20.0);

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        yawStep = Math.round(yawStep / gcd) * gcd;
        pitchStep = Math.round(pitchStep / gcd) * gcd;

        mc.player.setYaw(mc.player.getYaw() + (float) yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + (float) pitchStep, -90.0f, 90.0f));
    }

    private LivingEntity findFirstValidTarget(MinecraftClient mc, double maxRange) {
        for (Entity entity : mc.world.getEntitiesByClass(Entity.class, mc.player.getBoundingBox().expand(maxRange), e -> e instanceof LivingEntity && e != mc.player)) {
            LivingEntity target = (LivingEntity) entity;
            if (isValidTarget(target, maxRange)) return target;
        }
        return null;
    }

    private boolean isValidTarget(LivingEntity target, double maxRange) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !target.isAlive() || target.isRemoved() || mc.player.distanceTo(target) > maxRange) return false;
        return switch (targetType) {
            case "Entities", "Both" -> true;
            case "Players" -> target instanceof PlayerEntity;
            default -> target instanceof PlayerEntity;
        };
    }

    public double speed() { return speed; }
    public void setSpeed(double speed) { this.speed = MathHelper.clamp(speed, 0.1, 1.0); }
    public double range() { return range; }
    public void setRange(double range) { this.range = MathHelper.clamp(range, 3.0, 64.0); }
    public String targetType() { return targetType; }
    public void setTargetType(String targetType) {
        if ("Players".equals(targetType) || "Entities".equals(targetType) || "Both".equals(targetType)) this.targetType = targetType;
    }
}
