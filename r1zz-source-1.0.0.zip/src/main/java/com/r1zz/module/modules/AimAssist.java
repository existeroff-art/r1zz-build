package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class AimAssist extends Module {
    private double speed = 0.9;
    private double range = 8.0;
    private double noise = 0.10;
    private double fov = 180.0;
    private String targetType = "Players";
    private String weaponFilter = "Sword Only";
    private LivingEntity lockedTarget;
    private boolean lastTickSwung;

    public AimAssist() { super("aim_assist", "AimAssist", Category.COMBAT, false); }

    @Override protected void loadSettings() {
        speed = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.speed", 0.9), 0.1, 1.0);
        range = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.range", 8.0), 2.0, 12.0);
        noise = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.noise", 0.10), 0.0, 2.0);
        fov = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.fov", 180.0), 30.0, 360.0);
        targetType = choice(R1zzConfig.get("aim_assist.target_type", "Players"), "Players", "Entities", "Both");
        weaponFilter = choice(R1zzConfig.get("aim_assist.weapon_filter", "Sword Only"), "Sword Only", "Weapon", "All Items");
    }

    @Override protected void saveSettings() {
        R1zzConfig.put("aim_assist.speed", speed);
        R1zzConfig.put("aim_assist.range", range);
        R1zzConfig.put("aim_assist.noise", noise);
        R1zzConfig.put("aim_assist.fov", fov);
        R1zzConfig.put("aim_assist.target_type", targetType);
        R1zzConfig.put("aim_assist.weapon_filter", weaponFilter);
    }

    @Override protected void resetSettings() {
        speed = 0.9; range = 8.0; noise = 0.10; fov = 180.0;
        targetType = "Players"; weaponFilter = "Sword Only";
        lockedTarget = null; lastTickSwung = false;
    }

    @Override public void onEnable() {
        lockedTarget = null;
        lastTickSwung = false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.world != null) lockedTarget = findTarget(mc);
    }

    @Override public void onDisable() {
        lockedTarget = null;
        lastTickSwung = false;
    }

    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) { lockedTarget = null; return; }

        boolean swung = mc.player.handSwinging;
        if (lastTickSwung) { lastTickSwung = swung; return; }
        lastTickSwung = swung;

        if (lockedTarget != null && (!lockedTarget.isAlive() || lockedTarget.isRemoved()
                || mc.player.distanceTo(lockedTarget) > range)) {
            lockedTarget = null;
        }
        if (lockedTarget == null) lockedTarget = findTarget(mc);
        if (lockedTarget == null) return;

        if (mc.currentScreen != null || mc.player.isUsingItem() || mc.player.isBlocking()
                || mc.player.getOffHandStack().isOf(net.minecraft.item.Items.SHIELD)
                || !weaponFilterAllows(mc.player.getMainHandStack())) return;

        rotateTo(mc, lockedTarget);
    }

    private LivingEntity findTarget(MinecraftClient mc) {
        List<LivingEntity> candidates = mc.world.getEntitiesByClass(
                LivingEntity.class, mc.player.getBoundingBox().expand(range),
                e -> e != mc.player && e.isAlive() && !e.isSpectator()
                        && matchesTargetType(e) && withinFov(mc, e));
        return candidates.stream().min(Comparator.comparingDouble(mc.player::distanceTo)).orElse(null);
    }

    private boolean matchesTargetType(LivingEntity e) {
        return switch (targetType) {
            case "Players" -> e instanceof PlayerEntity;
            case "Entities" -> !(e instanceof PlayerEntity);
            default -> true;
        };
    }

    private boolean withinFov(MinecraftClient mc, LivingEntity target) {
        Vec3d look = mc.player.getRotationVec(1.0f).normalize();
        Vec3d to = target.getPos().add(0, target.getHeight() * 0.5, 0)
                .subtract(mc.player.getEyePos()).normalize();
        double angle = Math.toDegrees(Math.acos(MathHelper.clamp(look.dotProduct(to), -1.0, 1.0)));
        return angle <= fov * 0.5;
    }

    private boolean weaponFilterAllows(ItemStack stack) {
        return switch (weaponFilter) {
            case "Sword Only" -> stack.getItem() instanceof SwordItem;
            case "Weapon" -> stack.getItem() instanceof SwordItem || stack.getItem() instanceof AxeItem
                    || stack.getItem() instanceof TridentItem || stack.getItem() instanceof MaceItem;
            default -> true;
        };
    }

    private void rotateTo(MinecraftClient mc, LivingEntity target) {
        Vec3d diff = target.getPos().add(0, target.getHeight() * 0.5, 0).subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));
        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();

        double distanceFactor = MathHelper.clamp(1.0 - mc.player.distanceTo(target) / Math.max(range, 0.001), 0.7, 1.0);
        double speedFactor = (0.75 + speed * 1.10) * distanceFactor;
        float yawStep = (float) (yawDelta * (1.0 - Math.exp(-speedFactor)));
        float pitchStep = (float) (pitchDelta * (1.0 - Math.exp(-speedFactor)));

        if (Math.abs(yawDelta) > 8.0f) yawStep *= 1.08f + ThreadLocalRandom.current().nextFloat() * 0.06f;
        if (Math.abs(yawDelta) < 1.5f) yawStep *= 0.7f;
        if (Math.abs(pitchDelta) < 0.8f) pitchStep = 0.0f;

        yawStep += (float) (ThreadLocalRandom.current().nextGaussian() * Math.max(Math.abs(yawStep), 0.01f) * 0.04);
        yawStep += (ThreadLocalRandom.current().nextDouble(-noise, noise) * 0.05);

        float variance = 0.97f + ThreadLocalRandom.current().nextFloat() * 0.06f;
        float yawCap = 55.0f * variance;
        float pitchCap = 32.0f * variance;
        if (Math.abs(yawDelta) > 90.0f) yawCap = 22.0f * variance;
        yawStep = MathHelper.clamp(yawStep, -yawCap, yawCap);
        pitchStep = MathHelper.clamp(pitchStep, -pitchCap, pitchCap);

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }
        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    private static String choice(String value, String... values) {
        for (String v : values) if (v.equals(value)) return value;
        return values[0];
    }

    public double speed() { return speed; }
    public void setSpeed(double v) { speed = MathHelper.clamp(v, 0.1, 1.0); persist(); }
    public double range() { return range; }
    public void setRange(double v) { range = MathHelper.clamp(v, 2.0, 12.0); persist(); }
    public double noise() { return noise; }
    public void setNoise(double v) { noise = MathHelper.clamp(v, 0.0, 2.0); persist(); }
    public double fov() { return fov; }
    public void setFov(double v) { fov = MathHelper.clamp(v, 30.0, 360.0); persist(); }
    public String targetType() { return targetType; }
    public void setTargetType(String v) { targetType = choice(v, "Players", "Entities", "Both"); persist(); }
    public String weaponFilter() { return weaponFilter; }
    public void setWeaponFilter(String v) { weaponFilter = choice(v, "Sword Only", "Weapon", "All Items"); persist(); }
}
