package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class AimAssist extends Module {
    private double speed = 0.75, range = 8.0, noise = 0.4;
    private double fov = 180.0;
    private String targetType = "Players", weaponFilter = "Sword Only";
    private UUID targetId;
    private long lastTargetSwitchMs;
    private boolean wasSwinging;
    public AimAssist() { super("aim_assist", "Aim Assist", Category.COMBAT, false); }
    @Override protected void loadSettings() {
        speed = clamp(R1zzConfig.getDouble("aim.speed", .75), .1, 1); range = clamp(R1zzConfig.getDouble("aim.range", 8), 3, 12);
        noise = clamp(R1zzConfig.getDouble("aim.noise", .4), 0, 2); fov = clamp(R1zzConfig.getDouble("aim.fov", 180), 30, 360);
        targetType = choice(R1zzConfig.get("aim.target_type", "Players"), "Players", "Entities", "Both");
        weaponFilter = choice(R1zzConfig.get("aim.weapon_filter", "Sword Only"), "Sword Only", "Weapon", "All Items");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("aim.speed", speed); R1zzConfig.put("aim.range", range); R1zzConfig.put("aim.noise", noise); R1zzConfig.put("aim.fov", fov);
        R1zzConfig.put("aim.target_type", targetType); R1zzConfig.put("aim.weapon_filter", weaponFilter);
    }
    @Override protected void resetSettings() { speed=.75; range=8; noise=.4; fov=180; targetType="Players"; weaponFilter="Sword Only"; targetId=null; }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        var self = mc.player;
        boolean swinging = self.handSwinging, justFinished = wasSwinging && !swinging; wasSwinging = swinging;
        if (swinging || justFinished || self.isUsingItem() || self.isBlocking() || !weaponAllowed(self.getMainHandStack().getItem())) return;
        LivingEntity target = chooseTarget(mc);
        if (target == null) { targetId = null; return; }
        long now = System.currentTimeMillis();
        if (targetId != null && !targetId.equals(target.getUuid()) && now - lastTargetSwitchMs < 300) {
            LivingEntity locked = findByUuid(mc, targetId);
            if (valid(mc, locked)) target = locked;
        }
        if (targetId == null || !targetId.equals(target.getUuid())) { targetId = target.getUuid(); lastTargetSwitchMs = now; }
        double distance = self.distanceTo(target);
        Vec3d point = target.getPos().add(target.getVelocity().multiply(2.5)).add(0, target.getHeight() * 0.5, 0);
        Vec3d diff = point.subtract(self.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float)(Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float)-Math.toDegrees(Math.atan2(diff.y, horizontal));
        float yawDelta = MathHelper.wrapDegrees(targetYaw - self.getYaw()), pitchDelta = targetPitch - self.getPitch();
        double distanceFactor = clamp(1.0 - distance / range, .4, 1.0), speedFactor = (.20 + speed * .70) * distanceFactor;
        double smooth = 1.0 - Math.exp(-speedFactor);
        float overshoot = Math.abs(yawDelta) > 12 ? (float)ThreadLocalRandom.current().nextDouble(.06,.10) : 0;
        float yawStep = (float)(yawDelta * (1 + overshoot) * smooth), pitchStep = (float)(pitchDelta * smooth);
        if (Math.abs(yawDelta) < 1.5) yawStep *= .5f;
        if (Math.abs(pitchDelta) < 1.5) pitchStep *= .5f;
        yawStep += (float)ThreadLocalRandom.current().nextDouble(-noise*.30, noise*.30);
        pitchStep += (float)ThreadLocalRandom.current().nextDouble(-noise*.30, noise*.30);
        float yawCap = (float)(32.0 * ThreadLocalRandom.current().nextDouble(.95,1.05));
        yawStep = Math.max(-yawCap, Math.min(yawCap, yawStep));
        if (Math.abs(yawDelta) > 90) yawStep = Math.copySign(Math.min(Math.abs(yawStep), Math.abs(yawDelta)/5f), yawStep);
        float pitchCap = (float)(16.0 * ThreadLocalRandom.current().nextDouble(.95,1.05));
        pitchStep = Math.max(-pitchCap, Math.min(pitchCap, pitchStep));
        float sensitivity = mc.options.getMouseSensitivity().getValue().floatValue(), f = sensitivity*.6f+.2f, gcd=f*f*f*1.2f;
        if (gcd > 0) { yawStep=Math.round(yawStep/gcd)*gcd; pitchStep=Math.round(pitchStep/gcd)*gcd; }
        self.setYaw(self.getYaw()+yawStep); self.setPitch(MathHelper.clamp(self.getPitch()+pitchStep,-90,90));
    }
    private LivingEntity chooseTarget(MinecraftClient mc) {
        if (targetType.equals("Players") || targetType.equals("Both")) {
            PlayerEntity p = mc.world.getPlayers().stream().filter(e -> e != mc.player).filter(e -> valid(mc,e)).min((a,b)->Double.compare(mc.player.distanceTo(a), mc.player.distanceTo(b))).orElse(null);
            if (p != null) return p;
        }
        if (targetType.equals("Entities") || targetType.equals("Both")) {
            return mc.world.getEntitiesByClass(LivingEntity.class, mc.player.getBoundingBox().expand(range), e -> !(e instanceof PlayerEntity) && valid(mc,e))
                    .stream().min((a,b)->Double.compare(mc.player.distanceTo(a),mc.player.distanceTo(b))).orElse(null);
        }
        return null;
    }
    private boolean valid(MinecraftClient mc, LivingEntity e) {
        if (e == null || !e.isAlive() || e == mc.player || e.isSpectator() || mc.player.distanceTo(e) > range || !mc.player.canSee(e)) return false;
        Vec3d to = e.getPos().add(0,e.getHeight()*.5,0).subtract(mc.player.getEyePos()).normalize();
        double angle = Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, mc.player.getRotationVec(1).normalize().dotProduct(to)))));
        return angle <= fov*.5;
    }
    private static LivingEntity findByUuid(MinecraftClient mc, UUID id) { return mc.world.getEntitiesByClass(LivingEntity.class, mc.player.getBoundingBox().expand(16), e -> e.getUuid().equals(id)).stream().findFirst().orElse(null); }
    private boolean weaponAllowed(Item item) {
        if (weaponFilter.equals("All Items")) return true;
        if (weaponFilter.equals("Sword Only")) return item instanceof SwordItem;
        return item instanceof SwordItem || item instanceof AxeItem || item instanceof TridentItem || item instanceof MaceItem;
    }
    private static String choice(String v,String... allowed) { for (String a:allowed) if(a.equals(v)) return v; return allowed[0]; }
    private static double clamp(double v,double min,double max) { return Math.max(min,Math.min(max,v)); }
    public double speed(){return speed;} public void setSpeed(double v){speed=clamp(v,.1,1);persist();}
    public double range(){return range;} public void setRange(double v){range=clamp(v,3,12);persist();}
    public double noise(){return noise;} public void setNoise(double v){noise=clamp(v,0,2);persist();}
    public double fov(){return fov;} public void setFov(double v){fov=clamp(v,30,360);persist();}
    public String targetType(){return targetType;} public void setTargetType(String v){targetType=choice(v,"Players","Entities","Both");persist();}
    public String weaponFilter(){return weaponFilter;} public void setWeaponFilter(String v){weaponFilter=choice(v,"Sword Only","Weapon","All Items");persist();}
}
