package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

public final class AimAssist extends Module {
    private double speed = 0.55;
    private double range = 24.0;
    private String targetType = "Players";
    private boolean weaponOnly = true;
    private LivingEntity lockedTarget;
    private boolean previousHandSwinging;
    private int swingSkipTicks;

    public AimAssist() {
        super("aim_assist", "AimAssist", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        speed = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.speed", 0.55), 0.1, 1.0);
        range = MathHelper.clamp(R1zzConfig.getDouble("aim_assist.range", 24.0), 3.0, 64.0);
        targetType = choice(R1zzConfig.get("aim_assist.target_type", "Players"));
        weaponOnly = R1zzConfig.getBoolean("aim_assist.weapon_only", true);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("aim_assist.speed", speed);
        R1zzConfig.put("aim_assist.range", range);
        R1zzConfig.put("aim_assist.target_type", targetType);
        R1zzConfig.put("aim_assist.weapon_only", weaponOnly);
    }

    @Override
    protected void resetSettings() {
        speed = 0.55;
        range = 24.0;
        targetType = "Players";
        weaponOnly = true;
        lockedTarget = null;
        swingSkipTicks = 0;
    }

    @Override
    public void onEnable() {
        lockedTarget = null;
        swingSkipTicks = 0;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.world != null) {
            previousHandSwinging = mc.player.handSwinging;
            acquireTarget(mc);
        }
    }

    @Override
    public void onDisable() {
        lockedTarget = null;
        swingSkipTicks = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player == null || mc.world == null) return;

        ItemStack mainHand = mc.player.getMainHandStack();
        Item mainItem = mainHand.getItem();
        boolean isWeapon = mainItem instanceof SwordItem
                || mainItem instanceof AxeItem
                || mainItem instanceof TridentItem
                || mainItem instanceof MaceItem;

        if (weaponOnly && !isWeapon) return;

        if (lockedTarget == null) {
            acquireTarget(mc);
        }

        if (lockedTarget == null) {
            previousHandSwinging = mc.player.handSwinging;
            return;
        }

        if (!lockedTarget.isAlive() || lockedTarget.isRemoved()) {
            lockedTarget = null;
            acquireTarget(mc);
            if (lockedTarget == null) {
                previousHandSwinging = mc.player.handSwinging;
                return;
            }
        }

        boolean justSwung = swingSkipTicks > 0;

        if (mc.player.handSwinging && !previousHandSwinging) {
            swingSkipTicks = 1;
        } else if (swingSkipTicks > 0) {
            swingSkipTicks--;
        }

        previousHandSwinging = mc.player.handSwinging;

        if (mc.player.isUsingItem() || mc.currentScreen != null || justSwung) return;

        Vec3d bodyCenter = lockedTarget.getPos().add(0.0, lockedTarget.getHeight() * 0.5, 0.0);
        Vec3d delta = bodyCenter.subtract(mc.player.getEyePos());
        double distance = mc.player.getEyePos().distanceTo(bodyCenter);

        if (distance > 100.0) return;

        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();

        double distanceFactor = MathHelper.clamp(1.0 - (distance / range), 0.75, 1.0);
        double speedFactor = (0.60 + speed * 1.00) * distanceFactor;
        double smoothing = 1.0 - Math.exp(-speedFactor);

        float yawStep = (float) (yawDelta * smoothing);
        float pitchStep = (float) (pitchDelta * smoothing * 0.6);

        if (Math.abs(yawDelta) < 0.5f) yawStep = 0.0f;
        if (Math.abs(pitchDelta) < 1.0f) pitchStep = 0.0f;

        if (Math.abs(yawDelta) < 6.0f) yawStep = yawDelta;

        if (Math.abs(yawDelta) > 8.0f) {
            yawStep *= (float) (1.10 + ThreadLocalRandom.current().nextDouble(0.0, 0.08));
        }

        if (Math.abs(yawDelta) < 1.5f) yawStep *= 0.95f;

        yawStep = MathHelper.clamp(yawStep, -50.0f, 50.0f);
        pitchStep = MathHelper.clamp(pitchStep, -30.0f, 30.0f);

        float sensitivity = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sensitivity * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;

        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    private void acquireTarget(MinecraftClient mc) {
        if (lockedTarget != null || mc.player == null || mc.world == null) return;

        lockedTarget = findTarget(mc, range);

        if (lockedTarget == null && range < 64.0) {
            lockedTarget = findTarget(mc, 64.0);
        }
    }

    private LivingEntity findTarget(MinecraftClient mc, double scanRange) {
        return mc.world.getEntitiesByClass(
                LivingEntity.class,
                mc.player.getBoundingBox().expand(scanRange),
                entity -> validTarget(mc, entity)
                        && mc.player.getPos().squaredDistanceTo(entity.getPos()) <= scanRange * scanRange
        ).stream().findFirst().orElse(null);
    }

    private boolean validTarget(MinecraftClient mc, LivingEntity entity) {
        if (entity == mc.player || !entity.isAlive() || entity.isRemoved() || entity.isSpectator()) return false;

        if (entity instanceof PlayerEntity) {
            return targetType.equals("Players") || targetType.equals("Both");
        }

        return targetType.equals("Entities") || targetType.equals("Both");
    }

    private static String choice(String value) {
        return value.equals("Players") || value.equals("Entities") || value.equals("Both")
                ? value : "Players";
    }

    public double speed() {
        return speed;
    }

    public void setSpeed(double value) {
        speed = MathHelper.clamp(value, 0.1, 1.0);
        persist();
    }

    public double range() {
        return range;
    }

    public void setRange(double value) {
        range = MathHelper.clamp(value, 3.0, 64.0);
        persist();
    }

    public String targetType() {
        return targetType;
    }

    public void setTargetType(String value) {
        if (value.equals("Players") || value.equals("Entities") || value.equals("Both")) {
            targetType = value;
            persist();
        }
    }

    public boolean weaponOnly() {
        return weaponOnly;
    }

    public void setWeaponOnly(boolean value) {
        weaponOnly = value;
        persist();
    }
}
