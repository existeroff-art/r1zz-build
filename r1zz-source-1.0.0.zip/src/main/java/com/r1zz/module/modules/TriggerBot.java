package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

public final class TriggerBot extends Module {
    private int delay = 100;
    private long since;
    public TriggerBot() { super("trigger_bot", "TriggerBot", Category.COMBAT, false); }
    @Override protected void loadSettings() { delay = Math.max(0, Math.min(500, R1zzConfig.getInt("trigger_bot.delay", 100))); }
    @Override protected void saveSettings() { R1zzConfig.put("trigger_bot.delay", delay); }
    @Override protected void resetSettings() { delay = 100; since = 0; }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null || !(mc.targetedEntity instanceof LivingEntity target) || !target.isAlive()) { since = 0; return; }
        if (mc.player.distanceTo(target) > mc.player.getBlockInteractionRange()) { since = 0; return; }
        if (since == 0) since = System.currentTimeMillis();
        if (System.currentTimeMillis() - since >= delay && mc.player.getAttackCooldownProgress(0.5f) >= 1.0f) {
            CombatModuleUtil.attack(mc, target); since = 0;
        }
    }
    public int delay() { return delay; }
    public void setDelay(int v) { delay = Math.max(0, Math.min(500, v)); persist(); }
}
