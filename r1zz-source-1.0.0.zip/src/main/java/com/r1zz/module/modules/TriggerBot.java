package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
public final class TriggerBot extends Module {
 private int delay=100; private long since;
 public TriggerBot(){super("trigger_bot","TriggerBot",Category.COMBAT,false);}
 protected void loadSettings(){delay=Math.max(0,Math.min(500,R1zzConfig.getInt("trigger_bot.delay",100)));}
 protected void saveSettings(){R1zzConfig.put("trigger_bot.delay",delay);}
 protected void resetSettings(){delay=100;}
 public void onTick(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null||mc.currentScreen!=null||mc.targetedEntity==null)return;if(mc.targetedEntity instanceof LivingEntity t&&t.isAlive()&&mc.player.distanceTo(t)<=mc.player.getBlockInteractionRange()){if(since==0)since=System.currentTimeMillis();if(System.currentTimeMillis()-since>=delay&&mc.player.getAttackCooldownProgress(0)>=.9f){CombatModuleUtil.attack(mc,t);since=0;}}else since=0;}
 public int delay(){return delay;}public void setDelay(int v){delay=Math.max(0,Math.min(500,v));persist();}
}