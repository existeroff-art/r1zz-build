package com.r1zz.module.modules;

import com.r1zz.module.Module;

public final class TriggerBot extends Module {
    public TriggerBot() {
        super("trigger_bot", "TriggerBot", Category.COMBAT, false);
    }

    @Override
    public void onTick() {
        return;
    }
}
