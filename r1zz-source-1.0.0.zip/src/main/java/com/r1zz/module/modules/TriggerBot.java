package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public final class TriggerBot extends Module {
    private String hitMode = "Prioritize crits";
    private String reachMode = "Default";
    private double missChance = 0.0;
    private boolean whenUseHand = false;
    private boolean simulateClicks = false;
    private boolean onlyWeapon = true;
    private boolean antiZombieBot = false;
    private boolean ignoreShield = false;
    private boolean focusMode = false;
    private long eligibleSince;
    private int delayMs = 80;

    public TriggerBot() {
        super("trigger_bot", "TriggerBot", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        hitMode = choice(R1zzConfig.get("trigger_bot.hit_mode", "Prioritize crits"),
                "Prioritize crits", "Prioritize damage", "Normal");
        reachMode = choice(R1zzConfig.get("trigger_bot.reach", "Default"),
                "Default", "3.0", "3.5", "4.0");
        missChance = Math.max(0.0, Math.min(50.0, R1zzConfig.getDouble("trigger_bot.miss_chance", 0.0)));
        whenUseHand = R1zzConfig.getBoolean("trigger_bot.when_use_hand", false);
        simulateClicks = R1zzConfig.getBoolean("trigger_bot.simulate_clicks", false);
        onlyWeapon = R1zzConfig.getBoolean("trigger_bot.only_weapon", true);
        antiZombieBot = R1zzConfig.getBoolean("trigger_bot.anti_zombie_bot", false);
        ignoreShield = R1zzConfig.getBoolean("trigger_bot.ignore_shield", false);
        focusMode = R1zzConfig.getBoolean("trigger_bot.focus_mode", false);
        delayMs = MathHelper.clamp(R1zzConfig.getInt("trigger_bot.delay", 80), 0, 500);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("trigger_bot.hit_mode", hitMode);
        R1zzConfig.put("trigger_bot.reach", reachMode);
        R1zzConfig.put("trigger_bot.miss_chance", missChance);
        R1zzConfig.put("trigger_bot.when_use_hand", whenUseHand);
        R1zzConfig.put("trigger_bot.simulate_clicks", simulateClicks);
        R1zzConfig.put("trigger_bot.only_weapon", onlyWeapon);
        R1zzConfig.put("trigger_bot.anti_zombie_bot", antiZombieBot);
        R1zzConfig.put("trigger_bot.ignore_shield", ignoreShield);
        R1zzConfig.put("trigger_bot.focus_mode", focusMode);
        R1zzConfig.put("trigger_bot.delay", delayMs);
    }

    @Override
    protected void resetSettings() {
        hitMode = "Prioritize crits";
        reachMode = "Default";
        missChance = 0.0;
        whenUseHand = false;
        simulateClicks = false;
        onlyWeapon = true;
        antiZombieBot = false;
        ignoreShield = false;
        focusMode = false;
        delayMs = 80;
        eligibleSince = 0L;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            eligibleSince = 0L;
            return;
        }

        if (whenUseHand && !mc.player.getMainHandStack().isEmpty()) {
            eligibleSince = 0L;
            return;
        }
        if (!whenUseHand && mc.player.isUsingItem()) {
            eligibleSince = 0L;
            return;
        }
        if (onlyWeapon && !isWeapon(mc.player.getMainHandStack().getItem())) {
            eligibleSince = 0L;
            return;
        }

        if (!(mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult hit)
                || !(hit.getEntity() instanceof LivingEntity target)
                || target == mc.player
                || !target.isAlive()) {
            eligibleSince = 0L;
            return;
        }

        double reach = reach();
        if (mc.player.distanceTo(target) > reach) {
            eligibleSince = 0L;
            return;
        }

        if (focusMode && !isCentered(mc, target)) {
            eligibleSince = 0L;
            return;
        }

        if (!ignoreShield && target instanceof PlayerEntity player && player.isBlocking()) {
            eligibleSince = 0L;
            return;
        }

        if (antiZombieBot && isZombieLike(target)) {
            eligibleSince = 0L;
            return;
        }

        if (!hitMode.equals("Prioritize damage") && !hitMode.equals("Normal")) {
            if (!(mc.player.fallDistance > 0.0f && !mc.player.isOnGround())) {
                eligibleSince = 0L;
                return;
            }
        }

        if (eligibleSince == 0L) eligibleSince = System.currentTimeMillis();
        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;
        if (System.currentTimeMillis() - eligibleSince < delayMs) return;
        if (ThreadLocalRandom.current().nextDouble(100.0) < missChance) {
            eligibleSince = System.currentTimeMillis();
            return;
        }

        // simulateClicks is retained as a client setting; both paths use the public attack API.
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        eligibleSince = 0L;
    }

    private boolean isWeapon(net.minecraft.item.Item item) {
        return item instanceof SwordItem || item instanceof AxeItem
                || item instanceof TridentItem || item instanceof MaceItem;
    }

    private boolean isZombieLike(LivingEntity entity) {
        String name = entity.getName().getString().toLowerCase(Locale.ROOT);
        return name.contains("zombie") || name.contains("husk")
                || name.contains("drowned") || name.contains("zombified");
    }

    private boolean isCentered(MinecraftClient mc, LivingEntity target) {
        double reach = reach();
        net.minecraft.util.math.Vec3d eye = mc.player.getEyePos();
        net.minecraft.util.math.Vec3d center = target.getPos()
                .add(0.0, target.getHeight() * 0.5, 0.0);
        double distance = eye.distanceTo(center);
        if (distance <= 0.0) return true;
        net.minecraft.util.math.Vec3d look = mc.player.getRotationVec(1.0f).normalize();
        net.minecraft.util.math.Vec3d to = center.subtract(eye).normalize();
        return look.dotProduct(to) >= Math.cos(Math.toRadians(Math.min(8.0, 4.0 + reach)));
    }

    private double reach() {
        return switch (reachMode) {
            case "3.0" -> 3.0;
            case "3.5" -> 3.5;
            case "4.0" -> 4.0;
            default -> 3.0;
        };
    }

    private static String choice(String value, String... values) {
        for (String v : values) if (v.equals(value)) return value;
        return values[0];
    }

    public String hitMode() { return hitMode; }
    public void setHitMode(String value) { hitMode = choice(value, "Prioritize crits", "Prioritize damage", "Normal"); persist(); }

    public String reachMode() { return reachMode; }
    public void setReachMode(String value) { reachMode = choice(value, "Default", "3.0", "3.5", "4.0"); persist(); }

    public double missChance() { return missChance; }
    public void setMissChance(double value) { missChance = MathHelper.clamp(value, 0.0, 50.0); persist(); }

    public boolean whenUseHand() { return whenUseHand; }
    public void setWhenUseHand(boolean value) { whenUseHand = value; persist(); }

    public boolean simulateClicks() { return simulateClicks; }
    public void setSimulateClicks(boolean value) { simulateClicks = value; persist(); }

    public boolean onlyWeapon() { return onlyWeapon; }
    public void setOnlyWeapon(boolean value) { onlyWeapon = value; persist(); }

    public boolean antiZombieBot() { return antiZombieBot; }
    public void setAntiZombieBot(boolean value) { antiZombieBot = value; persist(); }

    public boolean ignoreShield() { return ignoreShield; }
    public void setIgnoreShield(boolean value) { ignoreShield = value; persist(); }

    public boolean focusMode() { return focusMode; }
    public void setFocusMode(boolean value) { focusMode = value; persist(); }
    public int delay() { return delayMs; }
    public void setDelay(int value) { delayMs = MathHelper.clamp(value, 0, 500); persist(); }
}
