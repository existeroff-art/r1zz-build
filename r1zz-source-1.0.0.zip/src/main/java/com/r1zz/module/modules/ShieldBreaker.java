package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public final class ShieldBreaker extends Module {
    private enum State { IDLE, SWAPPED, ATTACKED, REVERTED, COOLDOWN }
    private State state = State.IDLE;
    private int savedSlot = -1;
    private int axeSlot = -1;
    private Entity lockedEntity;
    private long swapTick;
    private long lastFullCycleTime;
    private long cooldownUntil;
    private int cooldown = 300;

    public ShieldBreaker() { super("shield_breaker", "ShieldBreaker", Category.COMBAT, false); }

    @Override public void onEnable() {
        state = State.IDLE; savedSlot = -1; axeSlot = -1; lockedEntity = null;
        swapTick = 0L; lastFullCycleTime = 0L; cooldownUntil = 0L;
    }

    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && savedSlot >= 0 && savedSlot <= 8 && (state == State.SWAPPED || state == State.ATTACKED)) {
            mc.player.getInventory().selectedSlot = savedSlot;
        }
        state = State.IDLE; savedSlot = -1; axeSlot = -1; lockedEntity = null;
    }

    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!enabled() || mc.player == null || mc.world == null || mc.interactionManager == null) return;
        switch (state) {
            case IDLE -> handleIdle(mc);
            case SWAPPED -> handleSwapped(mc);
            case ATTACKED -> handleAttacked(mc);
            case REVERTED -> handleReverted();
            case COOLDOWN -> { if (System.currentTimeMillis() >= cooldownUntil) state = State.IDLE; }
        }
    }

    private void handleIdle(MinecraftClient mc) {
        if (System.currentTimeMillis() < cooldownUntil) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity entity = hit.getEntity();
        if (!(entity instanceof LivingEntity target) || !isShielding(target)) return;
        lockedEntity = target;
        if (mc.player.getMainHandStack().getItem() instanceof AxeItem) {
            savedSlot = mc.player.getInventory().selectedSlot;
            attackTarget(mc, target);
            return;
        }
        int foundAxeSlot = findAxeSlot(mc);
        if (foundAxeSlot < 0) { lockedEntity = null; return; }
        savedSlot = mc.player.getInventory().selectedSlot;
        axeSlot = foundAxeSlot;
        mc.player.getInventory().selectedSlot = axeSlot;
        swapTick = System.currentTimeMillis();
        state = State.SWAPPED;
    }

    private void handleSwapped(MinecraftClient mc) {
        if (System.currentTimeMillis() <= swapTick) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)
                || hit.getEntity() != lockedEntity
                || !(hit.getEntity() instanceof LivingEntity target)
                || !isShielding(target)) {
            restoreSlot(mc);
            state = State.REVERTED;
            lastFullCycleTime = System.currentTimeMillis();
            return;
        }
        if (!(mc.player.getMainHandStack().getItem() instanceof AxeItem)) return;
        attackTarget(mc, target);
    }

    private void attackTarget(MinecraftClient mc, LivingEntity target) {
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        state = State.ATTACKED;
    }

    private void handleAttacked(MinecraftClient mc) {
        restoreSlot(mc);
        state = State.REVERTED;
        lastFullCycleTime = System.currentTimeMillis();
    }

    private void handleReverted() {
        cooldownUntil = lastFullCycleTime + cooldown;
        lockedEntity = null;
        state = State.COOLDOWN;
    }

    private boolean isShielding(LivingEntity target) {
        return target.isAlive() && !target.isRemoved() && target.isUsingItem()
                && target.getActiveItem().getItem() == Items.SHIELD;
    }

    private void restoreSlot(MinecraftClient mc) {
        if (savedSlot >= 0 && savedSlot <= 8) mc.player.getInventory().selectedSlot = savedSlot;
        savedSlot = -1; axeSlot = -1;
    }

    private int findAxeSlot(MinecraftClient mc) {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.getItem() instanceof AxeItem) return slot;
        }
        return -1;
    }

    public int cooldown() { return cooldown; }
    public void setCooldown(int cooldown) { this.cooldown = Math.max(0, Math.min(500, cooldown)); }
}
