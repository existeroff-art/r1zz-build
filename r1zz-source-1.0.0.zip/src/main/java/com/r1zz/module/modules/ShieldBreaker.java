package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

public final class ShieldBreaker extends Module {
    private int savedSlot = -1;
    private boolean swappedLastTick;

    public ShieldBreaker() {
        super("shield_breaker", "ShieldBreaker", Category.COMBAT, false);
    }

    @Override
    public void onEnable() {
        savedSlot = -1;
        swappedLastTick = false;
    }

    @Override
    public void onDisable() {
        if (swappedLastTick) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null && savedSlot >= 0 && savedSlot <= 8) {
                mc.player.getInventory().selectedSlot = savedSlot;
            }
        }
        savedSlot = -1;
        swappedLastTick = false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player == null || mc.world == null) return;
        if (!enabled()) return;

        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof LivingEntity target)) return;
        if (!target.isUsingItem()) return;
        if (!target.getActiveItem().isOf(Items.SHIELD)) return;

        if (swappedLastTick) {
            mc.player.getInventory().selectedSlot = savedSlot;
            swappedLastTick = false;
            savedSlot = -1;
            return;
        }

        PlayerInventory inventory = mc.player.getInventory();
        int axeSlot = findAxe(inventory);

        if (axeSlot < 0) return;

        savedSlot = inventory.selectedSlot;
        inventory.selectedSlot = axeSlot;
        swappedLastTick = true;
    }

    private int findAxe(PlayerInventory inventory) {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = inventory.getStack(slot);
            if (stack.getItem() instanceof AxeItem) {
                return slot;
            }
        }
        return -1;
    }
}
