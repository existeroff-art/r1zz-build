package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

public final class ShieldBreaker extends Module {
    private enum State { IDLE, SWAPPING, REVERTING }

    private State state = State.IDLE;
    private int savedSlot = -1;
    private int axeSlot = -1;
    private long lastSwapTime;
    private int axeHoldTicks;
    private long cooldownUntil;

    public ShieldBreaker() {
        super("shield_breaker", "ShieldBreaker", Category.COMBAT, false);
    }

    @Override
    public void onEnable() {
        state = State.IDLE;
        savedSlot = -1;
        axeSlot = -1;
        axeHoldTicks = 0;
        cooldownUntil = 0L;
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && state == State.REVERTING && savedSlot >= 0 && savedSlot <= 8) {
            mc.player.getInventory().selectedSlot = savedSlot;
        }
        state = State.IDLE;
        savedSlot = -1;
        axeSlot = -1;
        axeHoldTicks = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!enabled() || mc.player == null || mc.world == null) return;

        switch (state) {
            case IDLE -> handleIdle(mc);
            case SWAPPING -> handleSwapping(mc);
            case REVERTING -> handleReverting(mc);
        }
    }

    private void handleIdle(MinecraftClient mc) {
        if (System.currentTimeMillis() < cooldownUntil) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity entity = hit.getEntity();
        if (!(entity instanceof LivingEntity target)) return;
        if (!target.isUsingItem() || target.getActiveItem().getItem() != Items.SHIELD) return;

        int foundAxeSlot = findAxeSlot(mc);
        if (foundAxeSlot < 0) return;
        if (mc.player.getMainHandStack().getItem() instanceof AxeItem) return;

        savedSlot = mc.player.getInventory().selectedSlot;
        axeSlot = foundAxeSlot;
        axeHoldTicks = 0;
        lastSwapTime = System.currentTimeMillis();
        mc.player.getInventory().selectedSlot = axeSlot;
        state = State.SWAPPING;
    }

    private void handleSwapping(MinecraftClient mc) {
        if (System.currentTimeMillis() - lastSwapTime >= 500L) {
            state = State.IDLE;
            savedSlot = -1;
            axeSlot = -1;
            axeHoldTicks = 0;
            return;
        }
        if (!(mc.player.getMainHandStack().getItem() instanceof AxeItem)) return;
        axeHoldTicks++;
        if (axeHoldTicks >= 1) state = State.REVERTING;
    }

    private void handleReverting(MinecraftClient mc) {
        if (savedSlot >= 0 && savedSlot <= 8) mc.player.getInventory().selectedSlot = savedSlot;
        state = State.IDLE;
        savedSlot = -1;
        axeSlot = -1;
        axeHoldTicks = 0;
        cooldownUntil = System.currentTimeMillis() + 300L;
    }

    private int findAxeSlot(MinecraftClient mc) {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.getItem() instanceof AxeItem) return slot;
        }
        return -1;
    }
}
