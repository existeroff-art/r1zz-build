package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

/** Swaps to a hotbar axe when the crosshair is on a shield-blocking entity. */
public final class ShieldBreaker extends Module {
    private int cooldown = 150;
    private int savedSlot = -1;
    private boolean pendingRevert;
    private long lastSwapTime;

    public ShieldBreaker() {
        super("shield_breaker", "ShieldBreaker", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        cooldown = clampCooldown(R1zzConfig.getInt("shield_breaker.cooldown", 150));
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("shield_breaker.cooldown", cooldown);
    }

    @Override
    protected void resetSettings() {
        cooldown = 150;
        savedSlot = -1;
        pendingRevert = false;
        lastSwapTime = 0L;
    }

    @Override
    public void onEnable() {
        savedSlot = -1;
        pendingRevert = false;
        lastSwapTime = 0L;
    }

    @Override
    public void onDisable() {
        revertIfNeeded();
        savedSlot = -1;
        pendingRevert = false;
    }

    @Override
    public void onTick() {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) {
                return;
            }

            if (pendingRevert) {
                revertIfNeeded();
                pendingRevert = false;
                return;
            }

            if (System.currentTimeMillis() - lastSwapTime <= cooldown) {
                return;
            }

            if (!(mc.crosshairTarget instanceof EntityHitResult hit)) {
                return;
            }

            if (!(hit.getEntity() instanceof LivingEntity target)) {
                return;
            }

            if (!target.isUsingItem() || !target.getActiveItem().isOf(Items.SHIELD)) {
                return;
            }

            int axeSlot = findAxe(mc);
            if (axeSlot < 0 || axeSlot == mc.player.getInventory().selectedSlot) {
                return;
            }

            savedSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = axeSlot;
            lastSwapTime = System.currentTimeMillis();
            pendingRevert = true;
        } catch (Throwable ignored) {
            savedSlot = -1;
            pendingRevert = false;
        }
    }

    private int findAxe(MinecraftClient mc) {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.getItem() instanceof AxeItem) {
                return slot;
            }
        }
        return -1;
    }

    private void revertIfNeeded() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || savedSlot < 0 || savedSlot > 8) {
            return;
        }

        mc.player.getInventory().selectedSlot = savedSlot;
        savedSlot = -1;
    }

    private static int clampCooldown(int value) {
        return Math.max(0, Math.min(500, value));
    }

    public int cooldown() {
        return cooldown;
    }

    public void setCooldown(int value) {
        cooldown = clampCooldown(value);
        persist();
    }
}
