package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.AxeItem;
public final class ShieldBreaker extends Module {
 private int cooldown=150, oldSlot=-1, restoreTicks;
 private long lastBreak;
 public ShieldBreaker(){super("shield_breaker","Shield Breaker",Category.COMBAT,false);}
 protected void loadSettings(){cooldown=Math.max(0,Math.min(500,R1zzConfig.getInt("shield_breaker.cooldown",150)));}
 protected void saveSettings(){R1zzConfig.put("shield_breaker.cooldown",cooldown);}
 protected void resetSettings(){cooldown=150;}
 public void onTick(){MinecraftClient mc=MinecraftClient.getInstance(); if(mc.player==null||mc.world==null)return;
  if(restoreTicks>0){if(--restoreTicks==0&&oldSlot>=0)CombatModuleUtil.select(mc.player,oldSlot);return;}
  LivingEntity t=CombatModuleUtil.nearest(mc,4.5,true);
  if(t instanceof net.minecraft.entity.player.PlayerEntity p && p.isBlocking() && mc.player.getAttackCooldownProgress(0)>=.9f){
   int axe=-1; for(int i=0;i<9;i++)if(mc.player.getInventory().getStack(i).getItem() instanceof AxeItem){axe=i;break;}
   if(axe>=0&&System.currentTimeMillis()-lastBreak>=cooldown){lastBreak=System.currentTimeMillis();oldSlot=mc.player.getInventory().selectedSlot;CombatModuleUtil.select(mc.player,axe);CombatModuleUtil.attack(mc,t);restoreTicks=1;}
  }}
 public int cooldown(){return cooldown;} public void setCooldown(int v){cooldown=Math.max(0,Math.min(500,v));persist();}
}