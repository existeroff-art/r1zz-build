package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoFish extends Module {
    public AutoFish() { super("auto_fish", "AutoFish", Category.WORLD, false); }
    private int delay = 100;
    @Override protected void loadSettings() {
        delay=R1zzConfig.getInt("auto_fish.delay",100);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("auto_fish.delay", delay);
    }
    @Override protected void resetSettings() {
        delay=100;
    }
    public int delay() { return delay; }
    public void setDelay(int v) { delay=Math.max(0,Math.min(1000,v)); persist(); }
}
