package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public final class AutoFish extends Module {
    public AutoFish() { super("auto_fish", "AutoFish", Category.WORLD, false); }
    private int delay = 100;
    private long reelAt;
    private long recastAt;
    @Override protected void loadSettings() {
        delay=R1zzConfig.getInt("auto_fish.delay",100);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("auto_fish.delay", delay);
    }
    @Override protected void resetSettings() {
        delay=100;
        reelAt=0;
        recastAt=0;
    }
    @Override public void onDisable() { reelAt = 0; recastAt = 0; }

    /** Reels in when the bobber is yanked under, then recasts after the delay. */
    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (!mc.player.getMainHandStack().isOf(Items.FISHING_ROD)) return;
        long now = System.currentTimeMillis();
        FishingBobberEntity hook = mc.player.fishHook;
        if (hook != null) {
            if (reelAt == 0 && hook.age > 20 && hook.isTouchingWater() && hook.getVelocity().y < -0.08) {
                reelAt = now + delay;
            }
            if (reelAt != 0 && now >= reelAt) {
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                reelAt = 0;
                recastAt = now + delay + 500L;
            }
        } else {
            reelAt = 0;
            if (recastAt != 0 && now >= recastAt) {
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                recastAt = 0;
            }
        }
    }

    public int delay() { return delay; }
    public void setDelay(int v) { delay=Math.max(0,Math.min(1000,v)); persist(); }
}
