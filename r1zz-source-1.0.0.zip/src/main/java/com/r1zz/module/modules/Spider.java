package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Climb walls by holding forward into them. */
public final class Spider extends Module {
    public Spider() { super("spider", "Spider", Category.MOVEMENT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || !p.horizontalCollision || p.input.movementForward <= 0.0f) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, 0.2, v.z);
        p.fallDistance = 0.0f;
    }
}
