package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Spider extends Module {
    public Spider() { super("spider", "Spider", Category.MOVEMENT, false); }
}
