package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;

public final class AutoClicker extends Module {
    private int cps=8; private boolean hold; private long last;
    public AutoClicker(){super("auto_clicker","AutoClicker",Category.COMBAT,false);}
    @Override protected void loadSettings(){cps=Math.max(1,Math.min(20,R1zzConfig.getInt("auto_clicker.cps",8)));hold=R1zzConfig.getBoolean("auto_clicker.hold",false);}
    @Override protected void saveSettings(){R1zzConfig.put("auto_clicker.cps",cps);R1zzConfig.put("auto_clicker.hold",hold);}
    @Override protected void resetSettings(){cps=8;hold=false;last=0;}
    @Override public void onTick(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null||mc.currentScreen!=null)return;if(hold&&!mc.options.attackKey.isPressed())return;if(!hold&&!mc.options.attackKey.isPressed())return;if(System.currentTimeMillis()-last>=1000L/cps){mc.doAttack();last=System.currentTimeMillis();}}
    public int cps(){return cps;}public void setCps(int v){cps=Math.max(1,Math.min(20,v));persist();}public boolean hold(){return hold;}public void setHold(boolean v){hold=v;persist();}
}
