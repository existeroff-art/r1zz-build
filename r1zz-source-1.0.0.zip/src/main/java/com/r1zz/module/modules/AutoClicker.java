package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public final class AutoClicker extends Module {
    private int cps=8; private boolean hold; private long last;
    public AutoClicker(){super("auto_clicker","AutoClicker",Category.COMBAT,false);}
    @Override protected void loadSettings(){cps=Math.max(1,Math.min(20,R1zzConfig.getInt("auto_clicker.cps",8)));hold=R1zzConfig.getBoolean("auto_clicker.hold",false);}
    @Override protected void saveSettings(){R1zzConfig.put("auto_clicker.cps",cps);R1zzConfig.put("auto_clicker.hold",hold);}
    @Override protected void resetSettings(){cps=8;hold=false;last=0;}
    private long nextDelay = 125L;
    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        try {
            if(mc.player==null||mc.currentScreen!=null||mc.interactionManager==null||mc.options==null)return;
            if(mc.player.isUsingItem())return;
            if(hold&&!mc.options.attackKey.isPressed())return;
            long now=System.currentTimeMillis();
            if(now-last<nextDelay)return;
            last=now;
            nextDelay=Humanizer.jitter(1000L/cps,0.3);
            if(Humanizer.chance(0.05))return; // humans drop clicks
            if(mc.crosshairTarget instanceof EntityHitResult hit&&hit.getEntity() instanceof LivingEntity target&&target!=mc.player){
                if(mc.player.getAttackCooldownProgress(0.5f)<0.9f)return;
                mc.interactionManager.attackEntity(mc.player,target);
            }
            mc.player.swingHand(Hand.MAIN_HAND);
        } catch (RuntimeException ignored) { }
    }
    public int cps(){return cps;}public void setCps(int v){cps=Math.max(1,Math.min(20,v));persist();}public boolean hold(){return hold;}public void setHold(boolean v){hold=v;persist();}
}
