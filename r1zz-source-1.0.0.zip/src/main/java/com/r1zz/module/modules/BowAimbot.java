package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

/** While drawing a bow, aims at the nearest player with velocity lead and gravity drop compensation. */
public final class BowAimbot extends Module {
    private double range = 20;

    public BowAimbot() { super("bow_aimbot", "Bow Aimbot", Category.COMBAT, false); }

    @Override protected void loadSettings() { range = Math.max(5, Math.min(50, R1zzConfig.getDouble("bow_aimbot.range", 20))); }
    @Override protected void saveSettings() { R1zzConfig.put("bow_aimbot.range", range); }
    @Override protected void resetSettings() { range = 20; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (!mc.player.isUsingItem() || !mc.player.getActiveItem().isOf(Items.BOW)) return;
        LivingEntity target = CombatModuleUtil.nearest(mc, range, true);
        if (target == null || !mc.player.canSee(target)) return;

        float pull = Math.min(mc.player.getItemUseTime(), 20) / 20.0f;
        float power = (pull * pull + pull * 2.0f) / 3.0f;
        double arrowSpeed = Math.max(0.5, power * 3.0);
        double distance = mc.player.distanceTo(target);
        double flightTicks = distance / arrowSpeed;
        Vec3d velocity = target.getVelocity();
        Vec3d aim = target.getPos()
                .add(0.0, target.getHeight() * 0.65, 0.0)
                .add(velocity.x * flightTicks, 0.0, velocity.z * flightTicks)
                .add(0.0, 0.5 * 0.05 * flightTicks * flightTicks, 0.0);
        CombatModuleUtil.rotateToward(mc, aim, 0.6f, 40.0f, 25.0f);
    }

    public double range() { return range; }
    public void setRange(double v) { range = Math.max(5, Math.min(50, v)); persist(); }
}
