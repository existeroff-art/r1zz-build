package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
public final class BowAimbot extends Module {
 private double range=20;
 public BowAimbot(){super("bow_aimbot","Bow Aimbot",Category.COMBAT,false);}
 protected void loadSettings(){range=Math.max(5,Math.min(50,R1zzConfig.getDouble("bow_aimbot.range",20)));}
 protected void saveSettings(){R1zzConfig.put("bow_aimbot.range",range);}
 protected void resetSettings(){range=20;}
 public double range(){return range;}public void setRange(double v){range=Math.max(5,Math.min(50,v));persist();}
}