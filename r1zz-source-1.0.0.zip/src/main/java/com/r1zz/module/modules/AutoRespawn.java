package com.r1zz.module.modules;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
public final class AutoRespawn extends Module {
    public AutoRespawn(){super("auto_respawn","AutoRespawn",Category.PLAYER,false);}
    @Override public void onTick(){var p=MinecraftClient.getInstance().player;if(p!=null&&p.isDead())p.requestRespawn();}
}
