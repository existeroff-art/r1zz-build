package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;

public final class AutoRespawn extends Module {
    private int delay;
    private int wait=-1;
    public AutoRespawn(){super("auto_respawn","AutoRespawn",Category.PLAYER,false);}
    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null)return;
        if(mc.player.isDead()){
            if(wait<0)wait=Humanizer.ticks(8,22);
            if(delay<wait){delay++;return;}
            mc.player.requestRespawn();delay=0;wait=-1;
        }else{delay=0;wait=-1;}
    }
}
