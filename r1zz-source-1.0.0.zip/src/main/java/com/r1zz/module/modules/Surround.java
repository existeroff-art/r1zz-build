package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Keeps the four blocks around your feet filled (obsidian first, otherwise any solid block). */
public final class Surround extends Module {
    private int cooldown;

    public Surround() { super("surround", "Surround", Category.COMBAT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        int slot = CombatModuleUtil.findPlaceSlot(mc);
        if (slot < 0) return;
        BlockPos feet = mc.player.getBlockPos();
        for (Direction d : Direction.Type.HORIZONTAL) {
            BlockPos pos = feet.offset(d);
            if (!mc.world.getBlockState(pos).isReplaceable()) continue;
            if (CombatModuleUtil.placeWithSlot(mc, pos, slot)) { cooldown = 1; return; }
        }
    }
}
