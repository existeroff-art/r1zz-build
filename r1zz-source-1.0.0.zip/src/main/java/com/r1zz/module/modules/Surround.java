package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class Surround extends Module { public Surround(){super("surround","Surround",Category.COMBAT,false);} }