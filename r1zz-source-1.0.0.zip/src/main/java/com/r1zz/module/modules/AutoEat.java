package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoEat extends Module {
    public AutoEat() { super("auto_eat", "AutoEat", Category.PLAYER, false); }
}
