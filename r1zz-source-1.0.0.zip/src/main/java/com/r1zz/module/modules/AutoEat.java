package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Eats the best food from the hotbar when hunger drops, then swaps back. */
public final class AutoEat extends Module {
    private static final int HUNGER_THRESHOLD = 14;
    private final HoldUse holdUse = new HoldUse();

    public AutoEat() { super("auto_eat", "AutoEat", Category.PLAYER, false); }

    @Override
    public void onDisable() { holdUse.end(MinecraftClient.getInstance()); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options == null) return;
        if (holdUse.tick(mc)) return;
        if (mc.currentScreen != null || mc.player.isUsingItem()) return;
        if (mc.player.getHungerManager().getFoodLevel() > HUNGER_THRESHOLD) return;
        int normal = -1, golden = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty() || !stack.contains(DataComponentTypes.FOOD) || isBad(stack)) continue;
            if (stack.isOf(Items.GOLDEN_APPLE) || stack.isOf(Items.ENCHANTED_GOLDEN_APPLE)) { if (golden < 0) golden = i; }
            else if (normal < 0) normal = i;
        }
        int slot = normal >= 0 ? normal : golden;
        if (slot >= 0) holdUse.begin(mc, slot);
    }

    private static boolean isBad(ItemStack s) {
        return s.isOf(Items.ROTTEN_FLESH) || s.isOf(Items.SPIDER_EYE) || s.isOf(Items.POISONOUS_POTATO)
                || s.isOf(Items.PUFFERFISH) || s.isOf(Items.CHORUS_FRUIT) || s.isOf(Items.SUSPICIOUS_STEW);
    }
}
