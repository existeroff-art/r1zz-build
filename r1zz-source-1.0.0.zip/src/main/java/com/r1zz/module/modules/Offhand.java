package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Keeps the selected item (Totem / Crystal / Gapple / Auto) in the offhand. */
public final class Offhand extends Module {
    private String item = "Totem";
    private long lastSwap;

    public Offhand() { super("offhand", "Offhand", Category.COMBAT, false); }

    protected void loadSettings() { item = choice(R1zzConfig.get("offhand.item", "Totem")); }
    protected void saveSettings() { R1zzConfig.put("offhand.item", item); }
    protected void resetSettings() { item = "Totem"; }
    private static String choice(String v) { return switch (v) { case "Crystal", "Gapple", "Auto" -> v; default -> "Totem"; }; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (System.currentTimeMillis() - lastSwap < 150L) return;

        Item[] wanted = switch (item) {
            case "Crystal" -> new Item[]{Items.END_CRYSTAL};
            case "Gapple" -> new Item[]{Items.ENCHANTED_GOLDEN_APPLE, Items.GOLDEN_APPLE};
            case "Auto" -> mc.player.getHealth() <= 10.0f
                    ? new Item[]{Items.TOTEM_OF_UNDYING, Items.ENCHANTED_GOLDEN_APPLE, Items.GOLDEN_APPLE}
                    : new Item[]{Items.END_CRYSTAL, Items.ENCHANTED_GOLDEN_APPLE, Items.GOLDEN_APPLE, Items.TOTEM_OF_UNDYING};
            default -> new Item[]{Items.TOTEM_OF_UNDYING};
        };
        for (Item w : wanted) if (mc.player.getOffHandStack().isOf(w)) return;

        for (Item w : wanted) {
            for (int i = 0; i < 36; i++) {
                if (!mc.player.getInventory().getStack(i).isOf(w)) continue;
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, CombatModuleUtil.screenSlot(i), 40, SlotActionType.SWAP, mc.player);
                lastSwap = System.currentTimeMillis();
                return;
            }
        }
    }

    public String item() { return item; }
    public void setItem(String v) { item = choice(v); persist(); }
}
