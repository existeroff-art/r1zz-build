package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
public final class Offhand extends Module {
 private String item="Totem";
 public Offhand(){super("offhand","Offhand",Category.COMBAT,false);}
 protected void loadSettings(){item=choice(R1zzConfig.get("offhand.item","Totem"));}
 protected void saveSettings(){R1zzConfig.put("offhand.item",item);}
 protected void resetSettings(){item="Totem";}
 private static String choice(String v){return switch(v){case "Crystal","Gapple","Auto"->v;default->"Totem";};}
 public String item(){return item;}public void setItem(String v){item=choice(v);persist();}
}