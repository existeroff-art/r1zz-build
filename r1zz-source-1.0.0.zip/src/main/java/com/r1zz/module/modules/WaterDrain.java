package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Comparator;

/**
 * Legit water drain: replaces nearby still-water SOURCE blocks (level 0) with the solid block in your hand.
 * Human-like timing: 150-250 ms reaction, 3-5 tick wind-up, 500-800 ms between placements,
 * yaw capped at 18 deg/tick and GCD-aligned, line-of-sight raycast, auto-switch off by default.
 */
public final class WaterDrain extends Module {
    private static final double MAX_REACH = 4.0;
    private static final float YAW_CAP = 18.0f;
    private static final float PITCH_CAP = 12.0f;

    private double range = 3.5;
    private int cooldown = 650;
    private boolean autoSwitch = false;
    private int reactionDelay = 200;

    private long lastPlacementTime;
    private long nextCooldown = 650L;
    private BlockPos observedSource;
    private long sourceSeenAt;
    private long sourceReaction;
    private BlockPos pendingSource;
    private int windupTicks;
    private int pendingAge;
    private int switchSlot = -1;
    private long switchRequestedAt;
    private int originalSlot = -1;
    private int switchedSlot = -1;
    private long revertAt;
    private float lastHealth = Float.NaN;
    private long lastDamageTime;

    public WaterDrain() {
        super("water_drain", "WaterDrain", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        range = MathHelper.clamp(R1zzConfig.getDouble("water_drain.range", 3.5), 1.0, 4.5);
        cooldown = MathHelper.clamp(R1zzConfig.getInt("water_drain.cooldown", 650), 500, 800);
        autoSwitch = R1zzConfig.getBoolean("water_drain.auto_switch", false);
        reactionDelay = MathHelper.clamp(R1zzConfig.getInt("water_drain.reaction_delay", 200), 150, 250);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("water_drain.range", range);
        R1zzConfig.put("water_drain.cooldown", cooldown);
        R1zzConfig.put("water_drain.auto_switch", autoSwitch);
        R1zzConfig.put("water_drain.reaction_delay", reactionDelay);
    }

    @Override
    protected void resetSettings() {
        range = 3.5;
        cooldown = 650;
        autoSwitch = false;
        reactionDelay = 200;
        clearAll();
        restoreSelectedSlot(MinecraftClient.getInstance());
    }

    @Override
    public void onEnable() {
        clearAll();
    }

    @Override
    public void onDisable() {
        clearAll();
        restoreSelectedSlot(MinecraftClient.getInstance());
    }

    private void clearAll() {
        clearObserved();
        clearPending();
        lastPlacementTime = 0L;
        lastHealth = Float.NaN;
        lastDamageTime = 0L;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

            long now = System.currentTimeMillis();
            trackDamage(mc, now);
            if (revertAt > 0L && now >= revertAt) restoreSelectedSlot(mc);

            if (pendingSource != null) {
                processPending(mc, now);
                return;
            }
            if (lastPlacementTime > 0L && now - lastPlacementTime < nextCooldown) return;

            BlockPos source = findSource(mc);
            if (source == null) {
                clearObserved();
                return;
            }
            if (!source.equals(observedSource)) {
                // First sight of this source: start the human reaction timer.
                observedSource = source.toImmutable();
                sourceSeenAt = now;
                sourceReaction = Humanizer.between(Math.max(150, reactionDelay - 50), Math.min(250, reactionDelay + 50));
                return;
            }
            if (now - sourceSeenAt < sourceReaction) return;
            if (!hasBlockInHand(mc) && !(autoSwitch && findSolidBlockSlot(mc) >= 0)) return;

            pendingSource = source.toImmutable();
            windupTicks = Humanizer.ticks(3, 5);
            pendingAge = 0;
            switchSlot = -1;
            switchRequestedAt = 0L;
        } catch (RuntimeException e) {
            clearPending();
        }
    }

    private void processPending(MinecraftClient mc, long now) {
        pendingAge++;
        if (!isWaterSource(mc, pendingSource)
                || mc.player.squaredDistanceTo(Vec3d.ofCenter(pendingSource)) > MAX_REACH * MAX_REACH
                || Math.abs(pendingSource.getY() - mc.player.getBlockPos().getY()) > 2
                || isUnderPlayer(mc, pendingSource)
                || !hasLineOfSight(mc, pendingSource)
                || pendingAge > 20) {
            clearPending();
            return;
        }
        if (!rotationAllowed(mc, now)) return;

        Vec3d aim = Vec3d.ofCenter(pendingSource);
        CombatModuleUtil.rotateToward(mc, aim, 0.45f, YAW_CAP, PITCH_CAP);
        if (windupTicks > 0) {
            windupTicks--;
            return;
        }
        if (angleTo(mc, aim) > 12.0) return;
        if (!prepareBlockSlot(mc, now)) return;

        if (placeSolidBlock(mc, pendingSource)) {
            lastPlacementTime = now;
            nextCooldown = Humanizer.between(Math.max(500, cooldown - 100), Math.min(800, cooldown + 100));
            clearObserved();
        }
        if (switchedSlot >= 0) revertAt = now + Humanizer.between(150, 260);
        clearPending();
    }

    private BlockPos findSource(MinecraftClient mc) {
        BlockPos origin = mc.player.getBlockPos();
        double reach = Math.min(range, MAX_REACH);
        int radius = (int) Math.ceil(reach);
        return BlockPos.stream(origin.add(-radius, -2, -radius), origin.add(radius, 2, radius))
                .map(BlockPos::toImmutable)
                .filter(pos -> mc.player.squaredDistanceTo(Vec3d.ofCenter(pos)) <= reach * reach)
                .filter(pos -> isWaterSource(mc, pos))
                .filter(pos -> !isUnderPlayer(mc, pos))
                .filter(pos -> hasLineOfSight(mc, pos))
                .min(Comparator.comparingDouble(pos -> mc.player.squaredDistanceTo(Vec3d.ofCenter(pos))))
                .orElse(null);
    }

    /** Water block with fluid level 0 = a source block (flowing water has level 1-8). */
    private boolean isWaterSource(MinecraftClient mc, BlockPos pos) {
        BlockState state = mc.world.getBlockState(pos);
        return state.isOf(Blocks.WATER) && state.get(FluidBlock.LEVEL) == 0;
    }

    private boolean isUnderPlayer(MinecraftClient mc, BlockPos source) {
        for (PlayerEntity player : mc.world.getPlayers()) {
            BlockPos feet = player.getBlockPos();
            if (feet.getX() == source.getX() && feet.getZ() == source.getZ() && feet.getY() == source.getY() + 1) return true;
        }
        return false;
    }

    private boolean hasBlockInHand(MinecraftClient mc) {
        return isSolidBlockStack(mc, mc.player.getMainHandStack());
    }

    private boolean prepareBlockSlot(MinecraftClient mc, long now) {
        int selected = mc.player.getInventory().selectedSlot;
        if (isSolidBlockStack(mc, mc.player.getInventory().getStack(selected))) return true;
        if (!autoSwitch) return false;

        int slot = findSolidBlockSlot(mc);
        if (slot < 0) return false;
        if (switchSlot != slot) {
            switchSlot = slot;
            switchRequestedAt = now;
            return false;
        }
        if (now - switchRequestedAt < Humanizer.between(90, 160)) return false;

        if (originalSlot < 0) originalSlot = selected;
        CombatModuleUtil.select(mc.player, slot);
        switchedSlot = slot;
        switchRequestedAt = 0L;
        return true;
    }

    private int findSolidBlockSlot(MinecraftClient mc) {
        for (int i = 0; i < 9; i++) {
            if (isSolidBlockStack(mc, mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    private boolean isSolidBlockStack(MinecraftClient mc, ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) return false;
        BlockState state = blockItem.getBlock().getDefaultState();
        return !state.isReplaceable() && state.isSolidBlock(mc.world, mc.player.getBlockPos());
    }

    private boolean placeSolidBlock(MinecraftClient mc, BlockPos source) {
        if (!(mc.player.getMainHandStack().getItem() instanceof BlockItem)) return false;
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(source).add(0.0, 0.5, 0.0), Direction.UP, source, false);
        ActionResult result = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        if (result.isAccepted()) {
            mc.player.swingHand(Hand.MAIN_HAND);
            return true;
        }
        return false;
    }

    /** Raycast eye -> block centre; water is ignored, any other block in between breaks line of sight. */
    private boolean hasLineOfSight(MinecraftClient mc, BlockPos target) {
        BlockHitResult hit = mc.world.raycast(new RaycastContext(
                mc.player.getEyePos(),
                Vec3d.ofCenter(target),
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                mc.player));
        return hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(target);
    }

    private double angleTo(MinecraftClient mc, Vec3d point) {
        Vec3d to = point.subtract(mc.player.getEyePos());
        if (to.lengthSquared() < 1.0e-8) return 0.0;
        double dot = MathHelper.clamp(mc.player.getRotationVec(1.0f).normalize().dotProduct(to.normalize()), -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot));
    }

    /** Never steal the view while fighting: sprinting, recently hurt, or aiming at another player. */
    private boolean rotationAllowed(MinecraftClient mc, long now) {
        if (mc.player.isSprinting() || now - lastDamageTime < 500L) return false;
        return !(mc.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof PlayerEntity
                && hit.getEntity() != mc.player);
    }

    private void trackDamage(MinecraftClient mc, long now) {
        float health = mc.player.getHealth();
        if (!Float.isNaN(lastHealth) && health < lastHealth) lastDamageTime = now;
        lastHealth = health;
    }

    private void restoreSelectedSlot(MinecraftClient mc) {
        if (mc != null && mc.player != null && originalSlot >= 0
                && mc.player.getInventory().selectedSlot == switchedSlot) {
            CombatModuleUtil.select(mc.player, originalSlot);
        }
        originalSlot = -1;
        switchedSlot = -1;
        revertAt = 0L;
        switchSlot = -1;
        switchRequestedAt = 0L;
    }

    private void clearObserved() {
        observedSource = null;
        sourceSeenAt = 0L;
        sourceReaction = 0L;
    }

    private void clearPending() {
        pendingSource = null;
        windupTicks = 0;
        pendingAge = 0;
        switchSlot = -1;
        switchRequestedAt = 0L;
    }

    public double range() { return range; }
    public void setRange(double value) { range = MathHelper.clamp(value, 1.0, 4.5); persist(); }
    public int cooldown() { return cooldown; }
    public void setCooldown(int value) { cooldown = MathHelper.clamp(value, 500, 800); persist(); }
    public boolean autoSwitch() { return autoSwitch; }
    public void setAutoSwitch(boolean value) { autoSwitch = value; persist(); }
    public int reactionDelay() { return reactionDelay; }
    public void setReactionDelay(int value) { reactionDelay = MathHelper.clamp(value, 150, 250); persist(); }
}
