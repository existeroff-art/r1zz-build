package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** Legit-style fluid drain: only reacts to recently observed source blocks. */
public final class WaterDrain extends Module {
    private double range = 4.0;
    private int cooldown = 400;
    private final Map<BlockPos, Long> recentSources = new HashMap<>();
    private BlockPos pendingSource;
    private int rotationDelay;
    private long lastDrain;

    public WaterDrain() { super("water_drain", "Water Drain", Category.COMBAT, false); }

    @Override protected void loadSettings() {
        range = MathHelper.clamp(R1zzConfig.getDouble("water_drain.range", 4.0), 1.0, 4.5);
        cooldown = MathHelper.clamp(R1zzConfig.getInt("water_drain.cooldown", 400), 100, 500);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("water_drain.range", range); R1zzConfig.put("water_drain.cooldown", cooldown);
    }
    @Override protected void resetSettings() { range = 4.0; cooldown = 400; recentSources.clear(); pendingSource = null; rotationDelay = 0; lastDrain = 0L; }
    @Override public void onDisable() { recentSources.clear(); pendingSource = null; rotationDelay = 0; }

    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<BlockPos, Long>> it = recentSources.entrySet().iterator();
        while (it.hasNext()) if (now - it.next().getValue() > 10_000L) it.remove();

        trackNearbyFluidUpdates(mc, now);
        if (pendingSource != null) {
            if (rotationDelay > 0) { rotationDelay--; rotateTo(mc, Vec3d.ofCenter(pendingSource)); return; }
            if (rotationDelay == 0) { placeSolidBlock(mc, pendingSource); pendingSource = null; rotationDelay = -1; return; }
        }
        if (now - lastDrain < cooldown) return;
        BlockPos source = findRecentSource(mc);
        if (source == null) return;
        BlockPos placement = source.up();
        if (!validPlacement(mc, placement) || mc.player.squaredDistanceTo(Vec3d.ofCenter(placement)) <= 1.0) return;
        pendingSource = placement;
        rotationDelay = 2;
    }

    private void trackNearbyFluidUpdates(MinecraftClient mc, long now) {
        BlockPos origin = mc.player.getBlockPos();
        int r = (int) Math.ceil(range);
        for (int x=-r;x<=r;x++) for (int y=-r;y<=r;y++) for (int z=-r;z<=r;z++) {
            BlockPos pos = origin.add(x,y,z);
            if (mc.player.squaredDistanceTo(Vec3d.ofCenter(pos)) > range * range) continue;
            BlockState state = mc.world.getBlockState(pos);
            if ((state.isOf(Blocks.WATER) || state.isOf(Blocks.LAVA)) && mc.world.getFluidState(pos).isStill()) recentSources.put(pos.toImmutable(), now);
        }
    }

    private BlockPos findRecentSource(MinecraftClient mc) {
        BlockPos best = null; double bestDist = Double.MAX_VALUE;
        for (BlockPos pos : recentSources.keySet()) {
            double d = mc.player.squaredDistanceTo(Vec3d.ofCenter(pos));
            if (d <= range * range && d < bestDist && mc.world.getFluidState(pos).isStill() && canSee(mc, pos)) { best=pos; bestDist=d; }
        }
        return best;
    }

    private boolean validPlacement(MinecraftClient mc, BlockPos pos) {
        BlockState state = mc.world.getBlockState(pos);
        if (!state.isAir() && !state.getFluidState().isEmpty()) return false;
        if (state.isReplaceable()) return false;
        if (!mc.world.getBlockState(pos.down()).isSolidBlock(mc.world, pos.down())) return false;
        return canSee(mc, pos);
    }

    private void placeSolidBlock(MinecraftClient mc, BlockPos pos) {
        int slot = -1;
        for (int i=0;i<9;i++) {
            ItemStack stack=mc.player.getInventory().getStack(i);
            if (stack.getItem() instanceof BlockItem bi && bi.getBlock().getDefaultState().isSolidBlock(mc.world,pos.down())) { slot=i; break; }
        }
        if (slot < 0) return;
        CombatModuleUtil.select(mc.player, slot);
        BlockPos below=pos.down();
        BlockHitResult hit=new BlockHitResult(Vec3d.ofCenter(below), Direction.UP, below, false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        lastDrain=System.currentTimeMillis();
    }

    private boolean canSee(MinecraftClient mc, BlockPos pos) {
        Vec3d start=mc.player.getEyePos(), end=Vec3d.ofCenter(pos);
        BlockHitResult hit=mc.world.raycast(new RaycastContext(start,end,RaycastContext.ShapeType.OUTLINE,RaycastContext.FluidHandling.NONE,mc.player));
        return hit.getType()==HitResult.Type.MISS || hit.getBlockPos().equals(pos);
    }

    private void rotateTo(MinecraftClient mc, Vec3d target) {
        Vec3d d=target.subtract(mc.player.getEyePos()); double h=Math.sqrt(d.x*d.x+d.z*d.z);
        float yaw=(float)(Math.toDegrees(Math.atan2(d.z,d.x))-90), pitch=(float)-Math.toDegrees(Math.atan2(d.y,h));
        float sens=mc.options.getMouseSensitivity().getValue().floatValue(), f=sens*.6f+.2f, gcd=f*f*f*1.2f;
        float ys=Math.round(MathHelper.wrapDegrees(yaw-mc.player.getYaw())/gcd)*gcd;
        float ps=Math.round((pitch-mc.player.getPitch())/gcd)*gcd;
        mc.player.setYaw(mc.player.getYaw()+MathHelper.clamp(ys,-30,30));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch()+MathHelper.clamp(ps,-30,30),-90,90));
    }

    public double range(){return range;} public void setRange(double value){range=MathHelper.clamp(value,1.0,4.5);persist();}
    public int cooldown(){return cooldown;} public void setCooldown(int value){cooldown=MathHelper.clamp(value,100,500);persist();}
}
