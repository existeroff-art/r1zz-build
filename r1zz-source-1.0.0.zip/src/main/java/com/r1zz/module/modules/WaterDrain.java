package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Comparator;

public final class WaterDrain extends Module {
    private double range=4.0; private int cooldown=400; private String target="Water"; private boolean autoSwitch=true;
    private long lastDrain; private BlockPos pending; private int rotationDelay;

    public WaterDrain(){super("water_drain","Water Drain",Category.COMBAT,false);}
    @Override protected void loadSettings(){range=MathHelper.clamp(R1zzConfig.getDouble("water_drain.range",4),1,5);cooldown=MathHelper.clamp(R1zzConfig.getInt("water_drain.cooldown",400),100,500);target=choice(R1zzConfig.get("water_drain.target","Water"),"Water","Lava","Both");autoSwitch=R1zzConfig.getBoolean("water_drain.auto_switch",true);}
    @Override protected void saveSettings(){R1zzConfig.put("water_drain.range",range);R1zzConfig.put("water_drain.cooldown",cooldown);R1zzConfig.put("water_drain.target",target);R1zzConfig.put("water_drain.auto_switch",autoSwitch);}
    @Override protected void resetSettings(){range=4;cooldown=400;target="Water";autoSwitch=true;lastDrain=0;pending=null;rotationDelay=0;}
    @Override public void onDisable(){pending=null;rotationDelay=0;}

    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.world==null||mc.interactionManager==null||mc.currentScreen!=null)return;
        if(pending!=null){
            rotateTo(mc,Vec3d.ofCenter(pending));
            if(rotationDelay>0){rotationDelay--;return;}
            place(mc,pending);pending=null;rotationDelay=-1;return;
        }
        long now=System.currentTimeMillis(); if(now-lastDrain<cooldown)return;
        BlockPos source=findSource(mc);
        if(source==null)return;
        BlockPos place=source.up();
        if(mc.player.squaredDistanceTo(Vec3d.ofCenter(place))<=1||!validPlacement(mc,place)||!canSee(mc,place))return;
        pending=place;rotationDelay=2;
    }

    private BlockPos findSource(MinecraftClient mc){
        BlockPos o=mc.player.getBlockPos(); int r=(int)Math.ceil(range);
        return net.minecraft.util.math.BlockPos.stream(o.add(-r,-r,-r),o.add(r,r,r)).map(BlockPos::toImmutable)
                .filter(p->mc.player.squaredDistanceTo(Vec3d.ofCenter(p))<=range*range)
                .filter(p->mc.world.getFluidState(p).isStill()).filter(p->matches(mc.world.getBlockState(p)))
                .filter(p->canSee(mc,p)).min(Comparator.comparingDouble(p->mc.player.squaredDistanceTo(Vec3d.ofCenter(p)))).orElse(null);
    }
    private boolean matches(BlockState s){boolean w=s.isOf(Blocks.WATER),l=s.isOf(Blocks.LAVA);return switch(target){case"Water"->w;case"Lava"->l;default->w||l;};}
    private boolean validPlacement(MinecraftClient mc,BlockPos p){BlockState s=mc.world.getBlockState(p);return s.isReplaceable()&&mc.world.getBlockState(p.down()).isSolidBlock(mc.world,p.down());}
    private void place(MinecraftClient mc,BlockPos p){
        int slot=-1;for(int i=0;i<9;i++){ItemStack st=mc.player.getInventory().getStack(i);if(st.getItem() instanceof BlockItem bi&&bi.getBlock().getDefaultState().isSolidBlock(mc.world,p)){slot=i;break;}}
        if(slot<0)return;if(!autoSwitch&&!mc.player.getMainHandStack().getItem().equals(mc.player.getInventory().getStack(slot).getItem()))return;
        if(autoSwitch)CombatModuleUtil.select(mc.player,slot);
        BlockPos below=p.down();mc.interactionManager.interactBlock(mc.player,Hand.MAIN_HAND,new BlockHitResult(Vec3d.ofCenter(below),Direction.UP,below,false));lastDrain=System.currentTimeMillis();
    }
    private boolean canSee(MinecraftClient mc,BlockPos p){BlockHitResult hit=mc.world.raycast(new RaycastContext(mc.player.getEyePos(),Vec3d.ofCenter(p),RaycastContext.ShapeType.OUTLINE,RaycastContext.FluidHandling.NONE,mc.player));return hit.getType()==HitResult.Type.MISS||hit.getBlockPos().equals(p);}
    private void rotateTo(MinecraftClient mc,Vec3d t){Vec3d d=t.subtract(mc.player.getEyePos());double h=Math.sqrt(d.x*d.x+d.z*d.z);float y=(float)(Math.toDegrees(Math.atan2(d.z,d.x))-90),p=(float)-Math.toDegrees(Math.atan2(d.y,h));float sens=mc.options.getMouseSensitivity().getValue().floatValue(),f=sens*.6f+.2f,gcd=f*f*f*1.2f;float ys=MathHelper.clamp(Math.round(MathHelper.wrapDegrees(y-mc.player.getYaw())/gcd)*gcd,-30,30),ps=MathHelper.clamp(Math.round((p-mc.player.getPitch())/gcd)*gcd,-30,30);mc.player.setYaw(mc.player.getYaw()+ys);mc.player.setPitch(MathHelper.clamp(mc.player.getPitch()+ps,-90,90));}
    private static String choice(String v,String...a){for(String s:a)if(s.equals(v))return v;return a[0];}
    public double range(){return range;} public void setRange(double v){range=MathHelper.clamp(v,1,5);persist();}
    public int cooldown(){return cooldown;} public void setCooldown(int v){cooldown=MathHelper.clamp(v,100,500);persist();}
    public String target(){return target;} public void setTarget(String v){target=choice(v,"Water","Lava","Both");persist();}
    public boolean autoSwitch(){return autoSwitch;} public void setAutoSwitch(boolean v){autoSwitch=v;persist();}
}
