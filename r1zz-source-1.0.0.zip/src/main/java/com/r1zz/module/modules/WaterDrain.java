package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Comparator;

public final class WaterDrain extends Module {
    private double range = 4.0;
    private int cooldown = 400;
    private String target = "Water";
    private boolean autoSwitch = true;

    private long lastDrainTime = 0L;
    private BlockPos pendingSource;
    private BlockPos pendingPlacement;
    private int placementDelayTicks;

    public WaterDrain() {
        super("water_drain", "WaterDrain", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        range = MathHelper.clamp(R1zzConfig.getDouble("water_drain.range", 4.0), 1.0, 5.0);
        cooldown = MathHelper.clamp(R1zzConfig.getInt("water_drain.cooldown", 400), 100, 500);
        target = choice(R1zzConfig.get("water_drain.target", "Water"), "Water", "Lava", "Both");
        autoSwitch = R1zzConfig.getBoolean("water_drain.auto_switch", true);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("water_drain.range", range);
        R1zzConfig.put("water_drain.cooldown", cooldown);
        R1zzConfig.put("water_drain.target", target);
        R1zzConfig.put("water_drain.auto_switch", autoSwitch);
    }

    @Override
    protected void resetSettings() {
        range = 4.0;
        cooldown = 400;
        target = "Water";
        autoSwitch = true;
        clearPending();
        lastDrainTime = 0L;
    }

    @Override
    public void onDisable() {
        clearPending();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        if (pendingPlacement != null && pendingSource != null) {
            if (!isSource(mc, pendingSource) || !isValidPlacement(mc, pendingPlacement)
                    || mc.player.squaredDistanceTo(Vec3d.ofCenter(pendingPlacement)) <= 1.0
                    || !hasLineOfSight(mc, pendingPlacement)) {
                clearPending();
                return;
            }

            rotateToward(mc, Vec3d.ofCenter(pendingPlacement));
            if (placementDelayTicks > 0) {
                placementDelayTicks--;
                return;
            }

            placeSolidBlock(mc, pendingSource, pendingPlacement);
            lastDrainTime = System.currentTimeMillis();
            clearPending();
            return;
        }

        if (System.currentTimeMillis() - lastDrainTime < cooldown) return;

        BlockPos source = findSource(mc);
        if (source == null) return;

        BlockPos placement = source.up();
        if (mc.player.squaredDistanceTo(Vec3d.ofCenter(placement)) <= 1.0) return;
        if (!isValidPlacement(mc, placement)) return;
        if (!hasLineOfSight(mc, placement)) return;
        if (findSolidBlockSlot(mc) < 0) return;

        pendingSource = source;
        pendingPlacement = placement;
        placementDelayTicks = 2;
    }

    private BlockPos findSource(MinecraftClient mc) {
        BlockPos origin = mc.player.getBlockPos();
        int r = (int) Math.ceil(range);
        return BlockPos.stream(
                        origin.add(-r, -r, -r),
                        origin.add(r, r, r))
                .map(BlockPos::toImmutable)
                .filter(pos -> mc.player.squaredDistanceTo(Vec3d.ofCenter(pos)) <= range * range)
                .filter(pos -> isSource(mc, pos))
                .filter(pos -> hasLineOfSight(mc, pos.up()))
                .min(Comparator.comparingDouble(pos -> mc.player.squaredDistanceTo(Vec3d.ofCenter(pos))))
                .orElse(null);
    }

    private boolean isSource(MinecraftClient mc, BlockPos pos) {
        BlockState state = mc.world.getBlockState(pos);
        boolean water = state.isOf(Blocks.WATER) && mc.world.getFluidState(pos).isStill();
        boolean lava = state.isOf(Blocks.LAVA) && mc.world.getFluidState(pos).isStill();
        return switch (target) {
            case "Water" -> water;
            case "Lava" -> lava;
            default -> water || lava;
        };
    }

    private boolean isValidPlacement(MinecraftClient mc, BlockPos placement) {
        BlockState targetState = mc.world.getBlockState(placement);
        return targetState.isReplaceable();
    }

    private boolean placeSolidBlock(MinecraftClient mc, BlockPos source, BlockPos placement) {
        int slot = findSolidBlockSlot(mc);
        if (slot < 0) return false;
        if (autoSwitch) CombatModuleUtil.select(mc.player, slot);

        ItemStack held = mc.player.getMainHandStack();
        if (!(held.getItem() instanceof BlockItem)) return false;

        // Click the top face of the source block with the solid block in the main hand.
        BlockHitResult hit = new BlockHitResult(
                Vec3d.ofCenter(source).add(0.0, 0.5, 0.0),
                Direction.UP,
                source,
                false
        );
        ActionResult result = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        if (result.isAccepted()) {
            mc.player.swingHand(Hand.MAIN_HAND);
            return true;
        }
        return false;
    }

    private int findSolidBlockSlot(MinecraftClient mc) {
        int selected = mc.player.getInventory().selectedSlot;
        if (isSolidBlockStack(mc, mc.player.getInventory().getStack(selected))) return selected;
        if (!autoSwitch) return -1;
        for (int i = 0; i < 9; i++) {
            if (isSolidBlockStack(mc, mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    private boolean isSolidBlockStack(MinecraftClient mc, ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) return false;
        BlockState state = blockItem.getBlock().getDefaultState();
        return !state.isReplaceable() && state.isSolidBlock(mc.world, mc.player.getBlockPos());
    }

    private boolean hasLineOfSight(MinecraftClient mc, BlockPos targetPos) {
        Vec3d start = mc.player.getEyePos();
        Vec3d end = Vec3d.ofCenter(targetPos);
        BlockHitResult hit = mc.world.raycast(new RaycastContext(
                start,
                end,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.ANY,
                mc.player
        ));
        return hit.getType() == HitResult.Type.MISS
                || hit.getBlockPos().equals(targetPos)
                || (pendingSource != null && hit.getBlockPos().equals(pendingSource));
    }

    private void rotateToward(MinecraftClient mc, Vec3d targetPos) {
        Vec3d diff = targetPos.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));
        float yawStep = MathHelper.clamp(MathHelper.wrapDegrees(targetYaw - mc.player.getYaw()), -30.0f, 30.0f);
        float pitchStep = MathHelper.clamp(targetPitch - mc.player.getPitch(), -30.0f, 30.0f);

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    private void clearPending() {
        pendingSource = null;
        pendingPlacement = null;
        placementDelayTicks = 0;
    }

    private static String choice(String value, String... values) {
        for (String v : values) if (v.equals(value)) return value;
        return values[0];
    }

    public double range() { return range; }
    public void setRange(double value) { range = MathHelper.clamp(value, 1.0, 5.0); persist(); }
    public int cooldown() { return cooldown; }
    public void setCooldown(int value) { cooldown = MathHelper.clamp(value, 100, 500); persist(); }
    public String target() { return target; }
    public void setTarget(String value) { target = choice(value, "Water", "Lava", "Both"); persist(); }
    public boolean autoSwitch() { return autoSwitch; }
    public void setAutoSwitch(boolean value) { autoSwitch = value; persist(); }
}
