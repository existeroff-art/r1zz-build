package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class WaterDrain extends Module {
    private double range = 4.5;
    private int cooldown = 200;
    private String target = "Water";
    private boolean autoSwitch = true;
    private long lastDrain;

    public WaterDrain() {
        super("water_drain", "Water Drain", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        range = Math.max(1.0, Math.min(5.0, R1zzConfig.getDouble("water_drain.range", 4.5)));
        cooldown = MathHelper.clamp(R1zzConfig.getInt("water_drain.cooldown", 200), 100, 500);
        target = R1zzConfig.get("water_drain.target", "Water");
        if (!target.equals("Water") && !target.equals("Lava") && !target.equals("Both")) target = "Water";
        autoSwitch = R1zzConfig.getBoolean("water_drain.auto_switch", true);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("water_drain.range", range);
        R1zzConfig.put("water_drain.cooldown", cooldown);
        R1zzConfig.put("water_drain.target", target);
        R1zzConfig.put("water_drain.auto_switch", autoSwitch);
    }

    @Override
    protected void resetSettings() {
        range = 4.5;
        cooldown = 200;
        target = "Water";
        autoSwitch = true;
        lastDrain = 0L;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (System.currentTimeMillis() - lastDrain < cooldown) return;

        int blockSlot = findSolidBlock(mc);
        if (blockSlot < 0) return;
        if (!autoSwitch && !(mc.player.getMainHandStack().getItem() instanceof BlockItem)) return;

        BlockPos source = findSource(mc);
        if (source == null) return;
        BlockPos above = source.up();
        if (!mc.world.getBlockState(above).isAir()) return;
        if (!mc.player.canSee(Vec3d.ofCenter(above))) return;

        if (autoSwitch) CombatModuleUtil.select(mc.player, blockSlot);
        float oldYaw = mc.player.getYaw();
        float oldPitch = mc.player.getPitch();
        rotateTo(mc, Vec3d.ofCenter(source));

        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(source).add(0, 0.5, 0), Direction.UP, source, false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        lastDrain = System.currentTimeMillis();

        // Keep the player's view close to its previous direction instead of snapping permanently.
        mc.player.setYaw(oldYaw);
        mc.player.setPitch(oldPitch);
    }

    private BlockPos findSource(MinecraftClient mc) {
        BlockPos origin = mc.player.getBlockPos();
        int radius = (int) Math.ceil(range);
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    BlockPos pos = origin.add(x, y, z);
                    double distance = mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos));
                    if (distance > range * range || distance >= bestDistance) continue;
                    boolean water = mc.world.getBlockState(pos).isOf(Blocks.WATER) && mc.world.getFluidState(pos).isStill();
                    boolean lava = mc.world.getBlockState(pos).isOf(Blocks.LAVA) && mc.world.getFluidState(pos).isStill();
                    if ((target.equals("Water") && !water) || (target.equals("Lava") && !lava) || (target.equals("Both") && !water && !lava)) continue;
                    if (!mc.player.canSee(Vec3d.ofCenter(pos))) continue;
                    best = pos;
                    bestDistance = distance;
                }
            }
        }
        return best;
    }

    private int findSolidBlock(MinecraftClient mc) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!(stack.getItem() instanceof BlockItem blockItem)) continue;
            if (blockItem.getBlock().getDefaultState().isSolidBlock(mc.world, mc.player.getBlockPos())) return i;
        }
        return -1;
    }

    private void rotateTo(MinecraftClient mc, Vec3d targetPos) {
        Vec3d diff = targetPos.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));
        float sens = (float) mc.options.getMouseSensitivity().getValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        float yawStep = Math.round(MathHelper.wrapDegrees(yaw - mc.player.getYaw()) / gcd) * gcd;
        float pitchStep = Math.round((pitch - mc.player.getPitch()) / gcd) * gcd;
        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(yawStep, -30.0f, 30.0f));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(pitchStep, -20.0f, 20.0f), -90.0f, 90.0f));
    }

    public double range() { return range; }
    public void setRange(double value) { range = Math.max(1.0, Math.min(5.0, value)); persist(); }
    public int cooldown() { return cooldown; }
    public void setCooldown(int value) { cooldown = MathHelper.clamp(value, 100, 500); persist(); }
    public String target() { return target; }
    public void setTarget(String value) { if (value.equals("Water") || value.equals("Lava") || value.equals("Both")) target = value; persist(); }
    public boolean autoSwitch() { return autoSwitch; }
    public void setAutoSwitch(boolean value) { autoSwitch = value; persist(); }
}
