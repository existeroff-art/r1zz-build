package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

import java.util.Locale;

/** Drops every inventory stack whose item id contains one of the comma separated names in the item list. */
public final class AutoDrop extends Module {
    private String itemList = "";
    private int cooldown;

    public AutoDrop() { super("auto_drop", "AutoDrop", Category.MISC, false); }

    @Override protected void loadSettings() { itemList = R1zzConfig.get("auto_drop.itemList", ""); }
    @Override protected void saveSettings() { R1zzConfig.put("auto_drop.itemList", itemList); }
    @Override protected void resetSettings() { itemList = ""; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null || itemList.isBlank()) return;
        if (cooldown > 0) { cooldown--; return; }
        String[] tokens = itemList.toLowerCase(Locale.ROOT).split(",");
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            String id = Registries.ITEM.getId(stack.getItem()).getPath();
            for (String raw : tokens) {
                String token = raw.trim().replace("minecraft:", "").replace(' ', '_');
                if (token.isEmpty() || !id.contains(token)) continue;
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, CombatModuleUtil.screenSlot(i), 1, SlotActionType.THROW, mc.player);
                cooldown = 2;
                return;
            }
        }
    }

    public String itemList() { return itemList; }
    public void setItemList(String v) { itemList = v == null ? "" : v; persist(); }
}
