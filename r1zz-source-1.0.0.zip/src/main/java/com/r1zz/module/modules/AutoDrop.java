package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoDrop extends Module {
    public AutoDrop() { super("auto_drop", "AutoDrop", Category.MISC, false); }
    private String itemList = "";
    @Override protected void loadSettings() {
        itemList=R1zzConfig.get("auto_drop.itemList","");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("auto_drop.itemList", itemList);
    }
    @Override protected void resetSettings() {
        itemList="";
    }
    public String itemList() { return itemList; }
    public void setItemList(String v) { itemList=v == null ? "" : v; persist(); }
}
