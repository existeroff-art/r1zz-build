package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class Tracers extends Module { public Tracers(){super("tracers","Tracers",Category.RENDER,false);} }
