package com.r1zz.module.modules;
import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;
public final class Tracers extends Module { public Tracers(){super("tracers","Tracers",Category.RENDER,false);}     @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
