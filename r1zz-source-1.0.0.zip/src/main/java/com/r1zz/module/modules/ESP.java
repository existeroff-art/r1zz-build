package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
public final class ESP extends Module {
    private String targets="Players";
    private boolean box=true,outline=false,fill=false,health=false;
    public ESP(){super("esp","ESP",Category.RENDER,false);}
    @Override protected void loadSettings(){targets=choice(R1zzConfig.get("esp.targets","Players"));box=R1zzConfig.getBoolean("esp.box",true);outline=R1zzConfig.getBoolean("esp.outline",false);fill=R1zzConfig.getBoolean("esp.fill",false);health=R1zzConfig.getBoolean("esp.health",false);}
    @Override protected void saveSettings(){R1zzConfig.put("esp.targets",targets);R1zzConfig.put("esp.box",box);R1zzConfig.put("esp.outline",outline);R1zzConfig.put("esp.fill",fill);R1zzConfig.put("esp.health",health);}
    @Override protected void resetSettings(){targets="Players";box=true;outline=false;fill=false;health=false;}
    public String targets(){return targets;} public void setTargets(String v){targets=choice(v);persist();}
    public boolean option(String id){return switch(id){case"box"->box;case"outline"->outline;case"fill"->fill;case"health"->health;default->false;};}
    public void setOption(String id,boolean v){switch(id){case"box"->box=v;case"outline"->outline=v;case"fill"->fill=v;case"health"->health=v;}persist();}
    private static String choice(String v){return v.equals("Mobs")||v.equals("Both")?v:"Players";}
}
