package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Waypoints extends Module {
    public Waypoints() { super("waypoints", "Waypoints", Category.RENDER, false); }
    private String points = "";
    @Override protected void loadSettings() {
        points=R1zzConfig.get("waypoints.points","");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("waypoints.points", points);
    }
    @Override protected void resetSettings() {
        points="";
    }
    public String points() { return points; }
    public void setPoints(String v) { points=v == null ? "" : v; persist(); }
}
