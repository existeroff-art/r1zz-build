package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;

/** Emergency golden apple: when health is low, swap to a gapple, eat it and swap back. */
public final class FastGap extends Module {
    private static final float LOW_HEALTH = 10.0f;
    private final HoldUse holdUse = new HoldUse();
    private long lastEat;

    public FastGap() { super("fast_gap", "FastGap", Category.COMBAT, false); }

    @Override
    public void onDisable() {
        holdUse.end(MinecraftClient.getInstance());
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options == null) return;
        if (holdUse.tick(mc)) return;
        if (mc.currentScreen != null || mc.player.isUsingItem()) return;
        if (mc.player.getHealth() > LOW_HEALTH || System.currentTimeMillis() - lastEat < 1500L) return;
        int slot = CombatModuleUtil.findHotbarAny(mc.player, Items.ENCHANTED_GOLDEN_APPLE, Items.GOLDEN_APPLE);
        if (slot < 0) return;
        holdUse.begin(mc, slot);
        lastEat = System.currentTimeMillis();
    }
}
