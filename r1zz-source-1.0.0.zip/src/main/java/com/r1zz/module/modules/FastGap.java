package com.r1zz.module.modules;

import com.r1zz.module.Module;

/**
 * Single toggle. All behaviour lives in GoldenAppleMixin, which shortens the golden-apple
 * consume time while this module is enabled. No auto-eating, no settings.
 */
public final class FastGap extends Module {
    public FastGap() {
        super("fast_gap", "FastGap", Category.COMBAT, false);
    }

    @Override
    public void onTick() {
        return;
    }
}
