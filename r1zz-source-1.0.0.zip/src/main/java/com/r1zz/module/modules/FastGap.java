package com.r1zz.module.modules;

import com.r1zz.module.Module;

public final class FastGap extends Module {
    public FastGap() { super("fast_gap", "FastGap", Category.COMBAT, false); }
    @Override public void onTick() { }
}
