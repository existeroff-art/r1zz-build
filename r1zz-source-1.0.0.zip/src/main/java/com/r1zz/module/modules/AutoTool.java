package com.r1zz.module.modules;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.hit.BlockHitResult;
public final class AutoTool extends Module {
    private int oldSlot=-1;
    public AutoTool(){super("auto_tool","AutoTool",Category.PLAYER,false);}
    @Override public void onTick(){var mc=MinecraftClient.getInstance();if(mc.player==null||mc.world==null||mc.interactionManager==null)return;if(mc.interactionManager.isBreakingBlock()&&mc.crosshairTarget instanceof BlockHitResult hit){if(oldSlot<0)oldSlot=mc.player.getInventory().selectedSlot;var state=mc.world.getBlockState(hit.getBlockPos());int best=mc.player.getInventory().selectedSlot;float speed=0;for(int i=0;i<9;i++){float s=mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(state);if(s>speed){speed=s;best=i;}}mc.player.getInventory().selectedSlot=best;}else if(oldSlot>=0){mc.player.getInventory().selectedSlot=oldSlot;oldSlot=-1;}}
    @Override public void onDisable(){var p=MinecraftClient.getInstance().player;if(p!=null&&oldSlot>=0)p.getInventory().selectedSlot=oldSlot;oldSlot=-1;}
}
