package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.block.BlockState;

public final class AutoTool extends Module {
    public AutoTool() { super("auto_tool", "AutoTool", Category.COMBAT, false); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.crosshairTarget == null) return;
        if (mc.crosshairTarget.getType() != net.minecraft.util.hit.HitResult.Type.BLOCK || !mc.options.attackKey.isPressed()) return;
        BlockState state = mc.world.getBlockState(((net.minecraft.util.hit.BlockHitResult) mc.crosshairTarget).getBlockPos());
        int best = CombatModuleUtil.bestToolSlot(mc.player, state);
        if (best != mc.player.getInventory().selectedSlot) CombatModuleUtil.select(mc.player, best);
    }
}
