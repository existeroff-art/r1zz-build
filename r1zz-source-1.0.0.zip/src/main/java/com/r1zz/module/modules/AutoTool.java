package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class AutoTool extends Module { public AutoTool(){super("auto_tool","AutoTool",Category.COMBAT,false);} }