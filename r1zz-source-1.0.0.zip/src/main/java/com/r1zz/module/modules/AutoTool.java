package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

/** Picks the fastest hotbar tool for the block you are mining, with a short human-like delay. */
public final class AutoTool extends Module {
    private BlockPos watching;
    private long since;
    private long reaction = 70L;

    public AutoTool() { super("auto_tool", "AutoTool", Category.COMBAT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.crosshairTarget == null || mc.options == null) return;
            if (mc.crosshairTarget.getType() != HitResult.Type.BLOCK || !mc.options.attackKey.isPressed()) { watching = null; return; }
            BlockPos pos = ((BlockHitResult) mc.crosshairTarget).getBlockPos();
            long now = System.currentTimeMillis();
            if (!pos.equals(watching)) { watching = pos.toImmutable(); since = now; reaction = Humanizer.between(40, 120); }
            if (now - since < reaction) return;
            BlockState state = mc.world.getBlockState(pos);
            int best = CombatModuleUtil.bestToolSlot(mc.player, state);
            if (best != mc.player.getInventory().selectedSlot) CombatModuleUtil.select(mc.player, best);
        } catch (RuntimeException ignored) { }
    }
}
