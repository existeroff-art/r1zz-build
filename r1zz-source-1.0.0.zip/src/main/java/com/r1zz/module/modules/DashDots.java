package com.r1zz.module.modules;
public final class DashDots extends VisualToggle { public DashDots() { super("dash_dots", "Dash Dots", false); } }
