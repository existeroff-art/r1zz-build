package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;

public final class R1zzAssist extends Module {
    private double range=3.5, speed=0.6;
    private String targetType="Players";
    private int delayMs=80;
    private LivingEntity lockedTarget;
    private long readySince;
    private boolean skipAfterSwing;

    public R1zzAssist(){super("r1zz_assist","R1zzAssist",Category.COMBAT,false);}

    @Override protected void loadSettings(){
        range=MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.range",3.5),2.5,6.0);
        speed=MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.speed",0.6),0.1,1.0);
        targetType=choice(R1zzConfig.get("r1zz_assist.target_type","Players"),"Players","Entities","Both");
        delayMs=MathHelper.clamp(R1zzConfig.getInt("r1zz_assist.delay",80),0,500);
    }
    @Override protected void saveSettings(){
        R1zzConfig.put("r1zz_assist.range",range);R1zzConfig.put("r1zz_assist.speed",speed);
        R1zzConfig.put("r1zz_assist.target_type",targetType);R1zzConfig.put("r1zz_assist.delay",delayMs);
    }
    @Override protected void resetSettings(){range=3.5;speed=.6;targetType="Players";delayMs=80;lockedTarget=null;readySince=0;skipAfterSwing=false;}
    @Override public void onEnable(){lockedTarget=null;readySince=0;skipAfterSwing=false;}
    @Override public void onDisable(){lockedTarget=null;readySince=0;skipAfterSwing=false;}

    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.world==null||mc.interactionManager==null){lockedTarget=null;return;}

        boolean swung=mc.player.handSwinging;
        if(skipAfterSwing){skipAfterSwing=false;return;}
        if(swung){skipAfterSwing=true;return;}

        if(lockedTarget!=null&&(!lockedTarget.isAlive()||lockedTarget.isRemoved()||mc.player.distanceTo(lockedTarget)>range)){
            lockedTarget=null;readySince=0;
        }
        if(lockedTarget==null){
            lockedTarget=findTarget(mc);
            readySince=0;
            if(lockedTarget==null)return;
        }

        if(mc.currentScreen!=null||mc.player.isUsingItem()||mc.player.isBlocking()
                ||mc.player.getOffHandStack().isOf(net.minecraft.item.Items.SHIELD)||!isWeapon(mc.player.getMainHandStack().getItem())){
            readySince=0;return;
        }

        boolean rotated=rotate(mc,lockedTarget);
        if(rotated)return;
        if(!mc.player.canSee(lockedTarget)){readySince=0;return;}

        if(mc.player.getAttackCooldownProgress(0.5f)<1.0f){readySince=0;return;}
        if(readySince==0)readySince=System.currentTimeMillis();
        if(System.currentTimeMillis()-readySince<delayMs)return;

        mc.interactionManager.attackEntity(mc.player,lockedTarget);
        mc.player.swingHand(Hand.MAIN_HAND);
        readySince=0;
        skipAfterSwing=true;
    }

    private LivingEntity findTarget(MinecraftClient mc){
        return mc.world.getEntitiesByClass(LivingEntity.class,mc.player.getBoundingBox().expand(range),
                e->e!=mc.player&&e.isAlive()&&!e.isSpectator()&&matchesType(e))
                .stream().min(Comparator.comparingDouble(mc.player::distanceTo)).orElse(null);
    }
    private boolean matchesType(LivingEntity e){
        return switch(targetType){case"Players"->e instanceof PlayerEntity;case"Entities"->!(e instanceof PlayerEntity);default->true;};
    }
    private boolean isWeapon(Item item){return item instanceof SwordItem||item instanceof AxeItem||item instanceof TridentItem||item instanceof MaceItem;}

    private boolean rotate(MinecraftClient mc,LivingEntity target){
        Vec3d d=target.getPos().add(0,target.getHeight()*.5,0).subtract(mc.player.getEyePos());
        double h=Math.sqrt(d.x*d.x+d.z*d.z);
        float ty=(float)(Math.toDegrees(Math.atan2(d.z,d.x))-90),tp=(float)-Math.toDegrees(Math.atan2(d.y,h));
        float yd=MathHelper.wrapDegrees(ty-mc.player.getYaw()),pd=tp-mc.player.getPitch();
        double df=MathHelper.clamp(1.0-mc.player.distanceTo(target)/Math.max(range,.001),.6,1.0);
        float factor=(float)((.35+speed*.55)*df);
        float ys=yd*(1.0f-(float)Math.exp(-factor)),ps=pd*(1.0f-(float)Math.exp(-factor));
        if(Math.abs(yd)>10)ys*=1.06f+ThreadLocalRandom.current().nextFloat()*.04f;
        if(Math.abs(yd)<1.5)ys*=.7f;
        if(Math.abs(pd)<.8)ps=0;
        float variance=.97f+ThreadLocalRandom.current().nextFloat()*.06f;
        float yawCap=28*variance,pitchCap=16*variance;
        if(Math.abs(yd)>90)yawCap=22*variance;
        ys=MathHelper.clamp(ys,-yawCap,yawCap);ps=MathHelper.clamp(ps,-pitchCap,pitchCap);
        float sens=mc.options.getMouseSensitivity().getValue().floatValue(),f=sens*.6f+.2f,gcd=f*f*f*1.2f;
        if(gcd>0){ys=Math.round(ys/gcd)*gcd;ps=Math.round(ps/gcd)*gcd;}
        if(Math.abs(ys)<.0001f&&Math.abs(ps)<.0001f)return false;
        mc.player.setYaw(mc.player.getYaw()+ys);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch()+ps,-90,90));
        return true;
    }

    private static String choice(String v,String...values){for(String s:values)if(s.equals(v))return v;return values[0];}
    public double range(){return range;} public void setRange(double v){range=MathHelper.clamp(v,2.5,6);persist();}
    public double speed(){return speed;} public void setSpeed(double v){speed=MathHelper.clamp(v,.1,1);persist();}
    public String targetType(){return targetType;} public void setTargetType(String v){targetType=choice(v,"Players","Entities","Both");persist();}
    public int delay(){return delayMs;} public void setDelay(int v){delayMs=MathHelper.clamp(v,0,500);persist();}
}
