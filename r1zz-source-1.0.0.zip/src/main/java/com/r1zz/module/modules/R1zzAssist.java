package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;

public final class R1zzAssist extends Module {
    private double range = 3.5;
    private double speed = 0.75;
    private String targetType = "Players";
    private int delayMs = 80;
    private double hitVerifyAngle = 15.0;
    private boolean humanClicks = true;
    private boolean microJitter = true;

    private LivingEntity lockedTarget;
    private boolean hasEverLocked;
    private long lastAttackTime = 0L;
    private long lockAcquiredTime = 0L;
    private boolean releaseAttackNextTick;

    public R1zzAssist() {
        super("r1zz_assist", "R1zzAssist", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        range = MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.range", 3.5), 2.5, 6.0);
        speed = MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.speed", 0.75), 0.1, 1.0);
        targetType = choice(R1zzConfig.get("r1zz_assist.target_type", "Players"), "Players", "Entities", "Both");
        delayMs = MathHelper.clamp(R1zzConfig.getInt("r1zz_assist.delay", 80), 0, 500);
        hitVerifyAngle = MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.hit_verify_angle", 15.0), 5.0, 30.0);
        humanClicks = R1zzConfig.getBoolean("r1zz_assist.human_clicks", true);
        microJitter = R1zzConfig.getBoolean("r1zz_assist.micro_jitter", true);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("r1zz_assist.range", range);
        R1zzConfig.put("r1zz_assist.speed", speed);
        R1zzConfig.put("r1zz_assist.target_type", targetType);
        R1zzConfig.put("r1zz_assist.delay", delayMs);
        R1zzConfig.put("r1zz_assist.hit_verify_angle", hitVerifyAngle);
        R1zzConfig.put("r1zz_assist.human_clicks", humanClicks);
        R1zzConfig.put("r1zz_assist.micro_jitter", microJitter);
    }

    @Override
    protected void resetSettings() {
        range = 3.5;
        speed = 0.75;
        targetType = "Players";
        delayMs = 80;
        hitVerifyAngle = 15.0;
        humanClicks = true;
        microJitter = true;
        clearState();
    }

    @Override
    public void onEnable() {
        clearState();
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) mc.options.attackKey.setPressed(false);
        clearState();
    }

    private void clearState() {
        lockedTarget = null;
        hasEverLocked = false;
        lastAttackTime = 0L;
        lockAcquiredTime = 0L;
        releaseAttackNextTick = false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.options != null && releaseAttackNextTick) {
            mc.options.attackKey.setPressed(false);
            releaseAttackNextTick = false;
        }

        if (!enabled()) {
            lockedTarget = null;
            hasEverLocked = false;
            return;
        }
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        // TRUE sticky lock: validate the current lock; once it is gone, stay idle.
        // A new target is only ever acquired once per enable cycle (hasEverLocked).
        if (lockedTarget != null && !lockStillValid(mc, lockedTarget)) {
            lockedTarget = null;
            lockAcquiredTime = 0L;
        }
        if (lockedTarget == null && !hasEverLocked) {
            acquireTarget(mc);
            if (lockedTarget != null) hasEverLocked = true;
        }
        if (lockedTarget == null) return;

        if (mc.player.isUsingItem() || mc.currentScreen != null) return;
        if (!isWeapon(mc.player.getMainHandStack().getItem())) return;

        LivingEntity target = lockedTarget;
        rotate(mc, target);

        LivingEntity candidate = null;
        if (mc.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() == target
                && hit.getEntity() instanceof LivingEntity living) {
            candidate = living;
        } else if (angleToTarget(mc, target) <= hitVerifyAngle) {
            candidate = target;
        }
        if (candidate == null) return;

        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        long now = System.currentTimeMillis();
        if (now - lockAcquiredTime < 100L) return;

        long actualDelay = (long) (delayMs * (0.75 + Math.random() * 0.5));
        if (now - lastAttackTime < actualDelay) return;

        // NO MISS CHANCE: once all checks pass, use the same public attack path as TriggerBot.
        mc.interactionManager.attackEntity(mc.player, candidate);
        mc.player.swingHand(Hand.MAIN_HAND);
        lastAttackTime = System.currentTimeMillis();

        if (humanClicks) {
            mc.options.attackKey.setPressed(true);
            releaseAttackNextTick = true;
        }
    }

    private void acquireTarget(MinecraftClient mc) {
        LivingEntity target = mc.world.getEntitiesByClass(
                        LivingEntity.class,
                        mc.player.getBoundingBox().expand(range),
                        e -> validCandidate(mc, e))
                .stream()
                .min(Comparator.comparingDouble(mc.player::distanceTo))
                .orElse(null);
        if (target != null) {
            lockedTarget = target;
            lockAcquiredTime = System.currentTimeMillis();
        }
    }

    private boolean lockStillValid(MinecraftClient mc, LivingEntity target) {
        return target != null
                && target != mc.player
                && target.isAlive()
                && !target.isRemoved()
                && mc.player.distanceTo(target) <= range;
    }

    private boolean validCandidate(MinecraftClient mc, LivingEntity entity) {
        return entity != mc.player
                && entity.isAlive()
                && !entity.isRemoved()
                && !entity.isSpectator()
                && mc.player.distanceTo(entity) <= range
                && matchesType(entity)
                && mc.player.canSee(entity);
    }

    private boolean matchesType(LivingEntity entity) {
        return switch (targetType) {
            case "Players" -> entity instanceof PlayerEntity;
            case "Entities" -> !(entity instanceof PlayerEntity);
            default -> true;
        };
    }

    private boolean isWeapon(Item item) {
        return item instanceof SwordItem
                || item instanceof AxeItem
                || item instanceof TridentItem
                || item instanceof MaceItem;
    }

    private void rotate(MinecraftClient mc, LivingEntity target) {
        Vec3d targetPos = target.getPos().add(0.0, target.getHeight() * 0.5, 0.0);
        Vec3d diff = targetPos.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));

        float currentYaw = mc.player.getYaw();
        float currentPitch = mc.player.getPitch();
        float yawDelta = MathHelper.wrapDegrees(targetYaw - currentYaw);
        float pitchDelta = targetPitch - currentPitch;

        double distanceFactor = MathHelper.clamp(
                1.0 - (mc.player.distanceTo(target) / Math.max(range, 0.001)),
                0.7,
                1.0
        );
        double speedFactor = (0.65 + speed * 1.00) * distanceFactor;
        float yawStep = (float) (yawDelta * (1.0 - Math.exp(-speedFactor)));
        float pitchStep = (float) (pitchDelta * (1.0 - Math.exp(-speedFactor)));

        if (Math.abs(yawDelta) < 6.0f) {
            yawStep = yawDelta;
        } else {
            yawStep *= 1.12f + ThreadLocalRandom.current().nextFloat() * 0.08f;
        }
        if (Math.abs(yawDelta) < 1.5f) yawStep *= 0.9f;
        if (Math.abs(pitchDelta) < 0.8f) pitchStep = 0.0f;

        if (microJitter && Math.abs(yawDelta) > 0.5f) {
            yawStep += (float) ThreadLocalRandom.current().nextDouble(-0.15, 0.15);
        }

        float variance = 0.97f + ThreadLocalRandom.current().nextFloat() * 0.06f;
        float yawCap = Math.abs(yawDelta) > 90.0f ? 30.0f : 45.0f;
        yawCap *= variance;
        float pitchCap = 25.0f * variance;
        yawStep = MathHelper.clamp(yawStep, -yawCap, yawCap);
        pitchStep = MathHelper.clamp(pitchStep, -pitchCap, pitchCap);

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }

        mc.player.setYaw(currentYaw + yawStep);
        mc.player.setPitch(MathHelper.clamp(currentPitch + pitchStep, -90.0f, 90.0f));
    }

    private double angleToTarget(MinecraftClient mc, LivingEntity target) {
        Vec3d from = mc.player.getEyePos();
        Vec3d to = target.getPos().add(0.0, target.getHeight() * 0.5, 0.0).subtract(from);
        if (to.lengthSquared() < 1.0e-8) return 0.0;
        Vec3d look = mc.player.getRotationVec(1.0f).normalize();
        double dot = MathHelper.clamp(look.dotProduct(to.normalize()), -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot));
    }

    private static String choice(String value, String... values) {
        for (String v : values) if (v.equals(value)) return value;
        return values[0];
    }

    public double range() { return range; }
    public void setRange(double value) { range = MathHelper.clamp(value, 2.5, 6.0); persist(); }
    public double speed() { return speed; }
    public void setSpeed(double value) { speed = MathHelper.clamp(value, 0.1, 1.0); persist(); }
    public String targetType() { return targetType; }
    public void setTargetType(String value) { targetType = choice(value, "Players", "Entities", "Both"); persist(); }
    public int delay() { return delayMs; }
    public void setDelay(int value) { delayMs = MathHelper.clamp(value, 0, 500); persist(); }
    public double hitVerifyAngle() { return hitVerifyAngle; }
    public void setHitVerifyAngle(double value) { hitVerifyAngle = MathHelper.clamp(value, 5.0, 30.0); persist(); }
    public boolean humanClicks() { return humanClicks; }
    public void setHumanClicks(boolean value) { humanClicks = value; persist(); }
    public boolean microJitter() { return microJitter; }
    public void setMicroJitter(boolean value) { microJitter = value; persist(); }
}
