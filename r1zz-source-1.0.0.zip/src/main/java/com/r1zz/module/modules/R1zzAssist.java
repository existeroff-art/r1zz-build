package com.r1zz.module.modules;

import com.r1zz.config.R1zzSettings;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;

/** Blatant R1zzAssist with a sticky first-target lock. */
public final class R1zzAssist extends Module {
    private double range=3.5,speed=.75;
    private boolean hasLocked;
    private LivingEntity lockedTarget;
    private long lastAttack,lockTick;
    private boolean skipAfterSwing;

    public R1zzAssist(){super("r1zz_assist","R1zzAssist",Category.COMBAT,false);}

    @Override public void onEnable(){hasLocked=false;lockedTarget=null;skipAfterSwing=false;lastAttack=0;lockTick=0;}
    @Override public void onDisable(){hasLocked=false;lockedTarget=null;skipAfterSwing=false;}

    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.world==null||mc.currentScreen!=null||mc.interactionManager==null)return;
        if(mc.player.isUsingItem() && !R1zzSettings.getBoolean("r1zz_assist.when_use_hand",false))return;
        if(onlyWeapon()&&!isWeapon(mc.player.getMainHandStack().getItem()))return;
        sync();
        if(!hasLocked){
            LivingEntity first=mc.world.getEntitiesByClass(LivingEntity.class,mc.player.getBoundingBox().expand(range),e->valid(mc,e))
                    .stream().min(Comparator.comparingDouble(mc.player::distanceTo)).orElse(null);
            if(first==null)return;
            lockedTarget=first;hasLocked=true;lockTick=mc.world.getTime();
        }
        LivingEntity target=lockedTarget;
        if(target==null||!target.isAlive()||target.isRemoved()||mc.player.distanceTo(target)>range){hasLocked=false;lockedTarget=null;return;}
        if(skipAfterSwing){skipAfterSwing=false;return;}
        rotate(mc,target);
        if(mc.player.getAttackCooldownProgress(0.5f)<cooldownPercent()/100.0f)return;
        if(System.currentTimeMillis()-lastAttack<80L+delayVariance())return;
        if(ThreadLocalRandom.current().nextDouble(100)<missChance())return;
        if(!(mc.crosshairTarget instanceof EntityHitResult hit&&hit.getEntity()==target))return;
        if(!mc.player.canSee(target))return;
        mc.interactionManager.attackEntity(mc.player,target);
        mc.player.swingHand(Hand.MAIN_HAND);
        lastAttack=System.currentTimeMillis();
        skipAfterSwing=true;
    }

    private void sync(){
        range=R1zzSettings.getString("r1zz_assist.reach","Default").equals("Default")?3.5:Double.parseDouble(R1zzSettings.getString("r1zz_assist.reach","3.5"));
        speed=.75;
    }
    private long delayVariance(){return ThreadLocalRandom.current().nextLong(77,84);}
    private boolean valid(MinecraftClient mc,LivingEntity e){
        if(e==mc.player||!e.isAlive()||e.isRemoved()||e.isSpectator()||mc.player.distanceTo(e)>range)return false;
        boolean p=e instanceof PlayerEntity&&R1zzSettings.getBoolean("r1zz_assist.target_players",true);
        boolean a=e instanceof AnimalEntity&&R1zzSettings.getBoolean("r1zz_assist.target_animals",true);
        boolean m=e instanceof MobEntity&&!(e instanceof AnimalEntity)&&R1zzSettings.getBoolean("r1zz_assist.target_mobs",true);
        return p||a||m;
    }
    private void rotate(MinecraftClient mc,LivingEntity target){
        Vec3d d=target.getPos().add(0,target.getHeight()*.5,0).subtract(mc.player.getEyePos());
        double h=Math.sqrt(d.x*d.x+d.z*d.z);
        float ty=(float)(Math.toDegrees(Math.atan2(d.z,d.x))-90),tp=(float)-Math.toDegrees(Math.atan2(d.y,h));
        float yd=MathHelper.wrapDegrees(ty-mc.player.getYaw()),pd=tp-mc.player.getPitch();
        double df=MathHelper.clamp(1.0-mc.player.distanceTo(target)/Math.max(range,.001),.7,1.0);
        double sf=(.65+speed)*df*(.9+ThreadLocalRandom.current().nextDouble()*.2);
        float ys=(float)(yd*(1-Math.exp(-sf))),ps=(float)(pd*(1-Math.exp(-sf)));
        if(Math.abs(yd)>6)ys*=1.10f+ThreadLocalRandom.current().nextFloat()*.06f;
        if(Math.abs(yd)<1.5)ys*=.9f;
        float var=.97f+ThreadLocalRandom.current().nextFloat()*.06f;
        float yc=45f*var,pc=25f*var;
        ys=MathHelper.clamp(ys,-yc,yc);ps=MathHelper.clamp(ps,-pc,pc);
        if(Math.abs(yd)>.5)ys+=(float)ThreadLocalRandom.current().nextDouble(-.15,.15);
        if(Math.abs(pd)>.5)ps+=(float)ThreadLocalRandom.current().nextDouble(-.08,.08);
        float sens=mc.options.getMouseSensitivity().getValue().floatValue(),f=sens*.6f+.2f,gcd=f*f*f*1.2f;
        if(gcd>0){ys=Math.round(ys/gcd)*gcd;ps=Math.round(ps/gcd)*gcd;}
        mc.player.setYaw(mc.player.getYaw()+ys);mc.player.setPitch(MathHelper.clamp(mc.player.getPitch()+ps,-90,90));
    }
    private double missChance(){return R1zzSettings.getDouble("r1zz_assist.miss_chance",0);}
    private double cooldownPercent(){return R1zzSettings.getDouble("r1zz_assist.cooldown",80.1);}
    private boolean onlyWeapon(){return R1zzSettings.getBoolean("r1zz_assist.only_weapon",true);}
    private boolean isWeapon(Item i){return i instanceof SwordItem||i instanceof AxeItem||i instanceof TridentItem||i instanceof MaceItem;}
    public boolean hasLocked(){return hasLocked;}
    public LivingEntity lockedTarget(){return lockedTarget;}
    public double range(){return range;}
    public void setRange(double v){range=MathHelper.clamp(v,2.5,6);R1zzSettings.set("r1zz_assist.reach",range);persist();}
    public double speed(){return speed;}
    public void setSpeed(double v){speed=MathHelper.clamp(v,.1,1);persist();}
}
