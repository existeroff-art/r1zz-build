package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;

public final class R1zzAssist extends Module {
    private double range = 3.5;
    private double speed = 0.6;
    private String targetType = "Players";
    private LivingEntity lockedTarget;
    private int attackSkip;
    private long lastTargetLock;

    public R1zzAssist() { super("r1zz_assist", "R1zzAssist", Category.COMBAT, false); }

    @Override protected void loadSettings() {
        range = MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.range", 3.5), 2.5, 6.0);
        speed = MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.speed", 0.6), 0.1, 1.0);
        targetType = choice(R1zzConfig.get("r1zz_assist.target_type", "Players"), "Players", "Entities", "Both");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("r1zz_assist.range", range);
        R1zzConfig.put("r1zz_assist.speed", speed);
        R1zzConfig.put("r1zz_assist.target_type", targetType);
    }
    @Override protected void resetSettings() {
        range=3.5; speed=0.6; targetType="Players"; lockedTarget=null; attackSkip=0; lastTargetLock=0;
    }

    @Override public void onTick() {
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.world==null||mc.interactionManager==null){lockedTarget=null;return;}

        if(lockedTarget!=null && (!lockedTarget.isAlive() || mc.player.distanceTo(lockedTarget)>range)){
            lockedTarget=null;
        }
        if(lockedTarget==null){
            if(System.currentTimeMillis()-lastTargetLock<500L) return;
            lockedTarget=findTarget(mc);
            if(lockedTarget==null)return;
            lastTargetLock=System.currentTimeMillis();
        }

        if(attackSkip>0){attackSkip--;return;}

        // A hand-swing recovery tick is completely inert: no rotation and no attack.
        if(attackSkip>0)return;

        if(mc.currentScreen!=null || mc.player.isUsingItem() || mc.player.isBlocking()
                || !weapon(mc.player.getMainHandStack().getItem())
                || mc.player.getOffHandStack().isOf(net.minecraft.item.Items.SHIELD)) return;

        // Never rotate and swing in the same tick; rotation gets its own tick.
        if(mc.player.canSee(lockedTarget)){
            rotate(mc,lockedTarget);
            if(mc.player.getAttackCooldownProgress(0.5f)>=1.0f){
                // Rotation has just happened, so defer the swing until next tick.
                attackSkip=1;
                return;
            }
        }
        if(attackSkip>0)return;
        if(mc.player.canSee(lockedTarget) && mc.player.getAttackCooldownProgress(0.5f)>=1.0f){
            mc.interactionManager.attackEntity(mc.player,lockedTarget);
            mc.player.swingHand(Hand.MAIN_HAND);
            attackSkip=1;
        }
    }

    private LivingEntity findTarget(MinecraftClient mc){
        return mc.world.getEntitiesByClass(LivingEntity.class,mc.player.getBoundingBox().expand(range),
                e->e!=mc.player&&e.isAlive()&&!e.isSpectator()&&matchesType(e))
                .stream().min(Comparator.comparingDouble(mc.player::distanceTo)).orElse(null);
    }
    private boolean matchesType(LivingEntity e){
        return switch(targetType){case "Players"->e instanceof PlayerEntity;case "Entities"->!(e instanceof PlayerEntity);default->true;};
    }
    private boolean weapon(Item item){
        return item instanceof SwordItem||item instanceof AxeItem||item instanceof TridentItem||item instanceof MaceItem;
    }
    private void rotate(MinecraftClient mc,LivingEntity target){
        Vec3d diff=target.getPos().add(0,target.getHeight()*0.5,0).subtract(mc.player.getEyePos());
        double h=Math.sqrt(diff.x*diff.x+diff.z*diff.z);
        float ty=(float)(Math.toDegrees(Math.atan2(diff.z,diff.x))-90.0);
        float tp=(float)-Math.toDegrees(Math.atan2(diff.y,h));
        float yd=MathHelper.wrapDegrees(ty-mc.player.getYaw()),pd=tp-mc.player.getPitch();
        double distance=mc.player.distanceTo(target);
        float distanceFactor=(float)MathHelper.clamp(distance/Math.max(range,0.001),0.45,1.0);
        float factor=(float)((0.35+speed*0.55)*distanceFactor);
        float ys=MathHelper.clamp(yd*factor,-28.0f,28.0f);
        float ps=MathHelper.clamp(pd*factor,-16.0f,16.0f);
        float sens=mc.options.getMouseSensitivity().getValue().floatValue(),f=sens*.6f+.2f,gcd=f*f*f*1.2f;
        if(gcd>0){ys=Math.round(ys/gcd)*gcd;ps=Math.round(ps/gcd)*gcd;}
        mc.player.setYaw(mc.player.getYaw()+ys);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch()+ps,-90,90));
    }
    @Override public void onDisable(){lockedTarget=null;attackSkip=0;lastTargetLock=0;}
    private static String choice(String v,String... values){for(String s:values)if(s.equals(v))return v;return values[0];}
    public double range(){return range;} public void setRange(double v){range=MathHelper.clamp(v,2.5,6);persist();}
    public double speed(){return speed;} public void setSpeed(double v){speed=MathHelper.clamp(v,.1,1);persist();}
    public String targetType(){return targetType;} public void setTargetType(String v){targetType=choice(v,"Players","Entities","Both");persist();}
}
