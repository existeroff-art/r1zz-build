package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;

public final class R1zzAssist extends Module {
    private double range = 3.5;
    private double speed = 0.85;
    private String targetType = "Players";
    private boolean swingOnMiss = false;
    private LivingEntity lockedTarget;
    private int attackSkip;

    public R1zzAssist() {
        super("r1zz_assist", "R1zzAssist", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        range = MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.range", 3.5), 2.5, 6.0);
        speed = MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.speed", 0.85), 0.1, 1.0);
        targetType = choice(R1zzConfig.get("r1zz_assist.target_type", "Players"), "Players", "Entities", "Both");
        swingOnMiss = R1zzConfig.getBoolean("r1zz_assist.swing_on_miss", false);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("r1zz_assist.range", range);
        R1zzConfig.put("r1zz_assist.speed", speed);
        R1zzConfig.put("r1zz_assist.target_type", targetType);
        R1zzConfig.put("r1zz_assist.swing_on_miss", swingOnMiss);
    }

    @Override
    protected void resetSettings() {
        range = 3.5;
        speed = 0.85;
        targetType = "Players";
        swingOnMiss = false;
        lockedTarget = null;
        attackSkip = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            lockedTarget = null;
            return;
        }

        if (lockedTarget != null && (!lockedTarget.isAlive()
                || mc.player.distanceTo(lockedTarget) > range)) {
            lockedTarget = null;
        }

        if (lockedTarget == null) {
            lockedTarget = findTarget(mc);
            if (lockedTarget == null) return;
        }

        if (!mc.player.canSee(lockedTarget)) {
            if (swingOnMiss && mc.player.getAttackCooldownProgress(0.5f) >= 1.0f) {
                mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            }
            return;
        }

        if (mc.currentScreen == null && !mc.player.isUsingItem()) {
            rotate(mc, lockedTarget);
        }

        if (attackSkip > 0) {
            attackSkip--;
            return;
        }

        if (mc.currentScreen == null && mc.player.getAttackCooldownProgress(0.5f) >= 1.0f
                && weapon(mc.player.getMainHandStack().getItem())) {
            mc.interactionManager.attackEntity(mc.player, lockedTarget);
            mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            attackSkip = 1;
        }
    }

    private LivingEntity findTarget(MinecraftClient mc) {
        return mc.world.getEntitiesByClass(
                LivingEntity.class,
                mc.player.getBoundingBox().expand(range),
                e -> e != mc.player && e.isAlive() && !e.isSpectator()
                        && matchesType(e)
        ).stream()
                .min(Comparator.comparingDouble(mc.player::distanceTo))
                .orElse(null);
    }

    private boolean matchesType(LivingEntity entity) {
        return switch (targetType) {
            case "Players" -> entity instanceof PlayerEntity;
            case "Entities" -> !(entity instanceof PlayerEntity);
            default -> true;
        };
    }

    private boolean weapon(net.minecraft.item.Item item) {
        return item instanceof SwordItem || item instanceof AxeItem
                || item instanceof TridentItem || item instanceof MaceItem;
    }

    private void rotate(MinecraftClient mc, LivingEntity target) {
        Vec3d diff = target.getPos().add(0.0, target.getHeight() * 0.5, 0.0)
                .subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();
        float cap = (float) (45.0 * (0.97 + ThreadLocalRandom.current().nextDouble() * 0.06));
        float yawStep = MathHelper.clamp(yawDelta * (float) (0.25 + speed * 0.75), -cap, cap);
        float pitchStep = MathHelper.clamp(pitchDelta * (float) (0.25 + speed * 0.75), -25.0f, 25.0f);

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    @Override
    public void onDisable() {
        lockedTarget = null;
        attackSkip = 0;
    }

    private static String choice(String value, String... values) {
        for (String v : values) if (v.equals(value)) return value;
        return values[0];
    }

    public double range() { return range; }
    public void setRange(double value) { range = MathHelper.clamp(value, 2.5, 6.0); persist(); }
    public double speed() { return speed; }
    public void setSpeed(double value) { speed = MathHelper.clamp(value, 0.1, 1.0); persist(); }
    public String targetType() { return targetType; }
    public void setTargetType(String value) { targetType = choice(value, "Players", "Entities", "Both"); persist(); }
    public boolean swingOnMiss() { return swingOnMiss; }
    public void setSwingOnMiss(boolean value) { swingOnMiss = value; persist(); }
}
