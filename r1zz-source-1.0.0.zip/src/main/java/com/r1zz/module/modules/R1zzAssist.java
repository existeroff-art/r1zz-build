package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;

public final class R1zzAssist extends Module {
    private double range=3.5,speed=.75;
    private String targetType="Players";
    private int delayMs=80;
    private double hitVerifyAngle=15.0;
    private boolean humanClicks=true,microJitter=true;
    private LivingEntity lockedTarget;
    private long lastAttackTime,lockAcquiredTime,targetOccludedSince;
    private long nextAttackDelay=80;
    private boolean rotatedThisTick,skipAfterSwing;
    private float previousSpeedFactor=-1f;
    private boolean clickArmed;

    public R1zzAssist(){super("r1zz_assist","R1zzAssist",Category.COMBAT,false);}
    @Override protected void loadSettings(){
        range=MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.range",3.5),2.5,6.0);
        speed=MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.speed",.75),.1,1.0);
        targetType=choice(R1zzConfig.get("r1zz_assist.target_type","Players"),"Players","Entities","Both");
        delayMs=MathHelper.clamp(R1zzConfig.getInt("r1zz_assist.delay",80),1,500);
        hitVerifyAngle=MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.hit_verify_angle",15),5,30);
        humanClicks=R1zzConfig.getBoolean("r1zz_assist.human_clicks",true);
        microJitter=R1zzConfig.getBoolean("r1zz_assist.micro_jitter",true);
    }
    @Override protected void saveSettings(){
        R1zzConfig.put("r1zz_assist.range",range);R1zzConfig.put("r1zz_assist.speed",speed);R1zzConfig.put("r1zz_assist.target_type",targetType);
        R1zzConfig.put("r1zz_assist.delay",delayMs);R1zzConfig.put("r1zz_assist.hit_verify_angle",hitVerifyAngle);
        R1zzConfig.put("r1zz_assist.human_clicks",humanClicks);R1zzConfig.put("r1zz_assist.micro_jitter",microJitter);
    }
    @Override protected void resetSettings(){range=3.5;speed=.75;targetType="Players";delayMs=80;hitVerifyAngle=15;humanClicks=true;microJitter=true;clearState();}
    @Override public void onEnable(){clearState();}
    @Override public void onDisable(){clearState();MinecraftClient mc=MinecraftClient.getInstance();if(mc.options!=null)mc.options.attackKey.setPressed(false);}
    private void clearState(){lockedTarget=null;lastAttackTime=0;lockAcquiredTime=0;targetOccludedSince=0;nextAttackDelay=80;rotatedThisTick=false;skipAfterSwing=false;previousSpeedFactor=-1f;clickArmed=false;}

    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        try{
            if(mc.player==null||mc.world==null||mc.currentScreen!=null||mc.interactionManager==null||mc.options==null)return;
            if(mc.player.isUsingItem()||mc.player.isBlocking()||!isWeapon(mc.player.getMainHandStack().getItem()))return;
            if(clickArmed){
                mc.options.attackKey.setPressed(false);
                LivingEntity target=lockedTarget;
                clickArmed=false;
                if(target!=null&&target.isAlive()&&!target.isRemoved()&&mc.player.distanceTo(target)<=range&&onTarget(mc,target)&&mc.player.getAttackCooldownProgress(0.5f)>=1.0f){
                    mc.interactionManager.attackEntity(mc.player,target);
                    mc.player.swingHand(Hand.MAIN_HAND);
                    lastAttackTime=System.currentTimeMillis();
                    nextAttackDelay=Humanizer.jitter(delayMs,.25);
                    skipAfterSwing=true;
                }
                return;
            }
            if(skipAfterSwing){skipAfterSwing=false;return;}
            rotatedThisTick=false;
            long now=System.currentTimeMillis();
            if(lockedTarget!=null){
                if(!lockedTarget.isAlive()||lockedTarget.isRemoved()||mc.player.distanceTo(lockedTarget)>range)releaseTarget();
                else if(mc.player.canSee(lockedTarget))targetOccludedSince=0;
                else if(targetOccludedSince==0)targetOccludedSince=now;
                else if(now-targetOccludedSince>400)releaseTarget();
            }
            if(lockedTarget==null)acquireTarget(mc);
            if(lockedTarget==null)return;
            LivingEntity target=lockedTarget;
            if(!onTarget(mc,target)){
                rotate(mc,target);
                rotatedThisTick=true;
                return;
            }
            if(rotatedThisTick)return;
            if(mc.player.getAttackCooldownProgress(0.5f)<1.0f)return;
            if(now-lockAcquiredTime<ThreadLocalRandom.current().nextLong(50,201))return;
            if(now-lastAttackTime<Math.max(60,Math.min(120,nextAttackDelay)))return;
            if(now-lastAttackTime<ThreadLocalRandom.current().nextLong(60,121))return;
            if(ThreadLocalRandom.current().nextDouble()<.04){lastAttackTime=now;nextAttackDelay=Humanizer.jitter(delayMs,.25);return;}
            if(humanClicks){
                mc.options.attackKey.setPressed(true);
                clickArmed=true;
                return;
            }
            mc.interactionManager.attackEntity(mc.player,target);mc.player.swingHand(Hand.MAIN_HAND);
            lastAttackTime=System.currentTimeMillis();nextAttackDelay=Humanizer.jitter(delayMs,.25);skipAfterSwing=true;
        }catch(RuntimeException ignored){clearState();}
    }
    private void acquireTarget(MinecraftClient mc){
        LivingEntity t=mc.world.getEntitiesByClass(LivingEntity.class,mc.player.getBoundingBox().expand(range),e->valid(mc,e)).stream().min(Comparator.comparingDouble(mc.player::distanceTo)).orElse(null);
        if(t!=null){lockedTarget=t;lockAcquiredTime=System.currentTimeMillis();nextAttackDelay=Humanizer.jitter(delayMs,.25);}
    }
    private void releaseTarget(){lockedTarget=null;lockAcquiredTime=0;targetOccludedSince=0;}
    private boolean valid(MinecraftClient mc,LivingEntity e){return e!=mc.player&&e.isAlive()&&!e.isRemoved()&&!e.isSpectator()&&mc.player.distanceTo(e)<=range&&matchesType(e);}
    private boolean matchesType(LivingEntity e){return switch(targetType){case "Players"->e instanceof PlayerEntity;case "Entities"->!(e instanceof PlayerEntity);default->true;};}
    private boolean isWeapon(Item i){return i instanceof SwordItem||i instanceof AxeItem||i instanceof TridentItem||i instanceof MaceItem;}
    private boolean onTarget(MinecraftClient mc,LivingEntity t){
        if(mc.crosshairTarget instanceof EntityHitResult hit&&hit.getEntity()==t)return true;
        return angleToTarget(mc,t)<=hitVerifyAngle;
    }
    private double angleToTarget(MinecraftClient mc,LivingEntity t){Vec3d to=t.getPos().add(0,t.getHeight()*.5,0).subtract(mc.player.getEyePos());if(to.lengthSquared()<1e-8)return 0;double dot=MathHelper.clamp(mc.player.getRotationVec(1).normalize().dotProduct(to.normalize()),-1,1);return Math.toDegrees(Math.acos(dot));}
    private void rotate(MinecraftClient mc,LivingEntity t){
        Vec3d d=t.getPos().add(0,t.getHeight()*.5,0).subtract(mc.player.getEyePos());double h=Math.sqrt(d.x*d.x+d.z*d.z);
        float yaw=MathHelper.wrapDegrees((float)(Math.toDegrees(Math.atan2(d.z,d.x))-90)-mc.player.getYaw());
        float pitch=(float)-Math.toDegrees(Math.atan2(d.y,h))-mc.player.getPitch();
        double base=(.65+speed)*MathHelper.clamp(1.0-mc.player.distanceTo(t)/Math.max(range,.001),.7,1.0);
        float factor;do{factor=(float)(base*(.9+ThreadLocalRandom.current().nextDouble()*.2));}while(previousSpeedFactor>=0&&Math.abs(factor-previousSpeedFactor)<.005);previousSpeedFactor=factor;
        float yawStep=(float)(yaw*(1-Math.exp(-factor))),pitchStep=(float)(pitch*(1-Math.exp(-factor)));
        if(microJitter&&Math.abs(yaw)>.5)yawStep+=(float)ThreadLocalRandom.current().nextDouble(-.15,.15);
        if(microJitter&&Math.abs(yaw)>.5)pitchStep+=(float)ThreadLocalRandom.current().nextDouble(-.08,.08);
        yawStep=MathHelper.clamp(yawStep,-45,45);pitchStep=MathHelper.clamp(pitchStep,-25,25);
        float sens=mc.options.getMouseSensitivity().getValue().floatValue();float f=sens*.6f+.2f;float gcd=f*f*f*1.2f;
        yawStep=Math.round(yawStep/gcd)*gcd;pitchStep=Math.round(pitchStep/gcd)*gcd;
        mc.player.setYaw(mc.player.getYaw()+yawStep);mc.player.setPitch(MathHelper.clamp(mc.player.getPitch()+pitchStep,-90,90));
    }
    private static String choice(String v,String...a){for(String x:a)if(x.equals(v))return v;return a[0];}
    public double range(){return range;}public void setRange(double v){range=MathHelper.clamp(v,2.5,6);persist();}
    public double speed(){return speed;}public void setSpeed(double v){speed=MathHelper.clamp(v,.1,1);persist();}
    public String targetType(){return targetType;}public void setTargetType(String v){targetType=choice(v,"Players","Entities","Both");persist();}
    public int delay(){return delayMs;}public void setDelay(int v){delayMs=MathHelper.clamp(v,1,500);persist();}
    public double hitVerifyAngle(){return hitVerifyAngle;}public void setHitVerifyAngle(double v){hitVerifyAngle=MathHelper.clamp(v,5,30);persist();}
    public boolean humanClicks(){return humanClicks;}public void setHumanClicks(boolean v){humanClicks=v;persist();}
    public boolean microJitter(){return microJitter;}public void setMicroJitter(boolean v){microJitter=v;persist();}
}
