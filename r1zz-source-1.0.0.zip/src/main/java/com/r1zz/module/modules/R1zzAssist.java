package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;

public final class R1zzAssist extends Module {
    private double range = 3.5;
    private double speed = 0.75;
    private String targetType = "Players";
    private int delayMs = 80;
    private boolean humanClicks = true;
    private boolean microJitter = true;

    private LivingEntity lockedTarget;
    private long lastAttackTime = 0L;
    private long lockAcquiredTime = 0L;
    private boolean skipAfterSwing;
    private boolean releaseAttackNextTick;

    public R1zzAssist() {
        super("r1zz_assist", "R1zzAssist", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        range = MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.range", 3.5), 2.5, 6.0);
        speed = MathHelper.clamp(R1zzConfig.getDouble("r1zz_assist.speed", 0.75), 0.1, 1.0);
        targetType = choice(R1zzConfig.get("r1zz_assist.target_type", "Players"), "Players", "Entities", "Both");
        delayMs = MathHelper.clamp(R1zzConfig.getInt("r1zz_assist.delay", 80), 0, 500);
        humanClicks = R1zzConfig.getBoolean("r1zz_assist.human_clicks", true);
        microJitter = R1zzConfig.getBoolean("r1zz_assist.micro_jitter", true);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("r1zz_assist.range", range);
        R1zzConfig.put("r1zz_assist.speed", speed);
        R1zzConfig.put("r1zz_assist.target_type", targetType);
        R1zzConfig.put("r1zz_assist.delay", delayMs);
        R1zzConfig.put("r1zz_assist.human_clicks", humanClicks);
        R1zzConfig.put("r1zz_assist.micro_jitter", microJitter);
    }

    @Override
    protected void resetSettings() {
        range = 3.5;
        speed = 0.75;
        targetType = "Players";
        delayMs = 80;
        humanClicks = true;
        microJitter = true;
        clearState();
    }

    @Override
    public void onEnable() {
        clearState();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.world != null && isWeapon(mc.player.getMainHandStack().getItem())) {
            acquireTarget(mc);
        }
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) {
            mc.options.attackKey.setPressed(false);
        }
        clearState();
    }

    private void clearState() {
        lockedTarget = null;
        lastAttackTime = 0L;
        lockAcquiredTime = 0L;
        skipAfterSwing = false;
        releaseAttackNextTick = false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            if (mc.options != null) {
                mc.options.attackKey.setPressed(false);
            }
            lockedTarget = null;
            return;
        }

        // Release the simulated attack key exactly one tick after it was pressed.
        if (releaseAttackNextTick) {
            mc.options.attackKey.setPressed(false);
            releaseAttackNextTick = false;
        }

        // Skip exactly one tick after a hand swing. This also prevents rotation + swing
        // from occurring on the same tick.
        if (skipAfterSwing) {
            skipAfterSwing = false;
            return;
        }

        // Track the previous/current hand swing so we never act during the swing tick.
        if (mc.player.handSwinging) {
            skipAfterSwing = true;
            return;
        }

        if (!isSafeToAct(mc) || !isWeapon(mc.player.getMainHandStack().getItem())) {
            return;
        }

        long now = System.currentTimeMillis();

        // Sticky lock: only acquire when there is no target. A new closer target can
        // never replace an existing valid lock.
        if (lockedTarget == null) {
            acquireTarget(mc);
            if (lockedTarget == null) {
                return;
            }
        }

        // Release only for the requested lock-breaking conditions. Visibility is also
        // required for attacking, but a temporarily hidden target remains the lock.
        if (!lockStillValid(mc, lockedTarget)) {
            lockedTarget = null;
            lockAcquiredTime = 0L;
            return;
        }

        if (!mc.player.canSee(lockedTarget)) {
            return;
        }

        // Never rotate and swing on the same tick.
        if (rotate(mc, lockedTarget)) {
            return;
        }

        if (!mc.player.canSee(lockedTarget)) {
            return;
        }

        // Vanilla attack cooldown must be completely ready.
        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) {
            return;
        }

        // Doomsday-style delay starts after the previous successful attack.
        long actualDelay = (long) (delayMs * (0.75 + Math.random() * 0.5));
        if (now - lastAttackTime < actualDelay) {
            return;
        }

        // Give a newly acquired target a 100ms reaction window.
        if (now - lockAcquiredTime < 100L) {
            return;
        }

        // NO MISS CHANCE: once all checks pass, attack every time.
        mc.interactionManager.attackEntity(mc.player, lockedTarget);
        mc.player.swingHand(Hand.MAIN_HAND);
        lastAttackTime = System.currentTimeMillis();
        skipAfterSwing = true;

        if (humanClicks) {
            mc.options.attackKey.setPressed(true);
            releaseAttackNextTick = true;
        }
    }

    private void acquireTarget(MinecraftClient mc) {
        LivingEntity target = findTarget(mc);
        if (target != null) {
            lockedTarget = target;
            lockAcquiredTime = System.currentTimeMillis();
        }
    }

    private boolean isSafeToAct(MinecraftClient mc) {
        return mc.currentScreen == null
                && !mc.player.isUsingItem()
                && !mc.player.isBlocking()
                && !mc.player.getOffHandStack().isOf(net.minecraft.item.Items.SHIELD);
    }

    private boolean lockStillValid(MinecraftClient mc, LivingEntity target) {
        return target != mc.player
                && target.isAlive()
                && !target.isRemoved()
                && !target.isSpectator()
                && mc.player.distanceTo(target) <= range
                && matchesType(target);
    }

    private LivingEntity findTarget(MinecraftClient mc) {
        return mc.world.getEntitiesByClass(
                        LivingEntity.class,
                        mc.player.getBoundingBox().expand(range),
                        e -> validCandidate(mc, e)
                )
                .stream()
                .min(Comparator.comparingDouble(mc.player::distanceTo))
                .orElse(null);
    }

    private boolean validCandidate(MinecraftClient mc, LivingEntity e) {
        return e != mc.player
                && e.isAlive()
                && !e.isRemoved()
                && !e.isSpectator()
                && mc.player.distanceTo(e) <= range
                && matchesType(e)
                && mc.player.canSee(e);
    }

    private boolean matchesType(LivingEntity e) {
        return switch (targetType) {
            case "Players" -> e instanceof PlayerEntity;
            case "Entities" -> !(e instanceof PlayerEntity);
            default -> true;
        };
    }

    private boolean isWeapon(Item item) {
        return item instanceof SwordItem
                || item instanceof AxeItem
                || item instanceof TridentItem
                || item instanceof MaceItem;
    }

    private boolean rotate(MinecraftClient mc, LivingEntity target) {
        Vec3d diff = target.getPos()
                .add(0.0, target.getHeight() * 0.5, 0.0)
                .subtract(mc.player.getEyePos());

        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();

        if (Math.abs(pitchDelta) < 0.8f) {
            pitchDelta = 0.0f;
        }

        double distanceFactor = MathHelper.clamp(
                1.0 - mc.player.distanceTo(target) / Math.max(range, 0.001),
                0.7,
                1.0
        );
        double speedFactor = (0.65 + speed * 1.00) * distanceFactor;

        float yawStep = (float) (yawDelta * (1.0 - Math.exp(-speedFactor)));
        float pitchStep = (float) (pitchDelta * (1.0 - Math.exp(-speedFactor)));

        if (Math.abs(yawDelta) < 6.0f) {
            yawStep = yawDelta;
        } else {
            float overshoot = 1.12f + ThreadLocalRandom.current().nextFloat() * 0.08f;
            yawStep *= overshoot;
        }

        if (Math.abs(yawDelta) < 1.5f) {
            yawStep *= 0.9f;
        }

        if (microJitter && Math.abs(yawDelta) > 0.5f) {
            yawStep += (float) ThreadLocalRandom.current().nextDouble(-0.15, 0.15);
            pitchStep += (float) ThreadLocalRandom.current().nextDouble(-0.08, 0.08);
        }

        float capVariance = 0.97f + ThreadLocalRandom.current().nextFloat() * 0.06f;
        float yawCap;
        if (Math.abs(yawDelta) > 90.0f) {
            // Keep turns behind the player to roughly 30 degrees/tick, guaranteeing
            // at least three ticks rather than snapping instantly.
            yawCap = 30.0f * capVariance;
            if (Math.abs(yawStep) < 4.0f) {
                yawStep = Math.copySign(4.0f, yawDelta);
            }
        } else if (Math.abs(yawDelta) > 45.0f) {
            yawCap = 40.0f * capVariance;
        } else {
            yawCap = 45.0f * capVariance;
        }

        float pitchCap = 25.0f * capVariance;
        yawStep = MathHelper.clamp(yawStep, -yawCap, yawCap);
        pitchStep = MathHelper.clamp(pitchStep, -pitchCap, pitchCap);

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }

        if (Math.abs(yawStep) < 0.0001f && Math.abs(pitchStep) < 0.0001f) {
            return false;
        }

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
        return true;
    }

    private static String choice(String value, String... values) {
        for (String v : values) {
            if (v.equals(value)) {
                return value;
            }
        }
        return values[0];
    }

    public double range() {
        return range;
    }

    public void setRange(double v) {
        range = MathHelper.clamp(v, 2.5, 6.0);
        persist();
    }

    public double speed() {
        return speed;
    }

    public void setSpeed(double v) {
        speed = MathHelper.clamp(v, 0.1, 1.0);
        persist();
    }

    public String targetType() {
        return targetType;
    }

    public void setTargetType(String v) {
        targetType = choice(v, "Players", "Entities", "Both");
        persist();
    }

    public int delay() {
        return delayMs;
    }

    public void setDelay(int v) {
        delayMs = MathHelper.clamp(v, 0, 500);
        persist();
    }

    public boolean humanClicks() {
        return humanClicks;
    }

    public void setHumanClicks(boolean v) {
        humanClicks = v;
        persist();
    }

    public boolean microJitter() {
        return microJitter;
    }

    public void setMicroJitter(boolean v) {
        microJitter = v;
        persist();
    }
}
