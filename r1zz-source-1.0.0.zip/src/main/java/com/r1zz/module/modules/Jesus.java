package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Walk on water. Sneak to sink. */
public final class Jesus extends Module {
    public Jesus() { super("jesus", "Jesus", Category.MOVEMENT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || p.isSneaking() || p.isFallFlying()) return;
        boolean inWater = mc.world.getFluidState(p.getBlockPos()).isIn(FluidTags.WATER);
        BlockPos below = BlockPos.ofFloored(p.getX(), p.getY() - 0.1, p.getZ());
        boolean onSurface = !inWater && mc.world.getFluidState(below).isIn(FluidTags.WATER);
        Vec3d v = p.getVelocity();
        if (inWater) {
            p.setVelocity(v.x, 0.11, v.z);
        } else if (onSurface) {
            p.setVelocity(v.x, Math.max(0.0, v.y), v.z);
            p.setOnGround(true);
        }
    }
}
