package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Jesus extends Module {
    public Jesus() { super("jesus", "Jesus", Category.MOVEMENT, false); }
}
