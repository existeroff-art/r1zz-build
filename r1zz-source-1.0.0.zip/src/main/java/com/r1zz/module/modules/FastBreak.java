package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

public final class FastBreak extends Module {
    public FastBreak() { super("fast_break", "FastBreak", Category.WORLD, false); }
    private double multiplier = 1.5;
    private double carry;
    @Override protected void loadSettings() {
        multiplier=R1zzConfig.getDouble("fast_break.multiplier",1.5);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("fast_break.multiplier", multiplier);
    }
    @Override protected void resetSettings() {
        multiplier=1.5;
        carry=0;
    }

    /** Applies the extra break progress each tick while you are mining a block. */
    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.options == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed() || !mc.interactionManager.isBreakingBlock()) { carry = 0; return; }
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        double extra = multiplier - 1.0 + carry;
        int calls = (int) Math.floor(extra);
        carry = extra - calls;
        for (int i = 0; i < calls; i++) mc.interactionManager.updateBlockBreakingProgress(hit.getBlockPos(), hit.getSide());
    }

    public double multiplier() { return multiplier; }
    public void setMultiplier(double v) { multiplier=Math.max(1,Math.min(5,v)); persist(); }
}
