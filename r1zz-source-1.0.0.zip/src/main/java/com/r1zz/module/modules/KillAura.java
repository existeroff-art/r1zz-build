package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class KillAura extends Module {
    private double range = 3.0;
    private int cps = 8;
    private String rotation = "Smooth", target = "Players";
    private boolean swingOnly;
    private long last;
    public KillAura() { super("kill_aura", "KillAura", Category.COMBAT, false); }
    @Override protected void loadSettings() {
        range = clamp(R1zzConfig.getDouble("kill_aura.range", 3.0), 2.5, 6.0);
        cps = Math.max(1, Math.min(20, R1zzConfig.getInt("kill_aura.cps", 8)));
        rotation = choice(R1zzConfig.get("kill_aura.rotation", "Smooth"), "None", "Smooth", "Snap");
        target = choice(R1zzConfig.get("kill_aura.target", "Players"), "Players", "Entities", "Both");
        swingOnly = R1zzConfig.getBoolean("kill_aura.swing_only", false);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("kill_aura.range", range); R1zzConfig.put("kill_aura.cps", cps);
        R1zzConfig.put("kill_aura.rotation", rotation); R1zzConfig.put("kill_aura.target", target); R1zzConfig.put("kill_aura.swing_only", swingOnly);
    }
    @Override protected void resetSettings() { range=3.0; cps=8; rotation="Smooth"; target="Players"; swingOnly=false; last=0; }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || System.currentTimeMillis() - last < 1000L / cps) return;
        LivingEntity t = CombatModuleUtil.nearest(mc, range, "Players".equals(target));
        if (!CombatModuleUtil.validTarget(mc, t, range, target)) return;
        if (swingOnly && !mc.player.handSwinging) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;
        if (!"None".equals(rotation)) rotateTo(mc, t, "Snap".equals(rotation));
        CombatModuleUtil.attack(mc, t); last = System.currentTimeMillis();
    }
    private void rotateTo(MinecraftClient mc, LivingEntity target, boolean snap) {
        Vec3d d = target.getPos().add(0, target.getHeight() * .5, 0).subtract(mc.player.getEyePos());
        float yaw = (float)(Math.toDegrees(Math.atan2(d.z, d.x)) - 90);
        float pitch = (float)-Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x*d.x+d.z*d.z)));
        if (snap) { mc.player.setYaw(yaw); mc.player.setPitch(MathHelper.clamp(pitch,-90,90)); return; }
        mc.player.setYaw(mc.player.getYaw() + MathHelper.wrapDegrees(yaw-mc.player.getYaw())*.35f);
        mc.player.setPitch(mc.player.getPitch() + (pitch-mc.player.getPitch())*.35f);
    }
    static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    static String choice(String v,String... a){for(String x:a)if(x.equals(v))return v;return a[0];}
    public double range(){return range;} public void setRange(double v){range=clamp(v,2.5,6);persist();}
    public int cps(){return cps;} public void setCps(int v){cps=Math.max(1,Math.min(20,v));persist();}
    public String rotation(){return rotation;} public void setRotation(String v){rotation=choice(v,"None","Smooth","Snap");persist();}
    public String target(){return target;} public void setTarget(String v){target=choice(v,"Players","Entities","Both");persist();}
    public boolean swingOnly(){return swingOnly;} public void setSwingOnly(boolean v){swingOnly=v;persist();}
}
