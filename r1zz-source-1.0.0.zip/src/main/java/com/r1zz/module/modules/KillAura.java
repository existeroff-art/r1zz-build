package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class KillAura extends Module {
    private double range = 3.0;
    private int cps = 8;
    private String rotation = "Smooth", target = "Players";
    private boolean swingOnly;
    private long last;
    public KillAura() { super("kill_aura", "KillAura", Category.COMBAT, false); }
    @Override protected void loadSettings() {
        range = clamp(R1zzConfig.getDouble("kill_aura.range", 3.0), 2.5, 6.0);
        cps = Math.max(1, Math.min(12, R1zzConfig.getInt("kill_aura.cps", 8)));
        rotation = choice(R1zzConfig.get("kill_aura.rotation", "Smooth"), "None", "Smooth", "Snap");
        target = choice(R1zzConfig.get("kill_aura.target", "Players"), "Players", "Entities", "Both");
        swingOnly = R1zzConfig.getBoolean("kill_aura.swing_only", false);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("kill_aura.range", range); R1zzConfig.put("kill_aura.cps", cps);
        R1zzConfig.put("kill_aura.rotation", rotation); R1zzConfig.put("kill_aura.target", target); R1zzConfig.put("kill_aura.swing_only", swingOnly);
    }
    @Override protected void resetSettings() { range=3.0; cps=8; rotation="Smooth"; target="Players"; swingOnly=false; last=0; }
    private long nextDelay = 125L;
    private long reactionReadyAt;
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.player.isUsingItem()) return;
            long now = System.currentTimeMillis();
            if (now - last < nextDelay) return;
            LivingEntity t = CombatModuleUtil.nearest(mc, range, "Players".equals(target));
            if (!CombatModuleUtil.validTarget(mc, t, range, target)) { reactionReadyAt = 0L; return; }
            if (reactionReadyAt == 0L) reactionReadyAt = now + Humanizer.between(50, 200);
            if (now < reactionReadyAt) return;
            if (!mc.player.canSee(t)) return;
            if (swingOnly && !mc.player.handSwinging) return;
            if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;
            if (!"None".equals(rotation)) {
                rotateTo(mc, t, "Snap".equals(rotation));
                // only swing once the view is actually on the target
                if (angleTo(mc, t) > 25.0) return;
            }
            if (Humanizer.chance(0.04)) { last = now; nextDelay = Humanizer.jitter(1000L / cps, 0.3); return; } // occasional missed click
            CombatModuleUtil.attack(mc, t);
            last = System.currentTimeMillis();
            reactionReadyAt = 0L;
            nextDelay = Humanizer.jitter(1000L / cps, 0.25);
        } catch (RuntimeException ignored) { }
    }
    private void rotateTo(MinecraftClient mc, LivingEntity target, boolean snap) {
        Vec3d aim = target.getPos().add(0, target.getHeight() * (.45 + Math.random() * .15), 0);
        if (snap) CombatModuleUtil.rotateToward(mc, aim, 0.9f, 60.0f, 35.0f);
        else CombatModuleUtil.rotateToward(mc, aim, 0.35f, 30.0f, 18.0f);
    }
    private double angleTo(MinecraftClient mc, LivingEntity t) {
        Vec3d to = t.getPos().add(0, t.getHeight() * .5, 0).subtract(mc.player.getEyePos());
        if (to.lengthSquared() < 1.0e-8) return 0;
        double dot = MathHelper.clamp(mc.player.getRotationVec(1.0f).normalize().dotProduct(to.normalize()), -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot));
    }
    static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    static String choice(String v,String... a){for(String x:a)if(x.equals(v))return v;return a[0];}
    public double range(){return range;} public void setRange(double v){range=clamp(v,2.5,6);persist();}
    public int cps(){return cps;} public void setCps(int v){cps=Math.max(1,Math.min(12,v));persist();}
    public String rotation(){return rotation;} public void setRotation(String v){rotation=choice(v,"None","Smooth","Snap");persist();}
    public String target(){return target;} public void setTarget(String v){target=choice(v,"Players","Entities","Both");persist();}
    public boolean swingOnly(){return swingOnly;} public void setSwingOnly(boolean v){swingOnly=v;persist();}
}
