package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
public final class KillAura extends Module {
 private double range=3;private int cps=8;private String rotation="Smooth",target="Players";private boolean swingOnly;private long last;
 public KillAura(){super("kill_aura","KillAura",Category.COMBAT,false);}
 protected void loadSettings(){range=clamp(R1zzConfig.getDouble("kill_aura.range",3),2.5,6);cps=Math.max(1,Math.min(20,R1zzConfig.getInt("kill_aura.cps",8)));rotation=choice(R1zzConfig.get("kill_aura.rotation","Smooth"),"None","Smooth","Snap");target=choice(R1zzConfig.get("kill_aura.target","Players"),"Players","Entities","Both");swingOnly=R1zzConfig.getBoolean("kill_aura.swing_only",false);}
 protected void saveSettings(){R1zzConfig.put("kill_aura.range",range);R1zzConfig.put("kill_aura.cps",cps);R1zzConfig.put("kill_aura.rotation",rotation);R1zzConfig.put("kill_aura.target",target);R1zzConfig.put("kill_aura.swing_only",swingOnly);}
 protected void resetSettings(){range=3;cps=8;rotation="Smooth";target="Players";swingOnly=false;}
 public void onTick(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null||mc.currentScreen!=null||System.currentTimeMillis()-last<1000L/cps)return;LivingEntity t=CombatModuleUtil.nearest(mc,range,target.equals("Players"));if(t!=null&&(!swingOnly||mc.player.handSwinging)&&mc.player.getAttackCooldownProgress(0)>=.9f){CombatModuleUtil.attack(mc,t);last=System.currentTimeMillis();}}
 static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}static String choice(String v,String...a){for(String x:a)if(x.equals(v))return v;return a[0];}
 public double range(){return range;}public void setRange(double v){range=clamp(v,2.5,6);persist();}public int cps(){return cps;}public void setCps(int v){cps=Math.max(1,Math.min(20,v));persist();}public String rotation(){return rotation;}public void setRotation(String v){rotation=choice(v,"None","Smooth","Snap");persist();}public String target(){return target;}public void setTarget(String v){target=choice(v,"Players","Entities","Both");persist();}public boolean swingOnly(){return swingOnly;}public void setSwingOnly(boolean v){swingOnly=v;persist();}
}