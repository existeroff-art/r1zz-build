package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Watermark extends Module {
    public Watermark() { super("watermark", "Watermark", Category.RENDER, false); }
    private String position = "TopLeft";
    @Override protected void loadSettings() {
        position=R1zzConfig.get("watermark.position","TopLeft");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("watermark.position", position);
    }
    @Override protected void resetSettings() {
        position="TopLeft";
    }
    public String position() { return position; }
    public void setPosition(String v) { position=v == null ? "" : v; persist(); }
}
