package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Spam extends Module {
    public Spam() { super("spam", "Spam", Category.MISC, false); }
    private String message = "";
    private int delay = 1000;
    @Override protected void loadSettings() {
        message=R1zzConfig.get("spam.message","");
        delay=R1zzConfig.getInt("spam.delay",1000);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("spam.message", message);
        R1zzConfig.put("spam.delay", delay);
    }
    @Override protected void resetSettings() {
        message="";
        delay=1000;
    }
    public String message() { return message; }
    public void setMessage(String v) { message=v == null ? "" : v; persist(); }
    public int delay() { return delay; }
    public void setDelay(int v) { delay=Math.max(100,Math.min(10000,v)); persist(); }
}
