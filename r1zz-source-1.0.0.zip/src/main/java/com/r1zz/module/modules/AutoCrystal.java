package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class AutoCrystal extends Module {
    private double range = 4.5;
    private int ticks;
    public AutoCrystal() { super("auto_crystal", "AutoCrystal", Category.COMBAT, false); }
    @Override protected void loadSettings() { range = Math.max(3.0, Math.min(6.0, R1zzConfig.getDouble("auto_crystal.range", 4.5))); }
    @Override protected void saveSettings() { R1zzConfig.put("auto_crystal.range", range); }
    @Override protected void resetSettings() { range = 4.5; ticks = 0; }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (ticks > 0) { ticks--; return; }
        LivingEntity target = CombatModuleUtil.nearest(mc, range, true);
        if (target == null) return;
        int crystal = CombatModuleUtil.findHotbar(mc.player, Items.END_CRYSTAL);
        if (crystal < 0) return;
        BlockPos base = target.getBlockPos().down();
        if (!mc.world.getBlockState(base).isOf(net.minecraft.block.Blocks.OBSIDIAN) && !mc.world.getBlockState(base).isOf(net.minecraft.block.Blocks.BEDROCK)) return;
        int old = mc.player.getInventory().selectedSlot;
        CombatModuleUtil.select(mc.player, crystal);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(Vec3d.ofCenter(base).add(0, 1, 0), Direction.UP, base, false));
        CombatModuleUtil.select(mc.player, old);
        for (Entity e : mc.world.getOtherEntities(null, target.getBoundingBox().expand(3.0), e -> e instanceof EndCrystalEntity)) {
            if (e instanceof EndCrystalEntity crystalEntity && mc.player.distanceTo(crystalEntity) <= range + 1.5) {
                mc.interactionManager.attackEntity(mc.player, crystalEntity);
                mc.player.swingHand(Hand.MAIN_HAND);
                break;
            }
        }
        ticks = 4;
    }
    public double range() { return range; }
    public void setRange(double v) { range = Math.max(3.0, Math.min(6.0, v)); persist(); }
}
