package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
public final class AutoCrystal extends Module {
 private double range=4.5;private int ticks;
 public AutoCrystal(){super("auto_crystal","AutoCrystal",Category.COMBAT,false);}
 protected void loadSettings(){range=Math.max(3,Math.min(6,R1zzConfig.getDouble("auto_crystal.range",4.5)));}
 protected void saveSettings(){R1zzConfig.put("auto_crystal.range",range);}
 protected void resetSettings(){range=4.5;}
 public void onTick(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null)return;if(ticks>0){ticks--;return;}LivingEntity t=CombatModuleUtil.nearest(mc,range,true);if(t!=null&&CombatModuleUtil.findHotbar(mc.player,Items.END_CRYSTAL)>=0){int s=mc.player.getInventory().selectedSlot;int c=CombatModuleUtil.findHotbar(mc.player,Items.END_CRYSTAL);CombatModuleUtil.select(mc.player,c);if(mc.player.getAttackCooldownProgress(0)>=.9f)CombatModuleUtil.attack(mc,t);CombatModuleUtil.select(mc.player,s);ticks=4;}}
 public double range(){return range;}public void setRange(double v){range=Math.max(3,Math.min(6,v));persist();}
}