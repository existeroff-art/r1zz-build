package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
public final class AutoCity extends Module {
 private double range=4.5;
 public AutoCity(){super("auto_city","AutoCity",Category.COMBAT,false);}
 protected void loadSettings(){range=Math.max(3,Math.min(6,R1zzConfig.getDouble("auto_city.range",4.5)));}
 protected void saveSettings(){R1zzConfig.put("auto_city.range",range);}
 protected void resetSettings(){range=4.5;}
 public void onTick(){MinecraftClient mc=MinecraftClient.getInstance(); if(mc.player==null)return; /* tick-based combat placement/mine logic */}
 public double range(){return range;} public void setRange(double v){range=Math.max(3,Math.min(6,v));persist();}
}