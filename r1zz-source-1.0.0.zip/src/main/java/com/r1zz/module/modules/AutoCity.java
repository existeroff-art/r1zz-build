package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Mines one of the blocks surrounding the nearest player (their surround) with your best tool. */
public final class AutoCity extends Module {
    private double range = 4.5;
    private BlockPos mining;

    public AutoCity() { super("auto_city", "AutoCity", Category.COMBAT, false); }

    @Override protected void loadSettings() { range = Math.max(3, Math.min(6, R1zzConfig.getDouble("auto_city.range", 4.5))); }
    @Override protected void saveSettings() { R1zzConfig.put("auto_city.range", range); }
    @Override protected void resetSettings() { range = 4.5; mining = null; }
    @Override public void onDisable() { mining = null; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        LivingEntity target = CombatModuleUtil.nearest(mc, range + 2.0, true);
        if (target == null) { mining = null; return; }

        if (mining == null || !isMineable(mc, mining) || !CombatModuleUtil.reach(mc, mining, range)) {
            mining = null;
            BlockPos feet = target.getBlockPos();
            for (Direction d : Direction.Type.HORIZONTAL) {
                BlockPos pos = feet.offset(d);
                if (isMineable(mc, pos) && CombatModuleUtil.reach(mc, pos, range)) { mining = pos; break; }
            }
        }
        if (mining == null) return;

        BlockState state = mc.world.getBlockState(mining);
        CombatModuleUtil.select(mc.player, CombatModuleUtil.bestToolSlot(mc.player, state));
        mc.interactionManager.updateBlockBreakingProgress(mining, Direction.UP);
        mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
    }

    private boolean isMineable(MinecraftClient mc, BlockPos pos) {
        BlockState state = mc.world.getBlockState(pos);
        return !state.isAir() && !state.isReplaceable() && !state.isOf(Blocks.BEDROCK) && state.getHardness(mc.world, pos) >= 0.0f;
    }

    public double range() { return range; }
    public void setRange(double v) { range = Math.max(3, Math.min(6, v)); persist(); }
}
