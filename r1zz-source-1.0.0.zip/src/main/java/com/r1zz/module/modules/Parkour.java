package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Parkour extends Module {
    public Parkour() { super("parkour", "Parkour", Category.MOVEMENT, false); }
}
