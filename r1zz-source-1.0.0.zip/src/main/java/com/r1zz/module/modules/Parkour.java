package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Box;

/** Jumps automatically when you reach the edge of a block. */
public final class Parkour extends Module {
    public Parkour() { super("parkour", "Parkour", Category.MOVEMENT, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (!p.isOnGround() || p.isSneaking() || p.isTouchingWater() || p.isClimbing()) return;
        if (p.input.movementForward == 0.0f && p.input.movementSideways == 0.0f) return;
        // Box a hair narrower than the player, just under the feet: empty means the centre is past the edge.
        Box underFeet = p.getBoundingBox().offset(0.0, -0.5, 0.0).contract(0.28, 0.0, 0.28);
        if (mc.world.isSpaceEmpty(p, underFeet)) p.jump();
    }
}
