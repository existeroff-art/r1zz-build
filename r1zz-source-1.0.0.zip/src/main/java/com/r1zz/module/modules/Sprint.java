package com.r1zz.module.modules;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
public final class Sprint extends Module {
    public Sprint(){super("sprint","Sprint",Category.MOVEMENT,false);}
    @Override public void onTick(){var p=MinecraftClient.getInstance().player;if(p==null)return;if(p.input.movementForward>0.01f&&!p.isUsingItem())p.setSprinting(true);else if(p.input.movementForward<=0.01f)p.setSprinting(false);}
}
