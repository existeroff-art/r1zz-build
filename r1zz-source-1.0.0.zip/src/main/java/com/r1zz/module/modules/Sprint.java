package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

/** Sprints while moving forward. Respects hunger, blindness and item use, and starts a beat late like a real key press. */
public final class Sprint extends Module {
    private int startDelay;

    public Sprint() { super("sprint", "Sprint", Category.MOVEMENT, false); }

    @Override
    public void onDisable() { startDelay = 0; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.currentScreen != null) return;
            boolean canSprint = p.input.movementForward > 0.01f
                    && !p.isUsingItem()
                    && !p.horizontalCollision
                    && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                    && p.getHungerManager().getFoodLevel() > 6;
            if (canSprint) {
                if (!p.isSprinting()) {
                    if (startDelay == 0) startDelay = Humanizer.ticks(1, 3);
                    if (--startDelay > 0) return;
                    p.setSprinting(true);
                    startDelay = 0;
                }
            } else {
                startDelay = 0;
                if (p.input.movementForward <= 0.01f) p.setSprinting(false);
            }
        } catch (RuntimeException ignored) { }
    }
}
