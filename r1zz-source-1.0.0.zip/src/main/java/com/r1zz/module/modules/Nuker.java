package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.Comparator;
import java.util.Locale;

public final class Nuker extends Module {
    public Nuker() { super("nuker", "Nuker", Category.WORLD, false); }
    private double radius = 3;
    private String target = "All";
    @Override protected void loadSettings() {
        radius=R1zzConfig.getDouble("nuker.radius",3);
        target=R1zzConfig.get("nuker.target","All");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("nuker.radius", radius);
        R1zzConfig.put("nuker.target", target);
    }
    @Override protected void resetSettings() {
        radius=3;
        target="All";
    }

    /** Breaks the nearest matching block inside the radius. Target is "All" or comma separated block names. */
    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        BlockPos origin = mc.player.getBlockPos();
        int r = (int) Math.ceil(radius);
        BlockPos best = BlockPos.stream(origin.add(-r, -r, -r), origin.add(r, r, r))
                .map(BlockPos::toImmutable)
                .filter(p -> CombatModuleUtil.reach(mc, p, Math.min(radius, 5.0)) && matches(mc, p))
                .min(Comparator.comparingDouble(p -> mc.player.getEyePos().squaredDistanceTo(net.minecraft.util.math.Vec3d.ofCenter(p))))
                .orElse(null);
        if (best == null) return;
        BlockState state = mc.world.getBlockState(best);
        CombatModuleUtil.select(mc.player, CombatModuleUtil.bestToolSlot(mc.player, state));
        mc.interactionManager.updateBlockBreakingProgress(best, Direction.UP);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private boolean matches(MinecraftClient mc, BlockPos pos) {
        BlockState state = mc.world.getBlockState(pos);
        if (state.isAir() || state.isReplaceable() || state.getHardness(mc.world, pos) < 0.0f) return false;
        if (target == null || target.isBlank() || target.equalsIgnoreCase("All")) return true;
        String id = Registries.BLOCK.getId(state.getBlock()).getPath();
        for (String raw : target.toLowerCase(Locale.ROOT).split(",")) {
            String token = raw.trim().replace("minecraft:", "").replace(' ', '_');
            if (!token.isEmpty() && id.contains(token)) return true;
        }
        return false;
    }

    public double radius() { return radius; }
    public void setRadius(double v) { radius=Math.max(1,Math.min(6,v)); persist(); }
    public String target() { return target; }
    public void setTarget(String v) { target=v == null ? "" : v; persist(); }
}
