package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class Nuker extends Module {
    public Nuker() { super("nuker", "Nuker", Category.WORLD, false); }
    private double radius = 3;
    private String target = "All";
    @Override protected void loadSettings() {
        radius=R1zzConfig.getDouble("nuker.radius",3);
        target=R1zzConfig.get("nuker.target","All");
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("nuker.radius", radius);
        R1zzConfig.put("nuker.target", target);
    }
    @Override protected void resetSettings() {
        radius=3;
        target="All";
    }
    public double radius() { return radius; }
    public void setRadius(double v) { radius=Math.max(1,Math.min(6,v)); persist(); }
    public String target() { return target; }
    public void setTarget(String v) { target=v == null ? "" : v; persist(); }
}
