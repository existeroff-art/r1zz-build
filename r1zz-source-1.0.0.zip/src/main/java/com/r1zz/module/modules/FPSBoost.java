package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class FPSBoost extends Module {
    public FPSBoost() { super("f_p_s_boost", "FPSBoost", Category.RENDER, false); }
}
