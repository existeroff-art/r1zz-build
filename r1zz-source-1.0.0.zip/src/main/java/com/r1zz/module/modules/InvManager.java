package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class InvManager extends Module {
    public InvManager() { super("inv_manager", "InvManager", Category.PLAYER, false); }
}
