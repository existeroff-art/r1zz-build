package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.screen.slot.SlotActionType;

/** While your inventory is open, moves the best sword from the main inventory into hotbar slot 1. */
public final class InvManager extends Module {
    private int cooldown;

    public InvManager() { super("inv_manager", "InvManager", Category.PLAYER, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null || !(mc.currentScreen instanceof InventoryScreen)) return;
        if (cooldown > 0) { cooldown--; return; }
        int current = CombatModuleUtil.weaponRank(mc.player.getInventory().getStack(0).getItem());
        int best = -1, bestRank = current;
        for (int i = 9; i < 36; i++) {
            net.minecraft.item.Item item = mc.player.getInventory().getStack(i).getItem();
            if (!CombatModuleUtil.isSword(item)) continue;
            int rank = CombatModuleUtil.weaponRank(item);
            if (rank > bestRank) { bestRank = rank; best = i; }
        }
        if (best < 0) return;
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, best, 0, SlotActionType.SWAP, mc.player);
        cooldown = 5;
    }
}
