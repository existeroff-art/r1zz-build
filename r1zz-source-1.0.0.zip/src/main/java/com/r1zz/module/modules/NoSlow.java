package com.r1zz.module.modules;

import com.r1zz.module.Module;

public final class NoSlow extends Module {
    public NoSlow(){super("no_slow","NoSlow",Category.MOVEMENT,false);}
}
