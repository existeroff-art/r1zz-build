package com.r1zz.module.modules;

import com.r1zz.module.Module;
import com.r1zz.config.R1zzSettings;

public final class NoSlow extends Module {
    public NoSlow(){super("no_slow","NoSlow",Category.MOVEMENT,false);}
    @Override public void onTick(){ R1zzSettings.syncToModule(this); }
}
