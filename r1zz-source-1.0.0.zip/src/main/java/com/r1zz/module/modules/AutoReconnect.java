package com.r1zz.module.modules;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.ServerAddress;
public final class AutoReconnect extends Module {
    private int ticks;
    public AutoReconnect(){super("auto_reconnect","AutoReconnect",Category.MISC,false);}
    @Override public void onTick(){var mc=MinecraftClient.getInstance();if(!(mc.currentScreen instanceof DisconnectedScreen)||mc.getCurrentServerEntry()==null){ticks=0;return;}if(++ticks>=100){ticks=0;var s=mc.getCurrentServerEntry();ConnectScreen.connect(mc.currentScreen,mc,ServerAddress.parse(s.address),s,false,null);}}
}
