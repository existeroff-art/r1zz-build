package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/** Disconnects from the server when health falls to the threshold, then switches itself off. */
public final class AutoLog extends Module {
    private double hpThreshold = 6;

    public AutoLog() { super("auto_log", "AutoLog", Category.PLAYER, false); }

    @Override protected void loadSettings() { hpThreshold = R1zzConfig.getDouble("auto_log.hpThreshold", 6); }
    @Override protected void saveSettings() { R1zzConfig.put("auto_log.hpThreshold", hpThreshold); }
    @Override protected void resetSettings() { hpThreshold = 6; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.player.networkHandler == null) return;
        if (mc.player.isDead() || mc.player.getHealth() > hpThreshold) return;
        mc.player.networkHandler.getConnection().disconnect(Text.literal("[R1zz] AutoLog: health at " + Math.round(mc.player.getHealth()) + " (threshold " + Math.round(hpThreshold) + ")"));
        setEnabled(false);
    }

    public double hpThreshold() { return hpThreshold; }
    public void setHpThreshold(double v) { hpThreshold = Math.max(1, Math.min(20, v)); persist(); }
}
