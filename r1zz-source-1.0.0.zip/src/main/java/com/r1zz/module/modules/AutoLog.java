package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoLog extends Module {
    public AutoLog() { super("auto_log", "AutoLog", Category.PLAYER, false); }
    private double hpThreshold = 6;
    @Override protected void loadSettings() {
        hpThreshold=R1zzConfig.getDouble("auto_log.hpThreshold",6);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("auto_log.hpThreshold", hpThreshold);
    }
    @Override protected void resetSettings() {
        hpThreshold=6;
    }
    public double hpThreshold() { return hpThreshold; }
    public void setHpThreshold(double v) { hpThreshold=Math.max(1,Math.min(20,v)); persist(); }
}
