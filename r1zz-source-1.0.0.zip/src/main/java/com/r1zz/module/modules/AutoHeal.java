package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoHeal extends Module {
    public AutoHeal() { super("auto_heal", "AutoHeal", Category.PLAYER, false); }
    private double hpThreshold = 12;
    @Override protected void loadSettings() {
        hpThreshold=R1zzConfig.getDouble("auto_heal.hpThreshold",12);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("auto_heal.hpThreshold", hpThreshold);
    }
    @Override protected void resetSettings() {
        hpThreshold=12;
    }
    public double hpThreshold() { return hpThreshold; }
    public void setHpThreshold(double v) { hpThreshold=Math.max(1,Math.min(20,v)); persist(); }
}
