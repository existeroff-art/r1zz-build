package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Below the HP threshold: eats a golden apple, otherwise uses a healing potion. */
public final class AutoHeal extends Module {
    private double hpThreshold = 12;
    private long lastUse;
    private final HoldUse holdUse = new HoldUse();

    public AutoHeal() { super("auto_heal", "AutoHeal", Category.PLAYER, false); }

    @Override protected void loadSettings() { hpThreshold = R1zzConfig.getDouble("auto_heal.hpThreshold", 12); }
    @Override protected void saveSettings() { R1zzConfig.put("auto_heal.hpThreshold", hpThreshold); }
    @Override protected void resetSettings() { hpThreshold = 12; lastUse = 0; }
    @Override public void onDisable() { holdUse.end(MinecraftClient.getInstance()); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null || mc.options == null) return;
        if (holdUse.tick(mc)) return;
        if (mc.currentScreen != null || mc.player.isUsingItem()) return;
        if (mc.player.getHealth() > hpThreshold || System.currentTimeMillis() - lastUse < 1200L) return;

        int gapple = CombatModuleUtil.findHotbarAny(mc.player, Items.ENCHANTED_GOLDEN_APPLE, Items.GOLDEN_APPLE);
        if (gapple >= 0) {
            holdUse.begin(mc, gapple);
            lastUse = System.currentTimeMillis();
            return;
        }
        int splash = -1, drink = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!CombatModuleUtil.isHealingPotion(stack)) continue;
            if (stack.isOf(Items.SPLASH_POTION) && splash < 0) splash = i;
            if (stack.isOf(Items.POTION) && drink < 0) drink = i;
        }
        if (splash >= 0) {
            int old = mc.player.getInventory().selectedSlot;
            float pitch = mc.player.getPitch();
            CombatModuleUtil.select(mc.player, splash);
            mc.player.setPitch(90.0f);
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.player.setPitch(pitch);
            CombatModuleUtil.select(mc.player, old);
            lastUse = System.currentTimeMillis();
        } else if (drink >= 0) {
            holdUse.begin(mc, drink);
            lastUse = System.currentTimeMillis();
        }
    }

    public double hpThreshold() { return hpThreshold; }
    public void setHpThreshold(double v) { hpThreshold = Math.max(1, Math.min(20, v)); persist(); }
}
