package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
public final class AnchorAura extends Module {
 private double range=4.5;
 public AnchorAura(){super("anchor_aura","AnchorAura",Category.COMBAT,false);}
 protected void loadSettings(){range=Math.max(3,Math.min(6,R1zzConfig.getDouble("anchor_aura.range",4.5)));}
 protected void saveSettings(){R1zzConfig.put("anchor_aura.range",range);}
 protected void resetSettings(){range=4.5;}
 public void onTick(){MinecraftClient mc=MinecraftClient.getInstance(); if(mc.player==null)return; /* Nether/end only */}
 public double range(){return range;} public void setRange(double v){range=Math.max(3,Math.min(6,v));persist();}
}