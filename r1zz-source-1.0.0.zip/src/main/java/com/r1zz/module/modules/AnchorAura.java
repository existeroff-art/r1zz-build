package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Places, charges and detonates a respawn anchor above the nearest player (only where anchors explode). */
public final class AnchorAura extends Module {
    private double range = 4.5;
    private int ticks;

    public AnchorAura() { super("anchor_aura", "AnchorAura", Category.COMBAT, false); }

    @Override protected void loadSettings() { range = Math.max(3, Math.min(6, R1zzConfig.getDouble("anchor_aura.range", 4.5))); }
    @Override protected void saveSettings() { R1zzConfig.put("anchor_aura.range", range); }
    @Override protected void resetSettings() { range = 4.5; ticks = 0; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (ticks > 0) { ticks--; return; }
        // In the Nether anchors are only spawn points, they do not explode.
        if (mc.world.getDimension().respawnAnchorWorks()) return;
        LivingEntity target = CombatModuleUtil.nearest(mc, range, true);
        if (target == null) return;

        BlockPos pos = target.getBlockPos().up(2);
        BlockState state = mc.world.getBlockState(pos);
        if (state.isOf(net.minecraft.block.Blocks.RESPAWN_ANCHOR)) {
            // Never blow one up right next to yourself.
            if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) < 16.0) return;
            int charges = state.get(RespawnAnchorBlock.CHARGES);
            int old = mc.player.getInventory().selectedSlot;
            if (charges == 0) {
                int glow = CombatModuleUtil.findHotbar(mc.player, Items.GLOWSTONE);
                if (glow < 0) return;
                CombatModuleUtil.select(mc.player, glow);
                click(mc, pos);
                CombatModuleUtil.select(mc.player, old);
                ticks = 2;
            } else {
                int safe = old;
                if (mc.player.getInventory().getStack(old).isOf(Items.GLOWSTONE)) {
                    safe = -1;
                    for (int i = 0; i < 9; i++) if (!mc.player.getInventory().getStack(i).isOf(Items.GLOWSTONE)) { safe = i; break; }
                }
                if (safe < 0) return;
                CombatModuleUtil.select(mc.player, safe);
                click(mc, pos);
                CombatModuleUtil.select(mc.player, old);
                ticks = 6;
            }
        } else if (state.isReplaceable() && CombatModuleUtil.reach(mc, pos, 5.0)) {
            int anchor = CombatModuleUtil.findHotbar(mc.player, Items.RESPAWN_ANCHOR);
            if (anchor >= 0 && CombatModuleUtil.placeWithSlot(mc, pos, anchor)) ticks = 2;
        }
    }

    private void click(MinecraftClient mc, BlockPos pos) {
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(Vec3d.ofCenter(pos).add(0.0, 0.5, 0.0), Direction.UP, pos, false));
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    public double range() { return range; }
    public void setRange(double v) { range = Math.max(3, Math.min(6, v)); persist(); }
}
