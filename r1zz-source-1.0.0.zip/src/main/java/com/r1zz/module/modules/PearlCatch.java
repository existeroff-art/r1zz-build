package com.r1zz.module.modules;
import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
public final class PearlCatch extends Module {
 private int delay=2,ticks=-1,restore=-1;
 public PearlCatch(){super("pearl_catch","Pearl Catch",Category.COMBAT,false);}
 protected void loadSettings(){delay=Math.max(0,Math.min(10,R1zzConfig.getInt("pearl_catch.delay",2)));}
 protected void saveSettings(){R1zzConfig.put("pearl_catch.delay",delay);}
 protected void resetSettings(){delay=2;}
 public void onTick(){MinecraftClient mc=MinecraftClient.getInstance();if(mc.player==null)return;
  if(ticks>=0&&--ticks<0){int s=CombatModuleUtil.findHotbar(mc.player,Items.WIND_CHARGE);if(s>=0){restore=mc.player.getInventory().selectedSlot;CombatModuleUtil.select(mc.player,s);if(mc.interactionManager!=null)mc.interactionManager.interactItem(mc.player,net.minecraft.util.Hand.MAIN_HAND);}}
  if(restore>=0&&ticks<0){CombatModuleUtil.select(mc.player,restore);restore=-1;}
  if(ticks<0&&mc.player.getMainHandStack().isOf(Items.ENDER_PEARL)&&mc.player.isUsingItem())ticks=delay;}
 public int delay(){return delay;} public void setDelay(int v){delay=Math.max(0,Math.min(10,v));persist();}
}