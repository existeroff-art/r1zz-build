package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class PearlCatch extends Module {
    private int window = 30;
    private boolean autoAim = true;
    private int delay = 2;

    private int windowTicks;
    private int delayTicks;
    private Entity trackedPearl;
    private final List<Entity> pearls = new ArrayList<>();

    public PearlCatch() {
        super("pearl_catch", "PearlCatch", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        window = MathHelper.clamp(R1zzConfig.getInt("pearl_catch.window", 30), 10, 40);
        autoAim = R1zzConfig.getBoolean("pearl_catch.auto_aim", true);
        delay = MathHelper.clamp(R1zzConfig.getInt("pearl_catch.delay", 2), 0, 5);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("pearl_catch.window", window);
        R1zzConfig.put("pearl_catch.auto_aim", autoAim);
        R1zzConfig.put("pearl_catch.delay", delay);
    }

    @Override
    protected void resetSettings() {
        window = 30;
        autoAim = true;
        delay = 2;
        resetState();
    }

    @Override
    public void onDisable() {
        resetState();
        pearls.clear();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;

        pearls.removeIf(e -> e == null || e.isRemoved());
        discoverPearls(mc);

        if (trackedPearl != null) {
            double maxDistance = Math.max(32.0, window + 8.0);
            if (!trackedPearl.isAlive() || trackedPearl.isRemoved()
                    || mc.player.distanceTo(trackedPearl) > maxDistance) {
                resetState();
                return;
            }
        }

        if (trackedPearl == null) {
            trackedPearl = pearls.stream()
                    .filter(Entity::isAlive)
                    .filter(e -> e instanceof EnderPearlEntity)
                    .filter(e -> ((EnderPearlEntity) e).getOwner() == mc.player)
                    .min(Comparator.comparingDouble(mc.player::distanceTo))
                    .orElse(null);
            if (trackedPearl != null) {
                windowTicks = window;
                delayTicks = delay;
            }
        }

        if (trackedPearl == null) return;
        if (windowTicks <= 0) {
            resetState();
            return;
        }
        windowTicks--;

        // The macro's sequence is pearl first, then wind charge. The R1zz module
        // never sends a chat command and never throws either item automatically.
        if (!mc.player.getMainHandStack().isOf(Items.WIND_CHARGE)) return;

        if (delayTicks > 0) {
            delayTicks--;
            return;
        }

        if (autoAim) aimAtPearl(mc, trackedPearl.getPos());
    }

    private void discoverPearls(MinecraftClient mc) {
        for (EnderPearlEntity pearl : mc.world.getEntitiesByClass(
                EnderPearlEntity.class,
                mc.player.getBoundingBox().expand(32.0),
                p -> p.isAlive() && p.getOwner() == mc.player)) {
            if (!pearls.contains(pearl)) pearls.add(pearl);
        }
    }

    private void aimAtPearl(MinecraftClient mc, Vec3d target) {
        Vec3d diff = target.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();
        float speedFactor = 0.55f;
        float yawStep = (float) (yawDelta * (1.0 - Math.exp(-speedFactor)));
        float pitchStep = (float) (pitchDelta * (1.0 - Math.exp(-speedFactor)));

        float yawCap = 45.0f;
        float pitchCap = 25.0f;
        yawStep = MathHelper.clamp(yawStep, -yawCap, yawCap);
        pitchStep = MathHelper.clamp(pitchStep, -pitchCap, pitchCap);

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    private void resetState() {
        trackedPearl = null;
        windowTicks = 0;
        delayTicks = 0;
    }

    public int window() { return window; }
    public void setWindow(int value) { window = MathHelper.clamp(value, 10, 40); persist(); }
    public boolean autoAim() { return autoAim; }
    public void setAutoAim(boolean value) { autoAim = value; persist(); }
    public int delay() { return delay; }
    public void setDelay(int value) { delay = MathHelper.clamp(value, 0, 5); persist(); }
}
