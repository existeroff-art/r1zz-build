package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

public final class PearlCatch extends Module {
    private enum State { IDLE, PEARL_THROWN, WAITING_FOR_WIND_CHARGE, AIM_AT_PEARL }
    private int window=30, delay=2;
    private boolean autoAim=true;
    private State state=State.IDLE;
    private int windowTicks, aimDelay;
    private EnderPearlEntity trackedPearl;
    private final Set<Entity> knownPearls=new HashSet<>();

    public PearlCatch(){super("pearl_catch","Pearl Catch",Category.COMBAT,false);}
    @Override protected void loadSettings(){
        window=MathHelper.clamp(R1zzConfig.getInt("pearl_catch.window",30),10,40);
        autoAim=R1zzConfig.getBoolean("pearl_catch.auto_aim",true);
        delay=MathHelper.clamp(R1zzConfig.getInt("pearl_catch.delay",2),0,5);
    }
    @Override protected void saveSettings(){
        R1zzConfig.put("pearl_catch.window",window);R1zzConfig.put("pearl_catch.auto_aim",autoAim);R1zzConfig.put("pearl_catch.delay",delay);
    }
    @Override protected void resetSettings(){window=30;autoAim=true;delay=2;resetState();}
    @Override public void onDisable(){resetState();knownPearls.clear();}

    @Override public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.world==null||mc.interactionManager==null||mc.currentScreen!=null)return;

        EnderPearlEntity newest=findNewPearl(mc);
        if(state==State.IDLE && newest!=null){
            trackedPearl=newest;windowTicks=window;aimDelay=delay;state=State.PEARL_THROWN;
        }
        if(trackedPearl!=null && (!trackedPearl.isAlive() || mc.player.distanceTo(trackedPearl)>64)){
            resetState();return;
        }
        if(state==State.PEARL_THROWN){
            state=State.WAITING_FOR_WIND_CHARGE;
        }
        if(state==State.WAITING_FOR_WIND_CHARGE){
            if(--windowTicks<0){resetState();return;}
            if(mc.player.getMainHandStack().isOf(Items.WIND_CHARGE)){
                state=State.AIM_AT_PEARL;aimDelay=delay;
            }
        }
        if(state==State.AIM_AT_PEARL){
            if(trackedPearl==null||!trackedPearl.isAlive()){resetState();return;}
            if(!mc.player.getMainHandStack().isOf(Items.WIND_CHARGE)){state=State.WAITING_FOR_WIND_CHARGE;return;}
            if(autoAim)aimAt(mc,trackedPearl.getPos());
            if(aimDelay>0)aimDelay--;
            // Keep aiming while the wind charge is held; the actual right-click remains the user's throw.
        }
        knownPearls.removeIf(e->e==null||e.isRemoved());
    }

    private EnderPearlEntity findNewPearl(MinecraftClient mc){
        return mc.world.getEntitiesByClass(EnderPearlEntity.class,mc.player.getBoundingBox().expand(64),
                p->p.isAlive()&&!knownPearls.contains(p)&&p.getOwner()==mc.player)
                .stream().min(Comparator.comparingDouble(mc.player::distanceTo)).map(p->{knownPearls.add(p);return p;}).orElse(null);
    }
    private void aimAt(MinecraftClient mc,Vec3d target){
        Vec3d d=target.subtract(mc.player.getEyePos());double h=Math.sqrt(d.x*d.x+d.z*d.z);
        float yaw=(float)(Math.toDegrees(Math.atan2(d.z,d.x))-90),pitch=(float)-Math.toDegrees(Math.atan2(d.y,h));
        float ys=MathHelper.wrapDegrees(yaw-mc.player.getYaw())*.55f;
        float ps=(pitch-mc.player.getPitch())*.55f;
        float sens=mc.options.getMouseSensitivity().getValue().floatValue(),f=sens*.6f+.2f,gcd=f*f*f*1.2f;
        if(gcd>0){ys=Math.round(ys/gcd)*gcd;ps=Math.round(ps/gcd)*gcd;}
        mc.player.setYaw(mc.player.getYaw()+MathHelper.clamp(ys,-28,28));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch()+MathHelper.clamp(ps,-16,16),-90,90));
    }
    private void resetState(){state=State.IDLE;windowTicks=0;aimDelay=0;trackedPearl=null;}
    public int window(){return window;} public void setWindow(int v){window=MathHelper.clamp(v,10,40);persist();}
    public boolean autoAim(){return autoAim;} public void setAutoAim(boolean v){autoAim=v;persist();}
    public int delay(){return delay;} public void setDelay(int v){delay=MathHelper.clamp(v,0,5);persist();}
}
