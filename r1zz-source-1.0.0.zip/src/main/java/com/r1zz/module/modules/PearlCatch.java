package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Assists the wind-charge -> ender-pearl catch timing. */
public final class PearlCatch extends Module {
    private enum State { IDLE, WIND_CHARGE_THROWN, WAITING_FOR_PEARL, AIMING, COOLDOWN }

    private int window = 20;
    private boolean autoAim = true;
    private int delay = 1;
    private State state = State.IDLE;
    private int windowTicks;
    private int aimDelay;
    private int cooldownTicks;
    private boolean wasUsingWind;
    private boolean wasUsingPearl;
    private Vec3d windOrigin;
    private Vec3d windVelocity;
    private Vec3d expectedPosition;

    public PearlCatch() {
        super("pearl_catch", "Pearl Catch", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        window = MathHelper.clamp(R1zzConfig.getInt("pearl_catch.window", 20), 10, 30);
        autoAim = R1zzConfig.getBoolean("pearl_catch.auto_aim", true);
        delay = MathHelper.clamp(R1zzConfig.getInt("pearl_catch.delay", 1), 0, 5);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("pearl_catch.window", window);
        R1zzConfig.put("pearl_catch.auto_aim", autoAim);
        R1zzConfig.put("pearl_catch.delay", delay);
    }

    @Override
    protected void resetSettings() {
        window = 20;
        autoAim = true;
        delay = 1;
        resetState();
    }

    @Override
    public void onDisable() {
        resetState();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        boolean usingWind = mc.player.getMainHandStack().isOf(Items.WIND_CHARGE) && mc.player.isUsingItem();
        boolean usingPearl = mc.player.getMainHandStack().isOf(Items.ENDER_PEARL) && mc.player.isUsingItem();

        if (state == State.COOLDOWN) {
            if (cooldownTicks > 0) cooldownTicks--;
            if (cooldownTicks <= 0) resetState();
        }

        if ((state == State.IDLE || state == State.COOLDOWN) && usingWind && !wasUsingWind) {
            recordWindCharge(mc);
        }

        if (state == State.WIND_CHARGE_THROWN) {
            if (!usingWind || mc.player.getMainHandStack().getCount() < 1) {
                state = State.WAITING_FOR_PEARL;
            }
        }

        if (state == State.WAITING_FOR_PEARL) {
            if (--windowTicks < 0) {
                resetState();
            } else if (usingPearl && !wasUsingPearl) {
                state = State.AIMING;
                aimDelay = delay;
            }
        }

        if (state == State.AIMING) {
            if (!mc.player.getMainHandStack().isOf(Items.ENDER_PEARL)) {
                resetState();
            } else {
                if (autoAim && expectedPosition != null) aimAt(mc, expectedPosition);
                if (aimDelay > 0) aimDelay--;
                else if (!autoAim || aimDelay <= 0) {
                    state = State.COOLDOWN;
                    cooldownTicks = 10;
                }
            }
        }

        wasUsingWind = usingWind;
        wasUsingPearl = usingPearl;
    }

    private void recordWindCharge(MinecraftClient mc) {
        windOrigin = mc.player.getEyePos();
        Vec3d direction = mc.player.getRotationVec(1.0f).normalize();
        windVelocity = direction.multiply(1.5);
        expectedPosition = windOrigin.add(windVelocity.multiply(3.0));
        windowTicks = window;
        aimDelay = delay;
        state = State.WIND_CHARGE_THROWN;
    }

    private void aimAt(MinecraftClient mc, Vec3d target) {
        Vec3d diff = target.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));
        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();
        float smooth = 0.55f;
        float yawStep = MathHelper.clamp(yawDelta * smooth, -45.0f, 45.0f);
        float pitchStep = MathHelper.clamp(pitchDelta * smooth, -25.0f, 25.0f);
        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }
        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    private void resetState() {
        state = State.IDLE;
        windowTicks = 0;
        aimDelay = 0;
        cooldownTicks = 0;
        wasUsingWind = false;
        wasUsingPearl = false;
        windOrigin = null;
        windVelocity = null;
        expectedPosition = null;
    }

    public int window() { return window; }
    public void setWindow(int value) { window = MathHelper.clamp(value, 10, 30); persist(); }
    public boolean autoAim() { return autoAim; }
    public void setAutoAim(boolean value) { autoAim = value; persist(); }
    public int delay() { return delay; }
    public void setDelay(int value) { delay = MathHelper.clamp(value, 0, 5); persist(); }
}
