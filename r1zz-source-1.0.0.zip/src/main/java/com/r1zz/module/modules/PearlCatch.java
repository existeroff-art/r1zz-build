package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * 1) You throw an ender pearl (pearl in main hand, use completes -> item cooldown starts).
 * 2) The pearl entity within 5 blocks is remembered in flyingPearls.
 * 3) While you right-click a wind charge and a pearl is still flying, the view is steered toward it
 *    with GCD-aligned, speed-capped rotation steps.
 */
public final class PearlCatch extends Module {
    private int window = 30;
    private boolean autoAim = true;
    private int delay = 2;

    private boolean pearlCooldownLast;
    private boolean useDownLast;
    private boolean aiming;
    private int windowTicks;
    private int delayTicks;
    private int throwWatchTicks;
    private final List<Entity> flyingPearls = new ArrayList<>();

    public PearlCatch() {
        super("pearl_catch", "PearlCatch", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        window = MathHelper.clamp(R1zzConfig.getInt("pearl_catch.window", 30), 10, 40);
        autoAim = R1zzConfig.getBoolean("pearl_catch.auto_aim", true);
        delay = MathHelper.clamp(R1zzConfig.getInt("pearl_catch.delay", 2), 0, 5);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("pearl_catch.window", window);
        R1zzConfig.put("pearl_catch.auto_aim", autoAim);
        R1zzConfig.put("pearl_catch.delay", delay);
    }

    @Override
    protected void resetSettings() {
        window = 30;
        autoAim = true;
        delay = 2;
        resetState();
    }

    @Override
    public void onEnable() {
        resetState();
    }

    @Override
    public void onDisable() {
        resetState();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (mc.player == null || mc.world == null || mc.options == null) {
                resetState();
                return;
            }

            flyingPearls.removeIf(e -> e == null || e.isRemoved());

            boolean useDown = mc.options.useKey.isPressed();
            boolean useEdge = useDown && !useDownLast;
            useDownLast = useDown;
            boolean pearlInHand = mc.player.getMainHandStack().isOf(Items.ENDER_PEARL);
            boolean windInHand = mc.player.getMainHandStack().isOf(Items.WIND_CHARGE);

            // Throw completed: the pearl item goes on cooldown the moment it leaves the hand.
            boolean pearlCooling = mc.player.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL);
            if (pearlCooling && !pearlCooldownLast && (pearlInHand || throwWatchTicks == 0)) throwWatchTicks = 6;
            pearlCooldownLast = pearlCooling;

            if (throwWatchTicks > 0) {
                discoverNearbyPearls(mc);
                if (!flyingPearls.isEmpty()) windowTicks = window;
                throwWatchTicks--;
            }

            if (mc.currentScreen != null) return;

            if (windowTicks > 0 && --windowTicks == 0) {
                flyingPearls.clear();
                aiming = false;
                delayTicks = 0;
            }
            if (flyingPearls.isEmpty()) {
                aiming = false;
                return;
            }

            // Right-click with a wind charge while a pearl is airborne starts the catch.
            if (!aiming && windInHand && useEdge) {
                aiming = true;
                delayTicks = delay;
            }
            if (!aiming) return;
            if (!windInHand || !useDown) {
                aiming = false;
                return;
            }
            if (delayTicks > 0) {
                delayTicks--;
                return;
            }
            if (autoAim) {
                CombatModuleUtil.rotateToward(mc, flyingPearls.get(0).getPos(), 0.55f, 18.0f, 12.0f);
            }
        } catch (RuntimeException e) {
            resetState();
        }
    }

    /** Pearls within 5 blocks of the player thrown by the player (owner may still be unsynced right after the throw). */
    private void discoverNearbyPearls(MinecraftClient mc) {
        List<EnderPearlEntity> found = mc.world.getEntitiesByClass(
                EnderPearlEntity.class,
                mc.player.getBoundingBox().expand(5.0),
                pearl -> !pearl.isRemoved() && (pearl.getOwner() == mc.player || pearl.getOwner() == null));
        for (EnderPearlEntity pearl : found) {
            if (!flyingPearls.contains(pearl)) flyingPearls.add(pearl);
        }
    }

    private void resetState() {
        pearlCooldownLast = false;
        useDownLast = false;
        aiming = false;
        windowTicks = 0;
        delayTicks = 0;
        throwWatchTicks = 0;
        flyingPearls.clear();
    }

    public int window() { return window; }
    public void setWindow(int value) { window = MathHelper.clamp(value, 10, 40); persist(); }
    public boolean autoAim() { return autoAim; }
    public void setAutoAim(boolean value) { autoAim = value; persist(); }
    public int delay() { return delay; }
    public void setDelay(int value) { delay = MathHelper.clamp(value, 0, 5); persist(); }
}
