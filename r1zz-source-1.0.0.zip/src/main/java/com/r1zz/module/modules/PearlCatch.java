package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public final class PearlCatch extends Module {
    private enum State { IDLE, PEARL_THROWN, WAITING, SWAP, USE, REVERT }
    private int delay = 2;
    private State state = State.IDLE;
    private int ticks;
    private int originalSlot = -1;

    public PearlCatch() { super("pearl_catch", "Pearl Catch", Category.COMBAT, false); }
    @Override protected void loadSettings() { delay = Math.max(0, Math.min(10, R1zzConfig.getInt("pearl_catch.delay", 2))); }
    @Override protected void saveSettings() { R1zzConfig.put("pearl_catch.delay", delay); }
    @Override protected void resetSettings() { delay = 2; state = State.IDLE; ticks = 0; originalSlot = -1; }

    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && originalSlot >= 0) CombatModuleUtil.select(mc.player, originalSlot);
        state = State.IDLE; ticks = 0; originalSlot = -1;
    }

    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        switch (state) {
            case IDLE -> {
                if (mc.player.getMainHandStack().isOf(Items.ENDER_PEARL) && mc.player.isUsingItem()) state = State.PEARL_THROWN;
            }
            case PEARL_THROWN -> {
                if (!mc.player.isUsingItem()) { ticks = delay; state = State.WAITING; }
            }
            case WAITING -> {
                if (ticks > 0) { ticks--; } else state = State.SWAP;
            }
            case SWAP -> {
                int wind = CombatModuleUtil.findHotbar(mc.player, Items.WIND_CHARGE);
                if (wind < 0) { state = State.IDLE; break; }
                originalSlot = mc.player.getInventory().selectedSlot;
                CombatModuleUtil.select(mc.player, wind);
                state = State.USE;
            }
            case USE -> {
                if (mc.interactionManager != null) mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                state = State.REVERT;
            }
            case REVERT -> {
                if (originalSlot >= 0) CombatModuleUtil.select(mc.player, originalSlot);
                originalSlot = -1; state = State.IDLE;
            }
        }
    }
    public int delay() { return delay; }
    public void setDelay(int v) { delay = Math.max(0, Math.min(10, v)); persist(); }
}
