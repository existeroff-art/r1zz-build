package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class PearlCatch extends Module {
    private enum State { IDLE, PEARL_FLYING, AIMING }

    private int window = 30;
    private boolean autoAim = true;
    private int delay = 2;

    private State state = State.IDLE;
    private final List<Entity> flyingPearls = new ArrayList<>();
    private int windowTicks;
    private int delayTicks;
    private int throwWatchTicks;
    private int lastUseTime;
    private boolean lastUseDown;

    public PearlCatch() {
        super("pearl_catch", "PearlCatch", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        window = MathHelper.clamp(R1zzConfig.getInt("pearl_catch.window", 30), 10, 40);
        autoAim = R1zzConfig.getBoolean("pearl_catch.auto_aim", true);
        delay = MathHelper.clamp(R1zzConfig.getInt("pearl_catch.delay", 2), 0, 5);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("pearl_catch.window", window);
        R1zzConfig.put("pearl_catch.auto_aim", autoAim);
        R1zzConfig.put("pearl_catch.delay", delay);
    }

    @Override
    protected void resetSettings() {
        window = 30;
        autoAim = true;
        delay = 2;
        resetState();
    }

    @Override
    public void onEnable() {
        resetState();
    }

    @Override
    public void onDisable() {
        resetState();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options == null) {
            resetState();
            return;
        }

        // Cleanup first: never keep dead / removed pearls around.
        flyingPearls.removeIf(e -> e == null || e.isRemoved());

        // ---- input tracking (done before any early return so edges are never missed) ----
        int useTime = mc.player.getItemUseTime();
        boolean useDown = mc.options.useKey.isPressed();
        boolean useEdge = useDown && !lastUseDown;
        boolean pearlInHand = mc.player.getMainHandStack().isOf(Items.ENDER_PEARL);
        boolean windInHand = mc.player.getMainHandStack().isOf(Items.WIND_CHARGE);

        // Pearl throw: use-time dropping from >0 to 0, or (pearls are instant items) a fresh use-key press.
        boolean pearlThrown = pearlInHand && ((lastUseTime > 0 && useTime == 0) || useEdge);
        lastUseTime = useTime;
        lastUseDown = useDown;
        if (mc.currentScreen != null) return;
        if (pearlThrown) throwWatchTicks = 6;
        if (throwWatchTicks > 0) throwWatchTicks--;

        // ---- find the flying pearl (nearest to the player, within 5 blocks, freshly spawned) ----
        discoverPearls(mc);

        if (flyingPearls.isEmpty()) {
            if (state != State.IDLE) resetState();
            return;
        }

        if (state == State.IDLE) {
            state = State.PEARL_FLYING;
            windowTicks = window;
        }

        if (--windowTicks <= 0) {
            resetState();
            return;
        }

        if (state == State.PEARL_FLYING) {
            // Wind charge use while a pearl is in the air -> start aiming.
            if (windInHand && useEdge) {
                state = State.AIMING;
                delayTicks = delay;
            } else {
                return;
            }
        }

        // ---- AIMING ----
        Entity pearl = flyingPearls.get(0);
        if (pearl == null || pearl.isRemoved()) {
            flyingPearls.clear();
            resetState();
            return;
        }
        if (!windInHand) {
            state = State.PEARL_FLYING;
            return;
        }
        if (delayTicks > 0) {
            delayTicks--;
            return;
        }
        if (autoAim) aimAtPearl(mc, pearl.getPos());
    }

    private void discoverPearls(MinecraftClient mc) {
        Vec3d center = mc.player.getPos();
        Box box = mc.player.getBoundingBox().expand(5.0);
        List<EnderPearlEntity> nearby = mc.world.getEntitiesByClass(
                EnderPearlEntity.class,
                box,
                p -> !p.isRemoved() && !flyingPearls.contains(p) && p.age <= 6);
        nearby.sort(Comparator.comparingDouble(p -> p.squaredDistanceTo(center)));
        for (EnderPearlEntity pearl : nearby) {
            Entity owner = pearl.getOwner();
            boolean mine = owner == mc.player || (owner == null && throwWatchTicks > 0);
            if (!mine) continue;
            if (pearl.squaredDistanceTo(center) > 25.0) continue;
            flyingPearls.add(pearl);
        }
    }

    private void aimAtPearl(MinecraftClient mc, Vec3d target) {
        Vec3d diff = target.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();
        float speedFactor = 0.55f;
        float yawStep = (float) (yawDelta * (1.0 - Math.exp(-speedFactor)));
        float pitchStep = (float) (pitchDelta * (1.0 - Math.exp(-speedFactor)));

        yawStep = MathHelper.clamp(yawStep, -45.0f, 45.0f);
        pitchStep = MathHelper.clamp(pitchStep, -25.0f, 25.0f);

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    private void resetState() {
        state = State.IDLE;
        flyingPearls.clear();
        windowTicks = 0;
        delayTicks = 0;
        throwWatchTicks = 0;
    }

    public int window() { return window; }
    public void setWindow(int value) { window = MathHelper.clamp(value, 10, 40); persist(); }
    public boolean autoAim() { return autoAim; }
    public void setAutoAim(boolean value) { autoAim = value; persist(); }
    public int delay() { return delay; }
    public void setDelay(int value) { delay = MathHelper.clamp(value, 0, 5); persist(); }
}
