package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Pearl-catch helper for wind-charge -> ender-pearl PvP timing. */
public final class PearlCatch extends Module {
    private enum State { IDLE, WIND_CHARGE_THROWN, WAITING_FOR_PEARL, AIM_AT_CHARGE, DONE }

    private int delay = 2;
    private State state = State.IDLE;
    private int ticks;
    private long windChargeUntil;
    private boolean sawWindUse;
    private boolean sawPearlUse;
    private Vec3d windChargePosition = null;
    private float windChargeYaw;
    private float windChargePitch;

    public PearlCatch() {
        super("pearl_catch", "Pearl Catch", Category.COMBAT, false);
    }

    @Override
    protected void loadSettings() {
        delay = MathHelper.clamp(R1zzConfig.getInt("pearl_catch.delay", 2), 0, 10);
    }

    @Override
    protected void saveSettings() {
        R1zzConfig.put("pearl_catch.delay", delay);
    }

    @Override
    protected void resetSettings() {
        delay = 2;
        resetState();
    }

    @Override
    public void onDisable() {
        resetState();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) {
            return;
        }

        boolean usingWind = mc.player.getMainHandStack().isOf(Items.WIND_CHARGE) && mc.player.isUsingItem();
        boolean usingPearl = mc.player.getMainHandStack().isOf(Items.ENDER_PEARL) && mc.player.isUsingItem();

        if (usingWind && !sawWindUse) {
            windChargePosition = mc.player.getEyePos().add(mc.player.getRotationVec(1.0f).multiply(2.0));
            windChargeYaw = mc.player.getYaw();
            windChargePitch = mc.player.getPitch();
            windChargeUntil = System.currentTimeMillis() + 500L;
            ticks = delay;
            state = State.WIND_CHARGE_THROWN;
        }
        sawWindUse = usingWind;

        switch (state) {
            case IDLE -> {
                // Waiting for the first wind-charge use.
            }
            case WIND_CHARGE_THROWN -> {
                if (!usingWind) {
                    state = State.WAITING_FOR_PEARL;
                    ticks = delay;
                }
            }
            case WAITING_FOR_PEARL -> {
                if (System.currentTimeMillis() > windChargeUntil || windChargePosition == null) {
                    resetState();
                    return;
                }
                if (ticks > 0) {
                    ticks--;
                }
                if (usingPearl && !sawPearlUse && ticks <= 0) {
                    state = State.AIM_AT_CHARGE;
                }
            }
            case AIM_AT_CHARGE -> {
                if (windChargePosition == null || !mc.player.getMainHandStack().isOf(Items.ENDER_PEARL)) {
                    resetState();
                    return;
                }
                aimAt(mc, windChargePosition);
                state = State.DONE;
            }
            case DONE -> {
                // Do not keep rotating after the pearl has been released.
                if (!usingPearl) {
                    resetState();
                }
            }
        }

        sawPearlUse = usingPearl;
    }

    private void aimAt(MinecraftClient mc, Vec3d target) {
        Vec3d diff = target.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));

        float yawDelta = MathHelper.wrapDegrees(yaw - mc.player.getYaw());
        float pitchDelta = pitch - mc.player.getPitch();
        float sensitivity = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sensitivity * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;

        float yawStep = Math.round(yawDelta / gcd) * gcd;
        float pitchStep = Math.round(pitchDelta / gcd) * gcd;
        yawStep = MathHelper.clamp(yawStep, -45.0f, 45.0f);
        pitchStep = MathHelper.clamp(pitchStep, -30.0f, 30.0f);

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    private void resetState() {
        state = State.IDLE;
        ticks = 0;
        windChargeUntil = 0L;
        windChargePosition = null;
        sawWindUse = false;
        sawPearlUse = false;
        windChargeYaw = 0.0f;
        windChargePitch = 0.0f;
    }

    public int delay() {
        return delay;
    }

    public void setDelay(int value) {
        delay = MathHelper.clamp(value, 0, 10);
        persist();
    }
}
