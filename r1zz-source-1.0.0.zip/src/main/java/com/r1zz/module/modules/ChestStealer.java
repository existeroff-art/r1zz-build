package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class ChestStealer extends Module {
    public ChestStealer() { super("chest_stealer", "ChestStealer", Category.PLAYER, false); }
    private int delay = 50;
    @Override protected void loadSettings() {
        delay=R1zzConfig.getInt("chest_stealer.delay",50);
    }
    @Override protected void saveSettings() {
        R1zzConfig.put("chest_stealer.delay", delay);
    }
    @Override protected void resetSettings() {
        delay=50;
    }
    public int delay() { return delay; }
    public void setDelay(int v) { delay=Math.max(0,Math.min(500,v)); persist(); }
}
