package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/** Shift-clicks every item out of an open chest / barrel / shulker, one stack per delay interval. */
public final class ChestStealer extends Module {
    private int delay = 50;
    private long last;

    public ChestStealer() { super("chest_stealer", "ChestStealer", Category.PLAYER, false); }

    @Override protected void loadSettings() { delay = R1zzConfig.getInt("chest_stealer.delay", 50); }
    @Override protected void saveSettings() { R1zzConfig.put("chest_stealer.delay", delay); }
    @Override protected void resetSettings() { delay = 50; }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null) return;
        if (!(mc.currentScreen instanceof GenericContainerScreen screen)) return;
        if (System.currentTimeMillis() - last < delay) return;
        GenericContainerScreenHandler handler = screen.getScreenHandler();
        int containerSlots = handler.getRows() * 9;
        for (int i = 0; i < containerSlots; i++) {
            if (handler.getSlot(i).getStack().isEmpty()) continue;
            mc.interactionManager.clickSlot(handler.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
            last = System.currentTimeMillis();
            return;
        }
    }

    public int delay() { return delay; }
    public void setDelay(int v) { delay = Math.max(0, Math.min(500, v)); persist(); }
}
