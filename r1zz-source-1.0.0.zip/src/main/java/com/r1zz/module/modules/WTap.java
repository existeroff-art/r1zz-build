package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;

/** Releases forward for two ticks right after every attack so the next hit lands with fresh sprint knockback. */
public final class WTap extends Module {
    private float previousCooldown = 1.0f;
    private int releaseTicks;
    private boolean forwardWasDown;

    public WTap() { super("wtap", "WTap", Category.COMBAT, false); }

    @Override
    public void onDisable() {
        restore(MinecraftClient.getInstance());
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options == null) return;
        float cooldown = mc.player.getAttackCooldownProgress(0.0f);
        boolean attacked = previousCooldown > 0.85f && cooldown < 0.3f;
        previousCooldown = cooldown;

        if (releaseTicks > 0) {
            mc.options.forwardKey.setPressed(false);
            if (--releaseTicks == 0) restore(mc);
            return;
        }
        if (attacked && mc.player.isSprinting() && mc.options.forwardKey.isPressed() && Humanizer.chance(0.9)) {
            forwardWasDown = true;
            releaseTicks = Humanizer.ticks(1, 3);
            mc.options.forwardKey.setPressed(false);
        }
    }

    private void restore(MinecraftClient mc) {
        if (forwardWasDown && mc.options != null) mc.options.forwardKey.setPressed(CombatModuleUtil.physicalDown(mc, mc.options.forwardKey));
        forwardWasDown = false;
        releaseTicks = 0;
    }
}
