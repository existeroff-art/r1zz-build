package com.r1zz.module.modules;
import com.r1zz.module.Module;
public final class WTap extends Module { public WTap(){super("wtap","WTap",Category.COMBAT,false);} }