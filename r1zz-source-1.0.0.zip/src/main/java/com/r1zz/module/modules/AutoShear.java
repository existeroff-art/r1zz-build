package com.r1zz.module.modules;

import com.r1zz.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

import java.util.Comparator;

/** Shears the nearest shearable sheep within reach using shears from your hotbar. */
public final class AutoShear extends Module {
    private int cooldown;

    public AutoShear() { super("auto_shear", "AutoShear", Category.WORLD, false); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        int shears = CombatModuleUtil.findHotbar(mc.player, Items.SHEARS);
        if (shears < 0) return;
        SheepEntity sheep = mc.world.getEntitiesByClass(SheepEntity.class, mc.player.getBoundingBox().expand(4.0),
                        s -> s.isAlive() && !s.isBaby() && s.isShearable() && mc.player.distanceTo(s) <= 4.0)
                .stream().min(Comparator.comparingDouble(mc.player::distanceTo)).orElse(null);
        if (sheep == null) return;
        int old = mc.player.getInventory().selectedSlot;
        CombatModuleUtil.select(mc.player, shears);
        mc.interactionManager.interactEntity(mc.player, sheep, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        CombatModuleUtil.select(mc.player, old);
        cooldown = 10;
    }
}
