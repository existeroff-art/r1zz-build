package com.r1zz.module.modules;

import com.r1zz.config.R1zzConfig;
import com.r1zz.module.Module;

public final class AutoShear extends Module {
    public AutoShear() { super("auto_shear", "AutoShear", Category.WORLD, false); }
}
