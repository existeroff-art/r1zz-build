package com.r1zz.module;

import com.r1zz.config.R1zzConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public abstract class Module {
    public enum Category { COMBAT, MOVEMENT, RENDER, PLAYER, WORLD, MISC }
    private final String id, name;
    private final Category category;
    private final boolean defaultEnabled;
    private boolean enabled;
    private int keyCode = -1;
    protected Module(String id, String name, Category category, boolean defaultEnabled) {
        this.id = id; this.name = name; this.category = category; this.defaultEnabled = defaultEnabled; this.enabled = defaultEnabled;
    }
    public final void load() { enabled = R1zzConfig.getBoolean("module." + id + ".enabled", defaultEnabled); keyCode = R1zzConfig.getInt("key." + id, -1); loadSettings(); }
    public final void persist() { R1zzConfig.put("module." + id + ".enabled", enabled); R1zzConfig.put("key." + id, keyCode); saveSettings(); }
    protected void loadSettings() {}
    protected void saveSettings() {}
    protected void resetSettings() {}
    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public final void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
        persist();
        if (R1zzConfig.getBoolean("notify.chat", true)) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null) client.player.sendMessage(Text.literal("[R1zz] " + name + (value ? " enabled" : " disabled")), false);
        }
    }
    public final void toggle() { setEnabled(!enabled); }
    public final void resetToDefaults() { setEnabled(defaultEnabled); keyCode = -1; resetSettings(); persist(); }
    public String id() { return id; }
    public String name() { return name; }
    public Category category() { return category; }
    public boolean enabled() { return enabled; }
    public int keyCode() { return keyCode; }
    public void setKeyCode(int keyCode) { this.keyCode = keyCode < 0 ? -1 : keyCode; persist(); R1zzConfig.save(); }
}
