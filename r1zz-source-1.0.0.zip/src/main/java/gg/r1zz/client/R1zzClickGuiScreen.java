package gg.r1zz.client;

import gg.r1zz.client.config.R1zzConfig;
import gg.r1zz.client.module.ModuleCategory;
import gg.r1zz.client.module.R1zzModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;\nimport net.minecraft.client.render.RenderLayer;\nimport net.minecraft.util.Identifier;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public final class R1zzClickGuiScreen extends Screen {
    private static final int PURPLE = 0xFF9B4DFF;
    private static final int PANEL = 0xF20B0913;
    private static final int PANEL_TOP = 0xFF171322;
    private static final int TEXT = 0xFFF4F0FF;
    private static final int MUTED = 0xFFAAA2BD;\n    private static final Identifier R1ZZ_LOGO = Identifier.of("r1zzclient", "textures/gui/r1zz_logo.png");

    private int guiX, guiY, guiWidth, guiHeight;
    private boolean dragging;
    private int dragOffsetX, dragOffsetY;
    private ModuleCategory selected = ModuleCategory.COMBAT;
    private final List<ModuleCategory> categories = List.of(ModuleCategory.values());

    public R1zzClickGuiScreen() { super(Text.literal("R1zz Client")); }

    @Override protected void init() {
        guiWidth = Math.min(690, Math.max(300, width - 24));
        guiHeight = Math.min(390, Math.max(220, height - 24));
        guiX = (width - guiWidth) / 2; guiY = (height - guiHeight) / 2;
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(guiX, guiY, guiX + guiWidth, guiY + guiHeight, PANEL);
        ctx.fill(guiX, guiY, guiX + guiWidth, guiY + 36, PANEL_TOP);
        ctx.fill(guiX, guiY + 34, guiX + guiWidth, guiY + 36, PURPLE);
        ctx.drawText(textRenderer, "R1zz Client", guiX + 14, guiY + 13, TEXT, true);
        ctx.drawText(textRenderer, "1.21  •  RIGHT SHIFT", guiX + guiWidth - 145, guiY + 13, MUTED, false);

        int navW = 94, navY = guiY + 48;
        for (int i = 0; i < categories.size(); i++) {
            ModuleCategory cat = categories.get(i);
            int y = navY + i * 31;
            boolean active = selected == cat;
            if (active) ctx.fill(guiX + 8, y - 5, guiX + navW, y + 20, 0xFF2A1B3B);
            ctx.drawText(textRenderer, cat.displayName(), guiX + 16, y + 2, active ? PURPLE : MUTED, active);
        }

        int contentX = guiX + navW + 12, contentY = guiY + 50;
        ctx.drawText(textRenderer, selected.displayName().toUpperCase(), contentX, contentY, TEXT, true);
        ctx.drawText(textRenderer, "Click a module to toggle it", contentX, contentY + 15, MUTED, false);
        int rowY = contentY + 36;
        for (R1zzModule module : R1zzClient.MODULES.in(selected)) {
            int rowH = 32;
            boolean hover = mouseX >= contentX && mouseX <= guiX + guiWidth - 12
                    && mouseY >= rowY && mouseY < rowY + rowH - 3;
            ctx.fill(contentX, rowY, guiX + guiWidth - 12, rowY + rowH - 3,
                    hover ? 0xFF251C32 : 0xD9141120);
            ctx.drawText(textRenderer, module.name(), contentX + 9, rowY + 8,
                    module.enabled() ? PURPLE : TEXT, module.enabled());
            int toggleX = guiX + guiWidth - 42;
            ctx.fill(toggleX, rowY + 9, toggleX + 20, rowY + 20,
                    module.enabled() ? PURPLE : 0xFF514A60);
            ctx.fill(toggleX + (module.enabled() ? 10 : 2), rowY + 11,
                    toggleX + (module.enabled() ? 18 : 10), rowY + 18, 0xFFFFFFFF);
            rowY += rowH;
        }
        ctx.drawText(textRenderer, "R1zz • local client settings", guiX + 13,
                guiY + guiHeight - 17, MUTED, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && my >= guiY && my <= guiY + 36 && mx >= guiX && mx <= guiX + guiWidth) {
            dragging = true; dragOffsetX = (int) mx - guiX; dragOffsetY = (int) my - guiY; return true;
        }
        if (button == 0) {
            int navW = 94, navY = guiY + 48;
            for (int i = 0; i < categories.size(); i++) {
                int y = navY + i * 31;
                if (mx >= guiX + 8 && mx <= guiX + navW && my >= y - 5 && my <= y + 20) {
                    selected = categories.get(i); return true;
                }
            }
            int contentX = guiX + navW + 12, rowY = guiY + 50 + 36 + 36;
            for (R1zzModule module : R1zzClient.MODULES.in(selected)) {
                if (mx >= contentX && mx <= guiX + guiWidth - 12 && my >= rowY && my < rowY + 29) {
                    module.toggle();
                    try { R1zzConfig.save(R1zzClient.MODULES); } catch (Exception e) {
                        System.err.println("[R1zz] Could not save config: " + e.getMessage());
                    }
                    return true;
                }
                rowY += 32;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging && button == 0) {
            guiX = Math.max(0, Math.min(width - guiWidth, (int) mx - dragOffsetX));
            guiY = Math.max(0, Math.min(height - guiHeight, (int) my - dragOffsetY));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0) dragging = false;
        return super.mouseReleased(mx, my, button);
    }
    @Override public boolean shouldPause() { return false; }
}
