package gg.r1zz.client.module.impl;

import gg.r1zz.client.module.ModuleCategory;
import gg.r1zz.client.module.R1zzModule;

public final class R1zzFPS extends R1zzModule {
    public R1zzFPS() { super("R1zzFPS", ModuleCategory.HUD); }
}
