package gg.r1zz.client.module;

public abstract class R1zzModule {
    private final String name;
    private final ModuleCategory category;
    private boolean enabled;
    private int keyCode;

    protected R1zzModule(String name, ModuleCategory category) {
        this.name = name.startsWith("R1zz") ? name : "R1zz" + name;
        this.category = category;
    }
    public final String name() { return name; }
    public final ModuleCategory category() { return category; }
    public final boolean enabled() { return enabled; }
    public final int keyCode() { return keyCode; }
    public final void setKeyCode(int keyCode) { this.keyCode = keyCode; }
    public final void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }
    public final void setEnabled(boolean value) {
        if (enabled != value) toggle();
    }
    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
}
