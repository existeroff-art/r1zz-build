package gg.r1zz.client.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public final class ModuleManager {
    private final List<R1zzModule> modules = new ArrayList<>();
    public void register(R1zzModule module) { modules.add(module); }
    public List<R1zzModule> all() { return Collections.unmodifiableList(modules); }
    public List<R1zzModule> in(ModuleCategory category) {
        return modules.stream().filter(m -> m.category() == category).toList();
    }
    public Optional<R1zzModule> find(String name) {
        return modules.stream().filter(m -> m.id().equalsIgnoreCase(name)
                || m.name().equalsIgnoreCase(name)).findFirst();
    }
    public void tick() { for (R1zzModule m : modules) if (m.enabled()) m.onTick(); }
}
