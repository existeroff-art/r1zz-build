package gg.r1zz.client.module.impl;

import gg.r1zz.client.module.ModuleCategory;
import gg.r1zz.client.module.R1zzModule;

public final class R1zzCrosshair extends R1zzModule {
    public R1zzCrosshair() { super("R1zzCrosshair", ModuleCategory.RENDER); }
}
