package gg.r1zz.client.config;

import gg.r1zz.client.module.ModuleManager;
import gg.r1zz.client.module.R1zzModule;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class R1zzConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("r1zz-client.properties");
    private R1zzConfig() {}

    public static void save(ModuleManager manager) throws IOException {
        Properties p = new Properties();
        for (R1zzModule m : manager.all()) {
            p.setProperty(m.name() + ".enabled", Boolean.toString(m.enabled()));
            p.setProperty(m.name() + ".key", Integer.toString(m.keyCode()));
        }
        Files.createDirectories(FILE.getParent());
        try (var out = Files.newOutputStream(FILE)) {
            p.store(out, "R1zz Client settings");
        }
    }

    public static void load(ModuleManager manager) throws IOException {
        if (!Files.exists(FILE)) return;
        Properties p = new Properties();
        try (var in = Files.newInputStream(FILE)) { p.load(in); }
        for (R1zzModule m : manager.all()) {
            m.setEnabled(Boolean.parseBoolean(p.getProperty(m.name() + ".enabled", "false")));
            try { m.setKeyCode(Integer.parseInt(p.getProperty(m.name() + ".key", "0"))); }
            catch (NumberFormatException ignored) { m.setKeyCode(0); }
        }
    }
}
