package gg.r1zz.client;

import gg.r1zz.client.config.R1zzConfig;
import gg.r1zz.client.module.ModuleManager;
import gg.r1zz.client.module.impl.R1zzCoordinates;
import gg.r1zz.client.module.impl.R1zzCrosshair;
import gg.r1zz.client.module.impl.R1zzFPS;
import gg.r1zz.client.module.impl.R1zzKeystrokes;
import gg.r1zz.client.module.impl.R1zzTargetHUD;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class R1zzClient implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        MODULES.register(new R1zzFPS());
        MODULES.register(new R1zzCoordinates());
        MODULES.register(new R1zzKeystrokes());
        MODULES.register(new R1zzCrosshair());
        MODULES.register(new R1zzTargetHUD());
        try { R1zzConfig.load(MODULES); } catch (Exception e) {
            System.err.println("[R1zz] Could not load config: " + e.getMessage());
        }

        R1zzHud.register();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.r1zzclient.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.r1zzclient"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            MODULES.tick();
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen instanceof R1zzClickGuiScreen) client.setScreen(null);
                else if (client.currentScreen == null) client.setScreen(new R1zzClickGuiScreen());
            }
        });
    }
}
