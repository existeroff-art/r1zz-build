package gg.r1zz.client;

import gg.r1zz.client.module.R1zzModule;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

public final class R1zzHud {
    private static final int PURPLE = 0xFFB879FF;
    private static final int WHITE = 0xFFF3EDFF;
    private static final int PANEL = 0xD9100C1A;

    private R1zzHud() {}

    private static boolean enabled(String name) {
        return R1zzClient.MODULES.find(name).map(R1zzModule::enabled).orElse(false);
    }

    public static void register() {
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.textRenderer == null) return;

            int y = 8;
            if (enabled("R1zzFPS")) {
                drawContext.drawTextWithShadow(mc.textRenderer,
                        "R1zz | FPS " + mc.getCurrentFps(), 8, y, PURPLE);
                y += 12;
            }
            if (enabled("R1zzCoordinates")) {
                String coords = String.format(java.util.Locale.ROOT,
                        "R1zz | X %.1f Y %.1f Z %.1f",
                        mc.player.getX(), mc.player.getY(), mc.player.getZ());
                drawContext.drawTextWithShadow(mc.textRenderer, coords, 8, y, WHITE);
                y += 12;
            }
            if (enabled("R1zzKeystrokes")) {
                drawKeystrokes(drawContext, mc);
            }
            if (enabled("R1zzCrosshair")) {
                drawCrosshair(drawContext, mc);
            }
            if (enabled("R1zzTargetHUD")) {
                drawTargetHud(drawContext, mc);
            }
        });
    }

    private static void drawKeystrokes(DrawContext ctx, MinecraftClient mc) {
        int x = 8, y = 48, size = 20, gap = 3;
        drawKey(ctx, mc, "W", x + size + gap, y, mc.options.forwardKey.isPressed());
        drawKey(ctx, mc, "A", x, y + size + gap, mc.options.leftKey.isPressed());
        drawKey(ctx, mc, "S", x + size + gap, y + size + gap, mc.options.backKey.isPressed());
        drawKey(ctx, mc, "D", x + (size + gap) * 2, y + size + gap, mc.options.rightKey.isPressed());
        drawKey(ctx, mc, "JUMP", x, y + (size + gap) * 2, mc.options.jumpKey.isPressed(), size * 3 + gap * 2);
    }

    private static void drawKey(DrawContext ctx, MinecraftClient mc, String label, int x, int y, boolean down) {
        drawKey(ctx, mc, label, x, y, down, 20);
    }

    private static void drawKey(DrawContext ctx, MinecraftClient mc, String label, int x, int y,
                                boolean down, int width) {
        ctx.fill(x, y, x + width, y + 20, down ? 0xFF6B2DA8 : PANEL);
        ctx.fill(x, y, x + width, y + 1, down ? PURPLE : 0xFF4C3B60);
        int textWidth = mc.textRenderer.getWidth(label);
        ctx.drawTextWithShadow(mc.textRenderer, label, x + (width - textWidth) / 2,
                y + 6, WHITE);
    }

    private static void drawCrosshair(DrawContext ctx, MinecraftClient mc) {
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        ctx.fill(cx - 7, cy, cx - 2, cy + 1, PURPLE);
        ctx.fill(cx + 2, cy, cx + 7, cy + 1, PURPLE);
        ctx.fill(cx, cy - 7, cx + 1, cy - 2, PURPLE);
        ctx.fill(cx, cy + 2, cx + 1, cy + 7, PURPLE);
        ctx.fill(cx, cy, cx + 1, cy + 1, WHITE);
    }

    private static void drawTargetHud(DrawContext ctx, MinecraftClient mc) {
        if (!(mc.targetedEntity instanceof LivingEntity target) || !target.isAlive()) return;
        int x = mc.getWindow().getScaledWidth() / 2 + 14;
        int y = mc.getWindow().getScaledHeight() / 2 + 12;
        int w = 118, h = 34;
        ctx.fill(x, y, x + w, y + h, PANEL);
        ctx.fill(x, y, x + w, y + 2, PURPLE);
        String name = target.getName().getString();
        int maxNameWidth = w - 10;
        while (mc.textRenderer.getWidth(name) > maxNameWidth && name.length() > 3) {
            name = name.substring(0, name.length() - 2) + "…";
        }
        ctx.drawTextWithShadow(mc.textRenderer, name, x + 5, y + 6, WHITE);
        float maxHealth = Math.max(1.0f, target.getMaxHealth());
        float health = MathHelper.clamp(target.getHealth() / maxHealth, 0.0f, 1.0f);
        ctx.fill(x + 5, y + 21, x + w - 5, y + 27, 0xFF382B43);
        ctx.fill(x + 5, y + 21, x + 5 + (int)((w - 10) * health), y + 27, PURPLE);
        String hp = String.format(java.util.Locale.ROOT, "%.1f / %.1f", target.getHealth(), maxHealth);
        ctx.drawTextWithShadow(mc.textRenderer, hp, x + 5, y + 28, WHITE);
    }
}
