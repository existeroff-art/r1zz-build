package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.InventoryUtils;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

public final class CobwebPlacer extends Module implements TickListener {
    private final NumberSetting range = new NumberSetting(EncryptedString.of("Range"), 1.0, 4.0, 3.0, 0.1);
    private final NumberSetting cooldown = new NumberSetting(EncryptedString.of("Cooldown"), 100, 500, 500, 1);
    private final BooleanSetting autoSwitch = new BooleanSetting(EncryptedString.of("Auto Switch"), true);

    private long lastPlacement;
    private int rotationDelay = -1;
    private BlockPos pendingPos;
    private boolean manualTrigger;

    public CobwebPlacer() {
        super(EncryptedString.of("Cobweb Placer"), EncryptedString.of("Places a cobweb at a moving target's feet"), -1, Category.COMBAT);
        addSettings(range, cooldown, autoSwitch);
    }

    @Override
    public void onEnable() {
        manualTrigger = true;
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        pendingPos = null;
        rotationDelay = -1;
        manualTrigger = false;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        boolean rightClick = mc.player.isUsingItem() && mc.player.getMainHandStack().isOf(Items.COBWEB);
        boolean trigger = manualTrigger || rightClick;

        if (rotationDelay == 0 && pendingPos != null) {
            place(pendingPos);
            pendingPos = null;
            rotationDelay = -1;
            manualTrigger = false;
            return;
        }
        if (rotationDelay > 0) { rotationDelay--; return; }
        if (!trigger || System.currentTimeMillis() - lastPlacement < cooldown.getValueLong()) return;

        PlayerEntity target = findTarget();
        if (target == null) return;
        BlockPos feet = target.getBlockPos();
        BlockPos below = feet.down();
        if (!target.isOnGround() || !mc.world.getBlockState(below).isSolidBlock(mc.world, below) || !mc.world.getBlockState(feet).isAir()) return;
        if (!canSee(target)) return;

        if (!InventoryUtils.hasItemInHotbar(item -> item == Items.COBWEB)) return;
        if (!autoSwitch.getValue() && !mc.player.getMainHandStack().isOf(Items.COBWEB)) return;
        if (autoSwitch.getValue()) InventoryUtils.selectItemFromHotbar(Items.COBWEB);
        rotateTo(Vec3d.ofCenter(feet));
        pendingPos = feet;
        rotationDelay = 1;
    }

    private PlayerEntity findTarget() {
        Vec3d selfVel = mc.player.getVelocity();
        return mc.world.getPlayers().stream()
                .filter(p -> p != mc.player && p.isAlive() && !p.isSpectator() && p.isOnGround())
                .filter(p -> mc.player.distanceTo(p) <= range.getValue())
                .filter(p -> p.getVelocity().subtract(selfVel).dotProduct(mc.player.getPos().subtract(p.getPos())) > 0.0)
                .filter(this::canSee)
                .min((a, b) -> Double.compare(mc.player.distanceTo(a), mc.player.distanceTo(b))).orElse(null);
    }

    private boolean canSee(PlayerEntity player) {
        Vec3d a = mc.player.getEyePos(), b = player.getEyePos();
        BlockHitResult hit = mc.world.raycast(new RaycastContext(a, b, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return hit.getType() == HitResult.Type.MISS;
    }

    private void rotateTo(Vec3d target) {
        Vec3d d = target.subtract(mc.player.getEyePos());
        double h = Math.sqrt(d.x * d.x + d.z * d.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(d.y, h));
        float sens = mc.options.getMouseSensitivity().getValue().floatValue(), f = sens * 0.6f + 0.2f, gcd = f * f * f * 1.2f;
        float ys = MathHelper.wrapDegrees(yaw - mc.player.getYaw()) * 0.6f;
        float ps = (pitch - mc.player.getPitch()) * 0.6f;
        if (gcd > 0.0f) { ys = Math.round(ys / gcd) * gcd; ps = Math.round(ps / gcd) * gcd; }
        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(ys, -30.0f, 30.0f));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(ps, -25.0f, 25.0f), -90.0f, 90.0f));
    }

    private void place(BlockPos pos) {
        if (!mc.world.getBlockState(pos).isAir() || !mc.world.getBlockState(pos.down()).isSolidBlock(mc.world, pos.down())) return;
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(pos.down()), Direction.UP, pos.down(), false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        lastPlacement = System.currentTimeMillis();
    }
}
