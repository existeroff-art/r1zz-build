package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;

public final class R1zzAssist extends Module implements TickListener {
    public enum TargetType { Players, Entities, Both }

    private final NumberSetting range = new NumberSetting(EncryptedString.of("Range"), 2.5, 6.0, 3.5, 0.1);
    private final NumberSetting speed = new NumberSetting(EncryptedString.of("Speed"), 0.1, 1.0, 0.6, 0.1);
    private final ModeSetting<TargetType> targetType = new ModeSetting<>(EncryptedString.of("Target Type"), TargetType.Players, TargetType.class);
    private final NumberSetting delay = new NumberSetting(EncryptedString.of("Delay"), 0, 500, 80, 1);

    private LivingEntity lockedTarget;
    private long lastAttack;
    private int swingRecovery;
    private boolean rotatedLastTick;

    public R1zzAssist() {
        super(EncryptedString.of("R1zzAssist"), EncryptedString.of("Sticky body-lock combat assist"), -1, Category.COMBAT);
        addSettings(range, speed, targetType, delay);
    }

    @Override
    public void onEnable() {
        lockedTarget = findTarget();
        lastAttack = 0L;
        swingRecovery = 0;
        rotatedLastTick = false;
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        lockedTarget = null;
        swingRecovery = 0;
        rotatedLastTick = false;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        if (swingRecovery > 0) {
            swingRecovery--;
            rotatedLastTick = false;
            return;
        }
        if (mc.player.handSwinging) {
            swingRecovery = 1;
            rotatedLastTick = false;
            return;
        }

        if (lockedTarget != null && (!lockedTarget.isAlive() || mc.player.distanceTo(lockedTarget) > range.getValue())) {
            lockedTarget = null;
            return;
        }
        if (lockedTarget == null) {
            // Sticky lock: target selection only happens once after enabling.
            lockedTarget = findTarget();
            if (lockedTarget == null) return;
        }

        if (mc.currentScreen != null || mc.player.isUsingItem() || mc.player.isBlocking() || !isWeapon(mc.player.getMainHandStack().getItem())) {
            rotatedLastTick = false;
            return;
        }
        if (!mc.player.canSee(lockedTarget)) {
            rotatedLastTick = false;
            return;
        }

        rotate(lockedTarget);
        if (rotatedLastTick) {
            rotatedLastTick = false;
            return;
        }
        rotatedLastTick = true;

        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;
        if (System.currentTimeMillis() - lastAttack < delay.getValueLong()) return;
        if (!mc.player.canSee(lockedTarget)) return;

        mc.interactionManager.attackEntity(mc.player, lockedTarget);
        mc.player.swingHand(Hand.MAIN_HAND);
        lastAttack = System.currentTimeMillis();
        swingRecovery = 1;
        rotatedLastTick = false;
    }

    private LivingEntity findTarget() {
        if (mc.player == null || mc.world == null) return null;
        return mc.world.getEntitiesByClass(LivingEntity.class, mc.player.getBoundingBox().expand(range.getValue()),
                        e -> e != mc.player && e.isAlive() && !e.isSpectator() && matches(e) && mc.player.canSee(e))
                .stream().min(Comparator.comparingDouble(mc.player::distanceTo)).orElse(null);
    }

    private boolean matches(LivingEntity entity) {
        return switch (targetType.getMode()) {
            case Players -> entity instanceof PlayerEntity;
            case Entities -> !(entity instanceof PlayerEntity);
            case Both -> true;
        };
    }

    private boolean isWeapon(Item item) {
        return item instanceof SwordItem || item instanceof AxeItem || item instanceof TridentItem || item instanceof MaceItem;
    }

    private void rotate(LivingEntity target) {
        Vec3d targetPos = target.getPos().add(0.0, target.getHeight() * 0.5, 0.0);
        Vec3d delta = targetPos.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();

        double distance = mc.player.distanceTo(target);
        double distanceFactor = MathHelper.clamp(1.0 - (distance / Math.max(range.getValue(), 0.001)), 0.6, 1.0);
        double speedFactor = (0.35 + speed.getValue() * 0.55) * distanceFactor;
        double yawStep = yawDelta * (1.0 - Math.exp(-speedFactor));
        double pitchStep = Math.abs(pitchDelta) < 0.8 ? 0.0 : pitchDelta * (1.0 - Math.exp(-speedFactor));

        if (Math.abs(yawDelta) > 90.0) {
            yawStep = Math.copySign(Math.min(Math.abs(yawDelta), 22.0), yawDelta);
        } else if (Math.abs(yawDelta) > 10.0) {
            double overshoot = 1.0 + ThreadLocalRandom.current().nextDouble(0.06, 0.101);
            yawStep *= overshoot;
        } else if (Math.abs(yawDelta) < 1.5) {
            yawStep *= 0.7;
        }

        double capVariance = ThreadLocalRandom.current().nextDouble(0.97, 1.03);
        double yawCap = 28.0 * capVariance;
        double pitchCap = 16.0 * capVariance;
        yawStep = MathHelper.clamp(yawStep, -yawCap, yawCap);
        pitchStep = MathHelper.clamp(pitchStep, -pitchCap, pitchCap);

        // Small normal-distributed human-like step variance.
        yawStep += gaussian() * Math.abs(yawStep) * 0.04;
        pitchStep += gaussian() * Math.abs(pitchStep) * 0.04;
        yawStep += ThreadLocalRandom.current().nextDouble(-0.05, 0.051);

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }

        mc.player.setYaw(mc.player.getYaw() + (float) yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + (float) pitchStep, -90.0f, 90.0f));
    }

    private double gaussian() {
        double u = Math.max(ThreadLocalRandom.current().nextDouble(), 1.0e-12);
        double v = ThreadLocalRandom.current().nextDouble();
        return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    }
}
