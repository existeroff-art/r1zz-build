package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.InventoryUtils;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class WaterDrain extends Module implements TickListener {
    public enum Target { Water, Lava, Both }

    private final NumberSetting range = new NumberSetting(EncryptedString.of("Range"), 1.0, 5.0, 4.0, 0.1);
    private final NumberSetting cooldown = new NumberSetting(EncryptedString.of("Cooldown"), 100, 500, 400, 1);
    private final ModeSetting<Target> target = new ModeSetting<>(EncryptedString.of("Target"), Target.Water, Target.class);
    private final BooleanSetting autoSwitch = new BooleanSetting(EncryptedString.of("Auto Switch"), true);

    private final Map<BlockPos, Long> recentSources = new HashMap<>();
    private BlockPos pendingSource;
    private int rotationDelay = -1;
    private long lastDrain;

    public WaterDrain() {
        super(EncryptedString.of("Water Drain"), EncryptedString.of("Legit-style fluid source drain"), -1, Category.COMBAT);
        addSettings(range, cooldown, target, autoSwitch);
    }

    @Override
    public void onEnable() {
        recentSources.clear();
        pendingSource = null;
        rotationDelay = -1;
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        recentSources.clear();
        pendingSource = null;
        rotationDelay = -1;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<BlockPos, Long>> it = recentSources.entrySet().iterator();
        while (it.hasNext()) if (now - it.next().getValue() > 10_000L) it.remove();
        trackNearbySources(now);

        if (pendingSource != null) {
            if (rotationDelay > 0) {
                rotationDelay--;
                rotateTo(Vec3d.ofCenter(pendingSource));
                return;
            }
            if (rotationDelay == 0) {
                placeSolidBlock(pendingSource);
                pendingSource = null;
                rotationDelay = -1;
                return;
            }
        }

        if (now - lastDrain < cooldown.getValueLong()) return;
        BlockPos source = findRecentSource();
        if (source == null) return;
        BlockPos placement = source.up();
        if (!validPlacement(placement) || mc.player.squaredDistanceTo(Vec3d.ofCenter(placement)) <= 1.0) return;
        pendingSource = placement;
        rotationDelay = 2;
    }

    private void trackNearbySources(long now) {
        BlockPos origin = mc.player.getBlockPos();
        int r = (int) Math.ceil(range.getValue());
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos pos = origin.add(x, y, z);
            if (mc.player.squaredDistanceTo(Vec3d.ofCenter(pos)) > range.getValue() * range.getValue()) continue;
            BlockState state = mc.world.getBlockState(pos);
            if (isTarget(state) && mc.world.getFluidState(pos).isStill()) recentSources.put(pos.toImmutable(), now);
        }
    }

    private boolean isTarget(BlockState state) {
        return (target.isMode(Target.Water) || target.isMode(Target.Both)) && state.isOf(Blocks.WATER)
                || (target.isMode(Target.Lava) || target.isMode(Target.Both)) && state.isOf(Blocks.LAVA);
    }

    private BlockPos findRecentSource() {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos pos : recentSources.keySet()) {
            double d = mc.player.squaredDistanceTo(Vec3d.ofCenter(pos));
            if (d <= range.getValue() * range.getValue() && d < bestDist && mc.world.getFluidState(pos).isStill() && canSee(pos)) {
                best = pos;
                bestDist = d;
            }
        }
        return best;
    }

    private boolean validPlacement(BlockPos pos) {
        BlockState state = mc.world.getBlockState(pos);
        if (!state.isAir() || state.isReplaceable()) return false;
        if (!mc.world.getBlockState(pos.down()).isSolidBlock(mc.world, pos.down())) return false;
        return canSee(pos);
    }

    private void placeSolidBlock(BlockPos pos) {
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() instanceof BlockItem bi && bi.getBlock().getDefaultState().isSolidBlock(mc.world, pos.down())) {
                slot = i;
                break;
            }
        }
        if (slot < 0) return;
        if (!autoSwitch.getValue() && !mc.player.getInventory().getStack(mc.player.getInventory().selectedSlot).getItem().equals(mc.player.getInventory().getStack(slot).getItem())) return;
        if (autoSwitch.getValue()) InventoryUtils.selectItemFromHotbar(mc.player.getInventory().getStack(slot).getItem());
        BlockPos below = pos.down();
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(below), Direction.UP, below, false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        lastDrain = System.currentTimeMillis();
    }

    private boolean canSee(BlockPos pos) {
        Vec3d start = mc.player.getEyePos(), end = Vec3d.ofCenter(pos);
        BlockHitResult hit = mc.world.raycast(new RaycastContext(start, end, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, mc.player));
        return hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(pos);
    }

    private void rotateTo(Vec3d targetPos) {
        Vec3d d = targetPos.subtract(mc.player.getEyePos());
        double h = Math.sqrt(d.x * d.x + d.z * d.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(d.y, h));
        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        float ys = MathHelper.wrapDegrees(yaw - mc.player.getYaw());
        float ps = pitch - mc.player.getPitch();
        if (gcd > 0.0f) { ys = Math.round(ys / gcd) * gcd; ps = Math.round(ps / gcd) * gcd; }
        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(ys, -30.0f, 30.0f));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(ps, -30.0f, 30.0f), -90.0f, 90.0f));
    }
}
