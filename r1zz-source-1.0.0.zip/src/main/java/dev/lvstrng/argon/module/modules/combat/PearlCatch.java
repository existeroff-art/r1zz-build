package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class PearlCatch extends Module implements TickListener {
    private enum State { IDLE, PEARL_THROWN, WAITING_FOR_WIND_CHARGE, AIM_AT_PEARL, DONE }

    private final NumberSetting window = new NumberSetting(EncryptedString.of("Window"), 10, 40, 30, 1);
    private final BooleanSetting autoAim = new BooleanSetting(EncryptedString.of("Auto-aim"), true);
    private final NumberSetting delay = new NumberSetting(EncryptedString.of("Delay"), 0, 5, 2, 1);

    private final List<Entity> knownPearls = new ArrayList<>();
    private EnderPearlEntity trackedPearl;
    private State state = State.IDLE;
    private int windowTicks;
    private int aimDelay;

    public PearlCatch() {
        super(EncryptedString.of("Pearl Catch"), EncryptedString.of("Aims a wind charge at a thrown pearl"), -1, Category.COMBAT);
        addSettings(window, autoAim, delay);
    }

    @Override
    public void onEnable() {
        resetState();
        knownPearls.clear();
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        resetState();
        knownPearls.clear();
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        knownPearls.removeIf(e -> e == null || e.isRemoved());
        EnderPearlEntity newest = findNewPearl();
        if (state == State.IDLE && newest != null) {
            trackedPearl = newest;
            windowTicks = window.getValueInt();
            aimDelay = delay.getValueInt();
            state = State.PEARL_THROWN;
        }

        if (trackedPearl != null && (!trackedPearl.isAlive() || mc.player.distanceTo(trackedPearl) > 64.0)) {
            resetState();
            return;
        }

        if (state == State.PEARL_THROWN) state = State.WAITING_FOR_WIND_CHARGE;
        if (state == State.WAITING_FOR_WIND_CHARGE) {
            if (--windowTicks < 0) {
                resetState();
                return;
            }
            if (mc.player.getMainHandStack().isOf(Items.WIND_CHARGE)) {
                state = State.AIM_AT_PEARL;
                aimDelay = delay.getValueInt();
            }
        }

        if (state == State.AIM_AT_PEARL) {
            if (trackedPearl == null || !trackedPearl.isAlive()) {
                resetState();
                return;
            }
            if (!mc.player.getMainHandStack().isOf(Items.WIND_CHARGE)) {
                state = State.WAITING_FOR_WIND_CHARGE;
                return;
            }
            if (autoAim.getValue() && aimDelay <= 0) aimAt(trackedPearl.getPos());
            if (aimDelay > 0) aimDelay--;
        }

        if (state == State.AIM_AT_PEARL && !mc.player.getMainHandStack().isOf(Items.WIND_CHARGE))
            state = State.DONE;
    }

    private EnderPearlEntity findNewPearl() {
        return mc.world.getEntitiesByClass(EnderPearlEntity.class, mc.player.getBoundingBox().expand(64.0),
                        p -> p.isAlive() && !knownPearls.contains(p) && p.getOwner() == mc.player)
                .stream().min(Comparator.comparingDouble(mc.player::distanceTo)).map(p -> {
                    knownPearls.add(p);
                    return p;
                }).orElse(null);
    }

    private void aimAt(Vec3d target) {
        Vec3d delta = target.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        float yawStep = MathHelper.wrapDegrees(yaw - mc.player.getYaw()) * 0.55f;
        float pitchStep = (pitch - mc.player.getPitch()) * 0.55f;

        float sens = mc.options.getMouseSensitivity().getValue().floatValue();
        float f = sens * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        if (gcd > 0.0f) {
            yawStep = Math.round(yawStep / gcd) * gcd;
            pitchStep = Math.round(pitchStep / gcd) * gcd;
        }

        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(yawStep, -28.0f, 28.0f));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(pitchStep, -16.0f, 16.0f), -90.0f, 90.0f));
    }

    private void resetState() {
        state = State.IDLE;
        windowTicks = 0;
        aimDelay = 0;
        trackedPearl = null;
    }
}
