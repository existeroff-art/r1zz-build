package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.utils.EncryptedString;
import net.minecraft.util.math.Vec3d;

public final class JumpReset extends Module implements TickListener {
    private Vec3d lastVelocity = Vec3d.ZERO;
    private long lastJump;
    private boolean pending;

    public JumpReset() {
        super(EncryptedString.of("Jump Reset"), EncryptedString.of("Jumps after knockback to perform a jump reset"), -1, Category.COMBAT);
    }

    @Override
    public void onEnable() {
        lastVelocity = mc.player == null ? Vec3d.ZERO : mc.player.getVelocity();
        pending = false;
        lastJump = 0L;
        eventManager.add(TickListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        pending = false;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        Vec3d velocity = mc.player.getVelocity();
        double delta = velocity.subtract(lastVelocity).length();
        boolean knockback = delta > 0.18 && Math.abs(velocity.y - lastVelocity.y) > 0.02;
        lastVelocity = velocity;
        if (knockback && mc.player.isOnGround() && System.currentTimeMillis() - lastJump >= 500L) pending = true;
        if (pending && mc.player.isOnGround() && System.currentTimeMillis() - lastJump >= 500L) {
            mc.player.jump();
            lastJump = System.currentTimeMillis();
            pending = false;
        }
    }
}
