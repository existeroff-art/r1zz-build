# R1zz

Client-side Fabric mod for **Minecraft 1.21**, built with Java 21.

## Build and install

Requirements: JDK 21 and Gradle 8.x. From the project root:

```sh
./gradlew build --no-daemon
```

The mod JAR is `build/libs/r1zz-1.0.0.jar`. Copy it into `.minecraft/mods` with Fabric Loader 0.15.11+ and Fabric API 0.100.1+1.21 installed.

## GUI and configuration

- **Right Shift** opens the centered 500 × 340 ClickGUI. Choose a category in the sidebar.
- Search the module list, click a module card to expand its settings, click its switch to toggle, and click its key chip to bind. Right-click the chip to clear it; press Escape while capturing to cancel.
- The gear panel provides GUI/module keybinds, preferences, editable friends, and config save/load.
- Settings persist in `.minecraft/config/r1zz.properties`.

## Registered modules

- **AimAssist** — sticky target lock with Speed (0.1–1.0, default 0.55), Range (3–64 blocks, default 24), and Target Type (Players/Entities/Both, default Players).
- **TriggerBot** — placeholder toggle; no automated attacks.
- **FastGap** — UI toggle only; it does not alter item-use behavior.
- **ShieldBreaker** — switches to a hotbar axe while the crosshair targets an entity blocking with a shield, then restores the previous slot. Cooldown is configurable from 0–500 ms (default 200).

## FastGap — JVM Arguments

FastGap module is a UI toggle only. The actual golden apple eating speedup comes from JVM arguments applied to your launcher. Add these to your launcher's JVM arguments field:

```text
-Xms4G -Xmx4G
-XX:+UseG1GC
-XX:+ParallelRefProcEnabled
-XX:MaxGCPauseMillis=15
-XX:+UnlockExperimentalVMOptions
-XX:+DisableExplicitGC
-XX:+AlwaysPreTouch
-XX:G1NewSizePercent=40
-XX:G1MaxNewSizePercent=60
-XX:G1HeapRegionSize=8M
-XX:G1ReservePercent=10
-XX:G1HeapWastePercent=5
-XX:G1MixedGCCountTarget=8
-XX:InitiatingHeapOccupancyPercent=20
-XX:G1MixedGCLiveThresholdPercent=80
-XX:G1RSetUpdatingPauseTimePercent=5
-XX:SurvivorRatio=32
-XX:MaxTenuringThreshold=1
-XX:+UseStringDeduplication
-XX:+PerfDisableSharedMem
-XX:+UseNUMA
-XX:+UseFastUnorderedTimeStamps
-Dsun.rmi.dgc.server.gcInterval=2147483646
-Dsun.rmi.dgc.client.gcInterval=2147483646
```
