# R1zz Client — Minecraft Java 1.21 / Fabric

## Build the JAR with GitHub Actions

1. Download and extract this ZIP.
2. Create a GitHub repository.
3. Upload either the extracted source contents or the complete ZIP to the repository. The workflow searches for the actual Gradle project root, including inside a ZIP archive.
4. Open **Actions → Build R1zz Client → Run workflow** (or push to `main`/`master`).
5. When the run completes successfully, open it and download the `r1zz-client-1.21-jar` artifact.

The workflow installs Gradle 8.8 on GitHub's runner, locates the actual project root (including a ZIP uploaded to the repository), and builds with the wrapper when present or the installed Gradle otherwise. No hard-coded `cd source` path is used.

## Notes

This is a client-side Fabric project for Minecraft 1.21 and Java 21. The registered modules are FPS, coordinates, keystrokes, crosshair, and target HUD. No anti-cheat bypass is included.
