# R1zz

Client-side Fabric mod for **Minecraft 1.21**, built with Java 21.

## Build and install

Requirements: JDK 21 and Gradle 8.x. From the project root:

```sh
./gradlew build --no-daemon
```

The mod JAR is `build/libs/r1zz-1.0.0.jar`. Copy it into `.minecraft/mods` with Fabric Loader 0.15.11+ and Fabric API 0.100.1+1.21 installed.

## GUI and configuration

- **Right Shift** opens the centered 500 × 340 ClickGUI. Choose Combat, Movement, Render, Player, World, or Misc in the sidebar.
- Search the module list, click a module card to expand its settings, click its switch to toggle, and click its key chip to bind. Right-click the chip to clear it; press Escape while capturing to cancel.
- The gear panel provides GUI/module keybinds, the HUD keybind-list and chat-notification preferences, editable friends, and config save/load.
- Settings persist in `.minecraft/config/r1zz.properties`. The first run creates `.minecraft/config/r1zz_jvm_args.txt` with the requested JVM argument list; the mod does not apply those arguments to the launcher.

## Modules

**Combat:** AimAssist targets the body center and exposes speed, range, noise, FOV, target-type, and weapon-filter controls. FastGap is one toggle: manually hold use with a golden apple selected; the mixin shortens its 32-tick use duration to 16 ticks.

**Movement:** Sprint, one-block Step, NoFall, and Velocity with independent horizontal/vertical knockback-reduction sliders.

**Render:** ESP boxes/fill/health bars with Players/Mobs/Both filtering, crosshair-origin Tracers, enhanced Nametags, Fullbright, FogBlur, NoHurtCam, Freecam, hold-key Zoom, DashDots, Quality, Strength, HUD Elements, Tag Elements, Range, Hands, PlayerColor, FriendColor, and ColorMode.

**Player:** AutoRespawn, FastPlace, NoRotate, and AutoTool.

**World:** TimeChanger (client-side 0–24000) and WeatherChanger (Clear/Rain/Thunder). Disabling these reveals the server-provided values again.

**Misc:** AntiAFK, ChatSuffix (default ` | R1zz`), AutoReconnect, and PacketLogger (debug output to the console).

Right Shift is the default GUI key; all module keybinds default to NONE. Color overlays respect Strength and the friend list. The documented golden-apple speed effect follows the [Fast Gapple Modrinth page](https://modrinth.com/mod/fast-gapple).
