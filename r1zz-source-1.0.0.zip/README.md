# R1zz Client — Minecraft Java 1.21 / Fabric

## Build the JAR with GitHub Actions

1. Download and extract this ZIP.
2. Create a GitHub repository.
3. Upload the **contents of the extracted folder** to the repository root. `build.gradle`, `settings.gradle`, `gradle.properties`, `src/`, and `.github/` must be directly in the root. Do not put them inside another `source/` folder and do not rename the ZIP to `r1zz-source-1.0.0.zip`.
4. Open **Actions → Build R1zz Client → Run workflow** (or push to `main`/`master`).
5. When the run completes successfully, open it and download the `r1zz-client-1.21-jar` artifact.

The workflow installs Gradle on GitHub's runner and runs `gradle clean build`; a `gradlew` wrapper file is not required. The workflow intentionally does not run `chmod gradlew` or `cd source`.

## Notes

This source is a starting client-side Fabric project and has not been verified by a successful build in this environment. FPS/coordinates/crosshair/target HUD features and the ClickGUI are present at source level; not every displayed module/category is a finished feature. No anti-cheat bypass is included.
