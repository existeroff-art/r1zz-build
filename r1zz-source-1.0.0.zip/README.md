# R1zz Client

A Fabric 1.21 client with a focused combat GUI containing AimAssist, TriggerBot, and FastGap.

## FastGap — JVM Arguments

The FastGap module in this client is a UI toggle only. The actual golden apple eating speedup comes from JVM arguments applied to your Minecraft launcher. Add these arguments to your launcher's JVM arguments field (not the game arguments field):

```text
-Xms4G -Xmx4G
-XX:+UseG1GC
-XX:+ParallelRefProcEnabled
-XX:MaxGCPauseMillis=15
-XX:+UnlockExperimentalVMOptions
-XX:+DisableExplicitGC
-XX:+AlwaysPreTouch
-XX:G1NewSizePercent=40
-XX:G1MaxNewSizePercent=60
-XX:G1HeapRegionSize=8M
-XX:G1ReservePercent=10
-XX:G1HeapWastePercent=5
-XX:G1MixedGCCountTarget=8
-XX:InitiatingHeapOccupancyPercent=20
-XX:G1MixedGCLiveThresholdPercent=80
-XX:G1RSetUpdatingPauseTimePercent=5
-XX:SurvivorRatio=32
-XX:MaxTenuringThreshold=1
-XX:+UseStringDeduplication
-XX:+PerfDisableSharedMem
-XX:+UseNUMA
-XX:+UseFastUnorderedTimeStamps
-Dsun.rmi.dgc.server.gcInterval=2147483646
-Dsun.rmi.dgc.client.gcInterval=2147483646
```

These arguments reduce GC pauses so golden apple eating feels instant when FastGap toggle is on.
