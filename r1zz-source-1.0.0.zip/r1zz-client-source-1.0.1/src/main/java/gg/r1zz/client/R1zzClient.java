package gg.r1zz.client;

import gg.r1zz.client.config.R1zzConfig;
import gg.r1zz.client.module.ModuleManager;
import gg.r1zz.client.module.impl.R1zzCoordinates;
import gg.r1zz.client.module.impl.R1zzCrosshair;
import gg.r1zz.client.module.impl.R1zzFPS;
import gg.r1zz.client.module.impl.R1zzKeystrokes;
import gg.r1zz.client.module.impl.R1zzTargetHUD;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Locale;

public final class R1zzClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("R1zz");
    public static final ModuleManager MODULES = new ModuleManager();

    /** Default ClickGUI key: Right Shift (GLFW key code 344). Rebindable in Controls. */
    public static final int DEFAULT_MENU_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;

    private static KeyBinding openMenuKey;
    private static long tickCounter;
    /** Tick on which the GUI last closed; stops a close keypress from instantly re-opening it. */
    private static long menuClosedAtTick = Long.MIN_VALUE / 2;

    @Override
    public void onInitializeClient() {
        MODULES.register(new R1zzFPS());
        MODULES.register(new R1zzCoordinates());
        MODULES.register(new R1zzKeystrokes());
        MODULES.register(new R1zzCrosshair());
        MODULES.register(new R1zzTargetHUD());
        try {
            R1zzConfig.load(MODULES);
        } catch (IOException | RuntimeException e) {
            // Never let a bad config file stop the game from starting.
            LOGGER.warn("Could not load config, using defaults: {}", e.getMessage());
        }

        R1zzHud.register();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.r1zzclient.open_menu",
                InputUtil.Type.KEYSYM,
                DEFAULT_MENU_KEY,
                "category.r1zzclient"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            tickCounter++;
            boolean modulesToggled = MODULES.tick(client.currentScreen == null);
            if (modulesToggled) {
                try {
                    R1zzConfig.save(MODULES);
                } catch (IOException e) {
                    LOGGER.warn("Could not save config: {}", e.getMessage());
                }
            }

            // Always drain the key so presses made while a screen is open cannot pile up.
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null && tickCounter - menuClosedAtTick > 2) {
                    client.setScreen(new R1zzClickGuiScreen());
                }
            }
        });
    }

    /** True if the given key event is the configured "open R1zz menu" key. */
    public static boolean isMenuKey(int keyCode, int scanCode) {
        return openMenuKey != null && openMenuKey.matchesKey(keyCode, scanCode);
    }

    /** Human-readable name of the menu key, for on-screen hints. */
    public static String menuKeyLabel() {
        return openMenuKey == null
                ? "RIGHT SHIFT"
                : openMenuKey.getBoundKeyLocalizedText().getString().toUpperCase(Locale.ROOT);
    }

    /** Called by the GUI whenever it closes, by any route. */
    static void noteMenuClosed() {
        menuClosedAtTick = tickCounter;
    }
}
