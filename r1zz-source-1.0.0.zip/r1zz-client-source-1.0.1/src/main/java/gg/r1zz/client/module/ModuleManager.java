package gg.r1zz.client.module;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public final class ModuleManager {
    private final List<R1zzModule> modules = new ArrayList<>();

    public void register(R1zzModule module) {
        if (find(module.id()).isPresent()) {
            throw new IllegalArgumentException("Duplicate module ID: " + module.id());
        }
        modules.add(module);
        String keyId = module.id().toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9_.-]", "_");
        KeyBinding binding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.r1zzclient.module." + keyId,
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                "category.r1zzclient.modules"
        ));
        module.attachKeyBinding(binding);
    }

    public List<R1zzModule> all() {
        return Collections.unmodifiableList(modules);
    }

    public List<R1zzModule> in(ModuleCategory category) {
        return modules.stream().filter(module -> module.category() == category).toList();
    }

    public Optional<R1zzModule> find(String name) {
        return modules.stream().filter(module -> module.id().equalsIgnoreCase(name)
                || module.name().equalsIgnoreCase(name)).findFirst();
    }

    public boolean isKeyCodeInUse(int keyCode, R1zzModule except) {
        if (keyCode < GLFW.GLFW_KEY_SPACE) return false;
        return modules.stream().anyMatch(module -> module != except
                && module.keyCode() == keyCode);
    }

    /** Consume key events every tick; only toggle modules when no screen is open. */
    public boolean tick(boolean allowKeybinds) {
        boolean toggled = false;
        for (R1zzModule module : modules) {
            boolean pressed = false;
            while (module.wasKeyPressed()) pressed = true;
            if (pressed && allowKeybinds) {
                module.toggle();
                toggled = true;
            }
            if (module.enabled()) module.onTick();
        }
        return toggled;
    }
}
