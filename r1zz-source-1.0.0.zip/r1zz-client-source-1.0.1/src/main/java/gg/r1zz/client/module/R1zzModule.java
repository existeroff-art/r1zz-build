package gg.r1zz.client.module;

import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public abstract class R1zzModule {
    private final String id;
    private final String name;
    private final ModuleCategory category;
    private final String description;
    private boolean enabled;
    private int keyCode = GLFW.GLFW_KEY_UNKNOWN;
    private KeyBinding keyBinding;

    protected R1zzModule(String name, ModuleCategory category) {
        this(name, category, "");
    }

    protected R1zzModule(String name, ModuleCategory category, String description) {
        this.description = description == null ? "" : description;
        this.id = name;
        if (name.startsWith("R1zz ")) this.name = name;
        else if (name.startsWith("R1zz")) this.name = "R1zz " + name.substring(4);
        else this.name = "R1zz " + name;
        this.category = category;
    }

    public final String id() { return id; }
    public final String name() { return name; }
    public final ModuleCategory category() { return category; }
    public final String description() { return description; }
    public final boolean enabled() { return enabled; }
    public final int keyCode() { return keyCode; }

    public final void setKeyCode(int keyCode) {
        if (keyCode == 0 || keyCode < GLFW.GLFW_KEY_SPACE || keyCode > GLFW.GLFW_KEY_LAST) {
            this.keyCode = GLFW.GLFW_KEY_UNKNOWN;
        } else {
            this.keyCode = keyCode;
        }
        syncKeyBinding();
    }

    final void attachKeyBinding(KeyBinding keyBinding) {
        this.keyBinding = keyBinding;
        syncKeyBinding();
    }

    private void syncKeyBinding() {
        if (keyBinding == null) return;
        InputUtil.Key key = keyCode == GLFW.GLFW_KEY_UNKNOWN
                ? InputUtil.UNKNOWN_KEY
                : InputUtil.Type.KEYSYM.createFromCode(keyCode);
        keyBinding.setBoundKey(key);
        KeyBinding.updateKeysByCode();
    }

    public final Text keyBindingText() {
        return keyBinding == null ? Text.literal("Unbound") : keyBinding.getBoundKeyLocalizedText();
    }

    public final boolean wasKeyPressed() {
        return keyBinding != null && keyBinding.wasPressed();
    }

    public final void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public final void setEnabled(boolean value) {
        if (enabled != value) toggle();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
}
