package gg.r1zz.client.config;

import gg.r1zz.client.module.ModuleManager;
import gg.r1zz.client.module.R1zzModule;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

/**
 * Persists module state to {@code config/r1zz-client.properties}.
 *
 * <p>Format: Java properties, two keys per module: {@code <moduleId>.enabled}
 * ({@code true}/{@code false}) and {@code <moduleId>.key} (GLFW key code, {@code -1} = unbound).
 * Missing, malformed or conflicting values fall back to safe defaults
 * (disabled, unbound). A file that cannot be parsed is renamed to
 * {@code r1zz-client.properties.bad} before it would be overwritten.
 */
public final class R1zzConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir()
            .resolve("r1zz-client.properties");

    /** Snapshot of what is on disk, so unchanged settings are not rewritten. */
    private static Properties lastWritten = new Properties();

    private R1zzConfig() {}

    private static Properties snapshot(ModuleManager manager) {
        Properties properties = new Properties();
        for (R1zzModule module : manager.all()) {
            properties.setProperty(module.id() + ".enabled", Boolean.toString(module.enabled()));
            properties.setProperty(module.id() + ".key", Integer.toString(module.keyCode()));
        }
        return properties;
    }

    public static void save(ModuleManager manager) throws IOException {
        Properties properties = snapshot(manager);
        if (properties.equals(lastWritten) && Files.exists(FILE)) return;

        Files.createDirectories(FILE.getParent());
        Path temporaryFile = FILE.resolveSibling(FILE.getFileName() + ".tmp");
        try {
            try (var output = Files.newOutputStream(temporaryFile)) {
                properties.store(output, "R1zz Client settings");
            }
            try {
                Files.move(temporaryFile, FILE, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temporaryFile, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporaryFile);
        }
        lastWritten = properties;
    }

    public static void load(ModuleManager manager) throws IOException {
        if (!Files.isRegularFile(FILE)) return;
        Properties properties = new Properties();
        try (var input = Files.newInputStream(FILE)) {
            properties.load(input);
        } catch (IllegalArgumentException malformed) {
            // Properties.load throws this (not IOException) for bad \\uXXXX escapes.
            quarantineBadFile();
            throw new IOException("Malformed config file: " + malformed.getMessage(), malformed);
        } catch (IOException unreadable) {
            quarantineBadFile();
            throw unreadable;
        }

        for (R1zzModule module : manager.all()) {
            String enabled = properties.getProperty(module.id() + ".enabled");
            if (enabled != null) {
                enabled = enabled.trim();
                if (enabled.equalsIgnoreCase("true")) module.setEnabled(true);
                else if (enabled.equalsIgnoreCase("false")) module.setEnabled(false);
                // anything else: keep the module's default state
            }

            int keyCode = GLFW.GLFW_KEY_UNKNOWN;
            String rawKey = properties.getProperty(module.id() + ".key");
            if (rawKey != null) {
                try {
                    keyCode = Integer.parseInt(rawKey.trim());
                } catch (NumberFormatException ignored) {
                    keyCode = GLFW.GLFW_KEY_UNKNOWN;
                }
            }
            // Right Shift is reserved for the menu; a key may be used by one module only.
            if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT
                    || manager.isKeyCodeInUse(keyCode, module)) {
                keyCode = GLFW.GLFW_KEY_UNKNOWN;
            }
            module.setKeyCode(keyCode);
        }
        lastWritten = snapshot(manager);
    }

    private static void quarantineBadFile() {
        try {
            Files.move(FILE, FILE.resolveSibling(FILE.getFileName() + ".bad"),
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ignored) {
            // Best effort only; the next save simply overwrites it.
        }
    }
}
