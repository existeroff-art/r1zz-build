package gg.r1zz.client;

import gg.r1zz.client.config.R1zzConfig;
import gg.r1zz.client.module.ModuleCategory;
import gg.r1zz.client.module.R1zzModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class R1zzClickGuiScreen extends Screen {
    private static final Identifier LOGO = Identifier.of(
            "r1zzclient", "textures/gui/r1zz_logo.png");
    /** Size of the packaged logo texture (the 1536px original is kept in /branding). */
    private static final int LOGO_TEXTURE = 128;
    private static final int LOGO_SIZE = 34;
    private static final int HEADER_HEIGHT = 50;
    private static final int ROW_HEIGHT = 44;
    private static final int MAX_KEY_BUTTON_WIDTH = 88;
    private static final int TOGGLE_WIDTH = 30;
    private static final int FOOTER_HEIGHT = 24;

    // ---- theme (dark, pink accent) ----
    // Requested values:
    private static final int PANEL = 0xFF0A0A0F;        // main panel
    private static final int SIDEBAR = 0xFF050508;      // sidebar
    private static final int BORDER = 0xFF1A1A24;       // panel border / separators
    private static final int ACCENT = 0xFFFF6B9D;       // main accent
    private static final int ACCENT_END = 0xFFC41E5A;   // gradient endpoint
    // Derived neutrals (not specified; chosen to sit between PANEL and BORDER):
    private static final int PANEL_TOP = 0xFF0E0E15;
    private static final int ROW = 0xFF101018;
    private static final int ROW_HOVER = BORDER;
    private static final int TEXT = 0xFFF5F2F5;
    private static final int MUTED = 0xFFA8A3AD;
    private static final int TRACK_OFF = 0xFF2A2A36;
    private static final int TRACK_ON = ACCENT_END;
    private static final int NAV_ACTIVE = 0xFF1C0F18;
    private static final int KEY_IDLE = 0xFF15151E;
    private static final int KEY_HOVER = BORDER;
    private static final int KEY_CAPTURE = 0xFF3A1226;

    private final List<ModuleCategory> categories;
    private ModuleCategory selected;
    private List<R1zzModule> rows = List.of();
    private R1zzModule bindingModule;
    private String notice = "";

    private int focus = -1;
    private int scroll;

    private final Map<R1zzModule, Float> knobAnimation = new HashMap<>();
    private long lastFrameNanos = System.nanoTime();

    private int guiX;
    private int guiY;
    private int guiWidth;
    private int guiHeight;
    private boolean dragging;
    private int dragOffsetX;
    private int dragOffsetY;

    public R1zzClickGuiScreen() {
        super(Text.literal("R1zz Client"));
        categories = R1zzClient.MODULES.all().stream()
                .map(R1zzModule::category)
                .distinct()
                .toList();
        selected = categories.contains(ModuleCategory.HUD)
                ? ModuleCategory.HUD
                : (categories.isEmpty() ? ModuleCategory.HUD : categories.get(0));
        refreshRows();
    }

    private void refreshRows() {
        rows = R1zzClient.MODULES.in(selected);
        focus = -1;
        scroll = 0;
    }

    private void selectCategory(ModuleCategory category) {
        if (category == selected) return;
        selected = category;
        notice = "";
        refreshRows();
    }

    @Override
    protected void init() {
        guiWidth = Math.min(690, Math.max(180, width - 24));
        guiHeight = Math.min(390, Math.max(200, height - 24));
        if (guiWidth > width - 12) guiWidth = Math.max(1, width - 12);
        if (guiHeight > height - 12) guiHeight = Math.max(1, height - 12);
        guiX = Math.max(0, (width - guiWidth) / 2);
        guiY = Math.max(0, (height - guiHeight) / 2);
        scroll = Math.min(scroll, maxScroll());
    }

    @Override
    public void removed() {
        R1zzClient.noteMenuClosed();
    }

    public boolean isCapturingKeyBinding() {
        return bindingModule != null;
    }

    // ---- layout ----------------------------------------------------------------------

    private int navigationWidth() {
        return Math.min(112, Math.max(82, guiWidth / 4));
    }

    private int navigationTop() {
        return guiY + HEADER_HEIGHT + 15;
    }

    private int contentLeft() {
        return guiX + navigationWidth() + 16;
    }

    private int rowTop() {
        return guiY + HEADER_HEIGHT + 47;
    }

    private int viewBottom() {
        return guiY + guiHeight - FOOTER_HEIGHT;
    }

    private int rowRight() {
        return guiX + guiWidth - 12;
    }

    private int toggleX() {
        return rowRight() - TOGGLE_WIDTH - 4;
    }

    private int keyButtonWidth() {
        return Math.max(48, Math.min(MAX_KEY_BUTTON_WIDTH, (rowRight() - contentLeft()) / 4));
    }

    private int keyButtonX() {
        return toggleX() - keyButtonWidth() - 10;
    }

    private int maxScroll() {
        int content = rows.size() * ROW_HEIGHT - 3;
        return Math.max(0, content - (viewBottom() - rowTop()));
    }

    private boolean inListView(double mouseY) {
        return mouseY >= rowTop() && mouseY < viewBottom();
    }

    private String fit(String value, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (textRenderer.getWidth(value) <= maxWidth) return value;
        String ellipsis = "…";
        int end = value.length();
        while (end > 0 && textRenderer.getWidth(value.substring(0, end))
                + textRenderer.getWidth(ellipsis) > maxWidth) {
            end--;
        }
        return value.substring(0, end) + ellipsis;
    }

    private static int lerpColor(int from, int to, float t) {
        int a = (int) (((from >>> 24) & 0xFF) + (((to >>> 24) & 0xFF) - ((from >>> 24) & 0xFF)) * t);
        int r = (int) (((from >>> 16) & 0xFF) + (((to >>> 16) & 0xFF) - ((from >>> 16) & 0xFF)) * t);
        int g = (int) (((from >>> 8) & 0xFF) + (((to >>> 8) & 0xFF) - ((from >>> 8) & 0xFF)) * t);
        int b = (int) ((from & 0xFF) + ((to & 0xFF) - (from & 0xFF)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Horizontal two-colour gradient (DrawContext.fillGradient is vertical only). */
    private static void fillHorizontalGradient(DrawContext context, int x1, int y1, int x2, int y2,
                                               int from, int to) {
        int width = x2 - x1;
        if (width <= 0 || y2 <= y1) return;
        final int step = 2;
        for (int dx = 0; dx < width; dx += step) {
            float t = width <= 1 ? 0.0f : (float) dx / (width - 1);
            context.fill(x1 + dx, y1, Math.min(x1 + dx + step, x2), y2, lerpColor(from, to, t));
        }
    }

    /** 1px outline. */
    private static void drawBorder(DrawContext context, int x1, int y1, int x2, int y2, int color) {
        context.fill(x1, y1, x2, y1 + 1, color);
        context.fill(x1, y2 - 1, x2, y2, color);
        context.fill(x1, y1, x1 + 1, y2, color);
        context.fill(x2 - 1, y1, x2, y2, color);
    }

    /** Frame-rate independent ease toward the module's on/off state. */
    private float animatedKnob(R1zzModule module, float dt) {
        float target = module.enabled() ? 1.0f : 0.0f;
        float value = knobAnimation.getOrDefault(module, target);
        value += (target - value) * (1.0f - (float) Math.exp(-dt * 16.0f));
        if (Math.abs(target - value) < 0.01f) value = target;
        knobAnimation.put(module, value);
        return value;
    }

    // ---- rendering -------------------------------------------------------------------

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastFrameNanos) / 1.0e9f);
        lastFrameNanos = now;

        // Background is drawn exactly once. This screen has no child widgets, so
        // super.render() is deliberately not called: on 1.21 it can draw the
        // background a second time over the finished GUI.
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(guiX, guiY, guiX + guiWidth, guiY + guiHeight, PANEL);
        context.fill(guiX, guiY, guiX + guiWidth, guiY + HEADER_HEIGHT, PANEL_TOP);
        fillHorizontalGradient(context, guiX, guiY + HEADER_HEIGHT - 2, guiX + guiWidth,
                guiY + HEADER_HEIGHT, ACCENT, ACCENT_END);
        context.fill(guiX, guiY + HEADER_HEIGHT, guiX + navigationWidth() + 8,
                guiY + guiHeight, SIDEBAR);
        context.fill(guiX + navigationWidth() + 8, guiY + HEADER_HEIGHT,
                guiX + navigationWidth() + 9, guiY + guiHeight, BORDER);
        drawBorder(context, guiX, guiY, guiX + guiWidth, guiY + guiHeight, BORDER);

        // Logo: the whole texture scaled into LOGO_SIZE (the old call drew only a
        // 34x34 pixel corner of the 1536px image), inside an accent-coloured frame.
        context.fill(guiX + 9, guiY + 7, guiX + 11 + LOGO_SIZE, guiY + 9 + LOGO_SIZE, ACCENT);
        context.drawTexture(LOGO, guiX + 10, guiY + 8, LOGO_SIZE, LOGO_SIZE,
                0.0f, 0.0f, LOGO_TEXTURE, LOGO_TEXTURE, LOGO_TEXTURE, LOGO_TEXTURE);

        int hintRight = guiX + guiWidth - 34;
        String menuHint = R1zzClient.menuKeyLabel() + "  •  MENU";
        int hintWidth = textRenderer.getWidth(menuHint);
        int titleRight = guiX + 54 + textRenderer.getWidth("CLIENT INTERFACE");
        context.drawText(textRenderer, "R1zz Client", guiX + 54, guiY + 12, TEXT, true);
        context.drawText(textRenderer, "CLIENT INTERFACE", guiX + 54, guiY + 28, MUTED, false);
        if (hintRight - hintWidth > titleRight + 12) { // hide the hint rather than overlap
            context.drawText(textRenderer, menuHint, hintRight - hintWidth, guiY + 20, MUTED, false);
        }
        context.drawText(textRenderer, "×", guiX + guiWidth - 20, guiY + 18, TEXT, true);

        renderNavigation(context, mouseX, mouseY);
        renderModuleList(context, mouseX, mouseY, dt);
        renderFooter(context);
    }

    private void renderNavigation(DrawContext context, int mouseX, int mouseY) {
        context.drawText(textRenderer, "CATEGORIES", guiX + 14,
                guiY + HEADER_HEIGHT + 4, MUTED, false);
        int navWidth = navigationWidth();
        int top = navigationTop();
        for (int i = 0; i < categories.size(); i++) {
            ModuleCategory category = categories.get(i);
            int y = top + i * 34;
            if (y + 28 > guiY + guiHeight) break; // never draw outside the panel
            boolean active = selected == category;
            boolean hover = mouseX >= guiX + 8 && mouseX <= guiX + navWidth
                    && mouseY >= y && mouseY < y + 28;
            if (active) {
                context.fill(guiX + 7, y, guiX + navWidth, y + 28, NAV_ACTIVE);
                context.fill(guiX + 7, y + 3, guiX + 9, y + 25, ACCENT);
            } else if (hover) {
                context.fill(guiX + 7, y, guiX + navWidth, y + 28, ROW);
            }
            String count = Integer.toString(R1zzClient.MODULES.in(category).size());
            int countWidth = textRenderer.getWidth(count);
            context.drawText(textRenderer,
                    fit(category.displayName(), navWidth - 17 - countWidth - 14),
                    guiX + 17, y + 9, active ? ACCENT : TEXT, active);
            context.drawText(textRenderer, count, guiX + navWidth - countWidth - 9,
                    y + 9, MUTED, false);
        }
    }

    private void renderModuleList(DrawContext context, int mouseX, int mouseY, float dt) {
        int contentX = contentLeft();
        int contentY = guiY + HEADER_HEIGHT + 13;
        String heading = selected.displayName().toUpperCase(Locale.ROOT);
        context.drawText(textRenderer, heading, contentX, contentY, TEXT, true);
        context.drawText(textRenderer,
                fit("Click a row to toggle  •  arrows + Enter  •  B to bind",
                        rowRight() - contentX),
                contentX, contentY + 16, MUTED, false);

        if (rows.isEmpty()) {
            context.drawText(textRenderer, "No modules in this category yet.",
                    contentX, rowTop() + 8, MUTED, false);
            return;
        }

        scroll = Math.max(0, Math.min(scroll, maxScroll()));
        int keyWidth = keyButtonWidth();
        int keyX = keyButtonX();
        int toggleX = toggleX();
        int textMax = keyX - (contentX + 11) - 8;

        context.enableScissor(contentX - 2, rowTop(), rowRight() + 2, viewBottom());
        int y = rowTop() - scroll;
        for (int i = 0; i < rows.size(); i++, y += ROW_HEIGHT) {
            R1zzModule module = rows.get(i);
            if (y + ROW_HEIGHT < rowTop() || y > viewBottom()) {
                animatedKnob(module, dt);
                continue;
            }
            int bottom = y + ROW_HEIGHT - 3;
            float knob = animatedKnob(module, dt);
            boolean hover = inListView(mouseY) && mouseX >= contentX && mouseX <= rowRight()
                    && mouseY >= y && mouseY < y + ROW_HEIGHT;
            context.fill(contentX, y, rowRight(), bottom, hover ? ROW_HOVER : ROW);
            context.fill(contentX, y, contentX + 2, bottom,
                    lerpColor(BORDER, ACCENT, knob));
            if (i == focus) { // keyboard focus outline
                context.fill(contentX, y, rowRight(), y + 1, ACCENT);
                context.fill(contentX, bottom - 1, rowRight(), bottom, ACCENT);
                context.fill(rowRight() - 1, y, rowRight(), bottom, ACCENT);
            }

            context.drawText(textRenderer, fit(module.name(), textMax), contentX + 11, y + 7,
                    module.enabled() ? ACCENT : TEXT, module.enabled());
            String detail = module.description().isEmpty()
                    ? module.category().displayName() + " module"
                    : module.description();
            context.drawText(textRenderer, fit(detail, textMax), contentX + 11, y + 23,
                    MUTED, false);

            boolean keyHover = inListView(mouseY) && mouseX >= keyX && mouseX <= keyX + keyWidth
                    && mouseY >= y + 6 && mouseY < y + ROW_HEIGHT - 7;
            boolean capturing = bindingModule == module;
            context.fill(keyX, y + 7, keyX + keyWidth, y + ROW_HEIGHT - 8,
                    capturing ? KEY_CAPTURE : (keyHover ? KEY_HOVER : KEY_IDLE));
            String keyLabel = capturing ? "PRESS KEY" : keyLabel(module, keyWidth);
            drawCentered(context, fit(keyLabel, keyWidth - 8), keyX, y + 17, keyWidth,
                    capturing ? TEXT : MUTED, capturing);

            int sy = y + 13;
            context.fill(toggleX, sy, toggleX + TOGGLE_WIDTH, sy + 16,
                    lerpColor(TRACK_OFF, TRACK_ON, knob));
            int knobX = toggleX + 3 + Math.round(14 * knob);
            context.fill(knobX, sy + 3, knobX + 10, sy + 13, 0xFFFFFFFF);
        }
        context.disableScissor();

        if (maxScroll() > 0) { // slim scrollbar
            int trackTop = rowTop();
            int trackHeight = viewBottom() - rowTop();
            int thumb = Math.max(16, trackHeight * trackHeight / (trackHeight + maxScroll()));
            int thumbY = trackTop + (trackHeight - thumb) * scroll / maxScroll();
            context.fill(rowRight() + 3, trackTop, rowRight() + 5, viewBottom(), BORDER);
            context.fill(rowRight() + 3, thumbY, rowRight() + 5, thumbY + thumb, ACCENT);
        }
    }

    private String keyLabel(R1zzModule module, int boxWidth) {
        if (module.keyCode() == GLFW.GLFW_KEY_UNKNOWN) return "UNBOUND";
        return fit(module.keyBindingText().getString().toUpperCase(Locale.ROOT), boxWidth - 12);
    }

    private void drawCentered(DrawContext context, String value, int x, int y,
                              int boxWidth, int color, boolean shadow) {
        context.drawText(textRenderer, value,
                x + (boxWidth - textRenderer.getWidth(value)) / 2, y, color, shadow);
    }

    private void renderFooter(DrawContext context) {
        String footer = bindingModule == null
                ? (notice.isEmpty() ? "R1zz • local client settings" : notice)
                : "Press a key  •  Esc cancels  •  Backspace clears";
        context.drawText(textRenderer, fit(footer, guiWidth - 26), guiX + 13,
                guiY + guiHeight - 17, bindingModule == null ? MUTED : ACCENT, false);
    }

    // ---- input -----------------------------------------------------------------------

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (bindingModule != null && button == 0) {
            bindingModule = null;
            notice = "Key assignment cancelled.";
            return true;
        }

        if (button == 0 && mouseY >= guiY && mouseY <= guiY + HEADER_HEIGHT
                && mouseX >= guiX && mouseX <= guiX + guiWidth) {
            if (mouseX >= guiX + guiWidth - 28) {
                close();
                return true;
            }
            dragging = true;
            dragOffsetX = (int) mouseX - guiX;
            dragOffsetY = (int) mouseY - guiY;
            return true;
        }

        if (button == 0) {
            int navWidth = navigationWidth();
            int navTop = navigationTop();
            for (int i = 0; i < categories.size(); i++) {
                int y = navTop + i * 34;
                if (mouseX >= guiX + 7 && mouseX <= guiX + navWidth
                        && mouseY >= y && mouseY < y + 28) {
                    selectCategory(categories.get(i));
                    return true;
                }
            }

            if (inListView(mouseY)) {
                int contentX = contentLeft();
                int y = rowTop() - scroll;
                for (int i = 0; i < rows.size(); i++, y += ROW_HEIGHT) {
                    R1zzModule module = rows.get(i);
                    if (mouseX >= contentX && mouseX <= rowRight()
                            && mouseY >= y && mouseY < y + ROW_HEIGHT - 3) {
                        focus = i;
                        int keyX = keyButtonX();
                        if (mouseX >= keyX && mouseX < keyX + keyButtonWidth()
                                && mouseX < toggleX() - 4) {
                            beginBinding(module);
                            return true;
                        }
                        module.toggle();
                        saveSettings();
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void beginBinding(R1zzModule module) {
        bindingModule = module;
        notice = "";
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount,
                                 double verticalAmount) {
        if (maxScroll() > 0 && mouseX >= guiX && mouseX <= guiX + guiWidth) {
            scroll = Math.max(0, Math.min(maxScroll(),
                    scroll - (int) Math.round(verticalAmount * (ROW_HEIGHT / 2.0))));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindingModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                bindingModule = null;
                notice = "Key assignment cancelled.";
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
                bindingModule.setKeyCode(GLFW.GLFW_KEY_UNKNOWN);
                bindingModule = null;
                saveSettings();
                return true;
            }
            if (R1zzClient.isMenuKey(keyCode, scanCode)
                    || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
                notice = "That key is reserved for opening the R1zz GUI.";
                return true;
            }
            if (R1zzClient.MODULES.isKeyCodeInUse(keyCode, bindingModule)) {
                notice = "That key is already assigned to another module.";
                return true;
            }
            bindingModule.setKeyCode(keyCode);
            bindingModule = null;
            saveSettings();
            return true;
        }

        if (R1zzClient.isMenuKey(keyCode, scanCode)) {
            close();
            return true;
        }
        switch (keyCode) {
            case GLFW.GLFW_KEY_DOWN -> moveFocus(1);
            case GLFW.GLFW_KEY_UP -> moveFocus(-1);
            case GLFW.GLFW_KEY_RIGHT -> moveCategory(1);
            case GLFW.GLFW_KEY_LEFT -> moveCategory(-1);
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER, GLFW.GLFW_KEY_SPACE -> {
                if (focus < 0 || focus >= rows.size()) return true;
                rows.get(focus).toggle();
                saveSettings();
            }
            case GLFW.GLFW_KEY_B -> {
                if (focus < 0 || focus >= rows.size()) return true;
                beginBinding(rows.get(focus));
            }
            default -> {
                return super.keyPressed(keyCode, scanCode, modifiers); // Esc closes
            }
        }
        return true;
    }

    private void moveFocus(int direction) {
        if (rows.isEmpty()) return;
        focus = focus < 0
                ? (direction > 0 ? 0 : rows.size() - 1)
                : Math.max(0, Math.min(rows.size() - 1, focus + direction));
        int top = focus * ROW_HEIGHT;
        int viewHeight = viewBottom() - rowTop();
        if (top < scroll) scroll = top;
        else if (top + ROW_HEIGHT - 3 > scroll + viewHeight) scroll = top + ROW_HEIGHT - 3 - viewHeight;
        scroll = Math.max(0, Math.min(scroll, maxScroll()));
    }

    private void moveCategory(int direction) {
        int index = categories.indexOf(selected);
        if (index < 0 || categories.isEmpty()) return;
        selectCategory(categories.get(Math.floorMod(index + direction, categories.size())));
    }

    private void saveSettings() {
        try {
            R1zzConfig.save(R1zzClient.MODULES);
            notice = "Settings saved.";
        } catch (IOException e) {
            notice = "Could not save settings.";
            R1zzClient.LOGGER.warn("Could not save config: {}", e.getMessage());
        }
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button,
                                double deltaX, double deltaY) {
        if (dragging && button == 0) {
            guiX = Math.max(0, Math.min(width - guiWidth, (int) mouseX - dragOffsetX));
            guiY = Math.max(0, Math.min(height - guiHeight, (int) mouseY - dragOffsetY));
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) dragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
