package gg.r1zz.client.module.impl;

import gg.r1zz.client.module.ModuleCategory;
import gg.r1zz.client.module.R1zzModule;

public final class R1zzTargetHUD extends R1zzModule {
    public R1zzTargetHUD() { super("R1zzTargetHUD", ModuleCategory.RENDER,
                "Shows name and health of the entity you look at."); }
}
