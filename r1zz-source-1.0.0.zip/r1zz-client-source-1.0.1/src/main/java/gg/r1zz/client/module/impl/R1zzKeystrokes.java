package gg.r1zz.client.module.impl;

import gg.r1zz.client.module.ModuleCategory;
import gg.r1zz.client.module.R1zzModule;

public final class R1zzKeystrokes extends R1zzModule {
    public R1zzKeystrokes() { super("R1zzKeystrokes", ModuleCategory.HUD,
                "Shows W A S D and jump key presses."); }
}
