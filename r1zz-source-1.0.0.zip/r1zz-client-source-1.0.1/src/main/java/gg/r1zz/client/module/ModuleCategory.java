package gg.r1zz.client.module;

public enum ModuleCategory {
    COMBAT("Combat"), RENDER("Render"), HUD("HUD"), CLIENT("Client"), CONFIG("Config");
    private final String displayName;
    ModuleCategory(String displayName) { this.displayName = displayName; }
    public String displayName() { return displayName; }
}
