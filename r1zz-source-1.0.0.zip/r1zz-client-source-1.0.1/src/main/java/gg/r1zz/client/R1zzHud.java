package gg.r1zz.client;

import gg.r1zz.client.module.R1zzModule;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;

public final class R1zzHud {
    // Same palette as the ClickGUI (dark panel, pink accent).
    private static final int ACCENT = 0xFFFF6B9D;
    private static final int ACCENT_END = 0xFFC41E5A;
    private static final int BORDER = 0xFF1A1A24;
    private static final int WHITE = 0xFFF5F2F5;
    private static final int PANEL = 0xD90A0A0F;       // 0xFF0A0A0F main panel colour at ~85% alpha

    // Resolved once at registration instead of searching the module list every frame.
    private static R1zzModule fps;
    private static R1zzModule coordinates;
    private static R1zzModule keystrokes;
    private static R1zzModule crosshair;
    private static R1zzModule targetHud;

    // Text caches: strings are rebuilt only when the displayed value changes.
    private static int lastFps = -1;
    private static String fpsText = "";
    private static long lastX = Long.MIN_VALUE;
    private static long lastY = Long.MIN_VALUE;
    private static long lastZ = Long.MIN_VALUE;
    private static String coordinateText = "";

    private R1zzHud() {}

    private static boolean on(R1zzModule module) {
        return module != null && module.enabled();
    }

    public static void register() {
        fps = R1zzClient.MODULES.find("R1zzFPS").orElse(null);
        coordinates = R1zzClient.MODULES.find("R1zzCoordinates").orElse(null);
        keystrokes = R1zzClient.MODULES.find("R1zzKeystrokes").orElse(null);
        crosshair = R1zzClient.MODULES.find("R1zzCrosshair").orElse(null);
        targetHud = R1zzClient.MODULES.find("R1zzTargetHUD").orElse(null);

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client == null || client.player == null || client.world == null
                    || client.textRenderer == null || client.options == null
                    || client.options.hudHidden) return; // F1 hides the whole HUD

            int y = 8;
            if (on(fps)) {
                int currentFps = client.getCurrentFps();
                if (currentFps != lastFps) {
                    lastFps = currentFps;
                    fpsText = "R1zz | FPS " + currentFps;
                }
                drawContext.drawTextWithShadow(client.textRenderer, fpsText, 8, y, ACCENT);
                y += 12;
            }
            if (on(coordinates)) {
                long x = Math.round(client.player.getX() * 10.0);
                long py = Math.round(client.player.getY() * 10.0);
                long z = Math.round(client.player.getZ() * 10.0);
                if (x != lastX || py != lastY || z != lastZ) {
                    lastX = x;
                    lastY = py;
                    lastZ = z;
                    coordinateText = String.format(Locale.ROOT, "R1zz | X %.1f Y %.1f Z %.1f",
                            x / 10.0, py / 10.0, z / 10.0);
                }
                drawContext.drawTextWithShadow(client.textRenderer, coordinateText, 8, y, WHITE);
                y += 12;
            }
            if (on(keystrokes)) {
                drawKeystrokes(drawContext, client, Math.max(48, y + 4));
            }
            if (on(crosshair)) {
                drawCrosshair(drawContext, client);
            }
            if (on(targetHud)) {
                drawTargetHud(drawContext, client);
            }
        });
    }

    private static void drawKeystrokes(DrawContext context, MinecraftClient client, int top) {
        int x = 8, y = top, size = 20, gap = 3;
        drawKey(context, client, "W", x + size + gap, y,
                client.options.forwardKey.isPressed(), size);
        drawKey(context, client, "A", x, y + size + gap,
                client.options.leftKey.isPressed(), size);
        drawKey(context, client, "S", x + size + gap, y + size + gap,
                client.options.backKey.isPressed(), size);
        drawKey(context, client, "D", x + (size + gap) * 2, y + size + gap,
                client.options.rightKey.isPressed(), size);
        drawKey(context, client, "JUMP", x, y + (size + gap) * 2,
                client.options.jumpKey.isPressed(), size * 3 + gap * 2);
    }

    private static void drawKey(DrawContext context, MinecraftClient client, String label,
                                int x, int y, boolean down, int width) {
        context.fill(x, y, x + width, y + 20, down ? ACCENT_END : PANEL);
        context.fill(x, y, x + width, y + 1, down ? ACCENT : BORDER);
        int textWidth = client.textRenderer.getWidth(label);
        context.drawTextWithShadow(client.textRenderer, label,
                x + (width - textWidth) / 2, y + 6, WHITE);
    }

    private static void drawCrosshair(DrawContext context, MinecraftClient client) {
        int centerX = client.getWindow().getScaledWidth() / 2;
        int centerY = client.getWindow().getScaledHeight() / 2;
        context.fill(centerX - 7, centerY, centerX - 2, centerY + 1, ACCENT);
        context.fill(centerX + 2, centerY, centerX + 7, centerY + 1, ACCENT);
        context.fill(centerX, centerY - 7, centerX + 1, centerY - 2, ACCENT);
        context.fill(centerX, centerY + 2, centerX + 1, centerY + 7, ACCENT);
        context.fill(centerX, centerY, centerX + 1, centerY + 1, WHITE);
    }

    private static void drawTargetHud(DrawContext context, MinecraftClient client) {
        if (!(client.targetedEntity instanceof LivingEntity target) || !target.isAlive()) return;
        int x = client.getWindow().getScaledWidth() / 2 + 14;
        int y = client.getWindow().getScaledHeight() / 2 + 12;
        int width = 118, height = 40; // was 34: the health line (y+28, 8px tall) overflowed the panel
        context.fill(x, y, x + width, y + height, PANEL);
        context.fill(x, y, x + width, y + 2, ACCENT);

        String name = target.getName().getString();
        if (name.isBlank()) name = "Unknown";
        int maxNameWidth = width - 10;
        while (client.textRenderer.getWidth(name) > maxNameWidth && name.length() > 3) {
            name = name.substring(0, name.length() - 2) + "…";
        }
        context.drawTextWithShadow(client.textRenderer, name, x + 5, y + 6, WHITE);

        float maximumHealth = target.getMaxHealth();
        if (!Float.isFinite(maximumHealth) || maximumHealth <= 0.0f) maximumHealth = 1.0f;
        float currentHealth = target.getHealth();
        if (!Float.isFinite(currentHealth)) currentHealth = 0.0f;
        float healthRatio = MathHelper.clamp(currentHealth / maximumHealth, 0.0f, 1.0f);
        context.fill(x + 5, y + 21, x + width - 5, y + 27, BORDER);
        context.fill(x + 5, y + 21,
                x + 5 + (int) ((width - 10) * healthRatio), y + 27, ACCENT);
        String healthText = String.format(Locale.ROOT, "%.1f / %.1f",
                currentHealth, maximumHealth);
        context.drawTextWithShadow(client.textRenderer, healthText, x + 5, y + 29, WHITE);
    }
}
