package org.slf4j;
public class LoggerFactory { public static Logger getLogger(String n){ return (f,a)->System.err.println("[WARN] "+f+" "+java.util.Arrays.toString(a)); } }
