package net.fabricmc.fabric.api.client.rendering.v1;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.client.gui.DrawContext;
public interface HudRenderCallback { Event<HudRenderCallback> EVENT=new Event<>(); void onHudRender(DrawContext c, Object tickCounter); }
