package net.fabricmc.fabric.api.event;
public class Event<T> { public T last; public void register(T t){ last=t; } }
