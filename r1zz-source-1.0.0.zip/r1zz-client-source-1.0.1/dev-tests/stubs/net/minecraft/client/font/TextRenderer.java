package net.minecraft.client.font;
public class TextRenderer { public int getWidth(String s){return s.length()*6;} }
