package net.minecraft.client;
import net.minecraft.client.font.TextRenderer; import net.minecraft.client.gui.screen.Screen; import net.minecraft.client.option.GameOptions; import net.minecraft.client.util.Window; import net.minecraft.entity.*;
public class MinecraftClient { static final MinecraftClient I=new MinecraftClient(); public static MinecraftClient getInstance(){return I;}
 public Entity player=new Entity(); public Object world=new Object(); public TextRenderer textRenderer=new TextRenderer(); public GameOptions options=new GameOptions(); public Screen currentScreen; public Entity targetedEntity;
 public void setScreen(Screen s){ if(currentScreen!=null) currentScreen.removed(); currentScreen=s; } public int getCurrentFps(){return 60;} public Window getWindow(){return new Window();} }
