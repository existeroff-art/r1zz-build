package net.minecraft.client.gui.screen;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.font.TextRenderer; import net.minecraft.client.gui.DrawContext; import net.minecraft.text.Text;
public class Screen { protected MinecraftClient client; protected TextRenderer textRenderer=new TextRenderer(); public int width=480,height=270;
 protected Screen(Text t){} protected void init(){} public void removed(){} public void close(){ if(client!=null) client.setScreen(null);} 
 public void renderBackground(DrawContext c,int x,int y,float d){} public void render(DrawContext c,int x,int y,float d){}
 public boolean mouseClicked(double x,double y,int b){return false;} public boolean mouseScrolled(double x,double y,double h,double v){return false;}
 public boolean keyPressed(int k,int s,int m){ if(k==256){close();return true;} return false;} public boolean mouseDragged(double x,double y,int b,double dx,double dy){return false;}
 public boolean mouseReleased(double x,double y,int b){return false;} public boolean shouldPause(){return true;} }
