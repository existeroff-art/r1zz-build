package net.minecraft.client.gui;
import net.minecraft.client.font.TextRenderer; import net.minecraft.util.Identifier;
public class DrawContext { public void fill(int a,int b,int c,int d,int col){}
 public int drawText(TextRenderer r,String s,int x,int y,int c,boolean sh){return 0;}
 public int drawTextWithShadow(TextRenderer r,String s,int x,int y,int c){return 0;}
 public void drawTexture(Identifier i,int x,int y,int w,int h,float u,float v,int rw,int rh,int tw,int th){}
 public void drawTexture(Identifier i,int x,int y,float u,float v,int w,int h,int tw,int th){}
 public void enableScissor(int a,int b,int c,int d){} public void disableScissor(){} }
