package net.minecraft.client.option;
import net.minecraft.client.util.InputUtil; import net.minecraft.text.Text;
public class KeyBinding { public InputUtil.Key bound; public int presses;
 public KeyBinding(String n, InputUtil.Type t, int c, String cat){ bound=new InputUtil.Key(c);} 
 public boolean wasPressed(){ if(presses>0){presses--;return true;} return false;} public boolean isPressed(){return false;}
 public void setBoundKey(InputUtil.Key k){bound=k;} public static void updateKeysByCode(){}
 public Text getBoundKeyLocalizedText(){ return Text.literal("KEY"+bound.code);} public boolean matchesKey(int k,int s){return bound.code==k;} }
