package net.minecraft.client.option;
import net.minecraft.client.util.InputUtil;
public class GameOptions { public boolean hudHidden;
 static KeyBinding k(){ return new KeyBinding("k", InputUtil.Type.KEYSYM, 0, "c"); }
 public KeyBinding forwardKey=k(),leftKey=k(),backKey=k(),rightKey=k(),jumpKey=k(); }
