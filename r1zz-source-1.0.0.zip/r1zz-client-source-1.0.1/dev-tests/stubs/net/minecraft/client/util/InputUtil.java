package net.minecraft.client.util;
public class InputUtil { public static class Key { public final int code; public Key(int c){code=c;} }
 public static final Key UNKNOWN_KEY=new Key(-1);
 public enum Type { KEYSYM; public Key createFromCode(int c){ return new Key(c);} } }
