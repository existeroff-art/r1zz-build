package net.minecraft.client.util;
public class Window { public int getScaledWidth(){return 480;} public int getScaledHeight(){return 270;} }
