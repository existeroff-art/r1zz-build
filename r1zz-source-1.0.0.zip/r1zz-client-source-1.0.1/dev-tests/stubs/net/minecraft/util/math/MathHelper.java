package net.minecraft.util.math;
public class MathHelper { public static float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));} }
