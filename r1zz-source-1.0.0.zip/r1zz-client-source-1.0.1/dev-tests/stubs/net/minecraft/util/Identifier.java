package net.minecraft.util;
public class Identifier { public static Identifier of(String a,String b){return new Identifier();} }
