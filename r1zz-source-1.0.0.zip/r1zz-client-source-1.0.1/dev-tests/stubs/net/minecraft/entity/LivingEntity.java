package net.minecraft.entity;
public class LivingEntity extends Entity { public boolean isAlive(){return true;} public float getHealth(){return 1;} public float getMaxHealth(){return 20;} }
