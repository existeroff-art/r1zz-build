package net.minecraft.entity;
import net.minecraft.text.Text;
public class Entity { public double getX(){return 0;} public double getY(){return 0;} public double getZ(){return 0;} public Text getName(){return Text.literal("e");} }
