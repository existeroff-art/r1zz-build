package net.minecraft.text;
public class Text { final String s; Text(String s){this.s=s;} public static Text literal(String s){return new Text(s);} public String getString(){return s;} }
