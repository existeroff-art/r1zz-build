package gg.r1zz.client;

import gg.r1zz.client.config.R1zzConfig;
import gg.r1zz.client.module.*;
import gg.r1zz.client.module.impl.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import java.nio.file.*;
import java.util.*;

public class HarnessTest {
    static int pass, fail;
    static void check(String name, boolean ok) { System.out.println((ok ? "PASS  " : "FAIL  ") + name); if (ok) pass++; else fail++; }
    static Path cfg() { return Paths.get(System.getProperty("r1zz.cfg")).resolve("r1zz-client.properties"); }

    static ModuleManager fresh() {
        ModuleManager m = new ModuleManager();
        m.register(new R1zzFPS()); m.register(new R1zzCoordinates()); m.register(new R1zzKeystrokes());
        m.register(new R1zzCrosshair()); m.register(new R1zzTargetHUD());
        return m;
    }
    static void write(String s) throws Exception { Files.createDirectories(cfg().getParent()); Files.writeString(cfg(), s); }

    static class Rec extends DrawContext {
        int oob; int w, h; int texCalls; int scissorOn, scissorOff;
        @Override public int drawText(TextRenderer r, String s, int x, int y, int c, boolean sh) { if (x < 0 || y < 0 || x > w || y > h) oob++; return 0; }
        @Override public void drawTexture(Identifier i, int x, int y, int ww, int hh, float u, float v, int rw, int rh, int tw, int th) {
            texCalls++; if (ww != 34 || hh != 34 || rw != 128 || tw != 128) oob++; }
        @Override public void enableScissor(int a, int b, int c, int d) { scissorOn++; }
        @Override public void disableScissor() { scissorOff++; }
    }

    public static void main(String[] a) throws Exception {
        Path dir = Paths.get(System.getProperty("r1zz.cfg"));
        // ---- manager
        ModuleManager m = fresh();
        check("5 modules registered", m.all().size() == 5);
        try { m.register(new R1zzFPS()); check("duplicate ID rejected", false); } catch (IllegalArgumentException e) { check("duplicate ID rejected", true); }
        check("modules default disabled", m.all().stream().noneMatch(R1zzModule::enabled));
        check("all modules have descriptions", m.all().stream().allMatch(x -> !x.description().isEmpty()));
        check("categories HUD=3 RENDER=2", m.in(ModuleCategory.HUD).size() == 3 && m.in(ModuleCategory.RENDER).size() == 2);

        // ---- config: missing file
        Files.deleteIfExists(cfg());
        R1zzConfig.load(m);
        check("missing config -> defaults, no crash", m.all().stream().noneMatch(R1zzModule::enabled));

        // ---- config: roundtrip
        m.find("R1zzFPS").get().setEnabled(true);
        m.find("R1zzCrosshair").get().setKeyCode(71);
        R1zzConfig.save(m);
        check("config file written", Files.exists(cfg()));
        ModuleManager m2 = fresh(); R1zzConfig.load(m2);
        check("roundtrip enabled state", m2.find("R1zzFPS").get().enabled() && !m2.find("R1zzCoordinates").get().enabled());
        check("roundtrip key code", m2.find("R1zzCrosshair").get().keyCode() == 71);

        // ---- config: unchanged save does not rewrite
        long t0 = Files.getLastModifiedTime(cfg()).toMillis(); Thread.sleep(1100);
        R1zzConfig.save(m2);
        check("unchanged settings are not rewritten", Files.getLastModifiedTime(cfg()).toMillis() == t0);
        m2.find("R1zzFPS").get().setEnabled(false); R1zzConfig.save(m2);
        check("changed settings are rewritten", Files.getLastModifiedTime(cfg()).toMillis() > t0);

        // ---- config: bad values
        write("R1zzFPS.enabled=maybe\nR1zzFPS.key=abc\nR1zzCoordinates.enabled=TRUE\nR1zzCoordinates.key=9999\n"
            + "R1zzKeystrokes.key=71\nR1zzCrosshair.key=71\nR1zzTargetHUD.key=344\n");
        ModuleManager m3 = fresh(); R1zzConfig.load(m3);
        check("invalid boolean keeps default (off)", !m3.find("R1zzFPS").get().enabled());
        check("non-numeric key -> unbound", m3.find("R1zzFPS").get().keyCode() == -1);
        check("case-insensitive TRUE accepted", m3.find("R1zzCoordinates").get().enabled());
        check("out-of-range key -> unbound", m3.find("R1zzCoordinates").get().keyCode() == -1);
        check("duplicate key: first keeps, second unbound", m3.find("R1zzKeystrokes").get().keyCode() == 71 && m3.find("R1zzCrosshair").get().keyCode() == -1);
        check("reserved Right Shift rejected from config", m3.find("R1zzTargetHUD").get().keyCode() == -1);

        // ---- config: malformed file (illegal unicode escape) must not crash and is quarantined
        write("R1zzFPS.enabled=true\nbad=\\uZZZZ\n");
        ModuleManager m4 = fresh();
        boolean threwIo = false;
        try { R1zzConfig.load(m4); } catch (java.io.IOException e) { threwIo = true; }
        check("malformed file -> IOException (handled by caller), not unchecked", threwIo);
        check("malformed file quarantined as .bad", Files.exists(cfg().resolveSibling("r1zz-client.properties.bad")) && !Files.exists(cfg()));
        check("malformed file leaves defaults", m4.all().stream().noneMatch(R1zzModule::enabled));

        // ---- tick behaviour
        ModuleManager m5 = fresh();
        R1zzModule fps = m5.find("R1zzFPS").get();
        class Probe extends R1zzModule { int ticks; Probe() { super("Probe", ModuleCategory.CLIENT); } @Override public void onTick() { ticks++; } }
        Probe probe = new Probe(); m5.register(probe);
        m5.tick(true);
        check("disabled module does no tick work", probe.ticks == 0);
        probe.setEnabled(true); m5.tick(true);
        check("enabled module ticks", probe.ticks == 1);
        // key press consumption (screen open -> no toggle)
        probe.setKeyCode(80);
        java.lang.reflect.Field kb = R1zzModule.class.getDeclaredField("keyBinding"); kb.setAccessible(true);
        net.minecraft.client.option.KeyBinding k = (net.minecraft.client.option.KeyBinding) kb.get(probe);
        k.presses = 1; boolean t = m5.tick(false);
        check("key press with screen open is consumed, no toggle", !t && probe.enabled());
        k.presses = 1; t = m5.tick(true);
        check("key press in game toggles module", t && !probe.enabled());

        // ---- client init, HUD, menu key lifecycle
        Files.deleteIfExists(cfg()); Files.deleteIfExists(cfg().resolveSibling("r1zz-client.properties.bad"));
        write("R1zzFPS.enabled=true\nR1zzCoordinates.enabled=true\nR1zzKeystrokes.enabled=true\nR1zzCrosshair.enabled=true\nR1zzTargetHUD.enabled=true\n");
        new R1zzClient().onInitializeClient();
        check("init: 5 modules enabled from saved config", R1zzClient.MODULES.all().stream().allMatch(R1zzModule::enabled));
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.targetedEntity = new net.minecraft.entity.LivingEntity();
        HudRenderCallback hud = null;
        var hudEvt = HudRenderCallback.EVENT;
        // call registered lambda via reflection of the Event stub
        Object cb = hudEvt.last;
        java.lang.reflect.Method om = HudRenderCallback.class.getMethods()[0];
        for (var mm : HudRenderCallback.class.getMethods()) if (mm.getName().equals("onHudRender")) om = mm;
        Rec rec = new Rec();
        try {
            om.invoke(cb, rec, null);
            mc.player = null; om.invoke(cb, rec, null);           // leaving world
            mc.player = new net.minecraft.entity.Entity(); mc.world = null; om.invoke(cb, rec, null);
            mc.world = new Object(); mc.options.hudHidden = true; om.invoke(cb, rec, null);
            mc.options.hudHidden = false; mc.targetedEntity = null; om.invoke(cb, rec, null);
            check("HUD renders; safe with null player/world, hudHidden, no target", true);
        } catch (Throwable e) { e.printStackTrace(); check("HUD renders; safe with null player/world, hudHidden, no target", false); }
        mc.player = new net.minecraft.entity.Entity(); mc.world = new Object();

        ClientTickEvents.EndTick tick = ClientTickEvents.END_CLIENT_TICK.last;
        var menuKey = (net.minecraft.client.option.KeyBinding) getStatic(R1zzClient.class, "openMenuKey");
        mc.currentScreen = null; menuKey.presses = 1; tick.onEndTick(mc);
        check("menu key opens GUI in game", mc.currentScreen instanceof R1zzClickGuiScreen);
        R1zzClickGuiScreen scr = (R1zzClickGuiScreen) mc.currentScreen;
        setClient(scr, mc);
        scr.keyPressed(GLFW.GLFW_KEY_RIGHT_SHIFT, 0, 0);
        check("menu key closes GUI", mc.currentScreen == null);
        menuKey.presses = 1; tick.onEndTick(mc);
        check("close keypress does not immediately re-open GUI", mc.currentScreen == null);
        for (int i = 0; i < 4; i++) tick.onEndTick(mc);
        menuKey.presses = 1; tick.onEndTick(mc);
        check("menu key opens GUI again after cooldown", mc.currentScreen instanceof R1zzClickGuiScreen);
        // Esc closes
        scr = (R1zzClickGuiScreen) mc.currentScreen; setClient(scr, mc);
        scr.keyPressed(GLFW.GLFW_KEY_ESCAPE, 0, 0);
        check("Esc closes GUI", mc.currentScreen == null);

        // ---- GUI render at multiple sizes + input
        int[][] sizes = {{480,270},{320,180},{854,480},{240,160},{1000,700},{427,240}};
        boolean allOk = true;
        for (int[] sz : sizes) {
            R1zzClickGuiScreen s = new R1zzClickGuiScreen(); setClient(s, mc); s.width = sz[0]; s.height = sz[1]; s.init();
            Rec r = new Rec(); r.w = sz[0]; r.h = sz[1];
            try { s.render(r, sz[0]/2, sz[1]/2, 0.1f); s.render(r, 0, 0, 0.1f); }
            catch (Throwable e) { e.printStackTrace(); allOk = false; }
            if (r.oob != 0 || r.texCalls != 2 || r.scissorOn != r.scissorOff) { System.out.println("   size " + Arrays.toString(sz) + " oob=" + r.oob + " tex=" + r.texCalls + " scissor " + r.scissorOn + "/" + r.scissorOff); allOk = false; }
        }
        check("GUI renders at 6 window sizes; logo drawn scaled (34px from 128px tex); text in bounds; scissor balanced", allOk);

        // keyboard: DOWN -> focus first row, ENTER toggles
        R1zzClickGuiScreen s = new R1zzClickGuiScreen(); setClient(s, mc); s.width = 480; s.height = 270; s.init();
        R1zzModule first = R1zzClient.MODULES.in(ModuleCategory.HUD).get(0);
        boolean before = first.enabled();
        s.keyPressed(GLFW.GLFW_KEY_DOWN, 0, 0); s.keyPressed(GLFW.GLFW_KEY_ENTER, 0, 0);
        check("keyboard: Down+Enter toggles focused module", first.enabled() != before);
        R1zzClient.MODULES.all().forEach(x -> x.setEnabled(false)); first.setEnabled(false);
        s.keyPressed(GLFW.GLFW_KEY_B, 0, 0);
        check("keyboard: B starts key capture", s.isCapturingKeyBinding());
        s.keyPressed(GLFW.GLFW_KEY_RIGHT_SHIFT, 0, 0);
        check("capture rejects reserved menu key", s.isCapturingKeyBinding() && first.keyCode() == -1);
        s.keyPressed(71, 0, 0);
        check("capture binds key, ends capture", !s.isCapturingKeyBinding() && first.keyCode() == 71);
        Properties saved = new Properties(); try (var in = Files.newInputStream(cfg())) { saved.load(in); }
        check("GUI change persisted to config file", "71".equals(saved.getProperty(first.id() + ".key")));
        // conflict
        s.keyPressed(GLFW.GLFW_KEY_DOWN, 0, 0); s.keyPressed(GLFW.GLFW_KEY_B, 0, 0); s.keyPressed(71, 0, 0);
        check("capture rejects key already used by another module", s.isCapturingKeyBinding());
        s.keyPressed(GLFW.GLFW_KEY_BACKSPACE, 0, 0);
        check("Backspace clears binding", !s.isCapturingKeyBinding());
        // right arrow switches category
        s.keyPressed(GLFW.GLFW_KEY_RIGHT, 0, 0);
        check("keyboard: Right switches category", true);
        // mouse: click toggle area of first row in HUD (go back to HUD)
        s.keyPressed(GLFW.GLFW_KEY_LEFT, 0, 0);
        // header click on close "x" closes
        mc.currentScreen = s;
        s.mouseClicked(s.width / 2.0 + 330, s.height / 2.0 - 100, 0); // may or may not hit; ensure no exception
        check("mouse clicks do not throw", true);
        // scrolling on a tiny window doesn't throw and clamps
        R1zzClickGuiScreen tiny = new R1zzClickGuiScreen(); setClient(tiny, mc); tiny.width = 240; tiny.height = 160; tiny.init();
        tiny.mouseScrolled(100, 80, 0, -5); tiny.mouseScrolled(100, 80, 0, 50);
        Rec rt = new Rec(); rt.w = 240; rt.h = 160; tiny.render(rt, 10, 10, 0.1f);
        check("scrolling clamps and renders on small window", rt.oob == 0);

        // ---- theme + keybind (requested values) ----
        check("DEFAULT_MENU_KEY is Right Shift (344)", R1zzClient.DEFAULT_MENU_KEY == 344 && GLFW.GLFW_KEY_RIGHT_SHIFT == 344);
        String[][] themeChecks = {
            {"gg.r1zz.client.R1zzClickGuiScreen", "PANEL", "FF0A0A0F"},
            {"gg.r1zz.client.R1zzClickGuiScreen", "SIDEBAR", "FF050508"},
            {"gg.r1zz.client.R1zzClickGuiScreen", "BORDER", "FF1A1A24"},
            {"gg.r1zz.client.R1zzClickGuiScreen", "ACCENT", "FFFF6B9D"},
            {"gg.r1zz.client.R1zzClickGuiScreen", "ACCENT_END", "FFC41E5A"},
            {"gg.r1zz.client.R1zzHud", "ACCENT", "FFFF6B9D"},
            {"gg.r1zz.client.R1zzHud", "ACCENT_END", "FFC41E5A"},
            {"gg.r1zz.client.R1zzHud", "BORDER", "FF1A1A24"},
        };
        for (String[] tc : themeChecks) {
            boolean ok;
            try {
                java.lang.reflect.Field f = Class.forName(tc[0]).getDeclaredField(tc[1]);
                f.setAccessible(true);
                ok = f.getInt(null) == (int) Long.parseLong(tc[2], 16);
            } catch (Exception e) { ok = false; }
            check("theme " + tc[0].substring(tc[0].lastIndexOf('.') + 1) + "." + tc[1] + " = 0x" + tc[2], ok);
        }

        System.out.println("\nTOTAL: " + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
    static Object getStatic(Class<?> c, String n) throws Exception { var f = c.getDeclaredField(n); f.setAccessible(true); return f.get(null); }
    static void setClient(Object screen, MinecraftClient mc) throws Exception {
        Class<?> c = net.minecraft.client.gui.screen.Screen.class; var f = c.getDeclaredField("client"); f.setAccessible(true); f.set(screen, mc); }
}
