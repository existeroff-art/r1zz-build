# dev-tests (not part of the Gradle build)

`HarnessTest.java` exercises config persistence, module manager, tick handling,
HUD safety and ClickGUI input/render logic **against hand-written stub versions of the
Minecraft/Fabric APIs** in `stubs/`. The stubs encode what the author *believes* the
Yarn 1.21+build.9 / Fabric API 0.102.0 signatures are. A pass here proves the R1zz logic is
self-consistent; it does NOT prove the code compiles against the real APIs or runs in game.
Run `./run.sh` (needs a JDK 21 or the `jdk.compiler` module).
