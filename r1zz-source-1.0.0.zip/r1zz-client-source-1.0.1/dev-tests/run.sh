#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OUT=$(mktemp -d); CFG=$(mktemp -d)
JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"
$JAVAC -encoding UTF-8 -source 21 -target 21 -d "$OUT" $(find stubs ../src/main/java -name '*.java')
mkdir -p "$OUT/test" && $JAVAC -encoding UTF-8 -source 21 -target 21 -cp "$OUT" -d "$OUT/test" HarnessTest.java
java -Dr1zz.cfg="$CFG" -cp "$OUT:$OUT/test" gg.r1zz.client.HarnessTest
