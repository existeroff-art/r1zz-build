# R1zz Client — Minecraft Java 1.21 / Fabric (v1.0.1)

Client-side HUD and practice toolkit. Modules (all purely visual, no networking, no mixins):
FPS, Coordinates, Keystrokes, Crosshair, Target HUD.

## Build

Requires JDK 21 and Gradle 8.8+ (Loom 1.7.4). No Gradle wrapper is included (it could not be
generated offline). Either use the GitHub workflow (**Actions → Build R1zz Client → Run workflow**,
artifact `r1zz-client-1.0.1`) or, locally:

```bash
gradle --no-daemon clean build      # output: build/libs/r1zz-client-1.0.1.jar
```

Pinned versions: Minecraft 1.21, Yarn 1.21+build.9, Fabric Loader 0.15.11, Fabric API 0.102.0+1.21.

## Controls

- **Right Shift** (rebindable in Controls) opens/closes the GUI. Esc and the × also close it.
- Mouse: click a row to toggle; click the key button to bind; mouse wheel scrolls; drag the header to move.
- Keyboard: ↑/↓ select a row, Enter/Space toggle, **B** bind, ←/→ switch category.
  While binding: Esc cancels, Backspace/Delete clears.
- F1 hides the R1zz HUD along with the vanilla HUD.

## Configuration

File: `<minecraft dir>/config/r1zz-client.properties` (Java properties). Two keys per module:
`<moduleId>.enabled=true|false` and `<moduleId>.key=<GLFW key code>` (`-1` = unbound), e.g.
`R1zzFPS.enabled=true`. Invalid values fall back to disabled/unbound; duplicate or reserved
(Right Shift) keys are dropped; an unparseable file is renamed `.bad` and defaults are used.

## Theme

Dark panel with a pink accent: panel `0xFF0A0A0F`, sidebar `0xFF050508`, border `0xFF1A1A24`, accent
`0xFFFF6B9D`, gradient end `0xFFC41E5A` (used by `R1zzClickGuiScreen` and `R1zzHud`).
Default menu key: Right Shift (GLFW 344, `R1zzClient.DEFAULT_MENU_KEY`).

## Server compatibility

Test targets (all untested) are listed in `docs/SERVER-COMPATIBILITY.md`.

## Branding

`branding/r1zz_logo_original_1536.png` is the original supplied image. The GUI uses a 128px
copy at `assets/r1zzclient/textures/gui/r1zz_logo.png`.

## Scope

No anti-cheat evasion, concealment, or packet manipulation is included. See
`R1ZZ-REMAINING-ISSUES.md` for known limitations and what is untested.
