# R1zz Client — Changelog

> **Status: source changes only. Not compiled with Gradle/Loom against real Minecraft/Yarn/Fabric jars,
> and never launched in Minecraft.** No `r1zz-client-1.0.1.jar` is delivered (see R1ZZ-TEST-REPORT.md).

## 1.0.1 — revision 2 (this delivery; version number unchanged at 1.0.1)

Starting point: the previously delivered `r1zz-source-1.0.1.zip` found inside `files.zip`.

### GUI theme (implemented)
- `R1zzClickGuiScreen`: replaced the purple palette with the requested values — panel `0xFF0A0A0F`,
  sidebar `0xFF050508`, border `0xFF1A1A24`, accent `0xFFFF6B9D`, gradient end `0xFFC41E5A`.
- New 1px panel border and sidebar separator in the border colour; header underline is now a horizontal
  accent→gradient-end gradient (new `fillHorizontalGradient`, since `fillGradient` is vertical-only);
  toggle "on" track uses the gradient end colour.
- Colours you did not specify (row, hover, text, muted, toggle-off, key buttons, active-nav tint) were
  chosen by me as neutrals between panel and border; they are named constants at the top of the class.
- `R1zzHud`: HUD accent/crosshair/target bar/keystroke "down" state now use the same pink palette;
  panel is `0xFF0A0A0F` at ~85% alpha. Layout and behaviour unchanged.
- Panel is now opaque `0xFF0A0A0F` (was ~95% alpha), as specified.

### Keybind
- Default menu key was already Right Shift (344). Made it explicit as `R1zzClient.DEFAULT_MENU_KEY`
  (used for the registration); no behaviour change. Reserved-key handling in config/GUI unchanged.

### Build / packaging
- `.github/workflows/build.yml` rewritten: removed the "search the repo for a ZIP and extract it" logic;
  now checks out, sets up Java 21 + Gradle 8.8, builds (uses `./gradlew` if one is ever added), verifies the
  JAR (zip integrity, `fabric.mod.json` version, main class present), uploads the JAR + sources JAR
  as `r1zz-client-1.0.1`, and always uploads logs/reports. **It has not been run.**
- README: artifact name, theme and server-doc sections.

### Documentation
- Added `docs/SERVER-COMPATIBILITY.md` (Minemen Club ×4 addresses; MCPvP Java and Bedrock `19132`;
  Java/Bedrock distinction; all marked NOT RUN).

### Tests
- `dev-tests/HarnessTest.java`: +9 checks (menu key = 344; the 8 theme constants). Harness now 51 checks.

### Carried over unchanged from earlier 1.0.1 work
Corrupt-config crash fix; per-key config validation; HUD null/F1 handling; scrollable, keyboard-navigable
GUI; logo draw fix and 128px logo; Target HUD height fix. See git/zip history of the earlier delivery.

## Not changed (by design)
- Minecraft 1.21, Yarn 1.21+build.9, Loader 0.15.11, Fabric API 0.102.0+1.21, Loom 1.7.4.
- Modules: still the same 5 (IDs, categories, defaults). No modules added or removed.
- No networking, mixins or packet code exists, so there was nothing to change for protocol compatibility.

## Known limitations
See R1ZZ-REMAINING-ISSUES.md.
