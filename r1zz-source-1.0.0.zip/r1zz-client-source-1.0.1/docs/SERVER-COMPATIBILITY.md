# R1zz Client — Server compatibility test targets

**Status of every entry below: NOT RUN.** These are *intended* test targets. Nothing here has been
connected to, and no server is claimed to be online, to accept this mod, or to accept 1.21.0 clients.

R1zz Client 1.0.1 is a **Minecraft Java Edition 1.21 Fabric** client mod. It contains no networking
code and no mixins (verified by grep of `src/main`), so it sends no packets of its own.

## Minemen Club — Java Edition

| Region | Address |
|---|---|
| Main | `minemen.club` |
| North America | `na.minemen.club` |
| Europe | `eu.minemen.club` |
| Asia | `as.minemen.club` |

## MCPvP

| Edition | Address | Port |
|---|---|---|
| Java Edition | `mcpvp.com` | default (25565) |
| Bedrock Edition (reference only) | `mcpvp.com` | `19132` |

## Java vs Bedrock

R1zz is a Java Edition mod. It cannot join a Bedrock server and gives no Bedrock support. The Bedrock
address/port above is listed only so the documentation is complete; a Bedrock connection is **not** a
test of this mod, and must never be recorded as one.

## Things to check before any test

1. **Version.** R1zz targets Minecraft **1.21.0**. Third-party server-list sites (not verified, possibly
   stale) suggest Minemen Club may only accept 1.7.10–1.8.9 and 1.21.4+, which would reject 1.21.0.
   MCPvP is listed as accepting roughly 1.20.5 and newer. Confirm with each server's own site/Discord.
2. **Mod policy.** Both are competitive PvP servers. Read their rules (or ask staff) before joining with
   any client mod. R1zz's modules are visual only, but that is not a statement that any server allows them.
3. **Authorization.** Only test where the server rules permit it.

## Test checklist (all NOT RUN)

For each address: join; stay 5+ minutes with each module on; toggle modules and open/close the GUI
(Right Shift); disconnect and reconnect; switch worlds/lobbies; die and respawn; confirm no client
exception in `latest.log` and that the HUD hides with F1. Record result, MC version, Loader/Fabric API
versions and the server's reply to a version mismatch.
