# R1zz Client 1.0.1 — Remaining issues and manual steps

## Not delivered
- **`r1zz-client-1.0.1.jar` was not produced.** No Gradle, no network, no Minecraft/Fabric dependencies in the
  environment. No old JAR was renamed. Build with `gradle --no-daemon clean build` (JDK 21) or the workflow.
- **No Gradle wrapper.** `gradle-wrapper.jar` is a binary that cannot be generated offline. Run
  `gradle wrapper --gradle-version 8.8` once with network, then commit `gradlew`, `gradlew.bat`, `gradle/wrapper/`.
- GitHub workflow has never run. Verify remotely after pushing.

## Unverified
- Source has never been compiled against real mappings or run in game; stub results are logic checks only.
- The pink theme and gradient have not been seen on screen. Panel text/contrast on real GPUs is unchecked.

## Requested items that don't apply to this codebase
- The spec mentions sliders, dropdowns, colour controls, movement/packet code and anti-cheat diagnostics.
  R1zz has **none** of these: five visual HUD modules, a toggle/key-bind GUI, no mixins, no networking.
  Nothing was invented to match. No evasion/concealment features exist or were added.

## Known defects not fixed
1. **Duplicate crosshair:** the Crosshair module draws over the vanilla one; hiding it needs a mixin on
   `InGameHud#renderCrosshair`, not added blind (a wrong descriptor crashes at launch).
2. **Two sources of truth for key bindings:** module keys live in `r1zz-client.properties` and as Minecraft
   keybinds (`options.txt`); rebinding in vanilla Controls isn't reflected in the R1zz GUI. Use the R1zz GUI.
3. HUD positions are fixed (not draggable/scaled) and can overlap the F3 overlay.
4. Practical minimum GUI size is about 240×160 scaled pixels.
5. No `license` field in `fabric.mod.json` (none supplied).
6. Theme neutrals beyond your five colours were my choice; adjust the constants if you want a different feel.

## Logo
`r1zz_logo.png` is a composite containing a real person and another company's game artwork. Preserved as
instructed; confirm you have the rights to distribute it, or use an original mark.

## Server compatibility — all NOT RUN (see docs/SERVER-COMPATIBILITY.md)
- Third-party listings (unverified, possibly stale) suggest **minemen.club** accepts 1.7.10–1.8.9 and 1.21.4+,
  so a 1.21.0 client may be refused. Moving to 1.21.4+ is a separate port I did not do.
- **mcpvp.com** is listed as roughly 1.20.5+, so 1.21.0 is probably in range.
- Both are competitive PvP servers with their own client-mod rules; check them before joining. Bedrock
  `mcpvp.com:19132` is unrelated to this Java mod.

## Earlier-report item not re-verified
A previous delivery discussed a `system-b1.jar` (not merged, flagged for unclear license/provenance and
combat-automation features). It is not in this archive, so it was not re-examined.
