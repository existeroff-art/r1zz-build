# R1zz Client 1.0.1 (revision 2) — Test Report

Legend: **PASS** executed and passed · **FAIL** executed and failed · **PARTIAL** · **NOT RUN** not executed/blocked.
"Stub" = executed against hand-written stand-ins for Minecraft/Fabric classes (`dev-tests/stubs`), which encode
the author's belief about the API, not the real jars. Static inspection ≠ compilation ≠ runtime ≠ server test.

## Environment
- Ubuntu 24.04.4 LTS sandbox, kernel 6.18; OpenJDK **21.0.10 runtime** (no `javac` binary; the `jdk.compiler`
  module was invoked directly). **No Gradle installed. No network** (DNS resolution fails, `curl` rc=6, verified).
  No Minecraft/Fabric/Yarn jars, no GPU/display.
- Build command intended: `gradle --no-daemon clean build` (no wrapper in project).

## Results

| # | Check | Result | Notes |
|---|-------|--------|-------|
| 1 | Input `files.zip` opens; structure identified | PASS | contains `r1zz-source-1.0.1.zip` + 3 docs; project root `r1zz-client-source-1.0.1/` |
| 2 | **Gradle build (`clean build`)** | **NOT RUN** | no Gradle, no network to resolve Loom/Minecraft/Yarn |
| 3 | Real compile vs Yarn 1.21+build.9 / Fabric API | **NOT RUN** | same blocker |
| 4 | Java compile vs **stubs**, `-Xlint:all`, release 21 | PASS | 0 errors, 0 warnings. Not a real-API compile |
| 5 | Stub harness | PASS | **51/51** (42 existing + 9 new: menu key 344, 8 theme constants) |
| 6 | Existing project tests (`src/test`) | NOT RUN | project has none |
| 7 | Brace balance, all 12 main sources | PASS | |
| 8 | Duplicate module IDs / registrations | PASS | 5 unique IDs, 5 `register` calls, 0 duplicates; harness also rejects duplicate ID |
| 9 | Placeholders / TODO in `src/main` | PASS | 0 |
| 10 | Mixin config validation | NOT RUN (N/A) | no mixins, no mixin JSON; grep for Mixin/packet/network APIs: 0 hits |
| 11 | `fabric.mod.json`, `en_us.json` parse; entrypoint class exists | PASS | |
| 12 | Version consistency | PASS (source) | `gradle.properties` 1.0.1; `fabric.mod.json` uses `${version}` expanded by Gradle; README 1.0.1. Generated JAR metadata **not** checked (no JAR) |
| 13 | Menu key = Right Shift (344) | PASS (stub) | constant + harness check; real key registration not run |
| 14 | Theme constants match requested values | PASS (stub) | read by reflection in harness |
| 15 | Theme actually looks right in game | NOT RUN | pink/dark contrast, text legibility, gradient bar never viewed |
| 16 | GUI open/close, toggles, scroll, keyboard, binding | PARTIAL | logic exercised in harness only; no real input/rendering. Sliders, dropdowns, colour pickers **do not exist** in this GUI |
| 17 | Secrets scan of sources/config | PASS | 0 hits |
| 18 | `.github/workflows/build.yml` YAML syntax | PASS | parsed with PyYAML |
| 19 | GitHub Actions run | NOT RUN | no repository connected |
| 20 | JAR build, contents, metadata, size | NOT RUN | **no JAR exists** |
| 21 | Source ZIP integrity | PASS | `unzip -t` clean; extracted to a fresh dir and the 51-check harness re-run from the extracted copy: 51/51 |
| 22 | Minecraft launch / world join / HUD in game | NOT RUN | |
| 23 | Minemen Club `minemen.club` | NOT RUN | |
| 24 | Minemen Club NA `na.minemen.club` | NOT RUN | |
| 25 | Minemen Club EU `eu.minemen.club` | NOT RUN | |
| 26 | Minemen Club Asia `as.minemen.club` | NOT RUN | |
| 27 | MCPvP Java `mcpvp.com` | NOT RUN | |
| 28 | MCPvP Bedrock `mcpvp.com:19132` | NOT RUN (N/A) | reference only — this is a Java Fabric mod with **no Bedrock support**; must not be counted as a mod test |

## Unconfirmed API usage (check first if the real build fails)
`DrawContext.drawTexture(Identifier,int,int,int,int,float,float,int,int,int,int)`, `enableScissor/disableScissor`,
`Screen.mouseScrolled(double,double,double,double)`, `Screen.removed()/close()`, `KeyBinding.matchesKey(int,int)`,
`GameOptions.hudHidden`, `Identifier.of`, SLF4J logger. New in this revision: only `DrawContext.fill` with
computed colours (already used), no new Minecraft API.

## Environmental blockers
No Gradle, no `javac` binary, no network, no Minecraft jars, no display. To finish: run
`gradle --no-daemon clean build` on JDK 21 with internet, or run the included workflow.
